package tj.builder.app;

import android.util.Base64;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

/** Работа с GitHub: загрузка архива, ожидание сборки, скачивание APK. */
class Gh {
    static final String API = "https://api.github.com";

    final String token, owner, repo;

    Gh(String token, String owner, String repo) {
        this.token = token;
        this.owner = owner;
        this.repo = repo;
    }

    static class Resp {
        int code;
        String body;
    }

    private String base() {
        return API + "/repos/" + owner + "/" + repo;
    }

    Resp http(String method, String url, String body) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
        c.setRequestMethod(method);
        c.setConnectTimeout(20000);
        c.setReadTimeout(180000);
        c.setRequestProperty("Accept", "application/vnd.github+json");
        c.setRequestProperty("X-GitHub-Api-Version", "2022-11-28");
        c.setRequestProperty("User-Agent", "Builder-App");
        if (token != null && !token.isEmpty()) c.setRequestProperty("Authorization", "Bearer " + token);
        if (body != null) {
            byte[] b = body.getBytes(StandardCharsets.UTF_8);
            c.setDoOutput(true);
            c.setRequestProperty("Content-Type", "application/json; charset=utf-8");
            c.setFixedLengthStreamingMode(b.length);
            OutputStream o = c.getOutputStream();
            o.write(b);
            o.close();
        }
        Resp r = new Resp();
        r.code = c.getResponseCode();
        InputStream in = r.code >= 400 ? c.getErrorStream() : c.getInputStream();
        r.body = in == null ? "" : readAll(in);
        c.disconnect();
        return r;
    }

    static String readAll(InputStream in) throws Exception {
        ByteArrayOutputStream bo = new ByteArrayOutputStream();
        byte[] buf = new byte[16384];
        int n;
        while ((n = in.read(buf)) > 0) bo.write(buf, 0, n);
        in.close();
        return new String(bo.toByteArray(), StandardCharsets.UTF_8);
    }

    static String errText(Resp r) {
        try {
            String m = new JSONObject(r.body).optString("message", "");
            if (!m.isEmpty()) return "код " + r.code + ": " + m;
        } catch (Exception ignored) {
        }
        return "код " + r.code;
    }

    String login() throws Exception {
        Resp r = http("GET", API + "/user", null);
        if (r.code == 401) throw new Exception("Токен не подходит (возможно, он истёк или скопирован не полностью).");
        if (r.code != 200) throw new Exception("GitHub не ответил: " + errText(r));
        return new JSONObject(r.body).getString("login");
    }

    void checkRepo() throws Exception {
        Resp r = http("GET", base(), null);
        if (r.code == 404)
            throw new Exception("Репозиторий " + owner + "/" + repo + " не найден, или у токена нет к нему доступа.");
        if (r.code != 200) throw new Exception("Не удалось открыть репозиторий: " + errText(r));
    }

    /** Кладёт файл в репозиторий и возвращает sha нового коммита. */
    String upload(String path, byte[] data, String message) throws Exception {
        String sha = null;
        Resp g = http("GET", base() + "/contents/" + path, null);
        if (g.code == 200) sha = new JSONObject(g.body).optString("sha", null);
        JSONObject j = new JSONObject();
        j.put("message", message);
        j.put("content", Base64.encodeToString(data, Base64.NO_WRAP));
        if (sha != null) j.put("sha", sha);
        Resp r = http("PUT", base() + "/contents/" + path, j.toString());
        if (r.code == 401 || r.code == 403 || r.code == 404)
            throw new Exception("GitHub не дал загрузить файл (" + errText(r) + "). Проверь, что у токена есть право Contents: Read and write.");
        if (r.code != 200 && r.code != 201) throw new Exception("Загрузка не удалась: " + errText(r));
        return new JSONObject(r.body).getJSONObject("commit").getString("sha");
    }

    /** Сборка, запущенная этим коммитом, или null, если она ещё не появилась. */
    JSONObject findRun(String sha) throws Exception {
        Resp r = http("GET", base() + "/actions/runs?per_page=5&head_sha=" + sha, null);
        if (r.code != 200) return null;
        JSONArray a = new JSONObject(r.body).optJSONArray("workflow_runs");
        if (a == null || a.length() == 0) return null;
        return a.getJSONObject(0);
    }

    JSONObject run(long id) throws Exception {
        Resp r = http("GET", base() + "/actions/runs/" + id, null);
        if (r.code != 200) return null;
        return new JSONObject(r.body);
    }

    /** Название шага, на котором сборка упала. */
    String failedStep(long runId) {
        try {
            Resp r = http("GET", base() + "/actions/runs/" + runId + "/jobs", null);
            JSONArray jobs = new JSONObject(r.body).getJSONArray("jobs");
            for (int i = 0; i < jobs.length(); i++) {
                JSONArray steps = jobs.getJSONObject(i).optJSONArray("steps");
                if (steps == null) continue;
                for (int k = 0; k < steps.length(); k++) {
                    JSONObject s = steps.getJSONObject(k);
                    if ("failure".equals(s.optString("conclusion"))) return s.optString("name");
                }
            }
        } catch (Exception ignored) {
        }
        return null;
    }

    /** Адрес страницы релиза с APK (для браузера). */
    String releasePage(String slug) {
        return "https://github.com/" + owner + "/" + repo + "/releases/tag/app-" + slug;
    }

    /** Скачивает APK из релиза app-<slug>. */
    File downloadApk(String slug, File dir) throws Exception {
        Resp r = http("GET", base() + "/releases/tags/app-" + slug, null);
        if (r.code == 404) throw new Exception("APK для «" + slug + "» не найден. Возможно, сборка ещё не закончилась.");
        if (r.code != 200) throw new Exception("Не удалось получить APK: " + errText(r));
        JSONArray assets = new JSONObject(r.body).getJSONArray("assets");
        String url = null;
        for (int i = 0; i < assets.length(); i++) {
            JSONObject a = assets.getJSONObject(i);
            if (a.optString("name").endsWith(".apk")) {
                url = a.getString("url");
                break;
            }
        }
        if (url == null) throw new Exception("В релизе нет APK-файла.");
        File out = new File(dir, slug + ".apk");
        download(url, out);
        return out;
    }

    /** Скачивание с ручными переадресациями: токен отправляется только на api.github.com. */
    void download(String url, File out) throws Exception {
        for (int hop = 0; hop < 6; hop++) {
            URL u = new URL(url);
            HttpURLConnection c = (HttpURLConnection) u.openConnection();
            c.setInstanceFollowRedirects(false);
            c.setConnectTimeout(20000);
            c.setReadTimeout(180000);
            c.setRequestProperty("User-Agent", "Builder-App");
            if ("api.github.com".equals(u.getHost())) {
                c.setRequestProperty("Accept", "application/octet-stream");
                if (token != null && !token.isEmpty()) c.setRequestProperty("Authorization", "Bearer " + token);
            }
            int code = c.getResponseCode();
            if (code >= 300 && code < 400) {
                String loc = c.getHeaderField("Location");
                c.disconnect();
                if (loc == null) throw new Exception("Ошибка скачивания: пустая переадресация.");
                url = new URL(u, loc).toString();
                continue;
            }
            if (code != 200) {
                c.disconnect();
                throw new Exception("Ошибка скачивания APK: код " + code);
            }
            InputStream in = c.getInputStream();
            FileOutputStream fo = new FileOutputStream(out);
            byte[] buf = new byte[65536];
            int n;
            while ((n = in.read(buf)) > 0) fo.write(buf, 0, n);
            fo.close();
            in.close();
            c.disconnect();
            return;
        }
        throw new Exception("Слишком много переадресаций при скачивании.");
    }
}
