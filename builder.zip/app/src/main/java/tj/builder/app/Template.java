package tj.builder.app;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.nio.charset.StandardCharsets;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import java.util.zip.ZipOutputStream;

/** Готовит архив для сборки: проект Android как есть, или сайт (HTML) внутри шаблона WebView. */
class Template {

    private static final String[][] TR = {
            {"а", "a"}, {"б", "b"}, {"в", "v"}, {"г", "g"}, {"д", "d"}, {"е", "e"}, {"ё", "e"},
            {"ж", "zh"}, {"з", "z"}, {"и", "i"}, {"й", "y"}, {"к", "k"}, {"л", "l"}, {"м", "m"},
            {"н", "n"}, {"о", "o"}, {"п", "p"}, {"р", "r"}, {"с", "s"}, {"т", "t"}, {"у", "u"},
            {"ф", "f"}, {"х", "h"}, {"ц", "ts"}, {"ч", "ch"}, {"ш", "sh"}, {"щ", "sch"}, {"ъ", ""},
            {"ы", "y"}, {"ь", ""}, {"э", "e"}, {"ю", "yu"}, {"я", "ya"},
            {"ғ", "gh"}, {"ӣ", "i"}, {"қ", "q"}, {"ӯ", "u"}, {"ҳ", "h"}, {"ҷ", "j"}
    };

    /** Латинское имя для файлов и пакета: только a-z, 0-9 и _. */
    static String slug(String s) {
        if (s == null) s = "";
        s = s.toLowerCase(Locale.ROOT);
        s = s.replaceAll("\\s*\\(\\d+\\)$", "");
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < s.length(); i++) {
            String ch = s.substring(i, i + 1);
            String rep = ch;
            for (String[] p : TR) {
                if (p[0].equals(ch)) {
                    rep = p[1];
                    break;
                }
            }
            b.append(rep);
        }
        String r = b.toString().replaceAll("[^a-z0-9]+", "_").replaceAll("^_+|_+$", "");
        if (r.length() > 40) r = r.substring(0, 40);
        if (r.isEmpty()) r = "app";
        return r;
    }

    /** Проверяет архив: проект Android отдаёт как есть, сайт с index.html оборачивает в приложение. */
    static byte[] prepare(String label, String slug, byte[] zip) throws Exception {
        Map<String, byte[]> files = new LinkedHashMap<>();
        boolean gradle = false;
        try {
            ZipInputStream zin = new ZipInputStream(new ByteArrayInputStream(zip));
            ZipEntry e;
            byte[] buf = new byte[16384];
            while ((e = zin.getNextEntry()) != null) {
                if (e.isDirectory()) continue;
                String n = e.getName().replace('\\', '/');
                String low = n.toLowerCase(Locale.ROOT);
                if (low.endsWith("settings.gradle") || low.endsWith("settings.gradle.kts")) gradle = true;
                if (low.startsWith("__macosx/")) continue;
                ByteArrayOutputStream bo = new ByteArrayOutputStream();
                int k;
                while ((k = zin.read(buf)) > 0) bo.write(buf, 0, k);
                files.put(n, bo.toByteArray());
            }
            zin.close();
        } catch (Exception ex) {
            throw new Exception("Не получается открыть архив. Это точно zip-файл?");
        }
        if (files.isEmpty()) throw new Exception("Архив пустой или повреждён.");
        if (gradle) return zip;

        String index = null;
        for (String n : files.keySet()) {
            String low = n.toLowerCase(Locale.ROOT);
            if (low.equals("index.html") || low.endsWith("/index.html")) {
                if (index == null || n.length() < index.length()) index = n;
            }
        }
        if (index == null)
            throw new Exception("В архиве нет ни проекта Android (settings.gradle), ни сайта (index.html).");
        String dir = index.substring(0, index.length() - "index.html".length());
        Map<String, byte[]> site = new LinkedHashMap<>();
        for (Map.Entry<String, byte[]> en : files.entrySet()) {
            String n = en.getKey();
            if (!n.startsWith(dir)) continue;
            String rel = n.substring(dir.length());
            if (rel.equalsIgnoreCase("index.html")) rel = "index.html";
            site.put(rel, en.getValue());
        }
        return webApp(label, slug, site);
    }

    static byte[] html(String label, String slug, String code) throws Exception {
        Map<String, byte[]> m = new LinkedHashMap<>();
        m.put("index.html", code.getBytes(StandardCharsets.UTF_8));
        return webApp(label, slug, m);
    }

    private static String xml(String s) {
        return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
                .replace("\"", "\\\"").replace("'", "\\'").replace("@", "\\@").replace("?", "\\?");
    }

    private static final String[] COLORS = {"#4C8DFF", "#FF5A4E", "#22B07D", "#F5A623", "#9B59F5", "#E84393", "#00A8C6"};

    static byte[] webApp(String label, String slug, Map<String, byte[]> site) throws Exception {
        String pkg = "tj.made.app_" + slug;
        String color = COLORS[Math.abs(slug.hashCode() % COLORS.length)];
        int version = (int) (System.currentTimeMillis() / 60000L - 29000000L);
        if (version < 1) version = 1;

        Map<String, String> t = new LinkedHashMap<>();
        t.put("settings.gradle", """
                pluginManagement {
                    repositories { google(); mavenCentral(); gradlePluginPortal() }
                }
                dependencyResolutionManagement {
                    repositories { google(); mavenCentral() }
                }
                rootProject.name = "SLUG"
                include ':app'
                """.replace("SLUG", slug));
        t.put("build.gradle", """
                plugins {
                    id 'com.android.application' version '8.5.2' apply false
                }
                """);
        t.put("gradle.properties", "org.gradle.jvmargs=-Xmx2g\nandroid.useAndroidX=false\n");
        t.put("app/build.gradle", """
                plugins {
                    id 'com.android.application'
                }
                android {
                    namespace 'PKG'
                    compileSdk 34
                    defaultConfig {
                        applicationId 'PKG'
                        minSdk 24
                        targetSdk 34
                        versionCode @@VER@@
                        versionName '1.@@VER@@'
                    }
                    compileOptions {
                        sourceCompatibility JavaVersion.VERSION_17
                        targetCompatibility JavaVersion.VERSION_17
                    }
                }
                """.replace("PKG", pkg).replace("@@VER@@", String.valueOf(version)));
        t.put("app/src/main/AndroidManifest.xml", """
                <?xml version="1.0" encoding="utf-8"?>
                <manifest xmlns:android="http://schemas.android.com/apk/res/android">
                    <uses-permission android:name="android.permission.INTERNET" />
                    <application
                        android:label="@string/app_name"
                        android:icon="@drawable/ic_launcher"
                        android:allowBackup="true"
                        android:hardwareAccelerated="true"
                        android:theme="@android:style/Theme.DeviceDefault.NoActionBar">
                        <activity
                            android:name=".MainActivity"
                            android:exported="true"
                            android:configChanges="orientation|screenSize|screenLayout|keyboardHidden|smallestScreenSize|keyboard|navigation|uiMode"
                            android:windowSoftInputMode="adjustResize">
                            <intent-filter>
                                <action android:name="android.intent.action.MAIN" />
                                <category android:name="android.intent.category.LAUNCHER" />
                            </intent-filter>
                        </activity>
                    </application>
                </manifest>
                """);
        t.put("app/src/main/res/values/strings.xml",
                "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<resources>\n    <string name=\"app_name\">"
                        + xml(label) + "</string>\n    <color name=\"icbg\">" + color + "</color>\n</resources>\n");
        t.put("app/src/main/res/drawable/ic_fg.xml", """
                <?xml version="1.0" encoding="utf-8"?>
                <vector xmlns:android="http://schemas.android.com/apk/res/android"
                    android:width="108dp" android:height="108dp"
                    android:viewportWidth="108" android:viewportHeight="108">
                    <path android:fillColor="#FFFFFF"
                        android:pathData="M40,36h28a5,5 0 0 1 5,5v26a5,5 0 0 1 -5,5h-28a5,5 0 0 1 -5,-5v-26a5,5 0 0 1 5,-5z" />
                    <path android:fillColor="@color/icbg"
                        android:pathData="M40,44h28v23h-28z" />
                    <path android:fillColor="#FFFFFF"
                        android:pathData="M44,50h20v3h-20zM44,56h14v3h-14z" />
                </vector>
                """);
        t.put("app/src/main/res/drawable/ic_launcher.xml", """
                <?xml version="1.0" encoding="utf-8"?>
                <vector xmlns:android="http://schemas.android.com/apk/res/android"
                    android:width="48dp" android:height="48dp"
                    android:viewportWidth="108" android:viewportHeight="108">
                    <path android:fillColor="@color/icbg"
                        android:pathData="M24,6h60a18,18 0 0 1 18,18v60a18,18 0 0 1 -18,18h-60a18,18 0 0 1 -18,-18v-60a18,18 0 0 1 18,-18z" />
                    <path android:fillColor="#FFFFFF"
                        android:pathData="M36,30h36a6,6 0 0 1 6,6v36a6,6 0 0 1 -6,6h-36a6,6 0 0 1 -6,-6v-36a6,6 0 0 1 6,-6z" />
                    <path android:fillColor="@color/icbg"
                        android:pathData="M36,42h36v30h-36z" />
                    <path android:fillColor="#FFFFFF"
                        android:pathData="M42,50h24v4h-24zM42,58h16v4h-16z" />
                </vector>
                """);
        t.put("app/src/main/res/drawable-v26/ic_launcher.xml", """
                <?xml version="1.0" encoding="utf-8"?>
                <adaptive-icon xmlns:android="http://schemas.android.com/apk/res/android">
                    <background android:drawable="@color/icbg" />
                    <foreground android:drawable="@drawable/ic_fg" />
                </adaptive-icon>
                """);
        t.put("app/src/main/java/" + pkg.replace('.', '/') + "/MainActivity.java",
                WEB_ACTIVITY.replace("PKG", pkg));

        ByteArrayOutputStream bo = new ByteArrayOutputStream();
        ZipOutputStream z = new ZipOutputStream(bo);
        for (Map.Entry<String, String> e : t.entrySet()) {
            z.putNextEntry(new ZipEntry(e.getKey()));
            z.write(e.getValue().getBytes(StandardCharsets.UTF_8));
            z.closeEntry();
        }
        for (Map.Entry<String, byte[]> e : site.entrySet()) {
            z.putNextEntry(new ZipEntry("app/src/main/assets/" + e.getKey()));
            z.write(e.getValue());
            z.closeEntry();
        }
        z.close();
        return bo.toByteArray();
    }

    static final String WEB_ACTIVITY = """
            package PKG;

            import android.app.Activity;
            import android.content.ClipData;
            import android.content.Intent;
            import android.net.Uri;
            import android.os.Bundle;
            import android.webkit.ValueCallback;
            import android.webkit.WebChromeClient;
            import android.webkit.WebResourceRequest;
            import android.webkit.WebSettings;
            import android.webkit.WebView;
            import android.webkit.WebViewClient;

            public class MainActivity extends Activity {
                private WebView web;
                private ValueCallback<Uri[]> pending;

                @Override
                protected void onCreate(Bundle state) {
                    super.onCreate(state);
                    web = new WebView(this);
                    WebSettings s = web.getSettings();
                    s.setJavaScriptEnabled(true);
                    s.setDomStorageEnabled(true);
                    s.setDatabaseEnabled(true);
                    s.setAllowFileAccess(true);
                    s.setAllowFileAccessFromFileURLs(true);
                    s.setAllowUniversalAccessFromFileURLs(true);
                    s.setMediaPlaybackRequiresUserGesture(false);
                    web.setWebViewClient(new WebViewClient() {
                        @Override
                        public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                            String u = r.getUrl().toString();
                            if (u.startsWith("file:") || u.startsWith("http:") || u.startsWith("https:")) return false;
                            try {
                                startActivity(new Intent(Intent.ACTION_VIEW, r.getUrl()));
                            } catch (Exception ignored) {
                            }
                            return true;
                        }
                    });
                    web.setWebChromeClient(new WebChromeClient() {
                        @Override
                        public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> cb, FileChooserParams p) {
                            if (pending != null) pending.onReceiveValue(null);
                            pending = cb;
                            try {
                                Intent i = p.createIntent();
                                if (p.getMode() == FileChooserParams.MODE_OPEN_MULTIPLE)
                                    i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
                                startActivityForResult(i, 1);
                            } catch (Exception e) {
                                pending = null;
                                return false;
                            }
                            return true;
                        }
                    });
                    setContentView(web);
                    if (state == null || web.restoreState(state) == null)
                        web.loadUrl("file:///android_asset/index.html");
                }

                @Override
                protected void onSaveInstanceState(Bundle out) {
                    super.onSaveInstanceState(out);
                    web.saveState(out);
                }

                @Override
                protected void onActivityResult(int req, int res, Intent data) {
                    super.onActivityResult(req, res, data);
                    if (req != 1 || pending == null) return;
                    Uri[] r = null;
                    if (res == RESULT_OK && data != null) {
                        ClipData c = data.getClipData();
                        if (c != null) {
                            r = new Uri[c.getItemCount()];
                            for (int i = 0; i < r.length; i++) r[i] = c.getItemAt(i).getUri();
                        } else if (data.getData() != null) {
                            r = new Uri[]{data.getData()};
                        }
                    }
                    pending.onReceiveValue(r);
                    pending = null;
                }

                @Override
                protected void onPause() {
                    super.onPause();
                    android.webkit.CookieManager.getInstance().flush();
                }

                @Override
                public void onBackPressed() {
                    if (web.canGoBack()) web.goBack();
                    else super.onBackPressed();
                }
            }
            """;
}
