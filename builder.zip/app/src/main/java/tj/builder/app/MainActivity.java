package tj.builder.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.PendingIntent;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageInstaller;
import android.database.Cursor;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.OpenableColumns;
import android.provider.Settings;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.lang.ref.WeakReference;
import java.nio.charset.StandardCharsets;
import java.util.Locale;

public class MainActivity extends Activity {

    static final int BG = 0xFF10141C, CARD = 0xFF1B2230, ACCENT = 0xFF4C8DFF, TEXT = 0xFFFFFFFF,
            SUB = 0xFF9AA4B5, RED = 0xFFFF6B6B, GREEN = 0xFF3DD68C;

    static WeakReference<MainActivity> current = new WeakReference<>(null);

    SharedPreferences prefs;
    final Handler ui = new Handler(Looper.getMainLooper());

    TextView accountText, fileLabel, statusText, timeText;
    EditText nameField, codeField;
    Button zipTab, codeTab, buildBtn, installBtn, logBtn, browserBtn;
    LinearLayout zipBox, codeBox, resultBox, historyBox;
    ProgressBar progress;

    boolean codeMode = false;
    byte[] zipBytes;
    String zipName;
    volatile boolean busy = false;
    File lastApk;
    String lastRunUrl, lastSlug;
    long startTime;

    // ---------- интерфейс ----------

    int dp(float v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }

    GradientDrawable round(int color, float radius) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(radius));
        return g;
    }

    TextView text(String s, float size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(size);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    Button button(String s, boolean primary) {
        Button b = new Button(this);
        b.setText(s);
        b.setAllCaps(false);
        b.setTextSize(15);
        b.setTextColor(TEXT);
        b.setBackground(round(primary ? ACCENT : 0xFF2A3344, 12));
        b.setPadding(dp(14), dp(10), dp(14), dp(10));
        return b;
    }

    LinearLayout card(LinearLayout parent) {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setBackground(round(CARD, 16));
        c.setPadding(dp(16), dp(14), dp(16), dp(16));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.topMargin = dp(12);
        parent.addView(c, lp);
        return c;
    }

    EditText field(String hint) {
        EditText e = new EditText(this);
        e.setHint(hint);
        e.setHintTextColor(0xFF6B7588);
        e.setTextColor(TEXT);
        e.setTextSize(15);
        e.setBackground(round(0xFF121822, 10));
        e.setPadding(dp(12), dp(10), dp(12), dp(10));
        return e;
    }

    void addSpaced(LinearLayout p, View v, int top) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.topMargin = dp(top);
        p.addView(v, lp);
    }

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        current = new WeakReference<>(this);
        prefs = getSharedPreferences("builder", MODE_PRIVATE);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);

        ScrollView sv = new ScrollView(this);
        sv.setBackgroundColor(BG);
        sv.setFillViewport(true);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16), dp(18), dp(16), dp(32));
        sv.addView(root);

        root.addView(text("Сборщик", 28, TEXT, true));
        root.addView(text("Код или zip → готовое приложение", 14, SUB, false));

        // аккаунт
        LinearLayout acc = card(root);
        LinearLayout accRow = new LinearLayout(this);
        accRow.setGravity(Gravity.CENTER_VERTICAL);
        accountText = text("", 14, SUB, false);
        accRow.addView(accountText, new LinearLayout.LayoutParams(0, -2, 1));
        Button set = button("Настройки", false);
        set.setOnClickListener(v -> showSettings());
        accRow.addView(set);
        acc.addView(accRow);

        // что собираем
        LinearLayout src = card(root);
        LinearLayout tabs = new LinearLayout(this);
        zipTab = button("ZIP-архив", true);
        codeTab = button("HTML-код", false);
        LinearLayout.LayoutParams tl = new LinearLayout.LayoutParams(0, -2, 1);
        tl.rightMargin = dp(6);
        tabs.addView(zipTab, tl);
        LinearLayout.LayoutParams tr = new LinearLayout.LayoutParams(0, -2, 1);
        tr.leftMargin = dp(6);
        tabs.addView(codeTab, tr);
        src.addView(tabs);
        zipTab.setOnClickListener(v -> setMode(false));
        codeTab.setOnClickListener(v -> setMode(true));

        addSpaced(src, text("Название приложения", 13, SUB, false), 14);
        nameField = field("Например: Финансы");
        nameField.setSingleLine(true);
        addSpaced(src, nameField, 6);

        zipBox = new LinearLayout(this);
        zipBox.setOrientation(LinearLayout.VERTICAL);
        Button pick = button("Выбрать zip-файл", false);
        pick.setOnClickListener(v -> pickFile());
        addSpaced(zipBox, pick, 0);
        fileLabel = text("Файл не выбран", 13, SUB, false);
        addSpaced(zipBox, fileLabel, 8);
        zipBox.addView(text("Подходит проект Android (как в Галерее) или сайт с index.html.", 12, 0xFF6B7588, false));
        addSpaced(src, zipBox, 14);

        codeBox = new LinearLayout(this);
        codeBox.setOrientation(LinearLayout.VERTICAL);
        Button paste = button("Вставить из буфера обмена", false);
        paste.setOnClickListener(v -> pasteCode());
        addSpaced(codeBox, paste, 0);
        codeField = field("Или вставь HTML-код сюда");
        codeField.setGravity(Gravity.TOP);
        codeField.setMinLines(6);
        codeField.setMaxLines(14);
        codeField.setTextSize(12);
        codeField.setTypeface(Typeface.MONOSPACE);
        codeField.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE
                | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        codeField.setHorizontallyScrolling(false);
        addSpaced(codeBox, codeField, 8);
        Button clear = button("Очистить", false);
        clear.setOnClickListener(v -> codeField.setText(""));
        addSpaced(codeBox, clear, 8);
        addSpaced(src, codeBox, 14);

        buildBtn = button("Собрать APK", true);
        buildBtn.setTextSize(17);
        buildBtn.setOnClickListener(v -> startBuild());
        addSpaced(src, buildBtn, 16);

        // статус
        LinearLayout st = card(root);
        LinearLayout stRow = new LinearLayout(this);
        stRow.setGravity(Gravity.CENTER_VERTICAL);
        progress = new ProgressBar(this);
        progress.setIndeterminate(true);
        progress.setVisibility(View.GONE);
        LinearLayout.LayoutParams pl = new LinearLayout.LayoutParams(dp(28), dp(28));
        pl.rightMargin = dp(12);
        stRow.addView(progress, pl);
        LinearLayout stCol = new LinearLayout(this);
        stCol.setOrientation(LinearLayout.VERTICAL);
        statusText = text("Готов к работе", 15, TEXT, false);
        timeText = text("", 12, SUB, false);
        stCol.addView(statusText);
        stCol.addView(timeText);
        stRow.addView(stCol, new LinearLayout.LayoutParams(0, -2, 1));
        st.addView(stRow);

        resultBox = new LinearLayout(this);
        resultBox.setOrientation(LinearLayout.VERTICAL);
        installBtn = button("Установить", true);
        installBtn.setOnClickListener(v -> {
            if (lastApk != null) install(lastApk);
        });
        browserBtn = button("Скачать через браузер", false);
        browserBtn.setOnClickListener(v -> {
            if (lastSlug != null) openUrl(gh().releasePage(lastSlug));
        });
        logBtn = button("Открыть сборку на GitHub", false);
        logBtn.setOnClickListener(v -> {
            if (lastRunUrl != null) openUrl(lastRunUrl);
        });
        addSpaced(resultBox, installBtn, 12);
        addSpaced(resultBox, browserBtn, 8);
        addSpaced(resultBox, logBtn, 8);
        st.addView(resultBox);
        showResult(false, false, false);

        // история
        LinearLayout hist = card(root);
        hist.addView(text("Собранные приложения", 16, TEXT, true));
        hist.addView(text("Нажми, чтобы скачать и установить ещё раз", 12, SUB, false));
        historyBox = new LinearLayout(this);
        historyBox.setOrientation(LinearLayout.VERTICAL);
        addSpaced(hist, historyBox, 8);

        setContentView(sv);
        setMode(prefs.getBoolean("codeMode", false));
        refreshAccount();
        refreshHistory();
        handleIntent(getIntent());
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        handleIntent(intent);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (current.get() == this) current = new WeakReference<>(null);
    }

    void setMode(boolean code) {
        codeMode = code;
        prefs.edit().putBoolean("codeMode", code).apply();
        zipBox.setVisibility(code ? View.GONE : View.VISIBLE);
        codeBox.setVisibility(code ? View.VISIBLE : View.GONE);
        zipTab.setBackground(round(code ? 0xFF2A3344 : ACCENT, 12));
        codeTab.setBackground(round(code ? ACCENT : 0xFF2A3344, 12));
    }

    void showResult(boolean install, boolean browser, boolean log) {
        installBtn.setVisibility(install ? View.VISIBLE : View.GONE);
        browserBtn.setVisibility(browser ? View.VISIBLE : View.GONE);
        logBtn.setVisibility(log ? View.VISIBLE : View.GONE);
    }

    void status(String s, int color) {
        ui.post(() -> {
            statusText.setText(s);
            statusText.setTextColor(color);
        });
    }

    void toast(String s) {
        ui.post(() -> Toast.makeText(this, s, Toast.LENGTH_LONG).show());
    }

    void openUrl(String u) {
        try {
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(u)));
        } catch (Exception e) {
            toast("Не удалось открыть браузер");
        }
    }

    static void onInstallResult(String msg) {
        MainActivity a = current.get();
        if (a != null) a.status(msg, msg.endsWith("✓") ? GREEN : TEXT);
    }

    // ---------- настройки ----------

    Gh gh() {
        return new Gh(prefs.getString("token", ""), prefs.getString("owner", ""), prefs.getString("repo", "Builder"));
    }

    boolean configured() {
        return !prefs.getString("token", "").isEmpty() && !prefs.getString("owner", "").isEmpty();
    }

    void refreshAccount() {
        if (configured()) {
            accountText.setText("GitHub: " + prefs.getString("owner", "") + "/" + prefs.getString("repo", "Builder"));
            accountText.setTextColor(GREEN);
        } else {
            accountText.setText("GitHub не подключён. Открой настройки.");
            accountText.setTextColor(RED);
        }
    }

    void showSettings() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(20), dp(8), dp(20), dp(0));
        TextView t1 = text("Токен GitHub", 13, SUB, false);
        box.addView(t1);
        EditText token = field("github_pat_...");
        token.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        token.setText(prefs.getString("token", ""));
        addSpaced(box, token, 6);
        addSpaced(box, text("Репозиторий", 13, SUB, false), 14);
        EditText repo = field("Builder");
        repo.setSingleLine(true);
        repo.setText(prefs.getString("repo", "Builder"));
        addSpaced(box, repo, 6);
        addSpaced(box, text("Токен хранится только в этом телефоне. Никому его не отправляй.", 12, SUB, false), 12);

        new AlertDialog.Builder(this)
                .setTitle("Настройки")
                .setView(box)
                .setNegativeButton("Отмена", null)
                .setPositiveButton("Сохранить", (d, w) -> {
                    String tk = token.getText().toString().trim();
                    String rp = repo.getText().toString().trim();
                    if (rp.isEmpty()) rp = "Builder";
                    saveSettings(tk, rp);
                })
                .show();
    }

    void saveSettings(String token, String repo) {
        status("Проверяю токен…", TEXT);
        new Thread(() -> {
            try {
                String login = new Gh(token, "", repo).login();
                new Gh(token, login, repo).checkRepo();
                prefs.edit().putString("token", token).putString("owner", login).putString("repo", repo).apply();
                status("GitHub подключён ✓", GREEN);
            } catch (Exception e) {
                status(e.getMessage(), RED);
            }
            ui.post(this::refreshAccount);
        }).start();
    }

    // ---------- выбор файла / кода ----------

    void handleIntent(Intent in) {
        if (in == null) return;
        String act = in.getAction();
        if (Intent.ACTION_SEND.equals(act)) {
            Uri u = in.getParcelableExtra(Intent.EXTRA_STREAM);
            if (u != null) {
                loadFile(u);
            } else {
                String txt = in.getStringExtra(Intent.EXTRA_TEXT);
                if (txt != null) {
                    setMode(true);
                    codeField.setText(txt);
                }
            }
        } else if (Intent.ACTION_VIEW.equals(act) && in.getData() != null) {
            loadFile(in.getData());
        }
        setIntent(new Intent());
    }

    void pickFile() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("*/*");
        i.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{"application/zip", "application/x-zip-compressed",
                "application/octet-stream", "text/html"});
        try {
            startActivityForResult(i, 7);
        } catch (Exception e) {
            i = new Intent(Intent.ACTION_GET_CONTENT);
            i.addCategory(Intent.CATEGORY_OPENABLE);
            i.setType("*/*");
            startActivityForResult(i, 7);
        }
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req == 7 && res == RESULT_OK && data != null && data.getData() != null) loadFile(data.getData());
    }

    String displayName(Uri u) {
        try (Cursor c = getContentResolver().query(u, null, null, null, null)) {
            if (c != null && c.moveToFirst()) {
                int i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if (i >= 0) return c.getString(i);
            }
        } catch (Exception ignored) {
        }
        String p = u.getLastPathSegment();
        return p == null ? "file" : p;
    }

    void loadFile(Uri u) {
        try {
            InputStream in = getContentResolver().openInputStream(u);
            ByteArrayOutputStream bo = new ByteArrayOutputStream();
            byte[] buf = new byte[65536];
            int n;
            while ((n = in.read(buf)) > 0) bo.write(buf, 0, n);
            in.close();
            byte[] b = bo.toByteArray();
            String name = displayName(u);
            String base = name.replaceAll("\\.[A-Za-z0-9]{1,5}$", "").replaceAll("\\s*\\(\\d+\\)$", "");
            boolean isZip = b.length > 3 && b[0] == 'P' && b[1] == 'K';
            if (isZip) {
                setMode(false);
                zipBytes = b;
                zipName = base;
                fileLabel.setText("✓ " + name + " (" + sizeText(b.length) + ")");
                fileLabel.setTextColor(GREEN);
            } else {
                setMode(true);
                codeField.setText(new String(b, StandardCharsets.UTF_8));
            }
            if (nameField.getText().toString().trim().isEmpty()) nameField.setText(base);
        } catch (Exception e) {
            toast("Не удалось прочитать файл: " + e.getMessage());
        }
    }

    static String sizeText(long n) {
        if (n < 1024) return n + " Б";
        if (n < 1024 * 1024) return String.format(Locale.ROOT, "%.0f КБ", n / 1024.0);
        return String.format(Locale.ROOT, "%.1f МБ", n / 1048576.0);
    }

    void pasteCode() {
        ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        ClipData clip = cm == null ? null : cm.getPrimaryClip();
        if (clip == null || clip.getItemCount() == 0) {
            toast("Буфер обмена пуст. Сначала скопируй код.");
            return;
        }
        CharSequence cs = clip.getItemAt(0).coerceToText(this);
        codeField.setText(cs == null ? "" : cs.toString());
        toast("Вставлено символов: " + codeField.length());
    }

    // ---------- сборка ----------

    void startBuild() {
        if (busy) {
            toast("Сборка уже идёт");
            return;
        }
        if (!configured()) {
            toast("Сначала подключи GitHub в настройках");
            showSettings();
            return;
        }
        String label = nameField.getText().toString().trim();
        final String code = codeField.getText().toString();
        if (codeMode) {
            if (code.trim().isEmpty()) {
                toast("Вставь HTML-код");
                return;
            }
            if (label.isEmpty()) label = "Приложение";
        } else {
            if (zipBytes == null) {
                toast("Выбери zip-файл");
                return;
            }
            if (label.isEmpty()) label = zipName;
        }
        final String appLabel = label;
        final String slug = Template.slug(label);
        final boolean html = codeMode;
        final byte[] zip = zipBytes;

        busy = true;
        lastSlug = slug;
        lastRunUrl = null;
        lastApk = null;
        startTime = System.currentTimeMillis();
        buildBtn.setEnabled(false);
        buildBtn.setAlpha(0.5f);
        progress.setVisibility(View.VISIBLE);
        showResult(false, false, false);
        timeText.setText("");
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        ui.post(ticker);

        new Thread(() -> {
            String error = null;
            try {
                Gh g = gh();
                status("Готовлю архив…", TEXT);
                byte[] data = html ? Template.html(appLabel, slug, code) : Template.prepare(appLabel, slug, zip);
                status("Загружаю на GitHub (" + sizeText(data.length) + ")…", TEXT);
                String sha = g.upload("apps/" + slug + ".zip", data, "Сборка " + slug);

                status("Жду, когда GitHub начнёт сборку…", TEXT);
                JSONObject run = null;
                long t0 = System.currentTimeMillis();
                while (run == null) {
                    Thread.sleep(5000);
                    run = g.findRun(sha);
                    if (run == null && System.currentTimeMillis() - t0 > 180000)
                        throw new Exception("Сборка не запустилась. Проверь, что в репозитории есть файл .github/workflows/build.yml.");
                }
                long id = run.getLong("id");
                lastRunUrl = run.optString("html_url", null);
                ui.post(() -> showResult(false, false, lastRunUrl != null));

                while (!"completed".equals(run.optString("status"))) {
                    String s = run.optString("status");
                    status("queued".equals(s) || "waiting".equals(s) || "pending".equals(s)
                            ? "В очереди на GitHub…" : "Собирается… (обычно 3–6 минут)", TEXT);
                    Thread.sleep(8000);
                    JSONObject r2 = g.run(id);
                    if (r2 != null) run = r2;
                    if (System.currentTimeMillis() - t0 > 40 * 60000L)
                        throw new Exception("Сборка идёт слишком долго. Открой её на GitHub.");
                }
                String concl = run.optString("conclusion");
                if (!"success".equals(concl)) {
                    String step = g.failedStep(id);
                    throw new Exception("Сборка не удалась" + (step != null ? " на шаге «" + step + "»" : "")
                            + ". Нажми «Открыть сборку на GitHub» и пришли скриншот ошибки.");
                }

                status("Скачиваю APK…", TEXT);
                File apk = g.downloadApk(slug, getCacheDir());
                lastApk = apk;
                addHistory(slug, appLabel);
                status("Готово! " + appLabel + " (" + sizeText(apk.length()) + ")", GREEN);
                ui.post(() -> {
                    showResult(true, true, lastRunUrl != null);
                    refreshHistory();
                    install(apk);
                });
            } catch (Exception e) {
                error = e.getMessage() == null ? e.toString() : e.getMessage();
            }
            final String err = error;
            ui.post(() -> {
                busy = false;
                buildBtn.setEnabled(true);
                buildBtn.setAlpha(1f);
                progress.setVisibility(View.GONE);
                getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
                if (err != null) {
                    statusText.setText(err);
                    statusText.setTextColor(RED);
                    showResult(false, false, lastRunUrl != null);
                }
            });
        }).start();
    }

    final Runnable ticker = new Runnable() {
        @Override
        public void run() {
            if (!busy) return;
            long s = (System.currentTimeMillis() - startTime) / 1000;
            timeText.setText(String.format(Locale.ROOT, "Прошло %d:%02d", s / 60, s % 60));
            ui.postDelayed(this, 1000);
        }
    };

    // ---------- установка ----------

    void install(File apk) {
        if (Build.VERSION.SDK_INT >= 26 && !getPackageManager().canRequestPackageInstalls()) {
            new AlertDialog.Builder(this)
                    .setTitle("Нужно разрешение")
                    .setMessage("Разреши «Сборщику» устанавливать приложения. Потом вернись и нажми «Установить».")
                    .setPositiveButton("Открыть настройки", (d, w) -> {
                        try {
                            startActivity(new Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES,
                                    Uri.parse("package:" + getPackageName())));
                        } catch (Exception e) {
                            toast("Открой настройки телефона вручную");
                        }
                    })
                    .setNegativeButton("Отмена", null)
                    .show();
            return;
        }
        try {
            PackageInstaller pi = getPackageManager().getPackageInstaller();
            PackageInstaller.SessionParams params =
                    new PackageInstaller.SessionParams(PackageInstaller.SessionParams.MODE_FULL_INSTALL);
            int sid = pi.createSession(params);
            PackageInstaller.Session session = pi.openSession(sid);
            OutputStream out = session.openWrite("app", 0, apk.length());
            InputStream in = new FileInputStream(apk);
            byte[] buf = new byte[65536];
            int n;
            while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
            in.close();
            session.fsync(out);
            out.close();
            Intent cb = new Intent(this, InstallReceiver.class);
            int flags = PendingIntent.FLAG_UPDATE_CURRENT;
            if (Build.VERSION.SDK_INT >= 31) flags |= PendingIntent.FLAG_MUTABLE;
            PendingIntent p = PendingIntent.getBroadcast(this, sid, cb, flags);
            session.commit(p.getIntentSender());
            session.close();
            status("Открываю установку…", TEXT);
        } catch (Exception e) {
            status("Не удалось установить: " + e.getMessage(), RED);
        }
    }

    // ---------- история ----------

    void addHistory(String slug, String label) {
        try {
            JSONArray a = new JSONArray(prefs.getString("history", "[]"));
            JSONArray b = new JSONArray();
            JSONObject o = new JSONObject();
            o.put("slug", slug);
            o.put("label", label);
            o.put("time", System.currentTimeMillis());
            b.put(o);
            for (int i = 0; i < a.length() && b.length() < 30; i++) {
                if (!slug.equals(a.getJSONObject(i).optString("slug"))) b.put(a.getJSONObject(i));
            }
            prefs.edit().putString("history", b.toString()).apply();
        } catch (Exception ignored) {
        }
    }

    void refreshHistory() {
        historyBox.removeAllViews();
        try {
            JSONArray a = new JSONArray(prefs.getString("history", "[]"));
            if (a.length() == 0) {
                historyBox.addView(text("Пока пусто", 13, SUB, false));
                return;
            }
            for (int i = 0; i < a.length(); i++) {
                JSONObject o = a.getJSONObject(i);
                String slug = o.optString("slug");
                String label = o.optString("label", slug);
                TextView row = text("📦  " + label, 15, TEXT, false);
                row.setPadding(dp(12), dp(12), dp(12), dp(12));
                row.setBackground(round(0xFF232B3A, 10));
                row.setOnClickListener(v -> reinstall(slug, label));
                row.setOnLongClickListener(v -> {
                    openUrl(gh().releasePage(slug));
                    return true;
                });
                addSpaced(historyBox, row, 6);
            }
        } catch (Exception ignored) {
        }
    }

    void reinstall(String slug, String label) {
        if (busy) {
            toast("Подожди, идёт сборка");
            return;
        }
        status("Скачиваю " + label + "…", TEXT);
        progress.setVisibility(View.VISIBLE);
        new Thread(() -> {
            try {
                File apk = gh().downloadApk(slug, getCacheDir());
                lastApk = apk;
                lastSlug = slug;
                ui.post(() -> {
                    progress.setVisibility(View.GONE);
                    showResult(true, true, false);
                    install(apk);
                });
            } catch (Exception e) {
                ui.post(() -> progress.setVisibility(View.GONE));
                status(e.getMessage(), RED);
            }
        }).start();
    }
}
