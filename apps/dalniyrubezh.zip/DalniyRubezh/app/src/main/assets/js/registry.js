'use strict';
// ================= CONTENT REGISTRY =================
// Single source of truth with stable ids. Used by the game and by the checks.
const REG={regions:{},factions:{},systems:{},stations:{},links:[]};
REG.factions={
 league:{name:'Торговая Лига',short:'Лига',kind:'human',color:'#5fa8ff',desc:'Гражданские торговые дома ядра. Корабли с утопленными грузовыми отсеками.'},
 union:{name:'Союз Верфей',short:'Союз',kind:'human',color:'#e0a040',desc:'Промышленные миры. Грубо сваренные корпуса с открытыми сервисными фермами.'},
 teira:{name:'Дома Тейра',short:'Тейра',kind:'teira',color:'#d0603a',desc:'Семейные экипажи. Суда передаются по наследству, исполненные клятвы — узоры на броне.'},
 essen:{name:'Хор Эссен',short:'Эссен',kind:'essen',color:'#7fe0d0',desc:'Ориентируются по резонансу. Строят вложенные незамкнутые кольца.'},
 wake:{name:'Братство Свободной Кильватерной Линии',short:'Братство',kind:'human',color:'#c05050',desc:'Пираты, торговцы под чужими флагами и те, кому закрыты законные порты.'},
 none:{name:'Без владельца',short:'—',kind:'none',color:'#8a8a8a',desc:''}};
REG.regions={
 core:{name:'Торговое ядро',faction:'league',style:'league'},union:{name:'Промышленный союз',faction:'union',style:'union'},
 teira:{name:'Дома Тейра',faction:'teira',style:'teira'},essen:{name:'Хор Эссен',faction:'essen',style:'essen'},
 border:{name:'Спорное пограничье',faction:'none',style:'border'},free:{name:'Вольные системы',faction:'wake',style:'wake'},
 hidden:{name:'Неизвестно',faction:'none',style:'wake'}};
// planet classes: ocean, dry, ice, volcanic, giant, ringed, rock, damaged
// station families: dock, habitat, mining, observatory, military, ring; bespoke:<key>
// card: [id,name,region,owner,x,y,star[r,g,b],planet,landmark,population,income,danger(0-3),reason,stations[[id,name,family,services]]]
const SV='market,repair,equip,contracts,bar';
const SYS_CARDS=[
 ['yantar','Янтарь','core','league',220,330,[1.12,.9,.66],'dry','Охристая планета и Медный пояс','шахтёры и диспетчеры','руда, ремонт',0,'Начало пути: работа для новичка',
  [['kromka','Кромка','bespoke:kromka',SV+',shipyard'],['yan_mine','Медный Рудник','mining','market,repair,contracts'],['yan_obs','Янтарная Обсерватория','observatory','market,repair,bar'],['yan_sol','Причал Сола','habitat','market,repair,equip,bar']]],
 ['lira','Лира','core','league',150,255,[1,.98,.9],'ocean','Океанский мир со светящимися городами','столица Лиги','биржа, роскошь',0,'Крупнейший рынок и верфь Лиги',
  [['lira_ex','Биржа Лиры','bespoke:lira',SV+',shipyard,intel'],['lira_hab','Лира-Жилая','habitat','market,repair,bar'],['lira_dock','Тихий Док','dock','market,repair,equip'],['lira_post','Пост Лиги','military','repair,equip,contracts']]],
 ['sirin','Сирин','core','league',265,215,[.95,.95,1.1],'ringed','Кольца из ледяной пыли','фермеры орбиты','продовольствие, медицина',0,'Спокойные рейсы и медицина',
  [['sir_port','Сирин-Порт','habitat',SV],['sir_ring','Сирин-Рынок','ring','market,contracts,bar'],['sir_obs','Станция Перо','observatory','market,repair'],['sir_mine','Шахта Сирин-2','mining','market,repair']]],
 ['polden','Полдень','core','league',115,385,[1.15,1.05,.8],'dry','Пустынный мир под жарким солнцем','госпитали Лиги','медикаменты',1,'Медицинские конвои',
  [['pol_hab','Полуденная Гавань','habitat',SV],['pol_med','Медузел «Полдень»','habitat','market,repair,contracts'],['pol_dock','Склад Полдень','dock','market,repair,equip'],['pol_post','Пост Восход','military','repair,contracts']]],
 ['perekr','Перекрёсток','core','league',320,300,[1,.85,.7],'rock','Узел пяти ворот','таможенники','транзит',0,'Перекрёсток торговых путей',
  [['per_hub','Перекрёсток-Центр','bespoke:perekr',SV+',intel'],['per_cust','Таможня Перекрёстка','military','repair,contracts'],['per_dock','Узловой Док','dock','market,repair,equip,shipyard'],['per_ring','Кольцевой Рынок','ring','market,bar']]],
 ['inei','Иней','union','union',420,360,[.78,.92,1.2],'giant','Голубой гигант с кольцом','ремонтники','ремонт кораблей',1,'Верфь-9 и пропавшие конвои',
  [['verf9','Верфь-9','bespoke:verf9',SV+',shipyard'],['inei_hab','Ледяной Причал','habitat','market,repair,bar'],['inei_mine','Буровая «Изморозь»','mining','market,repair'],['inei_dock','Ремдок Инея','dock','market,repair,equip']]],
 ['gorn','Горн','union','union',480,258,[1.2,.75,.5],'volcanic','Вулканический мир в огне','плавильщики','металлы',1,'Металл и оружие Союза',
  [['gorn_forge','Горн-Плавильня','bespoke:gorn',SV+',shipyard'],['gorn_yard','Литейный Двор','dock','market,repair,equip'],['gorn_hab','Посёлок Горн','habitat','market,bar'],['gorn_mine','Рудная Шахта Горна','mining','market,repair']]],
 ['nakov','Наковальня','union','union',560,320,[1,.9,.8],'damaged','Расколотая луна','рабочие доков','запчасти',1,'Запчасти и тяжёлая техника',
  [['nak_dock','Наковальня-1','dock',SV+',shipyard'],['nak_hab','Наковальня-Жилая','habitat','market,bar'],['nak_ars','Арсенал Союза','military','repair,equip,contracts'],['nak_ring','Шлаковый Рынок','ring','market']]],
 ['stapel','Стапель','union','union',520,420,[.95,.95,1],'rock','Гигантские стапели на орбите','инженеры','корабли',1,'Верфь тяжёлых кораблей',
  [['stp_north','Стапель-Северный','dock',SV+',shipyard'],['stp_hab','Стапель-Жилой','habitat','market,bar'],['stp_test','Испытательный полигон','military','repair,equip,contracts'],['stp_ring','Стапельный Рынок','ring','market']]],
 ['kobalt','Кобальт','union','union',600,220,[.7,.8,1.3],'ice','Ледяной мир и цепь маяков','бурильщики','кобальт, лёд',2,'Странные сигналы маяков',
  [['kob_mine','Кобальт-Шахта','mining','market,repair,contracts'],['kob_obs','Кобальтовый Маяк','observatory','market,repair,intel'],['kob_port','Кобальт-Порт','habitat',SV],['kob_post','Пост Кобальт','military','repair,equip']]],
 ['teir_an','Тейр-Ан','teira','teira',400,118,[1.2,.8,.55],'dry','Красная пустыня и родовые залы','семейные экипажи','броня, клятвы',1,'Сердце Домов Тейра',
  [['tei_hall','Зал Родов','bespoke:teira_hall',SV+',shipyard'],['tei_dock','Причал Наследия','dock','market,repair,equip'],['tei_guard','Сторожевой Род','military','repair,contracts']]],
 ['venec','Венец Рода','teira','teira',320,78,[1.1,.85,.6],'ringed','Окольцованный мир-реликвия','старейшины','реликвии',1,'Родовые архивы',
  [['ven_nest','Венец-Гнездо','habitat',SV],['ven_obs','Обсерватория Предков','observatory','market,repair,intel'],['ven_ring','Рынок Обетов','ring','market,bar']]],
 ['ashket','Ашкет','teira','teira',480,88,[1.2,.7,.5],'volcanic','Лавовые реки','кузнецы Тейра','сплавы',2,'Тейрийские верфи',
  [['ash_yard','Ашкет-Верфь','dock',SV+',shipyard'],['ash_mine','Ашкет-Шахта','mining','market,repair'],['ash_post','Пост Клятвы','military','repair,contracts']]],
 ['krov','Кровная Мель','teira','teira',560,140,[1.1,.6,.5],'rock','Отмель обломков старой войны','изгои родов','трофеи',2,'Спорное наследство',
  [['krv_gate','Кровная Застава','military','repair,contracts'],['krv_ring','Рынок Мели','ring','market,bar'],['krv_nest','Гнездо Мели','habitat','market,repair,equip']]],
 ['essen_oi','Эссен-Ои','essen','essen',420,540,[.7,1,1.1],'ocean','Поющий океан','хоры','резонаторы',1,'Сердце Хора',
  [['ess_spire','Хоровой Шпиль','bespoke:essen_choir',SV+',shipyard'],['ess_ring','Кольцо Отклика','ring','market,bar'],['ess_dock','Резонатор-Док','dock','market,repair,equip']]],
 ['tikhy','Тихий Резонанс','essen','essen',320,520,[.8,1,1.2],'ice','Ледяные хоры','слушатели','кристаллы',1,'Кристаллы и тишина',
  [['tih_step','Тихая Ступень','habitat',SV],['tih_obs','Слушающая Обсерватория','observatory','market,repair,intel'],['tih_mine','Эхо-Шахта','mining','market,repair']]],
 ['lo_unna','Ло-Унна','essen','essen',520,545,[.9,1.1,1],'ocean','Сады на орбите','садовники Хора','биоматериалы',1,'Биоматериалы и медицина',
  [['lou_garden','Ло-Унна-Сад','habitat',SV],['lou_ring','Ло-Унна-Рынок','ring','market,bar'],['lou_dock','Дуговой Док','dock','market,repair,equip']]],
 ['shepot','Шёпот Дуги','essen','essen',600,500,[.75,.9,1.2],'giant','Гигант с поющим полем','отшельники','данные',2,'Затихшие сигналы',
  [['shp_post','Шёпот-Застава','military','repair,contracts'],['shp_obs','Дуга Наблюдения','observatory','market,repair,intel'],['shp_hab','Обитель Шёпота','habitat','market,bar']]],
 ['razlom','Разлом','border','none',360,195,[1.1,.95,.8],'damaged','Расколотая планета','пограничники','охрана',2,'Граница людей и Тейра',
  [['raz_fort','Форт Разлом','bespoke:razlom_fort',SV],['raz_mine','Шахта Трещина','mining','market,repair'],['raz_bar','Бар «Последний Ход»','habitat','market,bar']]],
 ['sporny','Спорный Брод','border','none',660,320,[1,.9,.9],'rock','Таможенный брод','контрабандисты','пошлины',2,'Таможня и контрабанда',
  [['spr_cust','Брод-Таможня','military','repair,contracts'],['spr_ring','Брод-Рынок','ring','market,bar'],['spr_dock','Бродячий Док','dock','market,repair,equip']]],
 ['gar','Гарь','border','none',700,420,[1.2,.8,.6],'volcanic','Выжженный мир и поле остовов','перевозчики','утиль',3,'Слухи о Чёрной Гавани',
  [['gar_set','Гарь-Поселение','habitat',SV],['gar_post','Пост Пепел','military','repair,contracts'],['gar_dump','Свалка Гари','dock','market,repair,equip']]],
 ['mezha','Межа','border','none',740,180,[.9,.9,1.1],'ice','Ледяная межа','картографы','разведданные',2,'Край старой сети',
  [['mez_post','Межевой Пост','military','repair,contracts'],['mez_obs','Межа-Обсерватория','observatory','market,repair,intel'],['mez_mine','Межа-Шахта','mining','market,repair']]],
 ['kilvater','Кильватер','free','wake',820,300,[1,.8,.8],'ringed','Базар на кольце','вольные торговцы','всё, что продаётся',2,'Столица вольных',
  [['kil_bazaar','Кильватерный Базар','bespoke:kilvater',SV+',shipyard'],['kil_dock','Кильватер-Док','dock','market,repair,equip'],['kil_pena','Таверна «Пена»','habitat','market,bar']]],
 ['rzhavy','Ржавый Рейд','free','wake',880,385,[1.1,.75,.6],'damaged','Кладбище кораблей','разборщики','запчасти',3,'Старые накладные',
  [['rzh_port','Ржавый Рейд-Порт','habitat',SV],['rzh_mine','Рейдовая Шахта','mining','market,repair'],['rzh_scrap','Разборка','dock','market,repair,equip']]],
 ['posledny','Последний Причал','free','wake',905,220,[.85,.9,1.15],'rock','Последний известный причал','отшельники','навигация',2,'Край карты',
  [['pos_ring','Последний Причал','ring',SV],['pos_guard','Сторож Края','military','repair,contracts'],['pos_obs','Маяк Края','observatory','market,repair,intel']]],
 ['pustosh','Пустошь Верна','free','wake',860,480,[1,.9,.75],'dry','Пыльная пустошь','беженцы','медицина в дефиците',2,'Пропажа медицинских грузов',
  [['pus_mine','Пустошь-Шахта','mining','market,repair'],['pus_shel','Приют Верна','habitat',SV],['pus_ring','Пустошь-Рынок','ring','market,bar']]],
 // ---- hidden ----
 ['black_harbor','Чёрная Гавань','hidden','wake',780,525,[1,.55,.45],'damaged','Расколотый промышленный цилиндр','пираты и их семьи','чёрный рынок',3,'Свои законы',
  [['bh_cyl','Гавань-Цилиндр','bespoke:harbor_cyl',SV+',shipyard,black'],['bh_med','Госпитальный Отсек','habitat','market,repair,bar'],['bh_tx','Рынок Транспондеров','ring','market,black']]],
 ['silent_garden','Немой Сад','hidden','essen',660,585,[.6,1,.9],'ocean','Умолкшие станции Хора','никого','древние резонаторы',2,'Тишина Хора',
  [['sg_spire','Немой Шпиль','bespoke:garden','market,repair,intel'],['sg_ring','Умолкшее Кольцо','ring','market'],['sg_obs','Спящая Обсерватория','observatory','repair,intel']]],
 ['ark','Ковчег','hidden','none',965,560,[.6,.6,.8],'rock','Флот беженцев у тёмной планеты','беженцы','взаимопомощь',1,'Убежище',
  [['ark_flag','Ковчег-Флагман','bespoke:ark',SV+',shipyard'],['ark_med','Ковчег-Лазарет','habitat','market,repair']]],
 ['white_pocket','Белый Карман','hidden','none',680,118,[1.4,1.4,1.5],'rock','Карликовая звезда','одиночки','редкая руда',3,'Редкая руда и жар',
  [['wp_station','Белый Карман-Станция','mining','market,repair']]],
 ['sklad9','Склад Девять','hidden','wake',962,330,[.9,.8,1],'damaged','Нелегальная верфь в астероиде','мастера','экспериментальные корабли',2,'Корабль, которого нет в реестрах',
  [['s9_yard','Склад Девять','bespoke:sklad9','market,repair,equip,shipyard'],['s9_shop','Девятый Цех','dock','market,repair,equip']]],
 ['iznanka','Изнанка','hidden','none',980,62,[.7,.5,1.2],'giant','Ядро древней сети','—','—',3,'То, что держит ворота',
  [['izn_core','Ядро Изнанки','bespoke:iznanka','repair']]]];
const HIDDEN_HOW={black_harbor:'жетон и створ трёх огней',silent_garden:'акустический ключ с трёх орбит',ark:'расследование пропажи медицины',white_pocket:'искривление сигналов маяков',sklad9:'шифр в старых накладных',iznanka:'финальный акт кампании'};
const LINK_LIST=[['yantar','lira'],['yantar','sirin'],['yantar','polden'],['yantar','perekr'],['yantar','inei'],['lira','sirin'],['lira','polden'],['perekr','inei'],['perekr','sirin'],['sirin','razlom'],
 ['inei','gorn'],['inei','stapel'],['gorn','nakov'],['gorn','kobalt'],['nakov','stapel'],['nakov','sporny'],['kobalt','mezha'],['razlom','teir_an'],['razlom','gorn'],['teir_an','venec'],['teir_an','ashket'],['ashket','krov'],['krov','mezha'],
 ['polden','tikhy'],['tikhy','essen_oi'],['essen_oi','lo_unna'],['lo_unna','shepot'],['stapel','essen_oi'],['sporny','gar'],['sporny','kilvater'],['gar','shepot'],['mezha','posledny'],['kilvater','rzhavy'],['kilvater','posledny'],['rzhavy','pustosh'],['gar','pustosh'],
 ['gar','black_harbor',1],['shepot','silent_garden',1],['pustosh','ark',1],['kobalt','white_pocket',1],['rzhavy','sklad9',1],['mezha','iznanka',1]];
const FAMILY_NAME={dock:'Док для сверхтяжёлых судов',habitat:'Жилая гавань',mining:'Шахтёрская база',observatory:'Обсерватория',military:'Военный узел',ring:'Рынок у старого кольца'};
const SERVICE_NAME={market:'Рынок',repair:'Ремонт',equip:'Оборудование',shipyard:'Верфь',contracts:'Контракты',bar:'Место встреч',intel:'Разведданные',black:'Чёрный рынок'};
(function buildRegistry(){
 for(const c of SYS_CARDS){const [id,name,region,owner,x,y,star,planet,landmark,pop,income,danger,reason,sts]=c;
  REG.systems[id]={id,name,region,owner,map:[x,y],star,planet,landmark,pop,income,danger,reason,hidden:region==='hidden',how:HIDDEN_HOW[id]||null,stations:sts.map(s=>s[0]),links:[]};
  sts.forEach((s,i)=>{const [sid,sname,fam,svc]=s;const bespoke=fam.startsWith('bespoke:');
   REG.stations[sid]={id:sid,name:sname,sys:id,orbit:sid,family:bespoke?'bespoke':fam,bespoke:bespoke?fam.slice(8):null,services:svc.split(','),faction:owner,main:i===0}})}
 for(const [a,b,secret] of LINK_LIST){REG.links.push({a,b,secret:!!secret});REG.systems[a].links.push(b);REG.systems[b].links.push(a)}})();
// ---- queries ----
function sysKnown(id){const s=REG.systems[id];return !s.hidden||(S&&S.discovered&&S.discovered.includes(id))}
function linkOpen(a,b){const l=REG.links.find(l=>(l.a===a&&l.b===b)||(l.a===b&&l.b===a));if(!l)return false;if(!l.secret)return true;const h=REG.systems[a].hidden?a:b;return sysKnown(h)}
function neighbours(id){return REG.systems[id].links.filter(n=>linkOpen(id,n))}
function findRoute(from,to){if(from===to)return [from];const prev={[from]:null},q=[from];while(q.length){const c=q.shift();for(const n of neighbours(c)){if(n in prev)continue;prev[n]=c;if(n===to){const r=[to];let k=c;while(k){r.unshift(k);k=prev[k]}return r}q.push(n)}}return null}
function stationsOf(sys){return REG.systems[sys].stations.map(id=>REG.stations[id])}
function registryCounts(){const sys=Object.values(REG.systems);return {systems:sys.length,known:sys.filter(s=>!s.hidden).length,hidden:sys.filter(s=>s.hidden).length,stations:Object.keys(REG.stations).length,
 bespoke:Object.values(REG.stations).filter(s=>s.bespoke).length,regions:Object.fromEntries(Object.keys(REG.regions).map(r=>[r,sys.filter(s=>s.region===r).length]))}}
