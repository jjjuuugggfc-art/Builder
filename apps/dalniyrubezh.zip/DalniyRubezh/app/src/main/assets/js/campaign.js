'use strict';
// ================= CAMPAIGN «ДОЛГИЙ СИГНАЛ» (original story) =================
// ---- heroes (7) ----
REG.heroes={
 vera:{name:'Вера Ольх',role:'диспетчер «Кромки»',kind:'human',want:'найти сына, пропавшего с рудовозом',voice:'сухие портовые формулы',flaw:'держится устава, но тайно ищет «Ласточку-3»',col:'#c98a4f'},
 taras:{name:'Тарас Гвоздь',role:'начальник Верфи-9',kind:'human',want:'спасти верфь и людей на ней',voice:'рубит коротко, по-рабочему',flaw:'скрывал потери конвоев, чтобы не лишиться заказов',col:'#e0a040'},
 ilan:{name:'Илан Дорн',role:'лаборант, позже инженер сети',kind:'human',want:'узнать правду о воротах',voice:'точно, с цифрами',flaw:'сам считал схемы перенаправления сбоев',col:'#7fb0ff'},
 kae:{name:'Каэ-Тирра из Дома Ашкет',role:'капитан семейного корабля Тейра',kind:'teira',want:'вернуть честь дома',voice:'говорит клятвами и долгами',flaw:'нуждается в помощи, но не может о ней просить',col:'#d0603a'},
 sun:{name:'Сун-Оэль',role:'голос Хора Эссен',kind:'essen',want:'пробудить умолкшие хоры',voice:'говорит созвучиями, свет на лице меняется',flaw:'знает цену сети и молчит о ней',col:'#7fe0d0'},
 mira:{name:'Мира Сайт',role:'вольная перевозчица',kind:'human',want:'свободы для своих',voice:'насмешливо, с прищуром',flaw:'возит для пиратов и спасает беженцев',col:'#c05050'},
 kassar:{name:'Адмирал Рейнгольд Кассар',role:'командующий коалиции',kind:'human',want:'удержать сеть под контролем',voice:'приказами, без пауз',flaw:'искренне хочет спасти людей — любой ценой',col:'#5fa8ff'}};
Object.assign(CITEMS,{probe:'Запись маяка',pod:'Спасательная капсула',archive:'Архивный модуль',isolator:'Изолятор',key:'Ключ ядра',crate:'Груз экспедиции',telemetry:'Телеметрия «Северянки»'});
// ---- mission definitions ----
// step types: goto, dock, scan, pickup, deliver, have, mine, kill, escort, stealth, capital, evac, rings, choice, event, arrive
const MIS={};
function MM(id,act,n,title,giver,from,reward,desc,steps,o={}){MIS[id]={id,act,n,title,giver,from,reward,desc,steps,...o}}
const L=(who,line)=>[REG.heroes[who]?REG.heroes[who].name:who,line];
// ---------- ACT I «Пропавшие рейсы» ----------
MM('m1',1,1,'Чёрный ящик','vera','kromka',350,'Подобрать самописец у буя №3 и сдать на Кромке.',[],{legacy:true});
MM('m2',1,2,'Спектральный след','ilan','kromka',500,'Добыть 3 ед. руды в Медном поясе.',[],{legacy:true});
MM('m3',1,3,'Посылка на верфь','ilan','kromka',550,'Доставить анализатор на Верфь-9.',[],{legacy:true});
MM('m4',1,4,'Последний рудовоз','taras','verf9',1200,'Провести рудовоз от обломков до Верфи-9.',[],{legacy:true});
MM('a1_5',1,5,'Ответ раньше вопроса','ilan','verf9',800,'Снять запись с маяка в Кобальте: он ответил на сигнал бедствия, которого ещё не было.',[
 {t:'goto',sys:'kobalt',orbit:'kob_obs',pos:[2200,400,-1600],r:600,name:'Маяк цепи K-7',say:[L('ilan','Маяк K-7 впереди. Подойди и держи нос на нём.')]},
 {t:'scan',sys:'kobalt',orbit:'kob_obs',pos:[2200,400,-1600],r:450,time:6,name:'Маяк цепи K-7',say:[L('ilan','Есть запись. Отметка времени… за девять дней до бедствия.'),L('ilan','Маяк ответил раньше, чем его позвали.')]},
 {t:'dock',st:'kob_obs'}],{after:[L('ilan','Ворота пропускают не только корабли. Сигналы тоже приходят не по порядку.'),L('ilan','Мне нужен свидетель — тот, кто видел переход сам.')],next:['a1_6']});
MM('a1_6',1,6,'Старый рейс','taras','verf9',900,'Проследить за грузовиком «Северянка» через ворота Иней → Горн.',[
 {t:'goto',sys:'inei',orbit:'verf9',gateTo:'gorn',off:600,r:500,name:'У ворот на Горн',say:[L('taras','«Северянка» выходит через минуту. Смотри внимательно.')]},
 {t:'event',fn:'freighterEnter',say:[L('taras','Ушла в ворота. Прыгай следом.')]},
 {t:'arrive',sys:'gorn'},
 {t:'event',fn:'freighterExit',say:[L('taras','Это не она… Это она. Обшивка как после тридцати лет рейсов.'),L('vera','«Северянка», ответьте. Повторяю: «Северянка», ответьте.')]},
 {t:'pickup',sys:'gorn',orbit:'gorn_forge',item:'telemetry',near:'freighter',name:'Буй телеметрии «Северянки»'},
 {t:'dock',st:'gorn_forge'}],{after:[L('taras','Тридцать лет за две секунды. Пиратам такое не под силу.'),L('ilan','Надо искать в чужих картах. У Тейра и Эссен старые записи ворот.')],next:['a2_1'],scene:'aged'});
// ---------- ACT II «Чужие карты» ----------
MM('a2_1',2,1,'Семейный борт','kae','tei_hall',900,'Переговоры на борту семейного корабля Дома Ашкет.',[
 {t:'dock',st:'tei_hall',say:[L('kae','Ты пришёл на наш борт без долга. Это странно. Говори.')]},
 {t:'choice',title:'Цена родовых карт',opts:[
  {label:'Принести клятву помощи',desc:'Дом Ашкет даст карты, но позже потребует исполнить клятву',eff:{flag:'oathAshket',rep:{teira:15}},say:[L('kae','Клятва принята. Мы запомним — и ты запомни.')]},
  {label:'Заплатить 1500 кр.',desc:'Чисто и без обязательств',cost:1500,eff:{flag:'paidAshket',rep:{teira:5}},say:[L('kae','Плата честная. Но плата — не родство.')]}]},
 {t:'dock',st:'tei_hall'}],{after:[L('kae','На картах дома ворота меняют возраст тех, кто проходит. Мы зовём это «долгим ветром».'),L('kae','Ищи там, где торгуют все: на таможне Брода.')],next:['a2_2'],scene:'teira'});
MM('a2_2',2,2,'Таможенный конвой','kae','tei_hall',1100,'Провести семейный транспорт через таможню Спорного Брода.',[
 {t:'goto',sys:'sporny',orbit:'spr_cust',pos:[0,200,2600],r:700,name:'Точка встречи конвоя'},
 {t:'escort',sys:'sporny',orbit:'spr_cust',from:[0,200,2600],to:[0,40,420],customs:{stop:8},hull:420,name:'Транспорт «Узор Ашкет»',enemies:[[6,'interceptor','conv'],[14,'flanker','p']],say:[L('kae','Транспорт идёт. Таможня проверит его. Не дай им повод.')]},
 {t:'dock',st:'spr_cust'}],{after:[L('kae','Груз прошёл. В бортовом журнале таможни — пилот, видевший «долгий ветер». Зовут Гриф.'),L('kae','Его видели на дорогах Хора.')],next:['a2_3']});
MM('a2_3',2,3,'Свидетель на маршруте','mira','ess_ring',700,'Найти пилота Грифа на торговом пути Хора.',[
 {t:'dock',st:'ess_ring',say:[L('mira','Гриф? Был тут, пил за троих. Ушёл в Ло-Унну, на рынок.')]},
 {t:'dock',st:'lou_ring',say:[['Гриф','Я видел, как старел мой ведомый. За один прыжок. Хочешь знать больше — плати.']]},
 {t:'choice',title:'Гриф просит 600 кр.',opts:[
  {label:'Заплатить 600',cost:600,eff:{flag:'helpedGrif'},say:[['Гриф','Сигнал шёл с Тихого Резонанса. Три маяка поют там чужую песню.'],['Гриф','Я запомню, что ты не торговался.']]},
  {label:'Отказать',eff:{flag:'refusedGrif'},say:[['Гриф','Ну и лети. Сам найдёшь Тихий Резонанс.'],['Гриф','Я тебе это припомню.']]}]}],
 {after:[L('mira','Дальше — Шёпот Дуги. Там пропал разведчик Хора.')],next:['a2_4']});
MM('a2_4',2,4,'Сломанное крыло','sun','shp_obs',1300,'Спасти капсулу повреждённого разведчика Хора у Шёпота Дуги.',[
 {t:'goto',sys:'shepot',orbit:'shp_obs',pos:[-2600,300,2400],r:900,name:'Сигнал капсулы'},
 {t:'kill',sys:'shepot',orbit:'shp_obs',pos:[-2600,300,2400],spawn:['flanker','missileer'],say:[L('sun','Чужие стоят над капсулой. Сначала они.')]},
 {t:'pickup',sys:'shepot',orbit:'shp_obs',pos:[-2600,300,2400],item:'pod',name:'Капсула разведчика'},
 {t:'deliver',item:'pod',st:'shp_obs'}],{after:[L('sun','Ты вернул голос, который мы считали умолкшим.'),L('sun','В Тихом Резонансе три маяка. Их песня — карта.')],next:['a2_5'],scene:'essen'});
MM('a2_5',2,5,'Язык маяка','sun','tih_obs',1200,'Записать песни трёх маяков Тихого Резонанса.',[
 {t:'scan',sys:'tikhy',orbit:'tih_obs',pos:[2400,0,1800],r:450,time:5,name:'Маяк «Первая нота»'},
 {t:'scan',sys:'tikhy',orbit:'tih_obs',pos:[-2600,500,1200],r:450,time:5,name:'Маяк «Вторая нота»'},
 {t:'scan',sys:'tikhy',orbit:'tih_obs',pos:[300,-400,-3000],r:450,time:5,name:'Маяк «Третья нота»',say:[L('sun','Три ноты сложились. Это координаты… и предупреждение.')]},
 {t:'dock',st:'tih_obs'}],{after:[L('ilan','Маяки шлют сводку сбоев. Сбои ворот куда-то уводят — в населённые системы.'),L('sun','Экспедиция Хора уже летит туда. Им нужна помощь.')],next:['a2_6']});
MM('a2_6',2,6,'Экспедиция или прибор','kassar','lou_garden',1500,'Экспедиция Хора в беде у Ло-Унны. Коалиция требует забрать их прибор.',[
 {t:'goto',sys:'lo_unna',orbit:'lou_garden',pos:[2800,200,-2200],r:900,name:'Экспедиция Хора',say:[L('kassar','Пилот, прибор экспедиции — приоритет. Люди — потом.'),L('sun','Там живые. Прошу тебя.')]},
 {t:'choice',title:'Кого спасать',opts:[
  {label:'Спасти экспедицию',desc:'Хор станет союзником; коалиция недовольна',eff:{flag:'savedExpedition',rep:{essen:20,league:-10}},say:[L('sun','Ты выбрал живых. Хор этого не забудет.')]},
  {label:'Забрать прибор',desc:'Коалиция получит прибор; Хор отвернётся',eff:{flag:'seizedDevice',rep:{league:15,essen:-20}},say:[L('kassar','Верное решение. Прибор пригодится всем.')]}]},
 {t:'pickup',sys:'lo_unna',orbit:'lou_garden',pos:[2800,200,-2200],item:'crate',name:'Груз экспедиции',fight:['interceptor','interceptor']},
 {t:'deliver',item:'crate',st:'lou_garden'}],{after:[L('ilan','В приборе — схема. Сеть ворот не чинит сбои. Она их перекладывает на другие системы.'),L('ilan','Кто-то решает, где будут стареть люди.')],next:['a3_1']});
// ---------- ACT III «Цена тишины» ----------
MM('a3_1',3,1,'Тихий ход','ilan','mez_obs',1400,'Подобраться к узлу перенаправления у Межи, не выдав себя.',[
 {t:'stealth',sys:'mezha',orbit:'mez_obs',pos:[-2800,300,-2600],r:350,hold:5,name:'Узел перенаправления',say:[L('ilan','Не жми форсаж, не стреляй, держи скорость ниже 80. Их сенсоры чуткие.')]},
 {t:'dock',st:'mez_obs'}],{after:[L('ilan','Узел живой. Он уводит сбои в Пустошь Верна.'),L('mira','В Пустоши мои люди. Значит, это не пираты их губили.')],next:['a3_2']});
MM('a3_2',3,2,'Архив в остове','mira','gar_set',1500,'Достать архивный модуль из вращающегося остова в Гари.',[
 {t:'goto',sys:'gar',orbit:'gar_set',pos:[2600,-200,2800],r:900,name:'Вращающийся остов',say:[L('mira','Остов крутится. Архив в нём. Лови, когда окажется рядом.')]},
 {t:'event',fn:'grifReturns'},
 {t:'pickup',sys:'gar',orbit:'gar_set',pos:[2600,-200,2800],item:'archive',orbitR:80,name:'Архивный модуль'},
 {t:'dock',st:'gar_set'}],{after:[L('ilan','В архиве — списки. Инженеры знали о жертвах.'),L('taras','Я тоже знал. Не всё — но знал.')],next:['a3_3']});
MM('a3_3',3,3,'Крейсер у ворот','kassar','nak_ars',2200,'Крейсер увозит баржу с архивом сети. Выбить буксирный узел и забрать архив.',[
 {t:'capital',sys:'nakov',orbit:'nak_dock',pos:[0,300,3500],node:'tow',escorts:['interceptor','flanker'],name:'Крейсер «Непреклонный»',say:[L('kassar','Буксирный узел под кормой. Сбей его — баржа отцепится.')]},
 {t:'pickup',sys:'nakov',orbit:'nak_dock',near:'capital',item:'archive2',name:'Архив сети',citem:'archive'},
 {t:'dock',st:'nak_ars'}],{after:[L('kassar','Отключить сеть — значит отрезать сотни систем от еды и лекарств.'),L('ilan','А не отключать — значит дальше выбирать, кто постареет.')],next:['a3_4'],scene:'battle'});
MM('a3_4',3,4,'Окна прыжка','mira','pus_shel',2000,'Эвакуировать беженцев из Пустоши Верна через нестабильные ворота.',[
 {t:'evac',sys:'pustosh',orbit:'pus_mine',gateTo:'gar',n:3,need:2,name:'Эвакуация',say:[L('mira','Окно открыто пятнадцать секунд. Потом — тридцать тишины. Прикрой их.')]},
 {t:'dock',st:'pus_shel'}],{after:[L('mira','Двое дошли. Это много. Это мало.'),L('ilan','Чтобы закрыть узлы, нужен изолятор. Его делают из кристаллов резонанса.')],next:['a3_5'],scene:'evac'});
MM('a3_5',3,5,'Изолятор','ilan','tih_obs',1600,'Добыть 4 кристалла резонанса и собрать изолятор.',[
 {t:'mine',good:'crystal',qty:4,sys:'tikhy',say:[L('ilan','Кристаллы в поясе Тихого Резонанса. Бури аккуратно — они хрупкие.')]},
 {t:'have',good:'crystal',qty:4,st:'tih_obs',gives:'isolator'}],{after:[L('ilan','Изолятор готов. Теперь нужно решить, кому мы его отдадим.')],next:['a3_m6']});
MM('a3_m6',3,6,'Два союзника','taras','verf9',2500,'Тарас и Илан спорят, как использовать изолятор.',[
 {t:'dock',st:'verf9',say:[L('taras','Изолятор — на ворота Инея. Спасём верфь и людей здесь.'),L('ilan','Нет. Его место у ядра. Иначе мы просто перенесём беду дальше.')]},
 {t:'choice',title:'Чей план поддержать',opts:[
  {label:'План Тараса',desc:'Защитить Иней сейчас',eff:{flag:'backTaras',rep:{union:15}},say:[L('taras','Спасибо. Я этого не забуду — и не прощу себе прошлого.')]},
  {label:'План Илана',desc:'Нести изолятор к ядру',eff:{flag:'backIlan',rep:{league:5,essen:5}},say:[L('ilan','Тогда нам нужна вся помощь, какую найдём.')]}]},
 {t:'kill',sys:'inei',orbit:'verf9',pos:[1800,300,2600],spawn:['heavy','flanker','interceptor'],say:[L('taras','Кто-то слил наш разговор. У верфи чужие!')]},
 {t:'dock',st:'verf9'}],{after:[L('taras','Возьми «Громобой» со стапеля. Он тебе нужнее.'),L('kassar','Коалиция собирает флот. Решай, кто пойдёт с тобой к Изнанке.')],next:['a4_1'],rewardShip:'gromoboi'});
// ---------- ACT IV «Последний створ» ----------
MM('a4_1',4,1,'Союзники','kassar','lira_ex',1500,'Собрать союзников: Лига, Дома Тейра, Хор, Союз.',[
 {t:'dock',st:'lira_ex',say:[L('kassar','Лига даст три фрегата. Остальных уговаривай сам.')],ally:'league'},
 {t:'dock',st:'tei_hall',ally:'teira',sayIf:{flag:'oathAshket',yes:[L('kae','Ты пришёл за клятвой. Дом Ашкет летит с тобой.')],no:[L('kae','Плата была честной. Но в бой за плату Дом не идёт. Двое наших — добровольцы.')]}},
 {t:'dock',st:'ess_spire',ally:'essen',sayIf:{flag:'savedExpedition',yes:[L('sun','Хор поёт с тобой. Все голоса.')],no:[L('sun','Хор помнит прибор. С тобой полетит один голос — мой.')]}}],
 {after:[L('kassar','Флот собран. Ему нужны запчасти и сплавы.')],next:['a4_2']});
MM('a4_2',4,2,'Снаряжение флота','taras','stp_north',1800,'Привезти на Стапель 6 сплавов и 3 узла двигателей.',[
 {t:'have',good:'alloy',qty:6,st:'stp_north',say:[L('taras','Сплавы — в Горне или Ашкете. Узлы двигателей — здесь, на Стапеле.')]},
 {t:'have',good:'engines',qty:3,st:'stp_north'}],{after:[L('taras','Флот на ходу. Теперь — люди с Межи.')],next:['a4_3']});
MM('a4_3',4,3,'Эвакуация Межи','vera','mez_post',2200,'Вывести гражданских из Межи до начала операции.',[
 {t:'evac',sys:'mezha',orbit:'mez_post',gateTo:'kobalt',n:4,need:2,name:'Эвакуация Межи',say:[L('vera','Борт «Ласточка-3»… Нет. Рейс номер девять, выход разрешаю.')]},
 {t:'dock',st:'mez_post'}],{after:[L('vera','В списке эвакуированных «Ласточки-3» нет. Значит, она там, за воротами.'),L('vera','Пилот. Принесите мне хоть что-нибудь.')],next:['a4_4']});
MM('a4_4',4,4,'Ключ ядра','ilan','pos_obs',2000,'Забрать ключ ядра у Маяка Края.',[
 {t:'scan',sys:'posledny',orbit:'pos_obs',pos:[-2400,600,2200],r:450,time:5,name:'Тайник Маяка Края'},
 {t:'kill',sys:'posledny',orbit:'pos_obs',pos:[-2400,600,2200],spawn:['guard','guard','support'],say:[L('ilan','Сторожа ключа. Сеть защищает себя.')]},
 {t:'pickup',sys:'posledny',orbit:'pos_obs',pos:[-2400,600,2200],item:'key',name:'Ключ ядра'},
 {t:'dock',st:'pos_obs'}],{after:[L('ilan','Ключ у нас. Путь к Изнанке — через ворота Межи.')],next:['a4_5']});
MM('a4_5',4,5,'Прорыв к Изнанке','kassar','mez_post',3000,'Прорваться через заслон у ворот Межи и уйти в Изнанку.',[
 {t:'capital',sys:'mezha',orbit:'mez_post',pos:[2400,300,2800],node:'eng',escorts:['flanker','interceptor','missileer'],name:'Страж ворот',allies:true,say:[L('kassar','Флот — за мной. Пилот, выбей ему двигатель!')]},
 {t:'event',fn:'openIznanka',say:[L('ilan','Ворота в Изнанку открылись. Только ты пройдёшь — остальные держат заслон.')]},
 {t:'arrive',sys:'iznanka'}],{after:[],next:['a4_6'],scene:'iznanka'});
MM('a4_6',4,6,'Последний створ','ilan','izn_core',5000,'Пролететь сквозь разрушающуюся конструкцию к ядру и решить судьбу сети.',[
 {t:'rings',sys:'iznanka',orbit:'izn_core',pts:[[0,0,3200],[600,300,2400],[-400,-200,1600],[200,100,900]],name:'Створ',say:[L('ilan','Конструкция рушится. Проходи кольца по порядку.')]},
 {t:'scan',sys:'iznanka',orbit:'izn_core',pos:[300,0,500],r:260,time:4,name:'Узел ядра'},
 {t:'choice',title:'Судьба сети',ending:true,opts:[
  {label:'Централизовать сеть',desc:'Коалиция берёт ядро под контроль. Сбои будут распределять открыто — и честно, обещают они.',eff:{ending:'A'},say:[L('kassar','Сеть под присмотром. Больше никаких тайн — я лично прослежу.')]},
  {label:'Разделить на региональные сети',desc:'Каждый регион держит свои ворота и свою цену. Длинные пути станут дороже.',eff:{ending:'B'},say:[L('sun','Каждый хор поёт свою песню. Теперь мы услышим друг друга.')]},
  {label:'Вывести механизм из эксплуатации',desc:'Ядро гаснет, открываются безопасные обходные пути. Медленнее, но никто не стареет за прыжок.',eff:{ending:'C'},say:[L('ilan','Ядро затихает. Обходные коридоры открыты. Мы справимся медленнее — но сами.')]}]}],
 {after:[],next:[],final:true,scene:'core'});
REG.missions=MIS;
const CAMPAIGN_ORDER=Object.values(MIS).sort((a,b)=>a.act-b.act||a.n-b.n).map(m=>m.id);
const ENDING_TEXT={A:'Сеть централизована. Коалиционные патрули стоят у ворот ядра, а между Горном и Сирином открыт коалиционный коридор.',
 B:'Сеть разделена на региональные. Вольный путь Кильватер — Перекрёсток открыт, но прыжки через чужие регионы облагаются пошлиной.',
 C:'Древний механизм выведен из эксплуатации. Обходной путь Шёпот Дуги — Ржавый Рейд открыт, корабли больше не стареют в воротах.'};
// ending consequences: extra links appear in the registry
LINK_LIST.push(['gorn','sirin',0,'A'],['kilvater','perekr',0,'B'],['shepot','rzhavy',0,'C']);
for(const [a,b,secret,cond] of LINK_LIST.slice(-3)){REG.links.push({a,b,secret:false,cond});REG.systems[a].links.push(b);REG.systems[b].links.push(a)}
// ================= engine =================
let CSLOT='camp';
function slotState(sl){if(!S[sl])S[sl]={cur:null,step:0,done:{},paid:{},flags:{},avail:[],ending:null,allies:[]};const s=S[sl];s.done=s.done||{};s.paid=s.paid||{};s.flags=s.flags||{};s.avail=s.avail||[];return s}
function camp(){return slotState(CSLOT)}
function flags(){return slotState('camp').flags}
function withSlot(sl,fn){const o=CSLOT;CSLOT=sl;try{return fn()}finally{CSLOT=o}}
function slotOf(id){return id&&id.startsWith('job_')?'job':MIS[id]&&MIS[id].side?'side':'camp'}
function cmGet(){if(!W.cms)W.cms={};return W.cms[CSLOT]}function cmSet(v){if(!W.cms)W.cms={};W.cms[CSLOT]=v}
function syncLegacy(){const c=camp();for(const id of ['m1','m2','m3','m4']){if(S.ms[id].st==='done'){c.done[id]=true;if(S.ms[id].paid)c.paid[id]=true}}
 if(c.done.m4&&!c.done.a1_5&&c.cur!=='a1_5'&&!c.avail.includes('a1_5'))c.avail.push('a1_5')}
function campMis(){const c=camp();return c.cur?(MIS[c.cur]||(c.def&&c.def.id===c.cur?c.def:null)):null}
function campStepDef(){const m=campMis();return m?m.steps[camp().step]:null}
function campOffersHere(){syncLegacy();return camp().avail.filter(id=>MIS[id].from===S.station)}
function campAccept(id){return withSlot(slotOf(id),()=>campAccept0(id))}
function campAccept0(id){const c=camp();const def=MIS[id]||c.def;if(c.cur)return 'Сначала завершите «'+(campMis()||{title:'текущее'}).title+'»';if(!c.avail.includes(id))return 'Задание недоступно';if(def.from!==S.station)return 'Задание выдают на станции '+STATIONS[def.from].name;
 c.avail=c.avail.filter(x=>x!==id);c.cur=id;c.step=0;cmSet(null);saveGame();const sd=campStepDef();if(sd&&sd.t==='dock'&&sd.st===S.station){const out=campOnDock0(S.station);if(out.length)uiDialog(out)}else if(sd&&sd.say)uiDialog(sd.say);return ''}
function campAdvance(){const c=camp();const m=campMis();if(!m)return;const sd=campStepDef();cmSet(null);c.step++;
 if(c.step>=m.steps.length){campComplete();return}const nd=campStepDef();if(nd&&nd.say&&!(nd.t==='dock'))uiDialog(nd.say,G.mode!=='hangar');saveGame()}
function campComplete(){const c=camp();const m=campMis();const id=m.id;c.done[id]=true;c.cur=null;c.step=0;
 if(!c.paid[id]){c.paid[id]=true;S.cr+=m.reward;if(m.rewardShip&&!S.ships.includes(m.rewardShip)){S.ships.push(m.rewardShip);fitOf(m.rewardShip)}}
 for(const n of m.next||[])if(!c.done[n]&&!c.avail.includes(n))c.avail.push(n);
 const lines=[...(m.after||[]),['Журнал','Задание «'+m.title+'» выполнено: +'+m.reward+' кр.']];saveGame();uiDialog(lines,G.mode!=='hangar');
 if(m.onDone)m.onDone();if(CSLOT==='job'){c.def=null;S.jobsDone=(S.jobsDone||0)+1}
 if(m.final)setTimeout(()=>uiCredits(),400)}
function campFail(text){const c=camp();if(!c.cur)return;cmSet(null);for(const e of W.enemies)if(e.mis)e.gone=true;W.transport=null;W.allies=[];uiCampFail(text)}
function campRetry(){for(const sl of ['camp','side','job'])withSlot(sl,()=>cmSet(null));G.mode='fly';lastT=performance.now();uiNote('Повтор с контрольной точки')}
// choice
function campChoose(i,sl){return withSlot(sl||CSLOT,()=>campChoose0(i))}
function campChoose0(i){const sd=campStepDef();const o=sd.opts[i];if(o.cost&&S.cr<o.cost)return 'Не хватает '+(o.cost-S.cr)+' кр.';if(o.cost)S.cr-=o.cost;const c=camp();
 if(o.eff.flag){c.flags[o.eff.flag]=true;flags()[o.eff.flag]=true}if(o.eff.fn&&SIDE_FX[o.eff.fn])SIDE_FX[o.eff.fn]();if(o.eff.rep){S.rep=S.rep||{};for(const k in o.eff.rep)S.rep[k]=(S.rep[k]||0)+o.eff.rep[k]}if(o.eff.ending){c.ending=o.eff.ending;S.ending=o.eff.ending}
 c.choices=c.choices||{};c.choices[campMis().id]=o.label;if(o.say)uiDialog(o.say,false);campAdvance();return ''}
// docking hook (called from finishDock)
function campOnDock(st){const out=[];for(const sl of ['camp','side','job'])out.push(...withSlot(sl,()=>campOnDock0(st)));return out}
function campOnDock0(st){const sd=campStepDef();if(!sd)return [];const out=[];
 if(sd.t==='dock'&&sd.st===st){if(sd.ally){const c=camp();if(!c.allies.includes(sd.ally))c.allies.push(sd.ally)}
  const say=sd.sayIf?(flags()[sd.sayIf.flag]?sd.sayIf.yes:sd.sayIf.no):sd.say;if(say)out.push(...say);campAdvance();return out.concat(campOnDock0(st))}
 if(sd.t==='deliver'&&sd.st===st&&S.citems.includes(sd.item)){S.citems=S.citems.filter(x=>x!==sd.item);campAdvance();return out}
 if(sd.t==='have'&&sd.st===st){if((S.cargo[sd.good]||0)>=sd.qty){S.cargo[sd.good]-=sd.qty;if(sd.gives)S.citems.push(sd.gives);campAdvance();return out}out.push(['Журнал','Нужно '+sd.qty+' ед.: '+GOODS[sd.good]+' (в трюме '+(S.cargo[sd.good]||0)+')'])}
 if(sd.t==='choice'){const sl=CSLOT;setTimeout(()=>withSlot(sl,()=>uiChoice(sd,sl)),50)}
 return out}
function campOnMine(good){for(const sl of ['camp','side','job'])withSlot(sl,()=>campOnMine0(good))}
function campOnMine0(good){const sd=campStepDef();if(sd&&sd.t==='mine'&&sd.good===good&&(!sd.sys||W.id===sd.sys)){const c=camp();c.mineN=(c.mineN||0)+1;if(c.mineN>=sd.qty){c.mineN=0;campAdvance()}}}
// objective & nav
function campPoi(sd){return {kind:'poi',name:sd.name||'Цель задания',pos:sd.pos||[0,0,0],nav:true,r:30}}
function campObjectiveAny(){for(const sl of ['camp','side','job']){const o=withSlot(sl,()=>campMis()?campObjective():null);if(o)return o}return null}
function campObjective(){const m=campMis();const sd=campStepDef();if(!sd)return null;const here=W.id===sd.sys&&(!sd.orbit||W.orbit===sd.orbit);const nav=sd.sys?(here?null:navToward(sd.sys,sd.orbit)):null;
 const T=(txt,tg)=>({text:txt,target:tg});const cm=cmGet()||{};
 switch(sd.t){
  case 'goto':return T(sd.name+(here?'':' · '+REG.systems[sd.sys].name),here?(cm.poi||campPoi(sd)):nav);
  case 'dock':return T('Состыкуйтесь: '+STATIONS[sd.st].name,navToStation(sd.st));
  case 'deliver':return T('Доставьте «'+CITEMS[sd.item]+'» на '+STATIONS[sd.st].name,navToStation(sd.st));
  case 'have':return T('Привезите '+GOODS[sd.good]+': '+(S.cargo[sd.good]||0)+'/'+sd.qty+' → '+STATIONS[sd.st].name,navToStation(sd.st));
  case 'mine':return T('Добудьте '+GOODS[sd.good].toLowerCase()+': '+(camp().mineN||0)+'/'+sd.qty+(sd.sys&&W.id!==sd.sys?' · '+REG.systems[sd.sys].name:''),sd.sys&&W.id!==sd.sys?navToward(sd.sys):null);
  case 'scan':return T((cm.scan>0?'Сканирование '+Math.round(cm.scan/sd.time*100)+'% · ':'Держите нос на цели: ')+sd.name,here?(cm.poi||campPoi(sd)):nav);
  case 'pickup':return T('Подберите: '+(sd.name||CITEMS[sd.item]),here?(cm.cont||campPoi(sd)):nav);
  case 'kill':return T(cm.spawned?'Уничтожьте противников: '+W.enemies.filter(e=>e.mis).length:'Летите к цели: '+(sd.name||'сектор'),here?(cm.spawned?W.enemies.find(e=>e.mis)||campPoi(sd):campPoi(sd)):nav);
  case 'escort':{const t=W.transport;if(t&&cm.started)return T(sd.name+': корпус '+Math.ceil(t.hull/t.max*100)+'%'+(cm.customs>0?' · таможня '+Math.ceil(cm.customs)+' с':' · до цели '+fmtD(dist(t.pos,cm.to))),t);return T('Встретьте конвой',here?campPoi({...sd,pos:sd.from}):nav)}
  case 'stealth':return T('Незаметно к узлу · излучение '+Math.round(cm.em||0)+'%'+(cm.hold>0?' · запись '+Math.round(cm.hold/sd.hold*100)+'%':''),here?campPoi(sd):nav);
  case 'capital':return T(cm.spawned?'Выбейте узел: '+({tow:'буксирный',eng:'двигательный'}[sd.node]):sd.name,here?(cm.cap||campPoi(sd)):nav);
  case 'evac':return T('Эвакуация: дошло '+(cm.passed||0)+'/'+sd.need+(cm.open?' · ОКНО ОТКРЫТО '+Math.ceil(cm.wt)+' с':' · окно через '+Math.ceil(cm.wt||0)+' с'),here?(cm.gate||null):nav);
  case 'rings':return T('Пройдите створ: кольцо '+((cm.i||0)+1)+'/'+sd.pts.length,here?(cm.ring||campPoi(sd)):nav);
  case 'arrive':return T('Прыжок в систему «'+REG.systems[sd.sys].name+'»',navToward(sd.sys));
  case 'choice':return T('Решение: '+sd.title+' (в порту)',null);
  case 'event':return T(m.title,null)}
 return T(m.title,null)}
// spatial step logic (each frame)
function campUpdate(dt){if(G.duel||!S)return;for(const sl of ['camp','side','job'])withSlot(sl,()=>campUpdate0(dt))}
function campUpdate0(dt){const sd=campStepDef();if(!sd||G.mode!=='fly')return;const here=W.id===sd.sys&&(!sd.orbit||W.orbit===sd.orbit);if(sd.t!=='arrive'&&sd.t!=='event'&&sd.t!=='mine'&&!here)return;
 if(!cmGet())cmSet({});const cm=cmGet();
 const posOf=sd=>{if(sd.gateTo){const g=gateTo(sd.gateTo);if(g)return add(g.pos,scl(g.dir,sd.off||500))}return sd.pos};
 switch(sd.t){
  case 'goto':{const p=posOf(sd);cm.poi=cm.poi||{kind:'poi',name:sd.name,pos:p,nav:true,r:30};if(dist(P.pos,p)<sd.r)campAdvance();break}
  case 'scan':{cm.poi=cm.poi||campPoi(sd);cm.scan=cm.scan||0;const d=dist(P.pos,sd.pos);const ang=Math.acos(clamp(dot(norm(sub(sd.pos,P.pos)),FWD(P.q)),-1,1));
   if(d<sd.r&&ang<.45&&P.spd<70){cm.scan+=dt*(shipStats().scan?1.6:1);if(Math.random()<dt*8)part(vlerp(P.pos,sd.pos,Math.random()),[0,0,0],.3,[.5,1,.9],1.2)}else cm.scan=Math.max(0,cm.scan-dt*.5);
   if(cm.scan>=sd.time){campAdvance()}break}
  case 'pickup':{if(!cm.cont){let p=sd.pos;if(sd.near==='freighter'&&W.cmFreighter)p=add(W.cmFreighter.pos,[30,20,0]);if(sd.near==='capital'){p=cm.capPos||W.cmCapPos||[0,300,3500]}
    if(!p)p=[0,300,2000];const item=sd.citem||sd.item;const c=makeCont(p,item,1,[0,0,0]);c.mis=true;c.name='Контейнер: '+(sd.name||CITEMS[item]);c.orbitR=sd.orbitR||0;c.orbitC=[...p];c.orbitA=0;W.conts.push(c);cm.cont=c;
    if(sd.fight)for(const k of sd.fight){const e=spawnEnemy(k,add(p,scl(rndDir(),700)),P);e.mis=true}}
   const c=cm.cont;if(c.orbitR){c.orbitA+=dt*.6;c.pos=add(c.orbitC,[Math.cos(c.orbitA)*c.orbitR,Math.sin(c.orbitA*.7)*20,Math.sin(c.orbitA)*c.orbitR])}
   const item=sd.citem||sd.item;if(S.citems.includes(item))campAdvance();break}
  case 'kill':{if(!cm.spawned&&dist(P.pos,sd.pos)<1600){cm.spawned=true;sd.spawn.forEach((k,i)=>{const e=spawnEnemy(k,add(sd.pos,add(scl(rndDir(),400),[i*120,0,0])),P);e.mis=true});uiNote('Противник!')}
   if(cm.spawned&&!W.enemies.some(e=>e.mis))campAdvance();break}
  case 'escort':campEscort(sd,cm,dt);break;
  case 'stealth':{cm.em=cm.em||0;const st=P.boosting?28:0;cm.em=clamp(cm.em+(st+(P.spd>80?12:0)+(IN.fire?40:0)-14)*dt,0,120);
   if(cm.em>=100){campFail('Вас засекли сенсоры узла.');break}if(dist(P.pos,sd.pos)<sd.r){cm.hold=(cm.hold||0)+dt;if(cm.hold>=sd.hold)campAdvance()}else cm.hold=Math.max(0,(cm.hold||0)-dt);break}
  case 'capital':campCapital(sd,cm,dt);break;
  case 'evac':campEvac(sd,cm,dt);break;
  case 'rings':campRings(sd,cm,dt);break;
  case 'arrive':if(W.id===sd.sys)campAdvance();break;
  case 'mine':break;
  case 'event':{if(cm.started)break;cm.started=true;CAMP_EVENTS[sd.fn](sd,cm);break}}}
function campEscort(sd,cm,dt){if(!cm.started){if(dist(P.pos,sd.from)<900){cm.started=true;cm.t=0;cm.n=0;const to=sd.to;cm.to=to;const dir=norm(sub(to,sd.from));
  W.transport={kind:'transport',name:sd.name,pos:[...sd.from],q:qLook(dir),vel:[0,0,0],spd:0,hull:sd.hull,max:sd.hull,shield:0,r:30,shieldFx:0};P.target=W.transport;if(sd.say)uiDialog(sd.say,true)}return}
 const t=W.transport;if(!t||t.dead){campFail('Транспорт уничтожен.');return}cm.t+=dt;const to=sub(cm.to,t.pos);const d=len(to);
 if(sd.customs&&!cm.customsDone&&d<700){cm.customs=cm.customs==null?sd.customs.stop:cm.customs-dt;t.spd=lerp(t.spd,0,damp(1,dt));if(cm.customs<=0){cm.customsDone=true;cm.customs=0;
   const bad=illegalCargo('spr_cust');if(bad.length){S.cr=Math.max(0,S.cr-300);uiNote('Таможня оштрафовала вас на 300 кр. за груз')}else uiNote('Таможня пропустила конвой')}}
 else t.spd=lerp(t.spd,d<300?25:60,damp(.5,dt));
 t.q=turnToward(t.q,norm(to),dt*.3);t.vel=scl(FWD(t.q),t.spd);t.pos=add(t.pos,scl(t.vel,dt));
 for(const [time,cls,tg] of sd.enemies||[])if(cm.t>time&&!(cm.sp||{})[time]){cm.sp=cm.sp||{};cm.sp[time]=1;const e=spawnEnemy(cls,add(t.pos,add(scl(norm(to),800),scl(rndDir(),300))),tg==='conv'?t:P);e.mis=true}
 if(d<200){W.transport=null;campAdvance()}}
function campCapital(sd,cm,dt){if(!cm.spawned&&dist(P.pos,sd.pos)<2200){cm.spawned=true;const e=spawnEnemy('capital',sd.pos,P,{q:qLook([1,0,.2]),name:sd.name});e.mis=true;e.route=add(sd.pos,[6000,0,1000]);cm.cap=e;
  (sd.escorts||[]).forEach((k,i)=>{const x=spawnEnemy(k,add(sd.pos,scl(rndDir(),500)),P);x.mis=true});
  if(sd.allies||(camp().allies||[]).length){W.allies=[];for(let i=0;i<Math.min(3,1+(camp().allies||[]).length);i++)W.allies.push({kind:'ally',cls:'guard',name:'Союзный фрегат',pos:add(P.pos,[i*60-60,20,-100]),q:P.q,vel:[0,0,0],hull:300,max:300,shield:100,r:9,cd:1})}
  W.onNode=(cap,n)=>{if(n.id===sd.node){cm.nodeDone=true;cm.capPos=add(cap.pos,qrot(cap.q,n.pos));W.cmCapPos=cm.capPos;uiNote('Узел выбит!')}}}
 if(cm.cap&&cm.cap.dead&&!cm.nodeDone){cm.nodeDone=true;cm.capPos=cm.cap.pos;W.cmCapPos=cm.capPos}
 if(cm.nodeDone){W.onNode=null;campAdvance()}}
function campEvac(sd,cm,dt){const g=gateTo(sd.gateTo);if(!g)return;if(!cm.init){cm.init=true;playScene('evac');cm.gate=g;cm.wt=10;cm.open=false;cm.passed=0;cm.lost=0;cm.list=[];
  for(let i=0;i<sd.n;i++){cm.list.push({kind:'transport',name:'Транспорт беженцев '+(i+1),pos:add(g.pos,add(scl(g.dir,1800+i*250),[i*120-180,(i%2)*80,0])),q:qLook(scl(g.dir,-1)),vel:[0,0,0],spd:0,hull:220,max:220,shield:0,r:30,shieldFx:0})}
  W.transport=cm.list[0];for(let i=0;i<3;i++){const e=spawnEnemy(i===2?'flanker':'interceptor',add(g.pos,add(scl(g.dir,2600),scl(rndDir(),400))),cm.list[i%cm.list.length]);e.mis=true}}
 cm.wt-=dt;if(cm.wt<=0){cm.open=!cm.open;cm.wt=cm.open?15:30;uiNote(cm.open?'Окно открыто!':'Окно закрылось')}
 for(const t of cm.list){if(t.dead||t.done)continue;const to=sub(g.pos,t.pos);const d=len(to);const go=cm.open||d>500;t.spd=lerp(t.spd,go?70:0,damp(.8,dt));t.q=turnToward(t.q,norm(to),dt*.4);t.vel=scl(FWD(t.q),t.spd);t.pos=add(t.pos,scl(t.vel,dt));
  if(d<120){if(cm.open){t.done=true;cm.passed++;explode(t.pos,.2);uiNote('Транспорт ушёл в окно')}else t.spd=0}}
 for(const t of cm.list)if(t.hull<=0&&!t.dead){t.dead=true;cm.lost++;explode(t.pos,1.2)}
 W.transport=cm.list.find(t=>!t.dead&&!t.done)||null;
 if(cm.passed>=sd.need){W.transport=null;for(const e of W.enemies)if(e.mis)e.gone=true;campAdvance()}else if(sd.n-cm.lost<sd.need)campFail('Слишком много транспортов потеряно.')}
function campRings(sd,cm,dt){cm.i=cm.i||0;const p=sd.pts[cm.i];cm.ring=cm.ring&&cm.ring.i===cm.i?cm.ring:{kind:'poi',name:'Кольцо '+(cm.i+1),pos:p,r:40,nav:true,i:cm.i};
 if(!cm.debris){cm.debris=true;for(let i=0;i<14;i++)W.asts.push({kind:'debris',pos:add(sd.pts[i%sd.pts.length],scl(rndDir(),rnd(80,200))),r:rnd(6,16),q:qrand(),spin:qaxis(rndDir(),.3),ore:0,mesh:M.debris[i%2],tint:.6,name:'Обломок конструкции'})}
 if(dist(P.pos,p)<70){cm.i++;sfx('pickup');if(cm.i>=sd.pts.length)campAdvance()}}
const CAMP_EVENTS={
 freighterEnter(sd,cm){const g=gateTo('gorn');const f={kind:'hauler',mesh:'transport',pos:add(g.pos,scl(g.dir,900)),q:qLook(scl(g.dir,-1)),s:1,into:g};W.traffic.push(f);W.cmFreighter=f;
  const tick=setInterval(()=>{if(!W||W.cmFreighter!==f){clearInterval(tick);return}const to=sub(g.pos,f.pos);if(len(to)<60){W.traffic=W.traffic.filter(x=>x!==f);clearInterval(tick);explode(g.pos,.3);if(sd.say)uiDialog(sd.say,true);campAdvance();return}f.pos=add(f.pos,scl(norm(to),Math.min(len(to),16)));f.q=qLook(to)},50)},
 freighterExit(sd,cm){const g=gateTo('inei');const f={kind:'hauler',mesh:'transport',pos:add(g.pos,scl(g.dir,120)),q:qLook(g.dir),s:1,aged:true};W.traffic.push(f);W.cmFreighter=f;cm.freighter=f;
  G.agedT=6;playScene('aged');setTimeout(()=>{if(sd.say)uiDialog(sd.say,true);campAdvance()},2500)},
 grifReturns(sd,cm){if(flags().helpedGrif){uiDialog([['Гриф','Помнишь меня? Ты заплатил без торга. Держи: архив выпадет на третьем витке.'],['Гриф','Остов чистый, я проверил.']],true)}
  else{uiDialog([['Гриф','А, это ты. Тот, кто отказал. Мои ребята проводят тебя.'],['Гриф','Без обид.']],true);for(let i=0;i<2;i++){const e=spawnEnemy('interceptor',add(P.pos,scl(rndDir(),900)),P);e.mis=true}}campAdvance()},
 openIznanka(sd,cm){S.discovered=S.discovered||[];if(!S.discovered.includes('iznanka'))S.discovered.push('iznanka');buildOrbit(W.id,W.orbit);newPlayer();P.pos=add(gateTo('iznanka').pos,scl(gateTo('iznanka').dir,400));P.q=qLook(scl(gateTo('iznanka').dir,-1));G.mode='fly';cam.reset=true;if(sd.say)uiDialog(sd.say,true);campAdvance()}};
// keep linkOpen aware of ending-dependent links
const _linkOpen=linkOpen;linkOpen=function(a,b){const l=REG.links.find(l=>(l.a===a&&l.b===b)||(l.a===b&&l.b===a));if(l&&l.cond)return !!S&&S.ending===l.cond;return _linkOpen(a,b)};

const SIDE_FX={};
