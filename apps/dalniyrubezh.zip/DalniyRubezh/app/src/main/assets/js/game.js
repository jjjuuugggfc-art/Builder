'use strict';
// ================= state =================
let S=null; // persistent save
const G={mode:'menu',time:0,duel:false,low:false,maxParts:2500};
let W=null; // world runtime
let P=null; // player runtime
const SET_DEF={vol:.7,volMusic:.6,volSfx:.9,volRadio:.9,quality:'high',invert:false,sens:1,joySize:1,btnScale:1,shake:1,assist:2};
const SET={...SET_DEF};
try{Object.assign(SET,JSON.parse(localStorage.getItem(SET_KEY)||'{}'))}catch(e){}
function storeSettings(){try{localStorage.setItem(SET_KEY,JSON.stringify(SET))}catch(e){}}

function defaultSave(){return {v:SAVE_VER,sys:'yantar',station:'kromka',cr:600,ships:['strizh'],active:'strizh',mods:{shield:false,plasma:false},
 cargo:{ore:0,elec:0,meds:0,parts:0},citems:[],fits:{strizh:{w:['p_iskra','p_iskra'],m:[],mis:null}},inv:{w:[],m:[]},stats:{minedTotal:0,kills:0},clues:[],marks:[],stocks:{kromka:{...STATIONS.kromka.stock},verf9:{...STATIONS.verf9.stock}},
 ms:{m1:{st:'active',paid:false},m2:{st:'locked',paid:false,mined:0},m3:{st:'locked',paid:false},m4:{st:'locked',paid:false}},
 camp:{cur:null,step:0,done:{},paid:{},flags:{},avail:[],ending:null,allies:[]},rep:{},discovered:[],contract:null,offers:{},tut:false,seenWreck:false,greeted:false,route:null}}
function hasSave(){try{return !!(localStorage.getItem(SAVE_KEY)||localStorage.getItem(SAVE_V1_KEY))}catch(e){return false}}
let saveErr='';
function saveGame(){if(G.duel||!S)return;try{const prev=localStorage.getItem(SAVE_KEY);if(prev)localStorage.setItem(SAVE_BAK,prev);S.v=SAVE_VER;S.savedAt=Date.now();localStorage.setItem(SAVE_KEY,JSON.stringify(S));saveErr=''}
 catch(e){saveErr='Не удалось сохранить: память браузера недоступна или переполнена';if(typeof uiNote==='function')uiNote(saveErr)}}
// v1 -> v2 migration (v1 = first release: key dalniy_rubezh_save, v:1)
function migrate(s){if(!s||typeof s!=='object')return null;
 if(s.v===1){s.v=2;s.stats={minedTotal:0};s.clues=[];s.marks=[];s.migratedFrom=1}
 if(s.v!==SAVE_VER)return null;const d=defaultSave();const m=Object.assign(d,s);
 m.ms=Object.assign(defaultSave().ms,s.ms||{});m.cargo=Object.assign(d.cargo,s.cargo||{});m.mods=Object.assign(defaultSave().mods,s.mods||{});m.stats=Object.assign({minedTotal:0},s.stats||{});
 if(!REG.ships[m.active])m.active='strizh';m.ships=m.ships.filter(x=>REG.ships[x]);if(!s.fits){delete m.fits;delete m.inv}migrateFits(m);if(!STATIONS[m.station])m.station='kromka';if(!SYSTEMS[m.sys])m.sys=STATIONS[m.station].sys;return m}
function parseSave(txt){try{return migrate(JSON.parse(txt))}catch(e){return null}}
// returns {save, status:'ok'|'migrated'|'backup'|'corrupt'|'none'}
function loadSlot(){let raw=null;try{raw=localStorage.getItem(SAVE_KEY)}catch(e){}
 if(raw){const s=parseSave(raw);if(s)return {save:s,status:'ok'};let b=null;try{b=localStorage.getItem(SAVE_BAK)}catch(e){}const bs=b&&parseSave(b);return bs?{save:bs,status:'backup'}:{save:null,status:'corrupt'}}
 let v1=null;try{v1=localStorage.getItem(SAVE_V1_KEY)}catch(e){}
 if(v1){try{localStorage.setItem(SAVE_V1_BAK,v1)}catch(e){}const s=parseSave(v1);if(s){S=s;saveGame();return {save:s,status:'migrated'}}return {save:null,status:'corrupt'}}
 return {save:null,status:'none'}}
function readSave(){return loadSlot().save}
function exportSave(){const src=S&&!G.duel?S:readSave();if(!src)return '';const j=JSON.stringify(src);return 'DR2:'+btoa(unescape(encodeURIComponent(j)))}
function importSave(txt){txt=(txt||'').trim();let j=txt;if(txt.startsWith('DR2:')){try{j=decodeURIComponent(escape(atob(txt.slice(4))))}catch(e){return 'Строка повреждена'}}
 const s=parseSave(j);if(!s)return 'Не удалось прочитать сохранение';try{const prev=localStorage.getItem(SAVE_KEY);if(prev)localStorage.setItem(SAVE_BAK,prev)}catch(e){}S=s;saveGame();return ''}
function diagLine(){const ms=S?Object.entries(S.ms).filter(([k,v])=>v.st==='active').map(([k])=>k).join(',')||'—':'—';
 return 'ДР '+GAME_VERSION+' | сист='+(W?W.sys.name:'—')+' | порт='+(S?STATIONS[S.station].name:'—')+' | орбита='+(W?W.station.name:'—')+' | задание='+ms+' | корабль='+(S?REG.ships[S.active].name:'—')+' | графика='+(G.low?'низкая':'высокая')+' | режим='+G.mode}

// ================= ship helpers =================
function cargoUsed(){let n=S.citems.length;for(const g in S.cargo)n+=S.cargo[g]||0;return n}
function cargoFree(){return shipStats().cargo-cargoUsed()}

// ================= world building =================
// ================= orbit scenes =================
// An orbit = one station's locale inside a system. Only the active orbit is built.
function mainOrbit(sys){return REG.systems[sys].stations[0]}
let stMeshCache={};
function stationMeshFor(id){if(stMeshCache[id])return stMeshCache[id];
 for(const k in stMeshCache){const c=stMeshCache[k];gl.deleteBuffer(c.mesh.buf);for(const r of c.rot)gl.deleteBuffer(r.mesh.buf)}stMeshCache={};
 const b=buildStation(REG.stations[id]);const c={mesh:makeMesh(b.tris),rot:b.rot.map(r=>({mesh:makeMesh(r.tris),z:r.z,speed:r.speed})),colliders:b.colliders,lights:b.lights};stMeshCache[id]=c;return c}
function buildSystem(id){buildOrbit(id,mainOrbit(id))}
function orbitConfig(id,orbit){const base=SYSTEMS[id];const st=REG.stations[orbit];const R=srand(hashStr(orbit));
 if(st.main&&base.hand){const h=base.hand;return {...base,...h,planet:{...h.planet,cls:base.planet.cls},main:true,gatePos:h.gatePos||{},gateDir:h.gateDir||{}}}
 const yaw=st.main?0:R()*Math.PI*2;const rot=v=>qrot(qaxis([0,1,0],yaw),v);const p=base.planet;
 const cfg={...base,main:st.main,sun:rot(base.sun),planet:{...p,pos:scl(rot(p.dir),p.dist)},moon:{pos:scl(rot(base.moon.dir),base.moon.dist),r:base.moon.r},pois:[],debris:[],gatePos:{},gateDir:{}};
 const fam=st.bespoke?BESPOKE_FAMILY[st.bespoke]:st.family;
 if(fam==='mining'||id==='white_pocket'||st.bespoke==='sklad9')cfg.belt={c:rot([-2600,-150,3600]),R:1300,h:320,n:90,ore:.4,ice:REG.systems[id].planet==='ice'};
 else cfg.belt={c:rot([2400,-200,-4200]),R:1100,h:300,n:R()<.5?40:20,ore:.12,ice:REG.systems[id].planet==='ice'};
 cfg.zone=base.danger>=2&&!REG.systems[id].hidden?{pos:rot([2800,300,-2600]),r:1100,spawn:base.danger>=3?['interceptor','heavy']:['interceptor'],after:'m1'}:null;
 if(cfg.zone)cfg.pois.push({id:'zone_'+orbit,name:'Опасный сектор',pos:cfg.zone.pos});
 return cfg}
function buildOrbit(id,orbit){if(!REG.stations[orbit]||REG.stations[orbit].sys!==id)orbit=mainOrbit(id);const sys=orbitConfig(id,orbit);const R=srand(hashStr(orbit)+11);
 W={id,orbit,sys,missiles:[],allies:[],asts:[],enemies:[],shots:[],parts:[],conts:[],statics:[],lights:[],traffic:[],colliders:[],transport:null,zoneCd:20,station:null,gates:[],gate:null,beacon:null,pois:[],dust:[],stMesh:null};
 const st=STATIONS[orbit];W.station={kind:'station',id:orbit,name:st.name,pos:[0,0,0],entrance:st.entrance,spot:st.spot,r:220,nav:true,faction:REG.stations[orbit].faction};
 for(const p of sys.pois||[])W.pois.push({kind:'poi',id:p.id,name:p.name,pos:p.pos,nav:true});
 // gates (main orbit only, one per open link)
 if(sys.main){const nb=neighbours(id);nb.forEach((to,i)=>{let pos=sys.gatePos[to]||HIDDEN_GATE[id+'>'+to];if(!pos){const m0=REG.systems[id].map,m1=REG.systems[to].map;const a=Math.atan2(m1[1]-m0[1],m1[0]-m0[0]);pos=[Math.cos(a)*5200,(i%2?1:-1)*(200+i*60),Math.sin(a)*5200+1500]}
  const dir=sys.gateDir[to]||norm(sub([0,0,0],pos));W.gates.push({kind:'gate',name:'Ворота → '+REG.systems[to].name,pos,dir,q:qLook(dir),to,r:110,nav:true})})}
 W.gate=W.gates[0]||null;
 // orbital transit beacon
 if(REG.systems[id].stations.length>1){const yaw=R()*Math.PI*2;const bp=id==='yantar'&&sys.main?[1500,-150,900]:qrot(qaxis([0,1,0],yaw),[0,120,1800]);W.beacon={kind:'beacon',name:'Орбитальный переход',pos:bp,r:30,nav:true};W.statics.push({mesh:'buoy',pos:bp,q:[0,0,0,1],s:3,beacon:true})}
 // station colliders (AABB / ring / sphere)
 const A=(x0,x1,y0,y1,z0,z1)=>W.colliders.push({t:'box',min:[x0,y0,z0],max:[x1,y1,z1]});
 const bes=REG.stations[orbit].bespoke;
 if(bes==='kromka'){A(-50,50,-50,50,-245,40);A(-56,-44,-33,33,40,172);A(44,56,-33,33,40,172);A(-56,56,22,33,40,172);A(-56,56,-33,-22,40,172);
  A(-23,23,43,73,-60,0);A(-23,23,-73,-43,-90,-30);A(43,73,-15,15,-130,-70);A(-73,-43,-15,15,-50,10);
  W.colliders.push({t:'ring',c:[0,0,-60],R:170,r:17},{t:'ring',c:[0,0,-140],R:170,r:17});
  for(const L of kromkaLights())W.lights.push(L);
  W.traffic.push({kind:'hauler',mesh:'transport',pos:[560,-140,560],q:qLook([1,0,.2]),s:1});
  W.traffic.push({kind:'tug',mesh:'tug',a:[0,-10,230],b:[520,-128,560],t:0,pos:[0,-10,230],q:[0,0,0,1],s:1});
 }else if(bes==='verf9'){A(-622,622,-12,32,-32,32);A(-60,60,-30,50,-50,10);A(-56,-44,-33,33,20,162);A(44,56,-33,33,20,162);A(-56,56,22,33,20,162);A(-56,56,-33,-22,20,162);
  for(const x of [-360,-200,220,400])W.colliders.push({t:'box',min:[x-45,-62,-70],max:[x+45,-58,70]});
  for(const L of verfLights())W.lights.push(L);
  W.traffic.push({kind:'drone',mesh:'tug',a:[-360,-40,140],b:[220,-40,140],t:.3,pos:[0,0,0],q:[0,0,0,1],s:.7});
 }else{const sm=stationMeshFor(orbit);W.stMesh=sm;W.colliders.push(...sm.colliders);W.lights.push(...sm.lights);
  W.traffic.push({kind:'tug',mesh:'tug',a:[0,-10,240],b:qrot(qaxis([0,1,0],R()*2-1),[480,-120,560]),t:R(),pos:[0,-10,240],q:[0,0,0,1],s:1});
  if(R()<.6)W.traffic.push({kind:'hauler',mesh:'transport',pos:qrot(qaxis([0,1,0],R()*2-1),[600,-160,520]),q:qLook([1,0,.2]),s:1})}
 // asteroid belt
 const b=sys.belt;if(b){const n=Math.round(b.n*(G.low?.6:1));
 for(let i=0;i<n;i++){const a=R()*Math.PI*2,rr=b.R*Math.sqrt(R());const pos=add(b.c,[Math.cos(a)*rr,(R()*2-1)*b.h,Math.sin(a)*rr]);
  const ore=R()<b.ore;const r=ore?rnd(18,34):(R()<.15?rnd(50,90):rnd(10,40));const fams=famOfBelt(id);const fam=fams[Math.floor(R()*fams.length)];const rich=ore?Math.floor(R()*3):0;
  const ast={kind:'ast',pos,r,q:qrand(R),spin:qaxis(rndDir(),rnd(-.08,.08)),ore:ore?3+rich*2+Math.floor(R()*2):0,maxOre:0,fam:ore?fam:null,good:ore?AST_FAM[fam].good:null,rich,
   mesh:ore?astMesh(fam,i%2):b.ice?M.ast.ice[i%3]:M.ast.shapes[i%4],tint:.85+R()*.3,belt:id=='yantar'&&sys.main};ast.maxOre=ast.ore;if(ore)ast.name=AST_FAM[fam].name;W.asts.push(ast)}}
 for(const [x,y,z,r] of sys.debris||[])W.asts.push({kind:'debris',pos:[x,y,z],r,q:qrand(R),spin:qaxis(rndDir(),.1),ore:0,mesh:M.debris[W.asts.length%2],tint:1,name:'Обломок'});
 if(id=='inei'&&sys.main){const w=sys.pois[0].pos;W.statics.push({mesh:'wreck',pos:w,q:qaxis(norm([.3,1,.2]),.8),s:1.6});
  for(let i=0;i<10;i++)W.asts.push({kind:'debris',pos:add(w,[rnd(-180,180),rnd(-60,60),rnd(-180,180)]),r:rnd(5,12),q:qrand(),spin:qaxis(rndDir(),.15),ore:0,mesh:M.debris[i%2],tint:.7,name:'Обломок'})}
 if(id=='yantar'&&sys.main){W.statics.push({mesh:'buoy',pos:sys.pois[0].pos,q:[0,0,0,1],s:2.2,buoy:true});
  if(S.ms.m1.st==='active'&&!S.citems.includes('recorder'))W.conts.push(makeCont([-420,40,2350],'recorder',1,[-1.2,0,1.6]))}
 // keep clear of gates/beacon
 W.asts=W.asts.filter(a=>!W.gates.some(g=>dist(g.pos,a.pos)<a.r+220)&&!(W.beacon&&dist(W.beacon.pos,a.pos)<a.r+120)&&dist(a.pos,[0,0,0])>a.r+350);
 const dn=G.low?120:320;for(let i=0;i<dn;i++)W.dust.push([rnd(0,300),rnd(0,300),rnd(0,300)]);
 W.m4=null;if(!G.duel){spawnTraffic();spawnSecretPois()}if(S&&!G.duel){S.visited=S.visited||[];if(!S.visited.includes(id))S.visited.push(id)}
}
// ---- navigation helpers ----
function routeNext(){if(!S.routeDest||S.routeDest===W.id)return null;const r=findRoute(W.id,S.routeDest);return r&&r[1]}
function gateTo(sys){return W.gates.find(g=>g.to===sys)||null}
// nav target for reaching a system (and optionally a specific orbit) from here
function navToward(sys,orbit){orbit=orbit||mainOrbit(sys);
 if(sys===W.id){if(orbit===W.orbit)return W.station;return W.beacon}
 if(!W.sys.main)return W.beacon;const r=findRoute(W.id,sys);if(!r)return null;return gateTo(r[1])}
function navToStation(id){return navToward(REG.stations[id].sys,REG.stations[id].orbit)}
function makeCont(pos,item,qty,vel=[0,0,0]){const name=CITEMS[item]||GOODS[item];return {kind:'cont',pos:[...pos],vel,item,qty,name:'Контейнер: '+name+(qty>1?' ×'+qty:''),q:qrand(),spin:qaxis(rndDir(),.6),r:4,life:item in CITEMS?1e9:240}}

// ================= player =================
function newPlayer(){const st=shipStats();P={energy:st.energy,heat:0,ovh:0,lockT:0,locked:null,jamCharges:st.jam,pos:[0,0,0],q:[0,0,0,1],vel:[0,0,0],spd:0,thr:0,boostT:3,boosting:false,hull:st.hull,shield:st.shield,shieldT:9,
 ang:[0,0,0],bank:0,weapon:0,cd:0,gun:0,target:null,nav:null,navUser:false,alive:true,kick:0,shake:0,dmgDirs:[],lastSrc:'',hitFx:0,hitPt:null,shieldFx:0}}
function stationWorld(v){return add(W.station.pos,v)}

// ================= flow =================
function newGame(){S=defaultSave();G.duel=false;saveGame();enterHangar(true)}
function continueGame(){const s=readSave();if(!s)return newGame();S=s;G.duel=false;enterHangar(false)}
function enterHangar(first){const so=REG.stations[S.station];S.sys=so.sys;S.orbit=so.orbit;buildOrbit(S.sys,S.orbit);newPlayer();const sp=stationWorld(STATIONS[S.station].spot);P.pos=sp;P.q=[0,0,0,1];G.mode='hangar';
 cam.mode='hangar';uiShowStation();if(first&&!S.greeted){S.greeted=true;saveGame();uiDialog(DLG.m1start)}}
function launch(){if(G.mode!=='hangar')return;uiHideStation();G.mode='launch';G.anim=0;const st=STATIONS[S.station];
 G.a0=stationWorld(st.spot);G.a1=stationWorld(add(st.entrance,[0,0,60]));P.q=[0,0,0,1];P.spd=0;sfx('dock')}
function startDocking(){if(G.mode!=='fly'||!canDock())return;{const bl=dockBlocked(W.station.id);if(bl){uiNote(bl);return}}G.mode='docking';G.anim=0;G.a0=[...P.pos];G.q0=[...P.q];P.target=null;stopDrill();
 const st=STATIONS[S.station];G.a1=stationWorld(st.entrance);G.a2=stationWorld(st.spot);sfx('dock')}
function canDock(){if(!W||!W.station||G.duel||G.time-(G.launchT||-99)<8)return false;const e=stationWorld(STATIONS[W.station.id].entrance);const rel=sub(P.pos,e);return len(rel)<450&&rel[2]>-30&&P.spd<110&&!W.enemies.some(x=>dist(x.pos,P.pos)<1500)}
function inspection(){const bad=illegalCargo(S.station);if(!bad.length)return null;const rep=S.rep&&S.rep[REG.stations[S.station].faction]||0;if(Math.random()>clamp(.6-rep*.004,.15,.9))return ['Таможня','Досмотр прошёл без вопросов. Повезло.'];
 let val=0;for(const g of bad){val+=REG.goods[g].base*S.cargo[g];S.cargo[g]=0}const fine=Math.min(S.cr,Math.round(val*.5));S.cr-=fine;addRep(REG.stations[S.station].faction,-5);return ['Таможня','Запрещённый груз изъят. Штраф '+fine+' кр.']}
function finishDock(){S.station=W.station.id;S.sys=W.id;S.orbit=W.orbit;const insp=inspection();if(insp)G.inspMsg=insp;stockOf(S.station);S.known=S.known||{};S.known[S.station]={t:Date.now(),p:JSON.parse(JSON.stringify(STATIONS[S.station].prices))};if(S.routeDest===W.id)S.routeDest=null;const st=shipStats();P.hull=st.hull;P.shield=st.shield;P.spd=0;P.vel=[0,0,0];
 W.enemies=[];W.shots=[];W.transport=null;G.mode='hangar';cam.mode='hangar';syncSide();const msgs=turnInMissions();if(isHome()){msgs.unshift(['Ваш док','С возвращением, капитан. Корабль на ремонте — бесплатно.'])}{const bc=W.station.id==='bh_cyl'&&bhDockChoice();if(bc)setTimeout(()=>{const s=slotState('camp');uiChoiceAd(bc)},300)}if(G.inspMsg){msgs.unshift(G.inspMsg);G.inspMsg=null}saveGame();uiShowStation();if(msgs.length)uiDialog(msgs)}
function playerDied(cause){if(!P.alive)return;P.alive=false;P.hull=0;explode(P.pos,1.6);sfx('explode');G.mode='dead';G.deathCause=cause;stopDrill();
 setTimeout(()=>uiDeath(cause),1400)}
function returnToDock(){if(G.duel){startDuel();return}const s=readSave();S=s||defaultSave();enterHangar(false)}

// ================= missions =================
function msActive(id){return S.ms[id].st==='active'}
function turnInMissions(){const out=[];if(!W.station)return out;const here=W.station.id;
 const pay=(id,dlg)=>{const m=S.ms[id];m.st='done';if(!m.paid){m.paid=true;S.cr+=MISSIONS.find(x=>x.id==id).reward}out.push(...dlg)};
 if(msActive('m1')&&here==='kromka'&&S.citems.includes('recorder')){S.citems=S.citems.filter(x=>x!=='recorder');pay('m1',DLG.m1done);S.ms.m2.st='offered'}
 if(msActive('m2')&&here==='kromka'&&S.ms.m2.mined>=3&&S.cargo.ore>=3){S.cargo.ore-=3;pay('m2',DLG.m2done);S.ms.m3.st='offered'}
 if(msActive('m3')&&here==='verf9'&&S.citems.includes('analyzer')){S.citems=S.citems.filter(x=>x!=='analyzer');pay('m3',DLG.m3done);S.ms.m4.st='offered'}
 if(msActive('m4')&&here==='verf9'&&S.m4arrived){S.m4arrived=false;pay('m4',DLG.m4done)}
 if(S.contract&&!S.contract.paid&&S.contract.to===here){const c=S.contract;if(c.good){const need=c.qty;const okMined=c.type!=='mine'||c.mined>=c.qty;
   if(S.cargo[c.good]>=need&&okMined){S.cargo[c.good]-=need;c.paid=true;S.cr+=c.reward;out.push(['Диспетчер','Контракт выполнен: +'+c.reward+' кр.']);S.contract=null;S.offers={}}}}
 if(S.ms.m4.st==='done')genOffers();
 syncLegacy();out.push(...campOnDock(here));
 return out}
function acceptMission(id){const m=S.ms[id];const def=MISSIONS.find(x=>x.id==id);if(m.st!=='offered')return 'Поручение недоступно';
 if(S.station!==def.from)return 'Это поручение выдают на станции '+STATIONS[def.from].name;
 if(id==='m3'){if(cargoFree()<1)return 'Нужно 1 свободное место в трюме: продайте что-нибудь на рынке';S.citems.push('analyzer');S.routeDest='inei'}
 m.st='active';if(id==='m2')m.mined=0;saveGame();return ''}
function genOffers(){const here=S.station;if(S.offers[here]&&S.offers[here].length)return;const other=here==='kromka'?'verf9':'kromka';
 const g=here==='kromka'?'meds':'parts';const q=4+Math.floor(Math.random()*4);
 S.offers[here]=[{id:'d'+Date.now(),type:'deliver',good:g,qty:q,to:other,from:here,reward:120+q*35,name:'Доставка: '+GOODS[g]+' ×'+q+' → '+STATIONS[other].name},
  {id:'o'+Date.now(),type:'mine',good:'ore',qty:4,to:'kromka',from:here,reward:520,mined:0,name:'Добыча: руда ×4 → Кромка'}]}
function acceptContract(i){if(S.contract)return 'Сначала выполните текущий контракт';const c=S.offers[S.station][i];if(!c)return 'Нет контракта';S.contract={...c,paid:false,mined:0};S.offers[S.station]=[];saveGame();return ''}
function dropContract(){S.contract=null;saveGame()}
// current objective {text, target}
function objective(){const sys=W.id;if(!G.duel&&S){const o=campObjectiveAny();if(o)return o}
 const stationT=id=>navToStation(id);
 if(G.duel)return {text:W.enemies.length?'Дуэль: уничтожьте противника':'Дуэль завершена',target:W.enemies[0]||null};
 if(msActive('m1')){if(!S.citems.includes('recorder')){if(W.id!=='yantar'||!W.sys.main)return {text:'Подберите самописец у буя №3',target:navToward('yantar','kromka')};const c=W.conts.find(x=>x.item==='recorder');return {text:'Подберите самописец у буя №3',target:c||W.pois[0]}}
  return {text:'Вернуться на Кромку',target:stationT('kromka')}}
 if(S.ms.m2.st==='offered')return {text:'Новое поручение: откройте «Контракты» на Кромке',target:stationT('kromka')};
 if(msActive('m2')){const m=S.ms.m2;if(m.mined<3)return {text:'Добудьте руду в Медном поясе: '+m.mined+'/3',target:sys=='yantar'&&W.sys.main?W.pois.find(p=>p.id=='belt'):navToward('yantar')};
  return {text:'Доставьте руду на Кромку',target:stationT('kromka')}}
 if(S.ms.m3.st==='offered')return {text:'Новое поручение на Кромке',target:stationT('kromka')};
 if(msActive('m3'))return {text:'Доставьте анализатор на Верфь-9',target:stationT('verf9')};
 if(S.ms.m4.st==='offered')return {text:'Новое поручение на Верфи-9',target:stationT('verf9')};
 if(msActive('m4')){if(sys!=='inei'||!W.sys.main)return {text:'Летите в Иней к обломкам конвоя',target:navToward('inei')};const m=W.m4;
  if(S.m4arrived)return {text:'Рудовоз в доке. Состыкуйтесь с Верфью-9',target:W.station};
  if(!m||m.phase==='goto')return {text:'Летите к обломкам конвоя',target:W.pois.find(p=>p.id=='wreck')};
  if(m.phase==='escort'){const t=W.transport;return {text:'Рудовоз: корпус '+Math.ceil(t.hull/t.max*100)+'% · до дока '+fmtD(dist(t.pos,stationWorld(STATIONS.verf9.entrance))),target:t}}
  if(m.phase==='failed')return {text:'Рудовоз уничтожен',target:null}}
 if(!G.duel&&S.camp&&S.ms.m4.st==='done'){syncLegacy();const av=S.camp.avail.filter(id=>MIS[id]);if(av.length){const m=MIS[av[0]];return {text:'Новое задание «'+m.title+'»: '+STATIONS[m.from].name,target:navToStation(m.from)}}}
 if(S.contract){const c=S.contract;if(c.type==='mine'&&c.mined<c.qty)return {text:'Контракт: добудьте руду '+c.mined+'/'+c.qty,target:sys=='yantar'&&W.sys.main?W.pois.find(p=>p.id=='belt'):navToward('yantar')};
  return {text:'Контракт: '+GOODS[c.good]+' ×'+c.qty+' → '+STATIONS[c.to].name,target:stationT(c.to)}}
 return {text:'Свободный полёт',target:null}}
function fmtD(d){return d>=1000?(d/1000).toFixed(1)+' км':Math.round(d)+' м'}

// ================= cargo =================
function addCargo(item,qty){if(cargoFree()<qty)return false;if(item in CITEMS)S.citems.push(item);else S.cargo[item]=(S.cargo[item]||0)+qty;return true}
function jettison(g){if(!(g in S.cargo)||S.cargo[g]<=0)return;S.cargo[g]--;if(W&&(G.mode==='fly'||G.mode==='pause')){W.conts.push(makeCont(add(P.pos,scl(FWD(P.q),-20)),g,1,scl(P.vel,.3)))}}
// ================= market =================
function price(g,side,st){return priceAt(g,side,st||S.station)}
function maxBuy(g){const p=price(g,'buy');if(!p)return 0;return Math.max(0,Math.min(Math.floor(S.cr/p),stockOf(S.station)[g]||0,cargoFree()))}
function buy(g,n){return atomic(()=>{n=Math.floor(n);if(n<=0)return 'Выберите количество';if(illegalHere(g))return 'Здесь это запрещено законом: '+lawOf(S.sys).name;const p=price(g,'buy');if(!p)return 'Здесь это не продают';const st=stockOf(S.station);
 if((st[g]||0)<n)return 'На складе только '+(st[g]||0);if(cargoFree()<n)return 'В трюме свободно только '+cargoFree();if(S.cr<p*n)return 'Не хватает кредитов: нужно '+p*n;
 S.cr-=p*n;st[g]-=n;S.cargo[g]=(S.cargo[g]||0)+n;saveGame();return ''})}
function sell(g,n){return atomic(()=>{n=Math.floor(n);if(n<=0)return 'Выберите количество';if((S.cargo[g]||0)<n)return 'У вас только '+(S.cargo[g]||0);if(illegalHere(g))return 'Здесь это запрещено: продать нельзя';
 const reserved=(S.ms.m2.st==='active'&&g==='ore'&&S.ms.m2.mined>=3)?3:0;if(reserved&&S.cargo[g]-n<reserved)return 'Эти 3 ед. руды нужны для поручения';
 const p=price(g,'sell');S.cr+=p*n;const st=stockOf(S.station);st[g]=(st[g]||0)+n;S.cargo[g]-=n;saveGame();return ''})}
// ================= equipment =================
function startDuel(){G.duel=true;S=defaultSave();S.fits.strizh.w=['p_iskra','pl_sgustok'];S.ships=['strizh'];syncLegacyMods();S.sys='inei';S.ms.m1.st='done';buildSystem('inei');newPlayer();
 const z=SYSTEMS.inei.zone.pos;P.pos=add(z,[0,0,-900]);P.q=[0,0,0,1];P.spd=80;P.thr=.6;P.vel=[0,0,80];G.mode='fly';cam.mode='chase';cam.reset=true;
 W.duelStage=0;spawnEnemy('interceptor',add(z,[400,80,500]),P);uiHideStation();uiNote('Дуэль: перехватчик. Затем — тяжёлый налётчик.')}
function exitDuel(){G.duel=false;S=readSave();G.mode='menu';uiMenu()}

// ================= enemies =================
// ================= mining =================
let DR=null;
function canDrill(){const t=P.target;return t&&t.kind==='ast'&&t.ore>0&&dist(t.pos,P.pos)-t.r<100}
function startDrill(){if(!canDrill())return;if(P.spd>30){P.thr=0;G.drillPending=true;uiNote('Торможение для бурения…');return}G.drillPending=false;DR={ast:P.target,heat:0,zone:0,lock:0,hold:false};uiNote('Держите кнопку бура: стрелка должна стоять в зелёной зоне')}
function stopDrill(){DR=null;G.drillPending=false;sndDrill(false,0)}
function updateDrill(dt,hold){if(!DR)return;const a=DR.ast;
 if(!a||a.ore<=0){stopDrill();uiNote('Жила исчерпана');return}
 if(dist(a.pos,P.pos)-a.r>100){stopDrill();uiNote('Добыча прервана: слишком далеко');return}
 if(cargoFree()<=0){DR.hold=false;sndDrill(false,0);DR.full=true;DR.heat=Math.max(0,DR.heat-dt*.4);return}DR.full=false;
 if(DR.lock>0){DR.lock-=dt;DR.heat=Math.max(0,DR.heat-dt*.35);sndDrill(false,0);return}
 DR.hold=hold;DR.heat=clamp(DR.heat+(hold?.55:-.4)*dt,0,1.05);sndDrill(hold,DR.heat);
 if(DR.heat>=1){DR.lock=2;DR.zone=Math.max(0,DR.zone-.5);sfx('overheat');uiNote('Перегрев! Бур отключён на 2 секунды');return}
 const st2=shipStats();const zw=.04*(a.rich||0)+(st2.drill?.05:0);const dmul=1+(st2.drill||0)+(S.active==='burovik'?1:0);if(DR.heat>=.5-zw&&DR.heat<=.82+zw){DR.zone+=dt*dmul;if(hold)for(let i=0;i<2;i++)part(veinPos(a),scl(rndDir(),rnd(5,15)),.4,[1,.6,.25],1.2)}
 if(DR.zone>=2){DR.zone=0;a.ore--;const gd=a.good||'ore';S.cargo[gd]=(S.cargo[gd]||0)+1;campOnMine(gd);S.stats.minedTotal=(S.stats.minedTotal||0)+1;sfx('ore');uiNote('+1 '+GOODS[gd].toLowerCase()+' · в жиле осталось '+a.ore);
  if(a.belt&&gd==='ore'&&msActive('m2'))S.ms.m2.mined++;if(S.contract&&S.contract.type==='mine'&&gd===S.contract.good)S.contract.mined++}}
function veinPos(a){return add(a.pos,qrot(a.q,scl([0,.85,0],a.r)))}

// ================= gates =================
function nearGate(){let b=null,bd=450;for(const g of W.gates){const d=dist(P.pos,g.pos);if(d<bd){bd=d;b=g}}return b}
function canJump(){return W&&!G.duel&&G.mode==='fly'&&!!nearGate()}
function nearBeacon(){return W.beacon&&dist(P.pos,W.beacon.pos)<380?W.beacon:null}
function doJump(){if(G.mode!=='fly'||!canJump())return;const gt=nearGate();G.jumpGate=gt;G.mode='jump';G.anim=0;stopDrill();sfx('jump')}
function finishJump(){const from=W.id,to=G.jumpGate.to;const hull=P.hull,sh=P.shield,wep=P.weapon,en=P.energy;S.sys=to;buildOrbit(to,mainOrbit(to));const g=gateTo(from)||W.gates[0];
 newPlayer();P.hull=hull;P.shield=sh;P.weapon=wep;P.energy=en;P.pos=add(g.pos,scl(g.dir,260));P.q=qLook(g.dir);P.spd=70;P.thr=.5;P.vel=scl(g.dir,70);
 G.mode='fly';cam.reset=true;if(S.routeDest===to)S.routeDest=null;uiNote('Система «'+SYSTEMS[to].name+'»');if(REG.systems[to].region==='teira')playScene('teira');if(to==='silent_garden')playScene('garden');if(to==='iznanka')playScene('core');
 if(to==='inei'&&msActive('m3')&&!S.seenWreck){S.seenWreck=true;uiDialog(DLG.m3arrive,true)}}
// ---- orbital transit ----
function startTransit(orbit){if(G.mode!=='fly'&&G.mode!=='map')return;if(orbit===W.orbit)return;G.transitTo=orbit;G.mode='transit';G.anim=0;stopDrill();sfx('jump');show('map',false)}
function finishTransit(){const hull=P.hull,sh=P.shield,wep=P.weapon;buildOrbit(W.id,G.transitTo);newPlayer();P.hull=hull;P.shield=sh;P.weapon=wep;
 const b=W.beacon?W.beacon.pos:[0,0,1500];const dir=norm(sub(W.station.pos,b));P.pos=add(b,scl(dir,120));P.q=qLook(dir);P.spd=60;P.thr=.5;P.vel=scl(dir,60);G.mode='fly';cam.reset=true;uiNote('Орбита: '+W.station.name)}
// ================= update =================
function update(dt){G.time+=dt;if(!W)return;
 if(G.mode==='launch'){G.anim+=dt;const k=clamp(G.anim/2,0,1),e=k*k*(3-2*k);P.pos=vlerp(G.a0,G.a1,e);P.spd=lerp(0,60,k);P.vel=scl(FWD(P.q),P.spd);
  if(k>=1){G.mode='fly';P.thr=.35;P.spd=60;cam.mode='chase';G.launchT=G.time;uiFlightStart();playScene('first')}}
 else if(G.mode==='docking'){G.anim+=dt;const k=clamp(G.anim/2.6,0,1);const e=k*k*(3-2*k);
  const mid=k<.5?vlerp(G.a0,G.a1,e*2>1?1:e*2):vlerp(G.a1,G.a2,(e-.5)*2);P.pos=k<.5?vlerp(G.a0,G.a1,Math.min(1,e*2)):vlerp(G.a1,G.a2,clamp((e-.5)*2,0,1));
  P.q=qslerp(G.q0,[0,0,0,1],Math.min(1,k*1.6));P.spd=lerp(P.spd,10,damp(2,dt));if(k>=1)finishDock()}
 else if(G.mode==='jump'){G.anim+=dt;P.pos=add(P.pos,scl(FWD(P.q),dt*(150+G.anim*400)));P.q=turnToward(P.q,norm(sub(G.jumpGate.pos,P.pos)),dt*1.5);if(G.anim>=1.6)finishJump()}
 else if(G.mode==='transit'){G.anim+=dt;P.pos=add(P.pos,scl(FWD(P.q),dt*(100+G.anim*300)));if(G.anim>=1.4)finishTransit()}
 else if(G.mode==='fly')flight(dt);
 else if(G.mode==='scene'){sceneStep(dt);P.pos=add(P.pos,scl(P.vel,dt))}
 if(G.mode==='fly'||G.mode==='dead'||G.mode==='jump'||G.mode==='transit'||G.mode==='launch'||G.mode==='docking')worldStep(dt);
 else ambient(dt);
 sndEngine(P?P.thr:0,P&&P.boosting,G.mode==='fly'||G.mode==='launch'||G.mode==='docking'||G.mode==='transit');}
function flight(dt){const st=shipStats();const I=IN;
 // rotation with smooth response
 const inv=SET.invert?-1:1;const sn=SET.sens||1;const tgt=[clamp(I.pitch*sn,-1,1)*inv*st.turn*.9,clamp(I.yaw*sn,-1,1)*st.turn,I.roll*2.2];
 for(let i=0;i<3;i++)P.ang[i]=lerp(P.ang[i],tgt[i],damp(7,dt));
 P.q=qnorm(qmul(P.q,qaxis([0,1,0],-P.ang[1]*dt)));P.q=qnorm(qmul(P.q,qaxis([1,0,0],-P.ang[0]*dt)));P.q=qnorm(qmul(P.q,qaxis([0,0,1],P.ang[2]*dt)));
 P.bank=lerp(P.bank,P.ang[1]/st.turn*.62,damp(4,dt));
 // throttle & boost
 if(I.thrSet!==null){P.thr=I.thrSet;I.thrSet=null}P.thr=clamp(P.thr+I.thrDelta*dt*.7,0,1);
 P.boosting=I.boost&&P.boostT>0.05;if(P.boosting)P.boostT=Math.max(0,P.boostT-dt);else P.boostT=Math.min(st.boostT,P.boostT+dt*st.boostT/7);
 const want=P.boosting?st.boost:st.speed*P.thr;const acc=want>P.spd?(P.boosting?st.accel*2:st.accel):st.accel*1.2;P.spd+=clamp(want-P.spd,-acc*dt,acc*dt);
 const f=FWD(P.q);P.vel=vlerp(P.vel,scl(f,P.spd),damp(clamp(48/st.mass,1.4,4.2),dt));P.pos=add(P.pos,scl(P.vel,dt));
 // shields
 P.shieldT+=dt;if(P.shieldT>5)P.shield=Math.min(st.shield,P.shield+dt*(10+st.shield*.04));P.shieldFx=Math.max(0,P.shieldFx-dt*3);
 // energy, heat, modules
 P.energy=Math.min(st.energy,P.energy+st.regen*dt*(P.beam?0:1));P.heat=Math.max(0,P.heat-st.cool*dt);if(P.ovh>0)P.ovh-=dt;
 if(st.repair&&(P.repT=(P.repT||0)+dt)>4)P.hull=Math.min(st.hull,P.hull+st.repair*dt);
 if(st.tractor)for(const c of W.conts){const d=dist(c.pos,P.pos);if(d<st.tractor&&d>20){c.vel=add(scl(c.vel,.9),scl(norm(sub(P.pos,c.pos)),40*dt*10));if(Math.random()<dt*10)part(vlerp(P.pos,c.pos,Math.random()),[0,0,0],.2,[.5,.8,1],1)}}
 P.jamT=Math.max(0,(P.jamT||0)-dt);P.stealthT=Math.max(0,(P.stealthT||0)-dt);P.stealthCd=Math.max(0,(P.stealthCd||0)-dt);P.warnT=Math.max(0,(P.warnT||0)-dt);
 // weapons
 playerFire(dt,I.fire);missileLockUpdate(dt);
 if(I.missileEdge){I.missileEdge=false;fireMissile()}if(I.jamEdge){I.jamEdge=false;useJammer()}if(I.stealthEdge){I.stealthEdge=false;useStealth()}
 P.kick=Math.max(0,P.kick-dt*3);P.shake=Math.max(0,P.shake-dt*2);
 // edges
 if(I.weaponEdge){I.weaponEdge=false;const gr=weaponGroups();if(gr.length>1){P.weapon=((P.weapon|0)+1)%gr.length;P.cd=0;uiNote(REG.weapons[gr[P.weapon]].name)}}
 if(I.targetEdge){I.targetEdge=false;cycleTarget()}
 if(I.actionEdge){I.actionEdge=false;doAction()}
 updateDrill(dt,I.actionHeld||I.fire);
 if(G.drillPending){if(!canDrill())G.drillPending=false;else if(P.spd<=30)startDrill()}
 if(!P.target&&!W.enemies.length&&miningActive()){const o=nearestOre(350);if(o)P.target=o}
 // collisions
 collide(dt);
 const R=len(P.pos);if(R>W.sys.bound){P.q=turnToward(P.q,norm(scl(P.pos,-1)),dt*1.2);if(!G.boundNote||G.time-G.boundNote>4){G.boundNote=G.time;uiNote('Граница системы — разворот')}}
 // nav target
 if(P.target&&(P.target.dead||(P.target.kind==='cont'&&!W.conts.includes(P.target))))P.target=null;
}
// aim assist: if an enemy's lead point is inside the assist cone, shots converge on it
const ASSIST_DEG=[0,4,8];
function assistAim(spd){const lvl=ASSIST_DEG[SET.assist|0]||0;if(!lvl)return null;const f=FWD(P.q);let best=null,ba=lvl*Math.PI/180;
 const cands=P.target&&P.target.kind==='enemy'?[P.target,...W.enemies]:W.enemies;
 for(const e of cands){const d=dist(e.pos,P.pos);if(d>1000)continue;const lt=leadTime(P.pos,P.vel,spd,e.pos,e.vel);const lp=add(e.pos,scl(sub(e.vel,P.vel),lt));
  const a=Math.acos(clamp(dot(norm(sub(lp,P.pos)),f),-1,1));const bonus=e===P.target?1.3:1;if(a<ba*bonus){ba=a/bonus;best={e,lp}}}
 if(!best)return null;if(!P.target||P.target.kind!=='enemy')P.target=best.e;return best.lp}
function nearestOre(maxD){let best=null,bd=maxD;for(const a of W.asts){if(a.ore<=0)continue;const d=dist(a.pos,P.pos)-a.r;if(d<bd){bd=d;best=a}}return best}
function miningActive(){return msActive('m2')||(S.contract&&S.contract.type==='mine')||(S.stats&&S.stats.minedTotal<3&&W.id==='yantar'&&dist(P.pos,W.sys.belt.c)<W.sys.belt.R+600)}
// step-by-step mining coach text (null when not relevant)
function miningCoach(){if(!miningActive()||W.enemies.length||G.mode!=='fly')return null;const b=W.sys.belt;if(!b.ore)return null;
 if(DR)return null;const inBelt=dist(P.pos,b.c)<b.R+500;if(!inBelt)return null;
 const t=P.target&&P.target.kind==='ast'&&P.target.ore>0?P.target:null;
 if(!t)return 'Ищите астероиды с оранжевой жилой — они отмечены ◆. Нажмите '+(G.touch?'◎':'Tab')+', чтобы выбрать';
 const d=dist(t.pos,P.pos)-t.r;if(d>=100)return 'Подлетите к жиле ближе 100 м (сейчас '+Math.round(d)+' м)';
 if(G.drillPending)return 'Торможение…';
 if(P.spd>30)return 'Сбавьте ход: '+(G.touch?'нажмите тягу «0»':'отпустите W / нажмите S')+' или сразу «Бурить»';
 return 'Нажмите «Бурить»'+(G.touch?'':' (E)')}
function collide(){const r=4.5;
 const hit=(n,why,dmg)=>{P.pos=n;const d=Math.max(4,P.spd*.3)*dmg;P.spd*=.3;P.vel=scl(P.vel,.3);damage(P,d,P.pos,{name:why,pos:P.pos});P.lastSrc=why};
 for(const a of W.asts){const v=sub(P.pos,a.pos),l=len(v);const rr=a.r*.92+r;if(l<rr){hit(add(a.pos,scl(v,rr/(l||1))),'Столкновение с астероидом',1);if(!P.alive){G.deathCause='Корабль разбит о '+(a.kind==='debris'?'обломок':'астероид')}return}}
 for(const c of W.colliders){if(c.t==='box'){const p=P.pos;if(p[0]>c.min[0]-r&&p[0]<c.max[0]+r&&p[1]>c.min[1]-r&&p[1]<c.max[1]+r&&p[2]>c.min[2]-r&&p[2]<c.max[2]+r){
   let best=1e9,ax=0,sg=1;for(let i=0;i<3;i++){const a=p[i]-(c.min[i]-r),b=(c.max[i]+r)-p[i];if(a<best){best=a;ax=i;sg=-1}if(b<best){best=b;ax=i;sg=1}}
   const n=[...p];n[ax]+=sg*(best+.1);hit(n,'Столкновение со станцией',.6);return}}
  else{const rel=sub(P.pos,c.c);const pr=[rel[0],rel[1],0];const lr=len(pr)||1;const near=add(c.c,scl(pr,c.R/lr));const v=sub(P.pos,near),l=len(v);if(l<c.r+r){hit(add(near,scl(v,(c.r+r)/(l||1))),'Столкновение со станцией',.6);return}}}
 for(const pl of [W.sys.planet,W.sys.moon]){const v=sub(P.pos,pl.pos);if(len(v)<pl.r+200){P.pos=add(pl.pos,scl(norm(v),pl.r+200));P.spd*=.5}}}
function doAction(){const a=currentAction();if(!a)return;a.fn()}
// contextual action
function currentAction(){if(G.mode!=='fly'||!P.alive)return null;
 if(DR)return {label:DR.lock>0?'Перегрев…':DR.full?'Трюм полон':'Держать бур',drill:true,fn:()=>{}};
 const c=nearCont();if(c)return {label:'Подобрать',fn:()=>pickup(c)};
 {const sa=secretsAction();if(sa)return sa}
 if(canDock()){const bl=dockBlocked(W.station.id);if(bl&&W.station.id.startsWith('bh_')&&!S.bhHanded)return {label:'Нужен допуск Гавани',fn:()=>uiNote(bl)};if(bl)return {label:'Компенсация '+compensation(W.station.id)+' кр.',fn:()=>{const r=payCompensation(W.station.id);uiNote(r||'Компенсация принята. Стыковка разрешена.')}};return {label:illegalCargo(W.station.id).length?'Стыковаться (досмотр!)':'Стыковаться',fn:startDocking}}
 if(canJump())return {label:'Прыжок → '+REG.systems[nearGate().to].name,fn:doJump};
 if(nearBeacon())return {label:'Переход по орбитам',fn:uiTransit};
 if(P.target&&P.target.kind==='ast'&&P.target.ore>0&&dist(P.target.pos,P.pos)-P.target.r<100)return {label:G.drillPending?'Торможение…':'Бурить',fn:startDrill};
 return null}
function nearCont(){let best=null,bd=70;for(const c of W.conts){const d=dist(c.pos,P.pos);if(d<bd){bd=d;best=c}}return best}
function pickup(c){if(!addCargo(c.item,c.qty)){const need=c.qty-cargoFree();uiNote(c.item in CITEMS?'Трюм полон. Пауза → Трюм → «Выбросить», чтобы освободить '+need+' мест':'Трюм полон: нет места для '+c.qty+' ед.');sfx('deny');return}
 W.conts=W.conts.filter(x=>x!==c);if(P.target===c)P.target=null;sfx('pickup');uiNote('В трюме: '+(CITEMS[c.item]||GOODS[c.item])+(c.qty>1?' ×'+c.qty:''));uiHintDone('pickup')}
function targetables(){const L=[];for(const e of W.enemies)L.push(e);if(W.transport)L.push(W.transport);for(const c of W.conts)L.push(c);
 for(const a of W.asts)if(a.ore>0&&dist(a.pos,P.pos)<2500)L.push(a);L.push(W.station,...W.gates,...W.pois);if(W.beacon)L.push(W.beacon);return L}
function cycleTarget(){const L=targetables().filter(t=>dist(t.pos,P.pos)<20000);const f=FWD(P.q);
 // enemies first, then by angle to nose
 L.sort((a,b)=>((a.kind==='enemy'?0:1)-(b.kind==='enemy'?0:1))||(Math.acos(clamp(dot(norm(sub(a.pos,P.pos)),f),-1,1))-Math.acos(clamp(dot(norm(sub(b.pos,P.pos)),f),-1,1))));
 if(!L.length)return;const i=L.indexOf(P.target);P.target=L[(i+1)%L.length];sfx('click')}

function worldStep(dt){ambient(dt);
 for(const e of W.enemies)updateEnemy(e,dt);
 // shots
 for(const s of W.shots){const a=s.p;s.p=add(s.p,scl(s.v,dt));s.life-=dt;const b=s.p;
  if(s.owner==='p'&&!s.ally&&W.npcs){let hitN=null;for(const n of W.npcs)if(segSphere(a,b,n.pos,n.r+s.r)){hitN=n;break}if(hitN){npcHit(hitN,s.dmg,b);s.life=0;continue}}
  if(s.owner==='p'){for(const e of W.enemies){if(e.dead)continue;
    if(e.cls==='capital'){if(dist(e.pos,b)<150&&hitCapital(e,a,b,s)){s.life=0;G.hitMark=.22;sfx('hit');break}continue}
    if(segSphere(a,b,e.pos,e.r+s.r)){damage(e,s.dmg,b,null,s);s.life=0;sfx('hit');G.hitMark=.22;if(s.slow)e.slowT=s.slow;if(s.disable){e.disT=s.disable;if(e.hull<e.max*.4&&!e.dropped){e.dropped=true;W.conts.push(makeCont(e.pos,'parts',2,scl(e.vel,.1)));uiNote('Цель обездвижена и сбросила груз')}}
     if(s.splash)for(const o of W.enemies)if(o!==e&&dist(o.pos,b)<s.splash)damage(o,s.dmg*.4,b,null,s);
     if(s.kind==='plasma')for(let i=0;i<14;i++)part(b,scl(rndDir(),rnd(10,35)),.5,[.6,1,.7],2);if(s.kind==='ion')for(let i=0;i<8;i++)part(b,scl(rndDir(),rnd(10,30)),.4,[.6,.6,1],1.6);break}}}
  else{if(P.alive&&segSphere(a,b,P.pos,5.5+s.r)){P.hitPt=b;damage(P,s.dmg,b,s.src,s);s.life=0}
   else if(P.alive&&s.kind!=='epulse_near'&&!s.nearDone&&dist(b,P.pos)<14){s.nearDone=true;sfx('whiz')}
   if(s.life>0&&W.transport&&!W.transport.dead){const t=W.transport;for(const k of [-25,-8,10,24]){if(segSphere(a,b,add(t.pos,qrot(t.q,[0,0,k])),9+s.r)){damage(t,s.dmg,b,s.src);s.life=0;break}}}
   if(s.life>0&&W.allies)for(const al of W.allies){if(!al.dead&&segSphere(a,b,al.pos,al.r+s.r)){damage(al,s.dmg,b,s.src);s.life=0;break}}}
  if(s.life>0)for(const as of W.asts){if(dist(as.pos,b)<as.r+60&&segSphere(a,b,as.pos,as.r*.95)){s.life=0;for(let i=0;i<5;i++)part(b,scl(rndDir(),rnd(5,20)),.3,[.9,.7,.5],1);break}}}
 W.shots=W.shots.filter(s=>s.life>0);if(W.shots.length>500)W.shots.splice(0,W.shots.length-500);
 updateMissiles(dt);
 W.enemies=W.enemies.filter(e=>!e.dead&&!e.gone);
 // containers
 for(const c of W.conts){c.pos=add(c.pos,scl(c.vel,dt));c.q=qnorm(qmul(c.spin,c.q));c.life-=dt}
 W.conts=W.conts.filter(c=>c.life>0);
 // pirate zone
 const z=W.sys.zone;if(z&&!G.duel&&(!z.after||S.ms[z.after].st==='done')&&!(W.m4&&W.m4.phase==='escort')){W.zoneCd-=dt;
  if(W.zoneCd<=0&&W.enemies.length===0&&dist(P.pos,z.pos)<z.r){W.zoneCd=75;z.spawn.forEach((t,i)=>spawnEnemy(t,add(z.pos,add(scl(rndDir(),500),[i*200,0,0])),P));uiNote('Пираты! Тревога')}}
 m4Step(dt);duelStep();campUpdate(dt);updateAllies(dt);updateNPCs(dt);secretsUpdate(dt);
 P.dmgDirs=P.dmgDirs.filter(d=>(d.t-=dt)>0);
}
function ambient(dt){for(const a of W.asts)a.q=qnorm(qmul(a.spin,a.q));W.ringRot=(W.ringRot||0)+dt*.05;
 for(const t of W.traffic)if(t.a){t.t+=dt*.025;const k=(Math.sin(t.t*Math.PI*2-Math.PI/2)+1)/2;const np=vlerp(t.a,t.b,k);const d=sub(np,t.pos);if(len(d)>.01)t.q=qslerp(t.q,qLook(d),damp(2,dt));t.pos=np}
 for(const p of W.parts){p.p=add(p.p,scl(p.v,dt));p.v=scl(p.v,1-dt*1.2);p.life-=dt}W.parts=W.parts.filter(p=>p.life>0)}
// ----- mission 4: escort -----
function m4Step(dt){if(W.id!=='inei'||!msActive('m4')||S.m4arrived)return;if(!W.m4)W.m4={phase:'goto',t:0,spawned:0};const m=W.m4;const wreck=W.pois.find(p=>p.id=='wreck').pos;
 if(m.phase==='goto'&&dist(P.pos,wreck)<900){m.phase='escort';m.t=0;m.spawned=0;const dock=stationWorld(STATIONS.verf9.entrance);const dir=norm(sub(dock,wreck));
  W.transport={kind:'transport',name:'Рудовоз «Тихоход»',pos:add(wreck,scl(dir,120)),q:qLook(dir),vel:[0,0,0],spd:0,hull:520,max:520,shield:0,r:30,shieldFx:0};P.target=W.transport;uiDialog(DLG.m4start,true)}
 if(m.phase==='escort'){m.t+=dt;const t=W.transport;const dock=stationWorld(STATIONS.verf9.entrance);const to=sub(dock,t.pos);const d=len(to);
  t.spd=lerp(t.spd,d<400?30:62,damp(.5,dt));t.q=turnToward(t.q,norm(to),dt*.3);t.vel=scl(FWD(t.q),t.spd);t.pos=add(t.pos,scl(t.vel,dt));
  const sp=(type,tgt)=>{const side=norm(cross(norm(to),[0,1,0]));const pos=add(t.pos,add(scl(norm(to),900),scl(side,(m.spawned%2?1:-1)*700)));const e=spawnEnemy(type,pos,tgt);m.spawned++;return e};
  if(m.spawned===0&&m.t>4){sp('interceptor',P);uiNote('Перехватчик заходит сбоку!')}
  if(m.spawned===1&&m.t>18){sp('interceptor',t);uiNote('Второй перехватчик атакует рудовоз!')}
  if(m.spawned===2&&(m.t>45||W.enemies.length===0)&&m.t>24){sp('heavy',t);uiNote('Тяжёлый налётчик! Следите за вспышкой на носу')}
  if(d<160){m.phase='arrived';S.m4arrived=true;W.transport=null;uiDialog(DLG.m4arrived,true)}}}
function retryM4(){W.enemies=[];W.shots=[];W.transport=null;W.m4={phase:'goto',t:0,spawned:0};uiNote('Сопровождение начнётся заново у обломков')}
function duelStep(){if(!G.duel||!P.alive)return;if(W.enemies.length===0){if(W.duelStage===0){W.duelStage=1;spawnEnemy('heavy',add(P.pos,add(scl(FWD(P.q),1100),[300,100,0])),P);uiNote('Второй противник: тяжёлый налётчик')}
 else if(W.duelStage===1){W.duelStage=2;uiDuelWin()}}}
