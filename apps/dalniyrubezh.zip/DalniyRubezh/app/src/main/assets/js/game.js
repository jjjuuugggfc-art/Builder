'use strict';
// ================= state =================
let S=null; // persistent save
const G={mode:'menu',time:0,duel:false,low:false,maxParts:2500};
let W=null; // world runtime
let P=null; // player runtime
const SET={vol:.7,quality:'high',invert:false};
try{Object.assign(SET,JSON.parse(localStorage.getItem(SET_KEY)||'{}'))}catch(e){}
function storeSettings(){try{localStorage.setItem(SET_KEY,JSON.stringify(SET))}catch(e){}}

function defaultSave(){return {v:SAVE_VER,sys:'yantar',station:'kromka',cr:600,ships:['strizh'],active:'strizh',mods:{shield:false,plasma:false},
 cargo:{ore:0,elec:0,meds:0,parts:0},citems:[],stocks:{kromka:{...STATIONS.kromka.stock},verf9:{...STATIONS.verf9.stock}},
 ms:{m1:{st:'active',paid:false},m2:{st:'locked',paid:false,mined:0},m3:{st:'locked',paid:false},m4:{st:'locked',paid:false}},
 contract:null,offers:{},tut:false,seenWreck:false,greeted:false,route:null}}
function hasSave(){try{return !!localStorage.getItem(SAVE_KEY)}catch(e){return false}}
function saveGame(){if(G.duel||!S)return;try{localStorage.setItem(SAVE_KEY,JSON.stringify(S))}catch(e){}}
function readSave(){try{const s=JSON.parse(localStorage.getItem(SAVE_KEY)||'null');if(!s||s.v!==SAVE_VER)return null;const d=defaultSave();
 const m=Object.assign(d,s);m.ms=Object.assign(defaultSave().ms,s.ms||{});m.cargo=Object.assign(d.cargo,s.cargo||{});return m}catch(e){return null}}

// ================= ship helpers =================
function shipStats(){const sh=SHIPS[S.active];return {...sh,shield:sh.shield+(S.mods.shield?35:0)}}
function cargoUsed(){let n=S.citems.length;for(const g of GOOD_IDS)n+=S.cargo[g];return n}
function cargoFree(){return shipStats().cargo-cargoUsed()}

// ================= world building =================
function buildSystem(id){const sys=SYSTEMS[id];const R=srand(id=='yantar'?42:7);
 W={id,sys,asts:[],enemies:[],shots:[],parts:[],conts:[],statics:[],lights:[],traffic:[],colliders:[],transport:null,zoneCd:20,station:null,gate:null,pois:[],dust:[]};
 const st=STATIONS[sys.station];W.station={kind:'station',id:sys.station,name:st.name,pos:[0,0,0],entrance:st.entrance,spot:st.spot,r:220,nav:true};
 W.gate={kind:'gate',name:'Ворота → '+SYSTEMS[sys.gate.to].name,pos:sys.gate.pos,dir:sys.gate.dir,q:qLook(sys.gate.dir),to:sys.gate.to,r:110,nav:true};
 for(const p of sys.pois)W.pois.push({kind:'poi',id:p.id,name:p.name,pos:p.pos,nav:true});
 // station colliders (AABB / ring)
 const A=(x0,x1,y0,y1,z0,z1)=>W.colliders.push({t:'box',min:[x0,y0,z0],max:[x1,y1,z1]});
 if(sys.station=='kromka'){A(-50,50,-50,50,-245,40);A(-56,-44,-33,33,40,172);A(44,56,-33,33,40,172);A(-56,56,22,33,40,172);A(-56,56,-33,-22,40,172);
  A(-23,23,43,73,-60,0);A(-23,23,-73,-43,-90,-30);A(43,73,-15,15,-130,-70);A(-73,-43,-15,15,-50,10);
  W.colliders.push({t:'ring',c:[0,0,-60],R:170,r:17},{t:'ring',c:[0,0,-140],R:170,r:17});
  for(const L of kromkaLights())W.lights.push(L);
  // traffic: tug shuttles between bay and parked ore carrier
  W.traffic.push({kind:'hauler',mesh:'transport',pos:[560,-140,560],q:qLook([1,0,.2]),s:1});
  W.traffic.push({kind:'tug',mesh:'tug',a:[0,-10,230],b:[520,-128,560],t:0,pos:[0,-10,230],q:[0,0,0,1],s:1});
 }else{A(-622,622,-12,32,-32,32);A(-60,60,-30,50,-50,10);A(-56,-44,-33,33,20,162);A(44,56,-33,33,20,162);A(-56,56,22,33,20,162);A(-56,56,-33,-22,20,162);
  for(const x of [-360,-200,220,400])W.colliders.push({t:'box',min:[x-45,-62,-70],max:[x+45,-58,70]});
  for(const L of verfLights())W.lights.push(L);
  W.traffic.push({kind:'drone',mesh:'tug',a:[-360,-40,140],b:[220,-40,140],t:.3,pos:[0,0,0],q:[0,0,0,1],s:.7});
 }
 // asteroid belt
 const b=sys.belt,n=Math.round(b.n*(G.low?.6:1));
 for(let i=0;i<n;i++){const a=R()*Math.PI*2,rr=b.R*Math.sqrt(R());const pos=add(b.c,[Math.cos(a)*rr,(R()*2-1)*b.h,Math.sin(a)*rr]);
  const ore=R()<b.ore;const r=ore?rnd(18,34):(R()<.15?rnd(50,90):rnd(10,40));
  const ast={kind:'ast',pos,r,q:qrand(R),spin:qaxis(rndDir(),rnd(-.08,.08)),ore:ore?Math.floor(rnd(3,7)):0,maxOre:0,
   mesh:ore?M.ast.ore[i%2]:b.ice?M.ast.ice[i%3]:M.ast.shapes[i%4],tint:.85+R()*.3,belt:id=='yantar'};ast.maxOre=ast.ore;if(ore)ast.name='Астероид с жилой';W.asts.push(ast)}
 for(const [x,y,z,r] of sys.debris)W.asts.push({kind:'debris',pos:[x,y,z],r,q:qrand(R),spin:qaxis(rndDir(),.1),ore:0,mesh:M.debris[W.asts.length%2],tint:1,name:'Обломок'});
 if(id=='inei'){const w=sys.pois[0].pos;W.statics.push({mesh:'wreck',pos:w,q:qaxis(norm([.3,1,.2]),.8),s:1.6});
  for(let i=0;i<10;i++)W.asts.push({kind:'debris',pos:add(w,[rnd(-180,180),rnd(-60,60),rnd(-180,180)]),r:rnd(5,12),q:qrand(),spin:qaxis(rndDir(),.15),ore:0,mesh:M.debris[i%2],tint:.7,name:'Обломок'})}
 if(id=='yantar'){W.statics.push({mesh:'buoy',pos:sys.pois[0].pos,q:[0,0,0,1],s:2.2,buoy:true});
  if(S.ms.m1.st==='active'&&!S.citems.includes('recorder'))W.conts.push(makeCont([-420,40,2350],'recorder',1,[-1.2,0,1.6]))}
 // space dust
 const dn=G.low?120:320;for(let i=0;i<dn;i++)W.dust.push([rnd(0,300),rnd(0,300),rnd(0,300)]);
 W.m4=null;
}
function makeCont(pos,item,qty,vel=[0,0,0]){const name=CITEMS[item]||GOODS[item];return {kind:'cont',pos:[...pos],vel,item,qty,name:'Контейнер: '+name+(qty>1?' ×'+qty:''),q:qrand(),spin:qaxis(rndDir(),.6),r:4,life:item in CITEMS?1e9:240}}

// ================= player =================
function newPlayer(){const st=shipStats();P={pos:[0,0,0],q:[0,0,0,1],vel:[0,0,0],spd:0,thr:0,boostT:3,boosting:false,hull:st.hull,shield:st.shield,shieldT:9,
 ang:[0,0,0],bank:0,weapon:0,cd:0,gun:0,target:null,nav:null,navUser:false,alive:true,kick:0,shake:0,dmgDirs:[],lastSrc:'',hitFx:0,hitPt:null,shieldFx:0}}
function stationWorld(v){return add(W.station.pos,v)}

// ================= flow =================
function newGame(){S=defaultSave();G.duel=false;saveGame();enterHangar(true)}
function continueGame(){const s=readSave();if(!s)return newGame();S=s;G.duel=false;enterHangar(false)}
function enterHangar(first){buildSystem(S.sys);newPlayer();const sp=stationWorld(STATIONS[S.station].spot);P.pos=sp;P.q=[0,0,0,1];G.mode='hangar';
 cam.mode='hangar';uiShowStation();if(first&&!S.greeted){S.greeted=true;saveGame();uiDialog(DLG.m1start)}}
function launch(){if(G.mode!=='hangar')return;uiHideStation();G.mode='launch';G.anim=0;const st=STATIONS[S.station];
 G.a0=stationWorld(st.spot);G.a1=stationWorld(add(st.entrance,[0,0,60]));P.q=[0,0,0,1];P.spd=0;sfx('dock')}
function startDocking(){if(G.mode!=='fly'||!canDock())return;G.mode='docking';G.anim=0;G.a0=[...P.pos];G.q0=[...P.q];P.target=null;stopDrill();
 const st=STATIONS[S.station];G.a1=stationWorld(st.entrance);G.a2=stationWorld(st.spot);sfx('dock')}
function canDock(){if(!W||G.duel||G.time-(G.launchT||-99)<8)return false;const e=stationWorld(STATIONS[W.station.id].entrance);const rel=sub(P.pos,e);return len(rel)<450&&rel[2]>-30&&P.spd<110&&!W.enemies.some(x=>dist(x.pos,P.pos)<1500)}
function finishDock(){S.station=W.station.id;S.sys=W.id;const st=shipStats();P.hull=st.hull;P.shield=st.shield;P.spd=0;P.vel=[0,0,0];
 W.enemies=[];W.shots=[];W.transport=null;G.mode='hangar';cam.mode='hangar';const msgs=turnInMissions();saveGame();uiShowStation();if(msgs.length)uiDialog(msgs)}
function playerDied(cause){if(!P.alive)return;P.alive=false;P.hull=0;explode(P.pos,1.6);sfx('explode');G.mode='dead';G.deathCause=cause;stopDrill();
 setTimeout(()=>uiDeath(cause),1400)}
function returnToDock(){if(G.duel){startDuel();return}const s=readSave();S=s||defaultSave();enterHangar(false)}

// ================= missions =================
function msActive(id){return S.ms[id].st==='active'}
function turnInMissions(){const out=[];const here=W.station.id;
 const pay=(id,dlg)=>{const m=S.ms[id];m.st='done';if(!m.paid){m.paid=true;S.cr+=MISSIONS.find(x=>x.id==id).reward}out.push(...dlg)};
 if(msActive('m1')&&here==='kromka'&&S.citems.includes('recorder')){S.citems=S.citems.filter(x=>x!=='recorder');pay('m1',DLG.m1done);S.ms.m2.st='offered'}
 if(msActive('m2')&&here==='kromka'&&S.ms.m2.mined>=3&&S.cargo.ore>=3){S.cargo.ore-=3;pay('m2',DLG.m2done);S.ms.m3.st='offered'}
 if(msActive('m3')&&here==='verf9'&&S.citems.includes('analyzer')){S.citems=S.citems.filter(x=>x!=='analyzer');pay('m3',DLG.m3done);S.ms.m4.st='offered'}
 if(msActive('m4')&&here==='verf9'&&S.m4arrived){S.m4arrived=false;pay('m4',DLG.m4done)}
 if(S.contract&&!S.contract.paid&&S.contract.to===here){const c=S.contract;if(c.good){const need=c.qty;const okMined=c.type!=='mine'||c.mined>=c.qty;
   if(S.cargo[c.good]>=need&&okMined){S.cargo[c.good]-=need;c.paid=true;S.cr+=c.reward;out.push(['Диспетчер','Контракт выполнен: +'+c.reward+' кр.']);S.contract=null;S.offers={}}}}
 if(S.ms.m4.st==='done')genOffers();
 return out}
function acceptMission(id){const m=S.ms[id];const def=MISSIONS.find(x=>x.id==id);if(m.st!=='offered')return 'Поручение недоступно';
 if(S.station!==def.from)return 'Это поручение выдают на станции '+STATIONS[def.from].name;
 if(id==='m3'){if(cargoFree()<1)return 'Нужно 1 свободное место в трюме: продайте что-нибудь на рынке';S.citems.push('analyzer');S.route='inei'}
 m.st='active';if(id==='m2')m.mined=0;saveGame();return ''}
function genOffers(){const here=S.station;if(S.offers[here]&&S.offers[here].length)return;const other=here==='kromka'?'verf9':'kromka';
 const g=here==='kromka'?'meds':'parts';const q=4+Math.floor(Math.random()*4);
 S.offers[here]=[{id:'d'+Date.now(),type:'deliver',good:g,qty:q,to:other,from:here,reward:120+q*35,name:'Доставка: '+GOODS[g]+' ×'+q+' → '+STATIONS[other].name},
  {id:'o'+Date.now(),type:'mine',good:'ore',qty:4,to:'kromka',from:here,reward:520,mined:0,name:'Добыча: руда ×4 → Кромка'}]}
function acceptContract(i){if(S.contract)return 'Сначала выполните текущий контракт';const c=S.offers[S.station][i];if(!c)return 'Нет контракта';S.contract={...c,paid:false,mined:0};S.offers[S.station]=[];saveGame();return ''}
function dropContract(){S.contract=null;saveGame()}
// current objective {text, target}
function objective(){const sys=W.id;
 const stationT=id=>{if(SYSTEMS[sys].station===id)return W.station;return W.gate};
 if(G.duel)return {text:W.enemies.length?'Дуэль: уничтожьте противника':'Дуэль завершена',target:W.enemies[0]||null};
 if(msActive('m1')){if(!S.citems.includes('recorder')){const c=W.conts.find(x=>x.item==='recorder');return {text:'Подберите самописец у буя №3',target:c||W.pois[0]}}
  return {text:'Вернуться на Кромку',target:stationT('kromka')}}
 if(S.ms.m2.st==='offered')return {text:'Новое поручение: откройте «Контракты» на Кромке',target:stationT('kromka')};
 if(msActive('m2')){const m=S.ms.m2;if(m.mined<3)return {text:'Добудьте руду в Медном поясе: '+m.mined+'/3',target:sys=='yantar'?W.pois.find(p=>p.id=='belt'):W.gate};
  return {text:'Доставьте руду на Кромку',target:stationT('kromka')}}
 if(S.ms.m3.st==='offered')return {text:'Новое поручение на Кромке',target:stationT('kromka')};
 if(msActive('m3'))return {text:'Доставьте анализатор на Верфь-9',target:stationT('verf9')};
 if(S.ms.m4.st==='offered')return {text:'Новое поручение на Верфи-9',target:stationT('verf9')};
 if(msActive('m4')){if(sys!=='inei')return {text:'Летите в Иней к обломкам конвоя',target:W.gate};const m=W.m4;
  if(S.m4arrived)return {text:'Рудовоз в доке. Состыкуйтесь с Верфью-9',target:W.station};
  if(!m||m.phase==='goto')return {text:'Летите к обломкам конвоя',target:W.pois.find(p=>p.id=='wreck')};
  if(m.phase==='escort'){const t=W.transport;return {text:'Рудовоз: корпус '+Math.ceil(t.hull/t.max*100)+'% · до дока '+fmtD(dist(t.pos,stationWorld(STATIONS.verf9.entrance))),target:t}}
  if(m.phase==='failed')return {text:'Рудовоз уничтожен',target:null}}
 if(S.contract){const c=S.contract;if(c.type==='mine'&&c.mined<c.qty)return {text:'Контракт: добудьте руду '+c.mined+'/'+c.qty,target:sys=='yantar'?W.pois.find(p=>p.id=='belt'):W.gate};
  return {text:'Контракт: '+GOODS[c.good]+' ×'+c.qty+' → '+STATIONS[c.to].name,target:stationT(c.to)}}
 return {text:'Свободный полёт',target:null}}
function fmtD(d){return d>=1000?(d/1000).toFixed(1)+' км':Math.round(d)+' м'}

// ================= cargo =================
function addCargo(item,qty){if(cargoFree()<qty)return false;if(item in CITEMS)S.citems.push(item);else S.cargo[item]+=qty;return true}
function jettison(g){if(!(g in S.cargo)||S.cargo[g]<=0)return;S.cargo[g]--;if(W&&(G.mode==='fly'||G.mode==='pause')){W.conts.push(makeCont(add(P.pos,scl(FWD(P.q),-20)),g,1,scl(P.vel,.3)))}}
// ================= market =================
function price(g,side){return STATIONS[S.station].prices[g][side==='buy'?0:1]}
function maxBuy(g){return Math.max(0,Math.min(Math.floor(S.cr/price(g,'buy')),S.stocks[S.station][g],cargoFree()))}
function buy(g,n){n=Math.floor(n);if(n<=0)return 'Выберите количество';const p=price(g,'buy');const st=S.stocks[S.station];
 if(st[g]<n)return 'На складе только '+st[g];if(cargoFree()<n)return 'В трюме свободно только '+cargoFree();if(S.cr<p*n)return 'Не хватает кредитов: нужно '+p*n;
 S.cr-=p*n;st[g]-=n;S.cargo[g]+=n;saveGame();return ''}
function sell(g,n){n=Math.floor(n);if(n<=0)return 'Выберите количество';if(S.cargo[g]<n)return 'У вас только '+S.cargo[g];
 const reserved=(S.ms.m2.st==='active'&&g==='ore'&&S.ms.m2.mined>=3)?3:0;if(reserved&&S.cargo[g]-n<reserved)return 'Эти 3 ед. руды нужны для поручения';
 const p=price(g,'sell');S.cr+=p*n;S.stocks[S.station][g]+=n;S.cargo[g]-=n;saveGame();return ''}
// ================= equipment =================
function buyMod(id){const m=MODS[id];if(S.mods[id])return 'Уже установлено';if(S.cr<m.price)return 'Не хватает '+(m.price-S.cr)+' кр.';S.cr-=m.price;S.mods[id]=true;
 if(id==='shield')P.shield=shipStats().shield;saveGame();return ''}
function buyShip(id){const s=SHIPS[id];if(S.ships.includes(id))return 'Корабль уже ваш';if(S.cr<s.price)return 'Не хватает '+(s.price-S.cr)+' кр.';
 S.cr-=s.price;S.ships.push(id);const r=switchShip(id);saveGame();return r?'Куплен. '+r:''}
function switchShip(id){if(!S.ships.includes(id))return 'Корабль не куплен';const need=cargoUsed()-SHIPS[id].cargo;if(need>0)return 'Сначала разгрузитесь: лишних '+need+' ед. груза';
 S.active=id;const st=shipStats();P.hull=st.hull;P.shield=st.shield;saveGame();return ''}

// ================= duel =================
function startDuel(){G.duel=true;S=defaultSave();S.mods.plasma=true;S.sys='inei';S.ms.m1.st='done';buildSystem('inei');newPlayer();
 const z=SYSTEMS.inei.zone.pos;P.pos=add(z,[0,0,-900]);P.q=[0,0,0,1];P.spd=80;P.thr=.6;P.vel=[0,0,80];G.mode='fly';cam.mode='chase';cam.reset=true;
 W.duelStage=0;spawnEnemy('interceptor',add(z,[400,80,500]),P);uiHideStation();uiNote('Дуэль: перехватчик. Затем — тяжёлый налётчик.')}
function exitDuel(){G.duel=false;S=readSave();G.mode='menu';uiMenu()}

// ================= enemies =================
function spawnEnemy(type,pos,tgt){const d=ENEMY[type];const e={kind:'enemy',type,name:d.name,pos:[...pos],q:qLook(sub(P.pos,pos)),vel:[0,0,0],spd:d.speed*.8,
 hull:d.hull,max:d.hull,shield:d.shield,maxSh:d.shield,shT:9,state:'approach',st:0,idx:W.enemies.length+Math.floor(Math.random()*5),cd:rnd(.5,1.5),burst:0,bursts:0,
 charge:0,chargeCd:rnd(3,5),tgt:tgt||P,r:d.r,shieldFx:0,hitPt:null,side:Math.random()<.5?1:-1};W.enemies.push(e);return e}
function tgtPos(e){return e.tgt===P?P.pos:e.tgt.pos}
function updateEnemy(e,dt){if(e.test){e.pos=add(e.pos,scl(e.vel,dt));return}const d=ENEMY[e.type];if(e.tgt!==P&&(!e.tgt||e.tgt.dead))e.tgt=P;
 const T=tgtPos(e),VT=e.tgt===P?P.vel:e.tgt.vel||[0,0,0];const rel=sub(T,e.pos),dd=len(rel);
 const f=FWD(e.q);const lt=leadTime(e.pos,e.vel,d.shotSpeed,T,VT);const aim=norm(sub(add(T,scl(VT,lt)),e.pos));const ang=Math.acos(clamp(dot(f,aim),-1,1));
 e.st+=dt;let want=aim,spd=d.speed;
 const ok=P.alive||e.tgt!==P;
 switch(e.state){
  case 'approach':{ // swing in from the side
   const side=norm(cross(rel,[0,1,0]));const off=dd>700?add(T,scl(side,e.side*Math.min(450,dd*.4))):T;want=norm(sub(off,e.pos));
   if(dd<850&&ang<.6){e.state='attack';e.st=0;e.bursts=0}break}
  case 'attack':{spd=d.speed*(e.type==='heavy'?.8:.9);
   if(ok&&ang<.07&&dd<760)fireEnemy(e,dt,f);
   if(dd<(e.type==='heavy'?240:170)||(e.type==='interceptor'&&e.bursts>=2)||e.st>(e.type==='heavy'?10:6)){e.state='breakoff';e.st=0;
    const up=[0,1,0];const ax=norm(cross(rel,up));const k=e.idx*2.3;e.bo=norm(add(add(scl(norm(rel),.7),scl(ax,Math.cos(k)*1.1)),[0,Math.sin(k)*.7,0]))}break}
  case 'breakoff':{want=e.bo;spd=d.speed;if(e.st>(e.type==='heavy'?3.4:2.6)||dd>1100){e.state='reattack';e.st=0}break}
  case 'reattack':{if(ang<.5&&dd<900){e.state='attack';e.st=0;e.bursts=0}if(e.st>8){e.state='approach'}break}
 }
 // heavy charged shot
 if(e.type==='heavy'&&ok){e.chargeCd-=dt;if(e.charge>0){e.charge-=dt;if(e.charge<=0){const nose=add(e.pos,qrot(e.q,[0,.1,9]));W.shots.push({p:nose,v:add(scl(f,330),e.vel),life:3,owner:'e',dmg:24,kind:'echarge',src:e,r:2.5});sfx('plasma');e.chargeCd=rnd(4.5,6)}}
  else if(e.chargeCd<=0&&ang<.12&&dd<800){e.charge=.5;if(dist(e.pos,P.pos)<1500)sfx('charge')}}
 // separation
 for(const o of W.enemies)if(o!==e){const v=sub(e.pos,o.pos),l=len(v);if(l<80&&l>0)want=norm(add(want,scl(v,1.5/l*(80-l)/80)))}
 for(const a of W.asts){const v=sub(e.pos,a.pos),l=len(v);if(l<a.r+40)want=norm(add(want,scl(v,2/l)))}
 e.q=turnToward(e.q,want,d.turn*dt);e.spd=lerp(e.spd,spd,damp(1.5,dt));const nf=FWD(e.q);e.vel=scl(nf,e.spd);e.pos=add(e.pos,scl(e.vel,dt));
 e.shT+=dt;if(e.shT>5)e.shield=Math.min(e.maxSh,e.shield+dt*6);e.shieldFx=Math.max(0,e.shieldFx-dt*3);
}
function fireEnemy(e,dt,f){const d=ENEMY[e.type];e.cd-=dt;if(e.cd>0)return;
 if(e.type==='interceptor'){e.burst++;e.cd=.09;if(e.burst>=5){e.burst=0;e.bursts++;e.cd=1.1}}else e.cd=.32;
 const gp=add(e.pos,qrot(e.q,[e.burst%2?3.5:-3.5,0,3]));const dir=norm(add(f,scl(rndDir(),.012)));
 W.shots.push({p:gp,v:add(scl(dir,d.shotSpeed),e.vel),life:1.8,owner:'e',dmg:d.dmg,kind:'epulse',src:e,r:1});if(dist(e.pos,P.pos)<1200)sfx('enemyShot')}

// ================= damage =================
function damage(t,amt,pt,src){const isP=t===P;
 if(t.shield>0){t.shield-=amt;t.shieldFx=1;t.hitPt=pt;if(t.shield<0){t.hull+=t.shield;t.shield=0}if(isP||dist(t.pos,P.pos)<900)sfx('shieldHit');
  for(let i=0;i<6;i++)part(pt,scl(rndDir(),rnd(5,20)),.35,[.4,.8,1],1.2)}
 else{t.hull-=amt;if(isP||dist(t.pos,P.pos)<900)sfx('hullHit');for(let i=0;i<12;i++)part(pt,scl(rndDir(),rnd(10,45)),rnd(.3,.7),[1,.75,.35],.8);
  for(let i=0;i<4;i++)part(pt,scl(rndDir(),rnd(4,12)),rnd(1,2),[.35,.33,.3],1.4,true)}
 if(isP){P.shieldT=0;P.shake=Math.min(1,P.shake+(t.shield>0?.25:.5));if(src){P.dmgDirs.push({from:src.pos?[...src.pos]:src,t:1.2});P.lastSrc=src.name||'огонь противника'}
  if(P.hull<=0)playerDied(src&&src.name?'Корабль уничтожен: '+src.name.toLowerCase():'Корабль уничтожен')}
 else{t.shT=0;if(t.hull<=0&&!t.dead){t.dead=true;onKill(t)}}}
function onKill(t){explode(t.pos,t.type==='heavy'?1.3:1);sfx('explode');
 if(t.kind==='enemy'){if(P.target===t)P.target=null;const chance=t.type==='heavy'?.75:.45;if(Math.random()<chance&&!G.duel){const g=Math.random()<.5?'parts':'elec';W.conts.push(makeCont(t.pos,g,1+Math.floor(Math.random()*2),scl(t.vel,.05)))}}
 if(t.kind==='transport'&&W.m4){W.m4.phase='failed';uiM4Failed()}}
function explode(p,s){part(p,[0,0,0],.35,[1,.9,.7],22*s);part(p,[0,0,0],.55,[1,.55,.2],14*s);
 const n=G.low?18:40;for(let i=0;i<n;i++)part(p,scl(rndDir(),rnd(10,60)*s),rnd(.3,.8),Math.random()<.5?[1,.6,.2]:[1,.85,.5],rnd(1.5,3.5)*s);
 for(let i=0;i<10;i++)part(p,scl(rndDir(),rnd(5,25)),rnd(1.2,2.4),[.3,.28,.26],rnd(1,2),true)}
function part(p,v,life,c,s,dark){if(W.parts.length>=G.maxParts)return;W.parts.push({p:[...p],v,life,max:life,c,s,dark})}

// ================= mining =================
let DR=null;
function canDrill(){const t=P.target;return t&&t.kind==='ast'&&t.ore>0&&dist(t.pos,P.pos)-t.r<100}
function startDrill(){if(!canDrill())return;if(P.spd>30){uiNote('Сбавьте скорость, чтобы бурить');return}DR={ast:P.target,heat:0,zone:0,lock:0,hold:false};uiNote('Держите кнопку бура: держите стрелку в зелёной зоне')}
function stopDrill(){DR=null;sndDrill(false,0)}
function updateDrill(dt,hold){if(!DR)return;const a=DR.ast;
 if(!a||a.ore<=0){stopDrill();uiNote('Жила исчерпана');return}
 if(dist(a.pos,P.pos)-a.r>100){stopDrill();uiNote('Добыча прервана: слишком далеко');return}
 if(cargoFree()<=0){DR.hold=false;sndDrill(false,0);DR.full=true;DR.heat=Math.max(0,DR.heat-dt*.4);return}DR.full=false;
 if(DR.lock>0){DR.lock-=dt;DR.heat=Math.max(0,DR.heat-dt*.35);sndDrill(false,0);return}
 DR.hold=hold;DR.heat=clamp(DR.heat+(hold?.55:-.4)*dt,0,1.05);sndDrill(hold,DR.heat);
 if(DR.heat>=1){DR.lock=2;DR.zone=Math.max(0,DR.zone-.5);sfx('overheat');uiNote('Перегрев! Бур отключён на 2 секунды');return}
 if(DR.heat>=.55&&DR.heat<=.8){DR.zone+=dt;if(hold)for(let i=0;i<2;i++)part(veinPos(a),scl(rndDir(),rnd(5,15)),.4,[1,.6,.25],1.2)}
 if(DR.zone>=2){DR.zone=0;a.ore--;S.cargo.ore++;sfx('ore');uiNote('+1 руда · в жиле осталось '+a.ore);
  if(a.belt&&msActive('m2'))S.ms.m2.mined++;if(S.contract&&S.contract.type==='mine'&&a.belt)S.contract.mined++}}
function veinPos(a){return add(a.pos,qrot(a.q,scl([0,.85,0],a.r)))}

// ================= gates =================
function canJump(){return W&&!G.duel&&dist(P.pos,W.gate.pos)<450&&G.mode==='fly'}
function doJump(){if(G.mode!=='fly'||!canJump())return;if(!S.route||S.route===W.id){uiMap();return}G.mode='jump';G.anim=0;stopDrill();sfx('jump')}
function finishJump(){const to=W.gate.to;const hull=P.hull,sh=P.shield,wep=P.weapon;S.sys=to;buildSystem(to);const g=W.gate;
 newPlayer();P.hull=hull;P.shield=sh;P.weapon=wep;P.pos=add(g.pos,scl(g.dir,260));P.q=qLook(g.dir);P.spd=70;P.thr=.5;P.vel=scl(g.dir,70);
 G.mode='fly';cam.reset=true;S.route=null;uiNote('Система «'+SYSTEMS[to].name+'»');
 if(to==='inei'&&msActive('m3')&&!S.seenWreck){S.seenWreck=true;uiDialog(DLG.m3arrive,true)}}

// ================= update =================
function update(dt){G.time+=dt;if(!W)return;
 if(G.mode==='launch'){G.anim+=dt;const k=clamp(G.anim/2,0,1),e=k*k*(3-2*k);P.pos=vlerp(G.a0,G.a1,e);P.spd=lerp(0,60,k);P.vel=scl(FWD(P.q),P.spd);
  if(k>=1){G.mode='fly';P.thr=.35;P.spd=60;cam.mode='chase';G.launchT=G.time;uiFlightStart()}}
 else if(G.mode==='docking'){G.anim+=dt;const k=clamp(G.anim/2.6,0,1);const e=k*k*(3-2*k);
  const mid=k<.5?vlerp(G.a0,G.a1,e*2>1?1:e*2):vlerp(G.a1,G.a2,(e-.5)*2);P.pos=k<.5?vlerp(G.a0,G.a1,Math.min(1,e*2)):vlerp(G.a1,G.a2,clamp((e-.5)*2,0,1));
  P.q=qslerp(G.q0,[0,0,0,1],Math.min(1,k*1.6));P.spd=lerp(P.spd,10,damp(2,dt));if(k>=1)finishDock()}
 else if(G.mode==='jump'){G.anim+=dt;P.pos=add(P.pos,scl(FWD(P.q),dt*(150+G.anim*400)));P.q=turnToward(P.q,norm(sub(W.gate.pos,P.pos)),dt*1.5);if(G.anim>=1.6)finishJump()}
 else if(G.mode==='fly')flight(dt);
 if(G.mode==='fly'||G.mode==='dead'||G.mode==='jump'||G.mode==='launch'||G.mode==='docking')worldStep(dt);
 else ambient(dt);
 sndEngine(P?P.thr:0,P&&P.boosting,G.mode==='fly'||G.mode==='launch'||G.mode==='docking');}
function flight(dt){const st=shipStats();const I=IN;
 // rotation with smooth response
 const inv=SET.invert?-1:1;const tgt=[I.pitch*inv*st.turn*.9,I.yaw*st.turn,I.roll*2.2];
 for(let i=0;i<3;i++)P.ang[i]=lerp(P.ang[i],tgt[i],damp(7,dt));
 P.q=qnorm(qmul(P.q,qaxis([0,1,0],-P.ang[1]*dt)));P.q=qnorm(qmul(P.q,qaxis([1,0,0],-P.ang[0]*dt)));P.q=qnorm(qmul(P.q,qaxis([0,0,1],P.ang[2]*dt)));
 P.bank=lerp(P.bank,P.ang[1]/st.turn*.62,damp(4,dt));
 // throttle & boost
 if(I.thrSet!==null){P.thr=I.thrSet;I.thrSet=null}P.thr=clamp(P.thr+I.thrDelta*dt*.7,0,1);
 P.boosting=I.boost&&P.boostT>0.05;if(P.boosting)P.boostT=Math.max(0,P.boostT-dt);else P.boostT=Math.min(3,P.boostT+dt*3/7);
 const want=P.boosting?st.boost:st.speed*P.thr;const acc=want>P.spd?(P.boosting?110:55):65;P.spd+=clamp(want-P.spd,-acc*dt,acc*dt);
 const f=FWD(P.q);P.vel=vlerp(P.vel,scl(f,P.spd),damp(3.2,dt));P.pos=add(P.pos,scl(P.vel,dt));
 // shields
 P.shieldT+=dt;if(P.shieldT>5)P.shield=Math.min(st.shield,P.shield+dt*10);P.shieldFx=Math.max(0,P.shieldFx-dt*3);
 // weapons
 P.cd-=dt;const w=WEAPONS[P.weapon];
 if(I.fire&&P.cd<=0&&!DR){P.cd=1/w.rate;
  if(P.weapon===0){P.gun^=1;const g=GUNS[S.active][P.gun];const gp=add(P.pos,qrot(P.q,g));W.shots.push({p:gp,v:add(P.vel,scl(f,w.speed)),life:w.life,owner:'p',dmg:w.dmg,kind:'pulse',r:1.2});
   part(add(gp,scl(f,1)),scl(P.vel,1),.06,[.5,.9,1],2.4);sfx('pulse')}
  else{const gp=add(P.pos,qrot(P.q,[0,-.3,7.5]));W.shots.push({p:gp,v:add(P.vel,scl(f,w.speed)),life:w.life,owner:'p',dmg:w.dmg,kind:'plasma',r:3});
   part(gp,scl(P.vel,1),.12,[.6,1,.7],6);P.spd=Math.max(0,P.spd-8);sfx('plasma')}
  P.kick+=w.kick}
 P.kick=Math.max(0,P.kick-dt*3);P.shake=Math.max(0,P.shake-dt*2);
 // edges
 if(I.weaponEdge){I.weaponEdge=false;if(S.mods.plasma){P.weapon^=1;uiNote(WEAPONS[P.weapon].name)}}
 if(I.targetEdge){I.targetEdge=false;cycleTarget()}
 if(I.actionEdge){I.actionEdge=false;doAction()}
 updateDrill(dt,I.actionHeld||I.fire);
 // collisions
 collide(dt);
 const R=len(P.pos);if(R>W.sys.bound){P.q=turnToward(P.q,norm(scl(P.pos,-1)),dt*1.2);if(!G.boundNote||G.time-G.boundNote>4){G.boundNote=G.time;uiNote('Граница системы — разворот')}}
 // nav target
 if(P.target&&(P.target.dead||(P.target.kind==='cont'&&!W.conts.includes(P.target))))P.target=null;
}
function collide(){const r=4.5;
 const hit=(n,why,dmg)=>{P.pos=n;const d=Math.max(4,P.spd*.3)*dmg;P.spd*=.3;P.vel=scl(P.vel,.3);damage(P,d,P.pos,{name:why,pos:P.pos});P.lastSrc=why};
 for(const a of W.asts){const v=sub(P.pos,a.pos),l=len(v);const rr=a.r*.92+r;if(l<rr){hit(add(a.pos,scl(v,rr/(l||1))),'Столкновение с астероидом',1);if(!P.alive){G.deathCause='Корабль разбит о '+(a.kind==='debris'?'обломок':'астероид')}return}}
 for(const c of W.colliders){if(c.t==='box'){const p=P.pos;if(p[0]>c.min[0]-r&&p[0]<c.max[0]+r&&p[1]>c.min[1]-r&&p[1]<c.max[1]+r&&p[2]>c.min[2]-r&&p[2]<c.max[2]+r){
   let best=1e9,ax=0,sg=1;for(let i=0;i<3;i++){const a=p[i]-(c.min[i]-r),b=(c.max[i]+r)-p[i];if(a<best){best=a;ax=i;sg=-1}if(b<best){best=b;ax=i;sg=1}}
   const n=[...p];n[ax]+=sg*(best+.1);hit(n,'Столкновение со станцией',.6);return}}
  else{const rel=sub(P.pos,c.c);const pr=[rel[0],rel[1],0];const lr=len(pr)||1;const near=add(c.c,scl(pr,c.R/lr));const v=sub(P.pos,near),l=len(v);if(l<c.r+r){hit(add(near,scl(v,(c.r+r)/(l||1))),'Столкновение со станцией',.6);return}}}
 for(const pl of [W.sys.planet,W.sys.moon]){const v=sub(P.pos,pl.pos);if(len(v)<pl.r+200){P.pos=add(pl.pos,scl(norm(v),pl.r+200));P.spd*=.5}}}
function doAction(){const a=currentAction();if(!a)return;a.fn()}
// contextual action
function currentAction(){if(G.mode!=='fly'||!P.alive)return null;
 if(DR)return {label:DR.lock>0?'Перегрев…':DR.full?'Трюм полон':'Держать бур',drill:true,fn:()=>{}};
 const c=nearCont();if(c)return {label:'Подобрать',fn:()=>pickup(c)};
 if(canDock())return {label:'Стыковаться',fn:startDocking};
 if(canJump())return {label:S.route&&S.route!==W.id?'Прыжок → '+SYSTEMS[W.gate.to].name:'Выбрать маршрут',fn:doJump};
 if(P.target&&P.target.kind==='ast'&&P.target.ore>0&&dist(P.target.pos,P.pos)-P.target.r<100)return {label:P.spd>30?'Сбавьте ход':'Бурить',fn:startDrill};
 return null}
function nearCont(){let best=null,bd=70;for(const c of W.conts){const d=dist(c.pos,P.pos);if(d<bd){bd=d;best=c}}return best}
function pickup(c){if(!addCargo(c.item,c.qty)){const need=c.qty-cargoFree();uiNote(c.item in CITEMS?'Трюм полон. Пауза → Трюм → «Выбросить», чтобы освободить '+need+' мест':'Трюм полон: нет места для '+c.qty+' ед.');sfx('deny');return}
 W.conts=W.conts.filter(x=>x!==c);if(P.target===c)P.target=null;sfx('pickup');uiNote('В трюме: '+(CITEMS[c.item]||GOODS[c.item])+(c.qty>1?' ×'+c.qty:''));uiHintDone('pickup')}
function targetables(){const L=[];for(const e of W.enemies)L.push(e);if(W.transport)L.push(W.transport);for(const c of W.conts)L.push(c);
 for(const a of W.asts)if(a.ore>0&&dist(a.pos,P.pos)<2500)L.push(a);L.push(W.station,W.gate,...W.pois);return L}
function cycleTarget(){const L=targetables().filter(t=>dist(t.pos,P.pos)<20000);const f=FWD(P.q);
 // enemies first, then by angle to nose
 L.sort((a,b)=>((a.kind==='enemy'?0:1)-(b.kind==='enemy'?0:1))||(Math.acos(clamp(dot(norm(sub(a.pos,P.pos)),f),-1,1))-Math.acos(clamp(dot(norm(sub(b.pos,P.pos)),f),-1,1))));
 if(!L.length)return;const i=L.indexOf(P.target);P.target=L[(i+1)%L.length];sfx('click')}

function worldStep(dt){ambient(dt);
 for(const e of W.enemies)updateEnemy(e,dt);
 // shots
 for(const s of W.shots){const a=s.p;s.p=add(s.p,scl(s.v,dt));s.life-=dt;const b=s.p;
  if(s.owner==='p'){for(const e of W.enemies){if(!e.dead&&segSphere(a,b,e.pos,e.r+s.r)){damage(e,s.dmg,b,null);s.life=0;sfx('hit');if(s.kind==='plasma')for(let i=0;i<14;i++)part(b,scl(rndDir(),rnd(10,35)),.5,[.6,1,.7],2);break}}}
  else{if(P.alive&&segSphere(a,b,P.pos,5.5+s.r)){P.hitPt=b;damage(P,s.dmg,b,s.src);s.life=0}
   else if(W.transport&&!W.transport.dead){const t=W.transport;for(const k of [-25,-8,10,24]){if(segSphere(a,b,add(t.pos,qrot(t.q,[0,0,k])),9+s.r)){damage(t,s.dmg,b,s.src);s.life=0;break}}}}
  if(s.life>0)for(const as of W.asts){if(dist(as.pos,b)<as.r+60&&segSphere(a,b,as.pos,as.r*.95)){s.life=0;for(let i=0;i<5;i++)part(b,scl(rndDir(),rnd(5,20)),.3,[.9,.7,.5],1);break}}}
 W.shots=W.shots.filter(s=>s.life>0);if(W.shots.length>400)W.shots.splice(0,W.shots.length-400);
 W.enemies=W.enemies.filter(e=>!e.dead);
 // containers
 for(const c of W.conts){c.pos=add(c.pos,scl(c.vel,dt));c.q=qnorm(qmul(c.spin,c.q));c.life-=dt}
 W.conts=W.conts.filter(c=>c.life>0);
 // pirate zone
 const z=W.sys.zone;if(z&&!G.duel&&(!z.after||S.ms[z.after].st==='done')&&!(W.m4&&W.m4.phase==='escort')){W.zoneCd-=dt;
  if(W.zoneCd<=0&&W.enemies.length===0&&dist(P.pos,z.pos)<z.r){W.zoneCd=75;z.spawn.forEach((t,i)=>spawnEnemy(t,add(z.pos,add(scl(rndDir(),500),[i*200,0,0])),P));uiNote('Пираты! Тревога')}}
 m4Step(dt);duelStep();
 P.dmgDirs=P.dmgDirs.filter(d=>(d.t-=dt)>0);
}
function ambient(dt){for(const a of W.asts)a.q=qnorm(qmul(a.spin,a.q));W.ringRot=(W.ringRot||0)+dt*.05;
 for(const t of W.traffic)if(t.a){t.t+=dt*.025;const k=(Math.sin(t.t*Math.PI*2-Math.PI/2)+1)/2;const np=vlerp(t.a,t.b,k);const d=sub(np,t.pos);if(len(d)>.01)t.q=qslerp(t.q,qLook(d),damp(2,dt));t.pos=np}
 for(const p of W.parts){p.p=add(p.p,scl(p.v,dt));p.v=scl(p.v,1-dt*1.2);p.life-=dt}W.parts=W.parts.filter(p=>p.life>0)}
// ----- mission 4: escort -----
function m4Step(dt){if(W.id!=='inei'||!msActive('m4')||S.m4arrived)return;if(!W.m4)W.m4={phase:'goto',t:0,spawned:0};const m=W.m4;const wreck=W.pois.find(p=>p.id=='wreck').pos;
 if(m.phase==='goto'&&dist(P.pos,wreck)<900){m.phase='escort';m.t=0;m.spawned=0;const dock=stationWorld(STATIONS.verf9.entrance);const dir=norm(sub(dock,wreck));
  W.transport={kind:'transport',name:'Рудовоз «Тихоход»',pos:add(wreck,scl(dir,120)),q:qLook(dir),vel:[0,0,0],spd:0,hull:520,max:520,shield:0,r:30,shieldFx:0};P.target=W.transport;uiDialog(DLG.m4start,true)}
 if(m.phase==='escort'){m.t+=dt;const t=W.transport;const dock=stationWorld(STATIONS.verf9.entrance);const to=sub(dock,t.pos);const d=len(to);
  t.spd=lerp(t.spd,d<400?30:62,damp(.5,dt));t.q=turnToward(t.q,norm(to),dt*.3);t.vel=scl(FWD(t.q),t.spd);t.pos=add(t.pos,scl(t.vel,dt));
  const sp=(type,tgt)=>{const side=norm(cross(norm(to),[0,1,0]));const pos=add(t.pos,add(scl(norm(to),900),scl(side,(m.spawned%2?1:-1)*700)));const e=spawnEnemy(type,pos,tgt);m.spawned++;return e};
  if(m.spawned===0&&m.t>4){sp('interceptor',P);uiNote('Перехватчик заходит сбоку!')}
  if(m.spawned===1&&m.t>18){sp('interceptor',t);uiNote('Второй перехватчик атакует рудовоз!')}
  if(m.spawned===2&&(m.t>45||W.enemies.length===0)&&m.t>24){sp('heavy',t);uiNote('Тяжёлый налётчик! Следите за вспышкой на носу')}
  if(d<160){m.phase='arrived';S.m4arrived=true;W.transport=null;uiDialog(DLG.m4arrived,true)}}}
function retryM4(){W.enemies=[];W.shots=[];W.transport=null;W.m4={phase:'goto',t:0,spawned:0};uiNote('Сопровождение начнётся заново у обломков')}
function duelStep(){if(!G.duel||!P.alive)return;if(W.enemies.length===0){if(W.duelStage===0){W.duelStage=1;spawnEnemy('heavy',add(P.pos,add(scl(FWD(P.q),1100),[300,100,0])),P);uiNote('Второй противник: тяжёлый налётчик')}
 else if(W.duelStage===1){W.duelStage=2;uiDuelWin()}}}
