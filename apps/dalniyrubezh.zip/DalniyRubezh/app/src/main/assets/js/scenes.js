'use strict';
// ================= staged in-engine scenes (skippable) =================
const SCENES={
 first:{cap:['«Стриж» выходит из ангара «Кромки»','Где-то в этом секторе пропадают рудовозы.'],dur:6,shot:()=>({focus:P.pos,a:[-26,6,30],b:[22,10,-26]})},
 aged:{cap:['«Северянка» выходит из ворот','Корпус — как после тридцати лет рейсов.'],dur:6,shot:()=>{const f=W.cmFreighter||{pos:P.pos};return {focus:f.pos,a:[90,30,60],b:[-60,40,120],track:f}}},
 teira:{cap:['Пространство Домов Тейра','Здесь каждый корабль — чьё-то наследство.'],dur:6,shot:()=>({focus:W.station.pos,a:[900,300,1400],b:[-700,200,1600]})},
 garden:{cap:['Немой Сад','Хоры, умолкшие столетия назад.'],dur:6,shot:()=>({focus:W.station.pos,a:[600,-200,1200],b:[-500,400,900]})},
 harbor:{cap:['Чёрная Гавань','Первые огни порта, которого нет на картах.'],dur:6,shot:()=>({focus:W.station.pos,a:[700,150,1500],b:[200,60,700]})},
 evac:{cap:['Окна прыжка','Пятнадцать секунд, чтобы уйти. Тридцать — чтобы дождаться.'],dur:5,shot:()=>{const g=W.gates.find(x=>x.to==='gar')||W.gates[0];return {focus:g.pos,a:[300,120,500],b:[-300,80,600]}}},
 core:{cap:['Изнанка','То, что держит все ворота сразу.'],dur:7,shot:()=>({focus:W.station.pos,a:[1200,400,2600],b:[300,100,1200]})},
 home:{cap:['Дом','Свой причал на краю привычных маршрутов.'],dur:5,shot:()=>({focus:W.station.pos,a:[500,120,900],b:[-200,60,500]})}};
function playScene(id){if(!S||G.duel||!SCENES[id]||window.NOSCENE)return;S.scenes=S.scenes||{};if(S.scenes[id])return;S.scenes[id]=true;const sh=SCENES[id].shot();G.scene={id,t:0,shot:sh,prev:G.mode==='scene'?'fly':G.mode};G.mode='scene';resetInput();sfx('radio')}
function sceneStep(dt){const sc=G.scene;if(!sc)return;sc.t+=dt;if(sc.shot.track)sc.shot.focus=sc.shot.track.pos;if(sc.t>=SCENES[sc.id].dur)endScene()}
function endScene(){if(!G.scene)return;G.mode=G.scene.prev||'fly';G.scene=null;cam.reset=true;lastT=performance.now()}
function sceneCamera(){const sc=G.scene;const k=clamp(sc.t/SCENES[sc.id].dur,0,1),e=k*k*(3-2*k);const sh=sc.shot;return {eye:add(sh.focus,vlerp(sh.a,sh.b,e)),look:sh.focus}}
function drawScene(){const sc=G.scene;if(!sc)return;const w=SW,h=SH;const bar=Math.round(h*.11);hx.fillStyle='#000';hx.fillRect(0,0,w,bar);hx.fillRect(0,h-bar,w,bar);
 const d=SCENES[sc.id];const a=Math.min(1,sc.t*1.5,(d.dur-sc.t)*1.5);hx.globalAlpha=Math.max(0,a);txt(d.cap[0],w/2,h-bar-34,'#ffe0b0',20,'center',true);txt(d.cap[1],w/2,h-bar-12,'#cfe0ff',13,'center',true);hx.globalAlpha=1;
 txt('Пропустить ›',w-16,bar-12,'#9fb6d8',13,'right',true)}
