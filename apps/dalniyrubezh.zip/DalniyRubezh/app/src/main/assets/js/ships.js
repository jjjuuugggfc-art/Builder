'use strict';
// ================= FLEET, WEAPONS, MODULES (original designs) =================
// ---- parametric hull builder ----
// p: {L,W,H,nose,wing,span,wingT,wingSweep,eng:[[x,y,r]],engZ,canopy:{z,h,w},keels,radiator,tanks,cargoFrame,arcs,asym,pal,acc}
const PAL={league:{hull:C(.76,.79,.85),mid:C(.52,.56,.64),dark:C(.26,.29,.35),acc:C(.25,.55,.95)},union:{hull:C(.56,.55,.52),mid:C(.42,.41,.39),dark:C(.22,.21,.2),acc:C(.95,.6,.15)},
 teira:{hull:C(.62,.44,.33),mid:C(.45,.3,.22),dark:C(.24,.15,.12),acc:C(.95,.5,.2)},essen:{hull:C(.74,.84,.86),mid:C(.5,.62,.66),dark:C(.24,.32,.36),acc:C(.45,1,.88,.6)},
 wake:{hull:C(.46,.38,.33),mid:C(.36,.33,.31),dark:C(.18,.16,.15),acc:C(.85,.25,.2)},border:{hull:C(.5,.53,.5),mid:C(.38,.4,.38),dark:C(.2,.22,.2),acc:C(.85,.35,.2)},
 exp:{hull:C(.3,.31,.36),mid:C(.2,.21,.25),dark:C(.1,.1,.12),acc:C(.95,.35,.15,.4)},relic:{hull:C(.2,.18,.25),mid:C(.14,.12,.18),dark:C(.06,.05,.08),acc:C(.95,.78,.38,.7)}};
function buildHull(p){const t=[];const pl=PAL[p.pal]||PAL.league;const hull=pl.hull,mid=pl.mid,dark=pl.dark,acc=pl.acc;const glass=C(.05,.08,.13);
 const L=p.L,W=p.W,H=p.H,zN=L/2,zT=-L/2;
 const sec=(z,w,h,b)=>({z,p:[[0,h],[-w*.72,h*.55],[-w,-.05*h],[-w*.62,-b],[w*.62,-b],[w,-.05*h],[w*.72,h*.55]]});
 let S0;if(p.nose==='blunt')S0=sec(zN,W*.55,H*.45,H*.4);else if(p.nose==='needle')S0={z:zN+L*.15,p:Array(7).fill([0,0])};else S0={z:zN,p:Array(7).fill([0,-H*.05])};
 const secs=[S0,sec(zN-L*.22,W*.6,H*.55,H*.45),sec(zN-L*.5,W,H*.9,H*.75),sec(zT+L*.18,W*.95,H*.85,H*.7),sec(zT,W*.78,H*.65,H*.55)];
 loft(t,secs,(s,i)=>{if(i===2||i===3)return tone(dark,1.1);if(i===0||i===6)return tone(hull,s%2?.96:1.04);if(s===0&&p.noseAcc)return acc;return tone(mid,s%2?.94:1.05)},I,tone(dark,.8));
 // fork nose: two prongs
 if(p.nose==='fork')for(const sx of [-1,1]){loft(t,[{z:zN-L*.1,p:[[sx*W*.25,H*.3],[sx*W*.7,H*.3],[sx*W*.7,-H*.35],[sx*W*.25,-H*.35]]},{z:zN+L*.32,p:[[sx*W*.38,H*.08],[sx*W*.5,H*.08],[sx*W*.5,-H*.12],[sx*W*.38,-H*.12]]}],(s,i)=>i%2?acc:hull)}
 // canopy
 const cz=p.canopy?p.canopy.z:zN-L*.3,ch=p.canopy?p.canopy.h:H*.5,cw=p.canopy?p.canopy.w:W*.45,cx=p.canopy&&p.canopy.x||0;
 loft(t,[{z:cz+L*.12,p:[[cx,H*.55],[cx-.05,H*.5],[cx+.05,H*.5]]},{z:cz,p:[[cx,H*.55+ch],[cx-cw,H*.6],[cx+cw,H*.6]]},{z:cz-L*.14,p:[[cx,H*.5+ch*.8],[cx-cw*.8,H*.62],[cx+cw*.8,H*.62]]}],(s,i)=>i===0?glass:tone(glass,1.6),I,dark);
 // wings
 const span=p.span||W*2.6,wt=p.wingT||.35,wz=p.wingZ!=null?p.wingZ:zN-L*.45,sw=p.wingSweep!=null?p.wingSweep:L*.3,chord=p.chord||L*.38;
 const wing=(sd,root,tip)=>{const X=v=>[v[0]*sd,v[1],v[2]];const up=(v,th)=>[v[0],v[1]+th/2,v[2]],dn=(v,th)=>[v[0],v[1]-th/2,v[2]];
  const [RL,RT,TL,TT,rt,tt]=[root[0],root[1],tip[0],tip[1],wt,wt*.45];const a=[up(RL,rt),up(TL,tt),up(TT,tt),up(RT,rt)],b=[dn(RL,rt),dn(TL,tt),dn(TT,tt),dn(RT,rt)];
  Q(t,a[0],a[1],a[2],a[3],tone(hull,1.02),X);Q(t,b[0],b[3],b[2],b[1],dark,X);Q(t,a[0],b[0],b[1],a[1],p.wingAcc===false?mid:acc,X);Q(t,a[1],b[1],b[2],a[2],mid,X);Q(t,a[2],b[2],b[3],a[3],tone(dark,.9),X)};
 const wy=p.wingY!=null?p.wingY:-H*.15;
 for(const sd of [1,-1]){if(p.asym&&sd<0&&p.wing!=='none'){/* mismatched panel on the left */}
  if(p.wing==='swept')wing(sd,[[W*.8,wy,wz+chord*.5],[W*.8,wy,wz-chord*.5]],[[span/2,wy-H*.2,wz-sw],[span/2+.3,wy-H*.2,wz-sw-chord*.35]]);
  else if(p.wing==='delta')wing(sd,[[W*.8,wy,wz+chord*.9],[W*.8,wy,wz-chord*.6]],[[span/2,wy,wz-chord*.5],[span/2,wy,wz-chord*.62]]);
  else if(p.wing==='forward')wing(sd,[[W*.8,wy,wz-chord*.3],[W*.8,wy,wz-chord*1.2]],[[span/2,wy+H*.1,wz+sw*.5],[span/2,wy+H*.1,wz+sw*.5-chord*.4]]);
  else if(p.wing==='stub')wing(sd,[[W*.8,wy,wz+chord*.4],[W*.8,wy,wz-chord*.4]],[[span/2,wy,wz+chord*.2],[span/2,wy,wz-chord*.35]]);
  else if(p.wing==='box')box(t,[sd*(W+span*.12),wy,wz],[span*.22,H*.9,chord*1.6],tone(mid,1.1));
  else if(p.wing==='arc')arc(t,[0,0,wz],span/2,sd>0?-.9:Math.PI-.9,sd>0?.9:Math.PI+.9,.35,acc,I,'xy')}
 if(p.asym){box(t,[-W*.9,H*.1,zN-L*.5],[.15,H*.8,L*.3],C(.55,.3,.2));box(t,[W*.95,-H*.2,zT+L*.3],[.2,H*.6,L*.25],C(.3,.38,.42));
  for(let i=0;i<4;i++)beam(t,[W*.6-i*.3,H*.7,zN-L*.35],[W*.5-i*.2,H*.5,zT+L*.2],.12,C(.12,.12,.12))}
 if(p.keels)for(const sd of [1,-1]){const kx=sd*(p.keelX||span*.32);T(t,[kx,wy,wz+chord*.2],[kx,wy-H*1.6,wz-chord*.4],[kx,wy,wz-chord*.6],tone(dark,1.3));T(t,[kx,wy,wz+chord*.2],[kx,wy,wz-chord*.6],[kx,wy-H*1.6,wz-chord*.4],tone(dark,1.3));
  for(let k=0;k<3;k++)box(t,[kx,wy-H*(.4+k*.35),wz-chord*.2],[.08,.25,chord*.3],acc,I,null,false)}
 if(p.tanks)for(const sd of [1,-1])cyl(t,wz+chord*.3,wz-chord*.5,.35*H,.35*H,8,()=>tone(mid,1.15),v=>add(v,[sd*W*1.4,wy-H*.55,0]),dark,dark);
 if(p.cargoFrame){const cw2=W*1.25;for(const z of [zN-L*.35,zN-L*.55,zN-L*.75]){beam(t,[-cw2,H*.9,z],[cw2,H*.9,z],.25,dark);beam(t,[-cw2,-H*.9,z],[cw2,-H*.9,z],.25,dark);beam(t,[-cw2,H*.9,z],[-cw2,-H*.9,z],.25,dark);beam(t,[cw2,H*.9,z],[cw2,-H*.9,z],.25,dark)}
  for(const sx of [-1,1])for(const sy of [-1,1])beam(t,[sx*cw2,sy*H*.9,zN-L*.35],[sx*cw2,sy*H*.9,zN-L*.75],.22,dark);box(t,[cw2*.55,0,zN-L*.55],[cw2*.75,H*1.4,L*.32],acc);box(t,[-cw2*.5,-.2,zN-L*.5],[cw2*.6,H*1.2,L*.26],tone(mid,1.2))}
 if(p.arcs){for(let i=0;i<3;i++){const r=W*(1.1+i*.35);arc(t,[0,H*.5,cz-i*.4],r,.25+i*.2,Math.PI-.25-i*.2,.12,i===1?acc:tone(hull,1.1),I,'xy')}}
 if(p.radiator)for(const sd of [1,-1]){const X=v=>[v[0]*sd,v[1],v[2]];Q(t,[W*.9,H*.3,zT+L*.4],[W*.9+span*.25,H*1.4,zT+L*.35],[W*.9+span*.25,H*1.4,zT+L*.1],[W*.9,H*.3,zT+L*.12],C(.5,.22,.12,.35),X);Q(t,[W*.9,H*.3,zT+L*.4],[W*.9,H*.3,zT+L*.12],[W*.9+span*.25,H*1.4,zT+L*.1],[W*.9+span*.25,H*1.4,zT+L*.35],C(.25,.12,.08),X)}
 if(p.heatShield)for(const sd of [1,-1])box(t,[sd*W*.95,0,zT+L*.06],[.25,H*1.2,L*.18],tone(dark,1.4));
 // engines
 const eng=p.eng||[[W*.5,0,H*.35],[-W*.5,0,H*.35]];const ez=zT+.1,elen=Math.max(1.5,L*.22);const noz=[];
 for(const [x,y,r] of eng){engineNacelle(t,x,y,ez-.6,ez+elen,r,mid);noz.push([x,y,ez-.6])}
 if(p.fins)for(const sd of [1,-1]){const X=v=>[v[0]*sd,v[1],v[2]];const f0=[W*.5,H*.6,zT+L*.25],f1=[W*.6,H*1.9,zT+L*.05],f2=[W*.55,H*.55,zT+L*.02];T(t,f0,f1,f2,tone(mid,1.1),X);T(t,f0,f2,f1,tone(mid,1.1),X)}
 // guns
 const guns=(p.guns||[[span*.33,wy,wz+chord*.45],[-span*.33,wy,wz+chord*.45]]);for(const g of guns){box(t,add(g,[0,0,-L*.06]),[.35,.35,L*.14],C(.16,.16,.18));box(t,add(g,[0,0,L*.04]),[.16,.16,L*.12],C(.1,.1,.11))}
 const gunsOut=guns.map(g=>add(g,[0,0,L*.11]));
 // markings
 if(p.marks)for(let k=0;k<p.marks;k++)box(t,[W*.95,H*.2,zN-L*.45-k*.6],[.05,.25,.35],acc,I,null,false);
 let rad=0;for(const tri of t)for(let i=0;i<3;i++)rad=Math.max(rad,len(tri[i]));
 return {tris:t,guns:gunsOut,nozzles:noz,radius:rad}}

// ---- ship catalogue (32) ----
// [id,name,class,maker,faction,price,source,hull,shield,cargo,energy,speed,boost,accel,turn,wslots,mslots,missile,mass,tradeoff,params]
const SHIP_DEFS=[
 // light (8)
 ['strizh','Стриж','light','КБ «Пустельга»','league',0,'start',100,60,12,100,120,220,55,1.85,2,2,1,10,'Мало брони — но прощает ошибки манёвром',{hand:'strizh'}],
 ['pustelga','Пустельга','light','КБ «Пустельга»','league',3200,'shop:kromka,lira_ex,per_dock',95,80,8,110,135,240,62,2.0,2,2,1,9,'Быстрее и вёрточнее Стрижа, но трюм всего 8',{L:11,W:1.1,H:.9,nose:'needle',wing:'swept',span:9,eng:[[.6,0,.5],[-.6,0,.5]],fins:true,pal:'league',noseAcc:true}],
 ['krechet','Кречет','light','Литейный двор Горна','union',4200,'shop:verf9,gorn_forge,nak_dock',130,55,10,100,128,215,58,1.8,3,2,1,11,'Три пушки, но щит слабый',{L:12,W:1.4,H:1.1,nose:'wedge',wing:'stub',span:8,chord:4,eng:[[.8,0,.6],[-.8,0,.6]],pal:'union',guns:[[2.8,-.2,1],[-2.8,-.2,1],[0,-1,3.5]],heatShield:true}],
 ['oska','Оска','light','мастерские Кильватера','wake',2900,'shop:kil_bazaar,rzh_scrap',85,50,10,90,132,235,60,1.95,2,2,1,9,'Дешёвая и злая, но корпус из обрезков',{L:10,W:1,H:.9,nose:'wedge',wing:'forward',span:8.5,eng:[[0,0,.75]],pal:'wake',asym:true}],
 ['teira_duel','Клинок Рода','light','Дом Ашкет','teira',7600,'shop:tei_hall,ash_yard',120,90,6,120,138,230,64,2.1,2,2,0,10,'Лучший дуэлянт, но без ракет и с крошечным трюмом',{hand:'teira_duel'}],
 ['essen_dart','Тонкая Нота','light','Хор Ло-Унна','essen',6900,'shop:ess_spire',80,120,8,140,140,250,66,2.05,2,2,1,8,'Огромный щит, хрупкий корпус',{L:12,W:.9,H:.8,nose:'needle',wing:'arc',span:9,eng:[[0,.2,.55],[0,-.6,.45]],pal:'essen',arcs:true}],
 ['strela','Стрела','light','Арсенал Союза','border',5400,'shop:raz_fort,nak_ars',110,70,6,110,145,260,70,1.9,2,2,1,10,'Самая быстрая из лёгких, но плохо держит удар',{L:13,W:1,H:.85,nose:'needle',wing:'delta',span:7.5,chord:5,eng:[[.55,0,.5],[-.55,0,.5],[0,.5,.4]],pal:'border',fins:true}],
 ['svist','Свист','light','гоночная мастерская Лиры','league',8800,'shop:lira_ex',75,70,4,120,155,280,75,2.2,2,1,0,7,'Гонщик: самый быстрый корпус, почти без трюма',{L:12.5,W:.8,H:.7,nose:'needle',wing:'forward',span:7,eng:[[0,0,.7]],pal:'league',fins:true,noseAcc:true}],
 // multirole (7)
 ['sokol','Сокол','multi','Верфи Лиры','league',9500,'shop:lira_ex,per_dock,kromka',160,110,16,130,118,210,52,1.6,3,3,1,15,'Универсал: всё понемногу',{L:15,W:1.6,H:1.3,nose:'wedge',wing:'swept',span:12,eng:[[.9,0,.7],[-.9,0,.7]],pal:'league',fins:true,tanks:true}],
 ['barsuk','Барсук','multi','Литейный двор Горна','union',8800,'shop:verf9,gorn_forge,stp_north',190,90,18,120,108,195,48,1.45,3,3,1,17,'Крепкий, но неповоротливый',{L:15,W:2,H:1.6,nose:'blunt',wing:'stub',span:10,chord:6,eng:[[1.1,0,.85],[-1.1,0,.85]],pal:'union',heatShield:true,tanks:true}],
 ['vestnik','Вестник','multi','Почтовая служба Лиги','league',12000,'shop:lira_ex,sir_port',150,120,22,150,130,240,58,1.6,2,4,1,13,'Курьер с дальним прыжком, но лишь два ствола',{L:16,W:1.3,H:1.1,nose:'needle',wing:'delta',span:9,chord:7,eng:[[.7,0,.6],[-.7,0,.6]],pal:'league',noseAcc:true}],
 ['teira_hunt','Наследник','multi','Дом Тейр-Ан','teira',14000,'shop:tei_hall',200,130,14,140,120,220,55,1.7,3,3,1,15,'Сильный и красивый, но Тейра продают его лишь друзьям',{L:16,W:1.5,H:1.2,nose:'fork',wing:'swept',span:11,eng:[[.9,0,.7],[-.9,0,.7]],pal:'teira',keels:true,marks:4}],
 ['essen_wave','Волна Хора','multi','Хор Эссен-Ои','essen',13500,'shop:ess_spire,lou_dock',140,200,16,180,124,230,54,1.65,3,3,1,13,'Щит и энергия в избытке, корпус тонкий',{L:15,W:1.2,H:1,nose:'needle',wing:'swept',span:13,eng:[[.6,0,.6],[-.6,0,.6]],pal:'essen',arcs:true,tanks:true}],
 ['perevertysh','Перевёртыш','multi','мастерские Кильватера','wake',11000,'shop:kil_bazaar,bh_cyl',170,100,20,120,122,225,55,1.6,3,3,1,15,'Скрытые отсеки для контрабанды, слабый реактор',{L:15,W:1.5,H:1.2,nose:'wedge',wing:'forward',span:11,eng:[[.9,0,.7],[-.9,0,.7]],pal:'wake',asym:true,tanks:true}],
 ['dozorny','Дозорный','multi','Форт Разлом','border',12500,'shop:raz_fort,spr_cust',180,120,12,140,125,225,56,1.65,3,3,1,15,'Сканер в носу, но мало груза',{L:15.5,W:1.4,H:1.2,nose:'blunt',wing:'swept',span:11,chord:6,eng:[[.8,0,.7],[-.8,0,.7]],pal:'border',fins:true}],
 // heavy (5)
 ['molot','Молот','heavy','Арсенал Союза','union',18000,'shop:nak_ars,stp_north,verf9',320,140,10,150,98,175,40,1.2,4,3,1,24,'Держит удар как станция, разворачивается как она же',{L:19,W:2.4,H:2,nose:'blunt',wing:'box',span:12,chord:6,eng:[[1.3,.4,1],[-1.3,.4,1],[0,-.8,1]],pal:'union',heatShield:true}],
 ['bastion','Бастион','heavy','Верфи Лиры','league',21000,'shop:lira_ex,lira_post',280,220,8,170,100,180,42,1.25,4,4,1,22,'Лучшая защита Лиги, дорогое обслуживание энергии',{L:18,W:2.2,H:1.8,nose:'wedge',wing:'delta',span:14,chord:8,eng:[[1.2,0,.95],[-1.2,0,.95]],pal:'league',tanks:true,fins:true}],
 ['bezymyanny','Безымянный','heavy','неизвестно','wake',16000,'shop:bh_cyl',290,120,14,130,112,215,48,1.4,4,3,1,21,'Собран из военного носа и буксира: мощь без лицензии',{hand:'bezymyanny'}],
 ['teira_keel','Старший Киль','heavy','Дом Ашкет','teira',24000,'mission:teira_side3',300,180,10,160,104,190,45,1.35,4,3,1,22,'Родовой корабль: выдаётся только за исполненную клятву',{L:19,W:2,H:1.6,nose:'fork',wing:'delta',span:15,chord:8,eng:[[1.1,0,.9],[-1.1,0,.9],[0,.8,.7]],pal:'teira',keels:true,keelX:5,marks:8}],
 ['gromoboi','Громобой','heavy','экспериментальный цех Союза','border',26000,'mission:a3_m6',340,160,8,180,96,170,40,1.15,5,3,1,25,'Пять стволов и тяжесть утюга',{L:20,W:2.6,H:2,nose:'blunt',wing:'stub',span:14,chord:7,eng:[[1.4,0,1],[-1.4,0,1],[0,.9,.8],[0,-.9,.8]],pal:'border',guns:[[4.5,-.3,1],[-4.5,-.3,1],[2,1.4,6],[-2,1.4,6],[0,-1.3,7]]}],
 // cargo / industrial (5)
 ['tyagach','Тягач','cargo','Литейный двор Горна','union',2400,'shop:kromka,verf9,gorn_yard,stp_north',150,60,28,100,95,175,34,1.3,2,2,0,20,'Огромный трюм и броня, но тяжёлый на разгоне',{hand:'tyagach'}],
 ['gruzchik','Грузчик','cargo','Стапель-Северный','union',6500,'shop:stp_north,nak_dock,verf9',200,70,40,110,88,160,30,1.1,2,3,0,26,'40 мест в трюме, но медленный',{L:18,W:2.2,H:2,nose:'blunt',wing:'none',eng:[[1.2,.5,.9],[-1.2,.5,.9],[1.2,-.8,.9],[-1.2,-.8,.9]],pal:'union',cargoFrame:true,heatShield:true}],
 ['karavan','Караван','cargo','Верфи Лиры','league',15000,'shop:lira_ex,per_dock',240,140,60,140,92,165,32,1.05,3,4,1,30,'Шестьдесят мест: торговый дом на крыльях',{L:22,W:2.6,H:2.2,nose:'wedge',wing:'stub',span:13,chord:9,eng:[[1.4,0,1],[-1.4,0,1]],pal:'league',tanks:true}],
 ['burovik','Буровик','cargo','Шахты Горна','union',7800,'shop:gorn_mine,yan_mine,kob_mine,inei_mine',190,80,24,120,96,170,36,1.25,2,4,0,22,'Двойная скорость бурения, мало оружия',{L:15,W:2,H:1.8,nose:'blunt',wing:'box',span:9,chord:5,eng:[[1,0,.8],[-1,0,.8],[0,1,.6]],pal:'union',tanks:true,guns:[[3,-.6,3],[-3,-.6,3]]}],
 ['teira_ark','Родовой Ковчег','cargo','Дом Венец','teira',19000,'shop:tei_hall,ven_nest',260,150,44,150,98,175,36,1.15,3,3,1,27,'Семейный грузовоз: прочный и вместительный, дорог',{L:21,W:2.4,H:2,nose:'fork',wing:'stub',span:12,eng:[[1.2,0,.9],[-1.2,0,.9]],pal:'teira',keels:true,keelX:3.5,cargoFrame:true,marks:6}],
 // scout / rescue (4)
 ['essen_scout','Слушающий','scout','Хор Тихого Резонанса','essen',9000,'shop:ess_spire,tih_obs',90,130,10,170,138,250,62,1.9,1,4,0,9,'Лучший сканер в секторе, но одна пушка',{hand:'essen_scout'}],
 ['razvedchik','Разведчик','scout','Обсерватории Лиги','league',7000,'shop:yan_obs,sir_obs,lira_ex',100,90,10,140,134,245,60,1.85,2,4,0,9,'Много слотов под приборы, слабое оружие',{L:13,W:1,H:.9,nose:'needle',wing:'delta',span:10,chord:4,eng:[[0,0,.6]],pal:'league',arcs:true}],
 ['spasatel','Спасатель','scout','Ковчег','border',8000,'shop:ark_flag',170,110,20,160,118,215,50,1.55,1,5,0,15,'Встроенный притягивающий луч и лазарет, почти безоружен',{L:16,W:1.8,H:1.5,nose:'blunt',wing:'none',span:10,eng:[[1,0,.75],[-1,0,.75]],pal:'border',tanks:true,cargoFrame:true,noseAcc:true}],
 ['mayak','Маяк','scout','картографы Межи','border',10500,'blueprint:bp_mayak',110,100,8,180,140,255,62,1.8,2,4,0,9,'Дальнобойный сканер и маскировка, слабая броня',{L:14,W:.9,H:.8,nose:'wedge',wing:'arc',span:10,eng:[[.5,0,.5],[-.5,0,.5]],pal:'border',arcs:true,fins:true}],
 // experimental (3)
 ['sklad9_x','Девятый','exp','Склад Девять','exp',48000,'shop:s9_yard',260,200,10,260,150,300,72,1.9,4,4,1,18,'Огромная мощь и перегрев: следите за энергией',{hand:'sklad9_x'}],
 ['izn_relic','Эхо Изнанки','exp','неизвестно','relic',0,'discover:iznanka',240,260,12,300,140,270,66,1.85,3,4,1,14,'Древний корпус: щит восстанавливается сам, ремонт только в Изнанке',{L:17,W:1.1,H:1,nose:'needle',wing:'arc',span:16,eng:[[0,0,.9]],pal:'relic',arcs:true,keels:true,keelX:3}],
 ['prototip','Прототип Л-7','exp','КБ «Пустельга»','league',0,'mission:collector3',200,180,10,220,145,280,68,1.95,3,3,1,15,'Опытный образец: всё лучшее, но запчасти не продаются',{L:15,W:1.2,H:1,nose:'needle',wing:'forward',span:12,eng:[[.7,0,.65],[-.7,0,.65]],pal:'exp',fins:true,radiator:true}]];
const CLASS_NAME={light:'Лёгкий истребитель',multi:'Многоцелевой',heavy:'Тяжёлый истребитель',cargo:'Грузовой / промышленный',scout:'Разведка / спасение',exp:'Экспериментальный'};
REG.ships={};
for(const d of SHIP_DEFS){const [id,name,cls,maker,fac,price,source,hull,shield,cargo,energy,speed,boost,accel,turn,wslots,mslots,missile,mass,tradeoff,params]=d;
 REG.ships[id]={id,name,cls,maker,fac,price,source,hull,shield,cargo,energy,speed,boost,accel,turn,wslots,mslots,missile:!!missile,mass,tradeoff,params,
  shops:source.startsWith('shop:')?source.slice(5).split(','):[]}}
// stations that sell ships get the shipyard service
for(const s of Object.values(REG.ships))for(const st of s.shops){const r=REG.stations[st];if(r&&!r.services.includes('shipyard'))r.services.push('shipyard')}
// ---- weapons (18 in 6 families) ----
const WFAM={pulse:'Импульсные',kinetic:'Кинетические',plasma:'Плазменные',beam:'Лучевые',ion:'Ионные',missile:'Ракеты'};
const WPN=[
 // id,name,family,price,dmg,rate,speed,life,energy,heat,extra
 ['p_iskra','Импульсник «Искра»','pulse',0,6,7.5,620,1.6,1.1,0,{role:'Надёжный стартовый: быстрые заряды, легко брать упреждение'}],
 ['p_shkval','Импульсник «Шквал»','pulse',2200,4,13,600,1.3,1,0,{role:'Поток мелких зарядов: прощает неточный прицел'}],
 ['p_kopye','Импульсник «Копьё»','pulse',3800,12,3.6,950,1.8,2.6,0,{role:'Дальний и быстрый заряд для стрельбы на сближении'}],
 ['k_otboy','Автопушка «Отбойник»','kinetic',2600,8,6,520,1.5,0,1.2,{spread:.02,burst:3,hullMul:1.6,shieldMul:.5,role:'Рвёт голый корпус, когда щит уже снят'}],
 ['k_igla','Рельсотрон «Игла»','kinetic',5200,32,1,1500,1.2,8,4,{hullMul:1.5,shieldMul:.6,role:'Один точный удар на большой дистанции'}],
 ['k_veer','Дробовик «Веер»','kinetic',3100,5,1.6,460,.9,0,3,{spread:.06,pellets:6,hullMul:1.5,shieldMul:.5,role:'В упор по крупным целям'}],
 ['pl_kaplya','Плазмомёт «Капля»','plasma',1600,18,2,360,2.6,0,9,{role:'Лёгкая плазма: больше выстрелов, меньше перегрева'}],
 ['pl_sgustok','Плазмомёт «Сгусток»','plasma',1100,34,1.15,300,3.2,0,15,{role:'Медленный яркий сгусток с большим уроном'}],
 ['pl_protub','Плазмомёт «Протуберанец»','plasma',6800,70,.55,240,3.5,0,28,{splash:25,role:'Тяжёлый заряд с разлётом: для тяжёлых целей'}],
 ['b_luch','Лучемёт «Луч-Л»','beam',2400,20,0,500,0,14,0,{role:'Удерживайте цель в прицеле — урон идёт непрерывно'}],
 ['b_rezak','Лучемёт «Резак»','beam',5600,46,0,260,0,26,0,{role:'Короткий, но страшный луч для ближнего боя'}],
 ['b_nit','Лучемёт «Нить»','beam',4900,16,0,900,0,12,0,{role:'Длинная тонкая нить для добивания на дистанции'}],
 ['i_ion','Ионник «Ион-1»','ion',2800,5,3,500,1.4,3,0,{shieldMul:3,hullMul:.2,role:'Срывает щиты втрое быстрее'}],
 ['i_glush','Ионник «Глушитель»','ion',3900,3,2,480,1.4,3,0,{shieldMul:1.5,hullMul:.2,slow:3,role:'Глушит двигатель цели: она не уйдёт'}],
 ['i_zahvat','Ионник «Захват»','ion',5200,2,1.5,450,1.4,4,0,{shieldMul:1,hullMul:.2,disable:4,role:'Отключает оружие; ослабленная цель сбрасывает груз'}],
 ['m_osa','Ракеты «Оса»','missile',1800,28,1.2,260,8,0,0,{turn:3.2,ammo:8,lock:1.2,ammoPrice:60,role:'Вёрткие ракеты против истребителей'}],
 ['m_taran','Ракеты «Таран»','missile',4200,90,.6,200,10,0,0,{turn:1.1,ammo:4,lock:2.2,ammoPrice:220,role:'Тяжёлая противокорабельная: против крупных целей'}],
 ['m_roy','Ракеты «Рой»','missile',3600,14,.8,230,9,0,0,{turn:2,ammo:5,lock:1.6,cluster:6,ammoPrice:150,role:'Распадается на шесть боеголовок рядом с целью'}]];
REG.weapons={};for(const w of WPN){const [id,name,fam,price,dmg,rate,speed,life,energy,heat,x]=w;REG.weapons[id]={id,name,fam,price,dmg,rate,speed,life,energy,heat,...x}}
// ---- modules (16) ----
const MODDEFS=[
 ['shield_p','Усиленный щит',700,{shield:35},2,1,'Максимум щита +35'],
 ['shield_mk2','Щит Mk2',3600,{shield:70},5,2,'Максимум щита +70, заметный расход энергии'],
 ['armor','Бронеплиты',1500,{hull:40},0,4,'Корпус +40, корабль тяжелее'],
 ['armor_comp','Композитная броня',5200,{hull:80},0,2,'Корпус +80 при малом весе'],
 ['reactor','Реактор «Пламя»',2800,{regen:.4},0,2,'Восстановление энергии +40%'],
 ['battery','Аккумулятор',1600,{energy:60},0,1,'Запас энергии +60'],
 ['cooler','Теплоотвод',1900,{cool:.7},1,1,'Оружие остывает на 70% быстрее'],
 ['afterburner','Форсажный ускоритель',2400,{boost:30,boostT:1},2,1,'Форсаж +30 м/с и +1 с'],
 ['cargo_ext','Грузовой расширитель',1800,{cargo:8,turn:-.08},0,3,'Трюм +8, манёвренность −8%'],
 ['scanner','Сканер «Око»',1400,{scan:1},2,1,'Состав жил, груз цели, захват ракет на 25% быстрее'],
 ['drill','Бур «Глубина»',1700,{drill:.6},2,1,'Бурение на 60% быстрее, шире рабочая зона'],
 ['tractor','Притягивающий луч',2100,{tractor:400},3,1,'Подтягивает контейнеры и капсулы с 400 м'],
 ['repair_drone','Ремонтный дрон',3400,{repair:1.5},3,1,'Чинит корпус в полёте, если вас не бьют'],
 ['jammer','Постановщик помех',2600,{jam:3},1,1,'Три заряда помех: срывают захват вражеских ракет'],
 ['stealth','Глушитель сигнатуры',4800,{stealth:6},4,1,'На 6 с враги теряют вас из виду (перезарядка 40 с)'],
 ['stabilizer','Гироскоп',1300,{turn:.15},1,1,'Манёвренность +15%']];
REG.modules={};for(const m of MODDEFS){const [id,name,price,eff,draw,mass,desc]=m;REG.modules[id]={id,name,price,eff,draw,mass,desc}}
// what each station sells (equipment): by faction + family
function shopEquipment(stId){const st=REG.stations[stId];if(!st||!st.services.includes('equip'))return {w:[],m:[]};const R=srand(hashStr(stId)+5);const fac=st.faction;
 const w=Object.values(REG.weapons).filter(x=>x.price>0).filter(x=>{if(x.id==='pl_sgustok')return true;
  const pref={league:['pulse','beam','missile'],union:['kinetic','plasma','pulse'],teira:['kinetic','pulse','missile'],essen:['beam','ion','pulse'],wake:['plasma','ion','missile','kinetic'],none:['pulse','kinetic','missile','plasma']}[fac]||['pulse'];
  return pref.includes(x.fam)&&R()<.75}).map(x=>x.id);
 const m=Object.values(REG.modules).filter(x=>x.id==='shield_p'||R()<.6).map(x=>x.id);return {w,m}}
// ---- enemy classes ----
const ENEMY_CLS={
 interceptor:{name:'Перехватчик',hull:55,shield:30,speed:150,turn:1.2,r:6.5,shotSpeed:520,dmg:4,mesh:'interceptor'},
 flanker:{name:'Фланговый стрелок',hull:70,shield:40,speed:130,turn:1.1,r:7,shotSpeed:560,dmg:4,mesh:'flanker'},
 heavy:{name:'Тяжёлый налётчик',hull:170,shield:70,speed:82,turn:.6,r:10,shotSpeed:460,dmg:5,mesh:'heavy'},
 missileer:{name:'Ракетоносец',hull:120,shield:60,speed:95,turn:.7,r:9,shotSpeed:480,dmg:3,mesh:'missileer'},
 guard:{name:'Охранник конвоя',hull:130,shield:90,speed:120,turn:1,r:8,shotSpeed:540,dmg:5,mesh:'guard'},
 support:{name:'Корабль поддержки',hull:90,shield:120,speed:110,turn:.9,r:8,shotSpeed:480,dmg:2,mesh:'support'},
 capital:{name:'Крейсер',hull:1400,shield:400,speed:28,turn:.12,r:60,shotSpeed:480,dmg:6,mesh:'capital'}};
const ENEMY_PARAMS={flanker:{L:12,W:1.3,H:1,nose:'wedge',wing:'delta',span:11,chord:5,eng:[[.7,0,.55],[-.7,0,.55]],pal:'wake',asym:true},
 missileer:{L:16,W:2,H:1.6,nose:'blunt',wing:'box',span:12,chord:7,eng:[[1,0,.8],[-1,0,.8]],pal:'wake',tanks:true},
 guard:{L:15,W:1.6,H:1.3,nose:'wedge',wing:'swept',span:12,eng:[[.9,0,.7],[-.9,0,.7]],pal:'border',fins:true},
 support:{L:14,W:1.8,H:1.6,nose:'blunt',wing:'arc',span:12,eng:[[.9,0,.7],[-.9,0,.7]],pal:'wake',arcs:true,tanks:true}};
// ---- hand-detailed hulls ----
function handHull(id){
 if(id==='strizh'){const t=buildStrizh();// service hump behind the deep-set canopy + scuffs
  loft(t,[{z:-1.8,p:[[0,1.02],[-.5,.9],[.5,.9]]},{z:-2.6,p:[[0,1.3],[-.75,.95],[.75,.95]]},{z:-4.6,p:[[0,1.1],[-.7,.85],[.7,.85]]},{z:-5.6,p:[[0,.82],[-.5,.75],[.5,.75]]}],(s,i)=>tone(C(.5,.54,.6),i?1:1.1),I,C(.3,.32,.36));
  box(t,[0,1.32,-3.4],[.5,.1,.9],C(.95,.48,.12));for(const [x,z] of [[.9,-2.5],[-1.1,-3.6],[2.6,-4.2]])box(t,[x,.62,z],[.4,.03,.3],C(.36,.33,.3),I,null,false);
  return {tris:t,guns:GUNS.strizh,nozzles:NOZZLES.strizh}}
 if(id==='tyagach'){const t=[];const Y=C(.86,.68,.2),G=C(.5,.53,.56),D=C(.25,.27,.3),glass=C(.06,.09,.14);
  // longitudinal cargo frame
  for(const sx of [-1,1])for(const sy of [-1,1])beam(t,[sx*3.4,sy*1.9,6],[sx*3.4,sy*1.9,-7],.32,D);
  for(let z=5;z>=-7;z-=3){beam(t,[-3.4,1.9,z],[3.4,1.9,z],.3,D);beam(t,[-3.4,-1.9,z],[3.4,-1.9,z],.3,D);beam(t,[-3.4,1.9,z],[-3.4,-1.9,z],.3,D);beam(t,[3.4,1.9,z],[3.4,-1.9,z],.3,D)}
  box(t,[0,0,-.5],[2.4,2.4,13],G);for(let k=0;k<4;k++){box(t,[1.6,0,3.5-k*3],[2.6,3,2.6],k%2?tone(G,1.1):Y);box(t,[-1.7,0,3.5-k*3],[2.4,2.8,2.6],k%2?Y:tone(G,.9))}
  // cockpit offset to starboard
  box(t,[-2.6,2.3,7],[2.6,1.8,3.2],tone(G,1.1));box(t,[-2.6,2.8,8.5],[2.2,.9,.4],glass);box(t,[-2.6,3.3,7.2],[2,.2,2.6],D);
  // nozzles behind heat shields
  for(const sx of [-1,1]){engineNacelle(t,2.2*sx,0,-9.4,-7.2,1.05,G);box(t,[3.5*sx,0,-8.6],[.35,3,2.4],tone(D,1.4));box(t,[2.2*sx,1.6,-8.6],[2.6,.3,2.2],tone(D,1.4))}
  box(t,[2.4,1.3,7.4],[.5,.5,2.6],C(.18,.18,.2));box(t,[-.3,-2.3,7.2],[.5,.5,2.6],C(.18,.18,.2));box(t,[0,0,8.4],[3,2.2,1.4],Y);
  return {tris:t,guns:[[2.4,1.3,8.8],[-.3,-2.3,8.6]],nozzles:[[2.2,0,-9.4],[-2.2,0,-9.4]]}}
 if(id==='teira_duel'){const r=buildHull({L:13,W:.9,H:1,nose:'fork',wing:'swept',span:9,eng:[[.55,0,.5],[-.55,0,.5]],pal:'teira',keels:true,keelX:3.2,marks:5,fins:false,canopy:{z:2,h:.55,w:.38}});
  for(const sx of [-1,1])for(let k=0;k<4;k++)box(r.tris,[sx*2.2-sx*k*.4,-.05,-1-k*.7],[.5,.05,.25],C(1,.62,.25,.5),I,null,false);return r}
 if(id==='essen_scout'){const r=buildHull({L:12,W:.85,H:.85,nose:'needle',wing:'none',span:8,eng:[[0,0,.6]],pal:'essen',canopy:{z:2.2,h:.6,w:.45}});
  // sensor arcs around the cockpit with open gaps
  for(let i=0;i<4;i++)arc(r.tris,[0,.5,2.2-i*.9],1.6+i*.55,-.4+i*.15,Math.PI+.4-i*.15,.13,i%2?C(.45,1,.88,.5):C(.74,.84,.86),I,'xy');
  for(const sx of [-1,1])arc(r.tris,[sx*.2,0,-2],2.2,sx>0?-1.2:Math.PI-1.2,sx>0?1.2:Math.PI+1.2,.12,C(.6,.75,.8),I,'xy');
  r.guns=[[0,-.6,6.2]];r.scanArcs=true;return r}
 if(id==='bezymyanny'){const t=[];const front=buildHull({L:11,W:1.3,H:1.1,nose:'wedge',wing:'delta',span:10,chord:4,eng:[],pal:'border',fins:false,wingZ:1.5,guns:[[3.5,-.3,3],[-3.5,-.3,3],[1.2,-.9,5.5],[-1.2,-.9,5.5]]});
  for(const tri of front.tris)t.push([add(tri[0],[0,0,4]),add(tri[1],[0,0,4]),add(tri[2],[0,0,4]),tri[3]]);
  // civilian tug engine block welded behind
  const tug=buildTug();for(const tri of tug)t.push([add(scl(tri[0],1.1),[0,.2,-4.5]),add(scl(tri[1],1.1),[0,.2,-4.5]),add(scl(tri[2],1.1),[0,.2,-4.5]),tri[3]]);
  // weld seam, cables, boosters, mismatched panels
  box(t,[0,0,-.6],[2.8,2.2,.6],C(.6,.35,.15,.25));for(let i=0;i<5;i++)beam(t,[-1+i*.5,1.2,2.5],[-1.4+i*.6,1.6,-5],.1,C(.08,.08,.08));
  for(const sx of [-1,1])cyl(t,-2,-6,.45,.45,8,()=>C(.4,.36,.33),v=>add(v,[sx*2.3,-.8,0]),C(.2,.2,.2),C(.9,.5,.2,.8));
  box(t,[1.6,.4,1],[.15,1.2,3],C(.55,.25,.18));box(t,[-1.65,.2,-1],[.15,1,2.4],C(.3,.4,.45));
  return {tris:t,guns:front.guns.map(g=>add(g,[0,0,4])),nozzles:[[0,.2,-11.5],[2.3,-.8,-6],[-2.3,-.8,-6]]}}
 if(id==='sklad9_x'){const r=buildHull({L:17,W:1.3,H:1.1,nose:'needle',wing:'forward',span:12,eng:[[1.3,0,1.05],[-1.3,0,1.05]],pal:'exp',radiator:true,fins:true,canopy:{z:3.5,h:.5,w:.4},guns:[[2.2,-.3,2],[-2.2,-.3,2],[.8,-.8,6],[-.8,-.8,6]]});
  for(const sx of [-1,1])for(let k=0;k<6;k++)box(r.tris,[sx*(2+k*.35),.9+k*.18,-6+k*.1],[.08,.9,1.4],C(.9,.3,.1,.5),I,null,false);r.heatGlow=true;return r}
 return null}
const SHIP_ASSET={};
function shipAsset(id){if(SHIP_ASSET[id])return SHIP_ASSET[id];const d=REG.ships[id];let b=d.params.hand?handHull(d.params.hand):buildHull(d.params);
 let rad=0;for(const tri of b.tris)for(let i=0;i<3;i++)rad=Math.max(rad,len(tri[i]));
 const a={mesh:makeMesh(b.tris),guns:b.guns,nozzles:b.nozzles,radius:rad,camDist:Math.max(16,rad*2.1),camUp:Math.max(4,rad*.42),scanArcs:!!b.scanArcs,heatGlow:!!b.heatGlow};SHIP_ASSET[id]=a;return a}
function enemyAsset(cls){const key='e_'+cls;if(SHIP_ASSET[key])return SHIP_ASSET[key];let a;
 if(cls==='interceptor'||cls==='heavy')a={mesh:M[cls],guns:cls==='heavy'?[[5,0,4],[-5,0,4]]:[[4.4,.3,2.4],[-4.4,.3,2.4]],nozzles:NOZZLES[cls],radius:cls==='heavy'?9:6};
 else if(cls==='capital')a=buildCapital();else{const b=buildHull(ENEMY_PARAMS[cls]);a={mesh:makeMesh(b.tris),guns:b.guns,nozzles:b.nozzles,radius:b.radius}}
 SHIP_ASSET[key]=a;return a}
// capital ship with destroyable nodes (turrets, engine, tow node)
function buildCapital(){const t=[];const H=C(.4,.38,.36),D=C(.2,.19,.18),R=C(.6,.18,.14);
 loft(t,[{z:70,p:[[0,10],[-18,0],[0,-12],[18,0]]},{z:30,p:[[0,22],[-34,2],[0,-24],[34,2]]},{z:-50,p:[[0,24],[-36,2],[0,-26],[36,2]]},{z:-90,p:[[0,18],[-26,2],[0,-20],[26,2]]}],(s,i)=>tone(i<2?H:D,s%2?1:.9),I,D);
 box(t,[0,26,-20],[20,10,40],tone(H,.85));for(let i=0;i<10;i++)box(t,[34.5,0,40-i*12],[.3,3,6],C(1,.8,.5,1),I,null,false);
 for(const sx of [-1,1])engineNacelle(t,14*sx,0,-102,-88,7,H);
 return {mesh:makeMesh(t),guns:[[0,0,72]],nozzles:[[14,0,-102],[-14,0,-102]],radius:60,
  nodes:[{id:'t1',name:'Орудийная башня',pos:[22,18,30],hp:180,r:7},{id:'t2',name:'Орудийная башня',pos:[-22,18,30],hp:180,r:7},{id:'t3',name:'Ракетная батарея',pos:[0,30,-30],hp:220,r:8},
   {id:'eng',name:'Двигательный узел',pos:[0,0,-95],hp:300,r:12},{id:'tow',name:'Буксирный узел',pos:[0,-26,-60],hp:200,r:8}]}}
