'use strict';
// ================= weapons, missiles, enemy AI =================
function wDef(id){return REG.weapons[id]}
function activeWeapon(){const g=weaponGroups();if(!g.length)return null;P.weapon=((P.weapon|0)%g.length+g.length)%g.length;return g[P.weapon]}
function gunPoint(k){const a=shipAsset(S.active);const g=a.guns[k%a.guns.length];return add(P.pos,qrot(P.q,g))}
// ---- player fire ----
function playerFire(dt,held){const st=shipStats();const id=activeWeapon();P.beam=null;if(!id||DR)return;const w=wDef(id);const f=fitOf(S.active);
 const slots=f.w.map((x,i)=>x===id?i:-1).filter(i=>i>=0);const n=slots.length;const mul=Math.max(1,n/2);
 if(P.ovh>0)return;
 if(w.fam==='beam'){if(!held)return;const need=w.energy*mul*dt;if(P.energy<need){if(!G.noEnergyNote||G.time-G.noEnergyNote>2){G.noEnergyNote=G.time;uiNote('Нет энергии для луча')}return}
  P.energy-=need;const aim=assistAim(1e5);const from=gunPoint(slots[0]);const dir=aim?norm(sub(aim,from)):FWD(P.q);const hit=rayHit(from,dir,w.speed);
  P.beam={from,to:hit?hit.p:add(from,scl(dir,w.speed)),fam:id,hitE:hit&&hit.e};if(hit&&hit.e){damage(hit.e,w.dmg*mul*dt,hit.p,null,{beam:true});G.hitMark=.12}
  else if(hit&&hit.a&&Math.random()<dt*20)part(hit.p,scl(rndDir(),10),.3,[1,.8,.5],1);return}
 P.cd-=dt;if(!held){P.cd=Math.max(P.cd,0);return}
 const rate=w.rate*mul;let guard=0;
 while(P.cd<=0&&guard++<4){const en=w.energy||0;if(P.energy<en){if(!G.noEnergyNote||G.time-G.noEnergyNote>2){G.noEnergyNote=G.time;uiNote('Нет энергии')}P.cd=.2;return}
  P.energy-=en;P.heat+=w.heat||0;if(P.heat>=100){P.ovh=2.2;P.heat=100;sfx('overheat');uiNote('Перегрев оружия!')}
  P.slotK=((P.slotK|0)+1)%n;const gp=gunPoint(slots[P.slotK]);const aim=assistAim(w.speed);let dir=aim?norm(sub(aim,gp)):FWD(P.q);
  const pel=w.pellets||1,burst=w.burst||1;
  for(let b=0;b<burst;b++)for(let k=0;k<pel;k++){const d=w.spread?norm(add(dir,scl(rndDir(),w.spread))):dir;
   W.shots.push({p:add(gp,scl(d,b*-3)),v:add(P.vel,scl(d,w.speed)),life:w.life,owner:'p',dmg:w.dmg,kind:w.fam,wid:id,r:w.fam==='plasma'?3:w.fam==='kinetic'?.8:1.2,shieldMul:w.shieldMul||1,hullMul:w.hullMul||1,splash:w.splash||0,slow:w.slow||0,disable:w.disable||0})}
  part(add(gp,scl(dir,1)),scl(P.vel,1),.06,w.fam==='plasma'?[.6,1,.7]:w.fam==='kinetic'?[1,.8,.4]:w.fam==='ion'?[.6,.6,1]:[.5,.9,1],w.fam==='plasma'?5:2.4);
  sfx(w.fam==='plasma'?'plasma':w.fam==='kinetic'?'kinetic':w.fam==='ion'?'ion':'pulse');P.kick+=w.fam==='plasma'?.35:w.fam==='kinetic'?.12:.04;if(w.fam==='plasma')P.spd=Math.max(0,P.spd-6);
  P.cd+=1/rate}}
function rayHit(from,dir,range){let best=null,bt=range;
 const test=(c,r,e,a)=>{const oc=sub(c,from);const t=dot(oc,dir);if(t<0||t>bt+r)return;const d2=dot(oc,oc)-t*t;if(d2>r*r)return;const th=t-Math.sqrt(r*r-d2);if(th<bt&&th>0){bt=th;best={p:add(from,scl(dir,th)),e,a}}};
 for(const e of W.enemies)if(!e.dead){if(e.cls==='capital'){for(const s of capSpheres(e))test(s.c,s.r,e)}else test(e.pos,e.r,e)}
 for(const a of W.asts)if(dist(a.pos,from)<range+a.r)test(a.pos,a.r*.95,null,a);return best}
// ---- missiles ----
function missileLockUpdate(dt){const f=fitOf(S.active);P.lockT=P.lockT||0;const t=P.target;
 if(!f.mis||!t||t.kind!=='enemy'||t.dead){P.lockT=0;P.locked=null;return}const w=wDef(f.mis.id);const d=dist(t.pos,P.pos);const ang=Math.acos(clamp(dot(norm(sub(t.pos,P.pos)),FWD(P.q)),-1,1));
 if(d<1800&&ang<.35&&losClear(P.pos,t.pos)){P.lockT+=dt;const need=w.lock*(shipStats().scan?.75:1);if(P.lockT>=need){if(P.locked!==t){P.locked=t;sfx('lock')}}}else{P.lockT=Math.max(0,P.lockT-dt*2);if(P.lockT<=0)P.locked=null}}
function losClear(a,b){const d=norm(sub(b,a)),L=dist(a,b);for(const s of W.asts){if(s.r<12)continue;const oc=sub(s.pos,a);const t=dot(oc,d);if(t<0||t>L)continue;if(dot(oc,oc)-t*t<s.r*s.r*.8)return false}return true}
function fireMissile(){const f=fitOf(S.active);if(!f.mis)return;if(f.mis.ammo<=0){uiNote('Ракеты кончились — пополните в порту');sfx('deny');return}
 if(!P.locked){uiNote('Нет захвата: держите цель в прицеле');sfx('deny');return}const w=wDef(f.mis.id);f.mis.ammo--;
 const q=P.q;W.missiles.push({p:add(P.pos,qrot(q,[0,-1.2,2])),q,spd:P.spd*.6+40,max:w.speed,turn:w.turn,tgt:P.locked,owner:'p',dmg:w.dmg,life:w.life,cluster:w.cluster||0,wid:f.mis.id,arm:.25,los:0});sfx('missile')}
function enemyMissile(e){W.missiles.push({p:add(e.pos,qrot(e.q,[0,-2,e.r])),q:e.q,spd:e.spd*.6+30,max:230,turn:2.2,tgt:P,owner:'e',dmg:18,life:8,cluster:0,src:e,arm:.3,los:0});if(dist(e.pos,P.pos)<1600)sfx('missile')}
function updateMissiles(dt){for(const m of W.missiles){m.life-=dt;m.arm-=dt;m.spd=Math.min(m.max,m.spd+180*dt);const tg=m.tgt;
  if(tg&&!m.lost&&!(tg.dead||(tg===P&&!P.alive))){m.los-=dt;if(m.los<=0){m.los=.25;if(!losClear(m.p,tg.pos)){m.lost=true;if(tg===P)uiNote('Ракета потеряла вас за астероидом')}}
   if(tg===P&&P.jamT>0){m.lost=true}
   if(tg===P&&P.stealthT>0)m.lost=true;
   const tv=tg===P?P.vel:(tg.vel||[0,0,0]);const tt=dist(m.p,tg.pos)/Math.max(50,m.spd);const want=norm(sub(add(tg.pos,scl(tv,tt*.5)),m.p));m.q=turnToward(m.q,want,m.turn*dt)}
  const f=FWD(m.q);const a=m.p;m.p=add(m.p,scl(f,m.spd*dt));
  if(Math.random()<.7)part(sub(m.p,scl(f,1.5)),scl(f,-20),.5,[.7,.7,.75],1.6,true);part(sub(m.p,scl(f,1)),[0,0,0],.08,[1,.7,.3],1.8);
  if(m.arm>0)continue;
  if(m.cluster&&tg&&!m.lost&&dist(m.p,tg.pos)<180){for(let i=0;i<m.cluster;i++){const d=norm(add(norm(sub(tg.pos,m.p)),scl(rndDir(),.18)));W.shots.push({p:[...m.p],v:scl(d,420),life:1.2,owner:m.owner,dmg:14,kind:'plasma',r:2,shieldMul:1,hullMul:1})}explode(m.p,.4);m.life=0;continue}
  const victims=m.owner==='p'?W.enemies:[P];for(const v of victims){if(v.dead||(v===P&&!P.alive))continue;const rr=v===P?5.5:v.cls==='capital'?40:v.r;if(segSphere(a,m.p,v.pos,rr+2)){damage(v,m.dmg,m.p,m.src||null,{});explode(m.p,.5);m.life=0;break}}
  if(m.life>0)for(const s of W.asts){if(dist(s.pos,m.p)<s.r){explode(m.p,.4);m.life=0;break}}}
 W.missiles=W.missiles.filter(m=>m.life>0);if(W.missiles.length>60)W.missiles.splice(0,W.missiles.length-60)}
// countermeasures
function useJammer(){const st=shipStats();if(!st.jam){uiNote('Постановщик помех не установлен');return}if((P.jamCharges??st.jam)<=0){uiNote('Помехи кончились');sfx('deny');return}
 P.jamCharges=(P.jamCharges??st.jam)-1;P.jamT=1.2;for(const m of W.missiles)if(m.tgt===P)m.lost=true;for(let i=0;i<20;i++)part(P.pos,scl(rndDir(),rnd(20,60)),1.2,[1,.85,.4],2.5);sfx('jam');uiNote('Помехи! Осталось: '+P.jamCharges)}
function useStealth(){const st=shipStats();if(!st.stealth){uiNote('Глушитель сигнатуры не установлен');return}if((P.stealthCd||0)>0){uiNote('Перезарядка '+Math.ceil(P.stealthCd)+' с');return}
 P.stealthT=st.stealth;P.stealthCd=40;for(const e of W.enemies)if(e.tgt===P){e.state='search';e.st=0}sfx('jam');uiNote('Сигнатура скрыта')}
// ---- enemies ----
function spawnEnemy(cls,pos,tgt,opts={}){const d=ENEMY_CLS[cls];const a=enemyAsset(cls);
 const e={kind:'enemy',cls,type:cls,name:opts.name||d.name,pos:[...pos],q:qLook(sub(P.pos,pos)),vel:[0,0,0],spd:d.speed*.8,hull:d.hull,max:d.hull,shield:d.shield,maxSh:d.shield,shT:9,
  state:'approach',st:0,idx:W.enemies.length+Math.floor(Math.random()*5),cd:rnd(.5,1.5),burst:0,bursts:0,charge:0,chargeCd:rnd(3,5),misCd:rnd(5,8),lockT:0,
  tgt:tgt||P,r:d.r,shieldFx:0,hitPt:null,side:Math.random()<.5?1:-1,hot:[],slowT:0,disT:0,protect:opts.protect||null,faction:opts.faction||'wake',bounty:opts.bounty||0};
 if(cls==='capital'){e.nodes=a.nodes.map(n=>({...n,max:n.hp}));e.q=opts.q||qLook([0,0,1])}
 W.enemies.push(e);return e}
function tgtPos(e){return e.tgt===P?P.pos:e.tgt.pos}
function capSpheres(e){const out=[];for(let z=-80;z<=60;z+=28)out.push({c:add(e.pos,qrot(e.q,[0,0,z])),r:30});return out}
function attackers(){return W.enemies.filter(e=>e.tgt===P&&(e.state==='attack'||e.state==='approach'||e.state==='reattack')).length}
function updateEnemy(e,dt){if(e.test){e.pos=add(e.pos,scl(e.vel,dt));return}const d=ENEMY_CLS[e.cls];
 if(e.tgt!==P&&(!e.tgt||e.tgt.dead))e.tgt=P;
 e.slowT=Math.max(0,e.slowT-dt);e.disT=Math.max(0,e.disT-dt);
 if(e.cls==='capital')return updateCapital(e,dt);
 const T=tgtPos(e),VT=e.tgt===P?P.vel:e.tgt.vel||[0,0,0];const rel=sub(T,e.pos),dd=len(rel);
 const f=FWD(e.q);const lt=leadTime(e.pos,e.vel,d.shotSpeed,T,VT);const aim=norm(sub(add(T,scl(VT,lt)),e.pos));const ang=Math.acos(clamp(dot(f,aim),-1,1));
 e.st+=dt;let want=aim,spd=d.speed;const ok=(P.alive||e.tgt!==P)&&!(e.tgt===P&&P.stealthT>0);
 // retreat when badly damaged
 if(e.hull<e.max*.22&&e.state!=='flee'&&e.cls!=='heavy'){e.state='flee';e.st=0;if(dist(e.pos,P.pos)<1500)uiNote(e.name+' выходит из боя')}
 // attack slots: a newcomer is never mobbed by everyone at once
 const maxAtk=(S&&S.stats&&S.stats.kills||0)<8?2:3;
 if(e.tgt===P&&(e.state==='approach'||e.state==='reattack')&&!e.token){if(attackers()>maxAtk){e.state='hold';e.st=0}else e.token=true}
 if(e.tgt===P&&P.stealthT>0&&e.state!=='flee')e.state='search';
 switch(e.state){
  case 'approach':{const side=norm(cross(rel,[0,1,0]));const k=e.cls==='flanker'?520:450;const off=dd>650?add(T,scl(side,e.side*Math.min(k,dd*.45))):T;want=norm(sub(off,e.pos));
   if(e.cls==='missileer'){if(dd<1000){e.state='standoff';e.st=0}}else if(dd<850&&ang<.6){e.state='attack';e.st=0;e.bursts=0}break}
  case 'attack':{spd=d.speed*(e.cls==='heavy'?.8:.9);
   if(e.cls==='flanker'){const side=norm(cross(rel,[0,1,0]));if(dd<420)want=norm(add(aim,scl(side,e.side*.9)))}
   if(ok&&ang<.07&&dd<760&&e.disT<=0)fireEnemy(e,dt,f);
   if(dd<(e.cls==='heavy'?240:170)||(e.cls==='interceptor'&&e.bursts>=2)||e.st>(e.cls==='heavy'?10:6)){e.state='breakoff';e.st=0;e.token=false;
    const ax=norm(cross(rel,[0,1,0]));const k=e.idx*2.3;e.bo=norm(add(add(scl(norm(rel),.7),scl(ax,Math.cos(k)*1.1)),[0,Math.sin(k)*.7,0]))}break}
  case 'breakoff':{want=e.bo;if(e.st>(e.cls==='heavy'?3.4:2.6)||dd>1100){e.state='reattack';e.st=0}break}
  case 'reattack':{if(ang<.5&&dd<900){e.state='attack';e.st=0;e.bursts=0}if(e.st>8)e.state='approach';break}
  case 'hold':{const side=norm(cross(rel,[0,1,0]));const orbit=add(T,add(scl(norm(rel),-700),scl(side,e.side*300)));want=norm(sub(orbit,e.pos));spd=d.speed*.7;if(e.st>3&&attackers()<maxAtk){e.state='approach';e.st=0}break}
  case 'standoff':{const keep=dd<800?scl(aim,-1):dd>1200?aim:norm(cross(rel,[0,1,0]));want=norm(add(keep,scl(aim,.3)));spd=d.speed*.8;
   e.misCd-=dt;if(ok&&e.misCd<=1.6&&e.misCd>0&&e.tgt===P){P.warnLock=e;P.warnT=.3}if(ok&&e.misCd<=0){enemyMissile(e);e.misCd=rnd(7,10)}if(ok&&ang<.08&&dd<700)fireEnemy(e,dt,f);break}
  case 'search':{want=norm(add(FWD(e.q),[Math.sin(e.st)*.3,0,Math.cos(e.st)*.3]));spd=d.speed*.6;if(e.st>3&&!(P.stealthT>0)){e.state='approach';e.st=0}break}
  case 'flee':{want=norm(scl(rel,-1));spd=d.speed;if(dd>2600){e.gone=true}break}
 }
 if(e.cls==='support'){const ally=W.enemies.filter(o=>o!==e&&!o.dead&&o.cls!=='capital').sort((a,b)=>a.shield/a.maxSh-b.shield/b.maxSh)[0];
  if(ally&&e.state!=='flee'){const to=sub(ally.pos,e.pos);want=len(to)>250?norm(to):norm(cross(to,[0,1,0]));if(len(to)<320){ally.shield=Math.min(ally.maxSh,ally.shield+12*dt);if(Math.random()<dt*6)part(vlerp(e.pos,ally.pos,Math.random()),[0,0,0],.4,[.4,.9,1],1.5)}
   if(dist(e.pos,P.pos)<450)want=norm(add(want,scl(norm(sub(e.pos,P.pos)),1.5)))}}
 if(e.cls==='guard'&&e.protect&&!e.protect.dead&&e.state!=='flee'){const pr=e.protect;const thr=W.enemies.length&&P;const dP=dist(P.pos,pr.pos);
  if(!(e.hostile)&&dP>900){const slot=add(pr.pos,qrot(pr.q||[0,0,0,1],[e.side*60,20,40]));want=norm(sub(slot,e.pos));spd=Math.min(d.speed,len(sub(slot,e.pos))*.8+40)}}
 // heavy charged shot
 if(e.cls==='heavy'&&ok&&e.disT<=0){e.chargeCd-=dt;if(e.charge>0){e.charge-=dt;if(e.charge<=0){const nose=add(e.pos,qrot(e.q,[0,.1,9]));W.shots.push({p:nose,v:add(scl(f,330),e.vel),life:3,owner:'e',dmg:24,kind:'echarge',src:e,r:2.5,shieldMul:1,hullMul:1});sfx('plasma');e.chargeCd=rnd(4.5,6)}}
  else if(e.chargeCd<=0&&ang<.12&&dd<800){e.charge=.5;if(dist(e.pos,P.pos)<1500)sfx('charge')}}
 // separation + avoidance
 for(const o of W.enemies)if(o!==e){const v=sub(e.pos,o.pos),l=len(v);const rr=o.cls==='capital'?140:80;if(l<rr&&l>0)want=norm(add(want,scl(v,1.5/l*(rr-l)/rr)))}
 for(const a of W.asts){const v=sub(e.pos,a.pos),l=len(v);if(l<a.r+40)want=norm(add(want,scl(v,2/l)))}
 const turn=d.turn*(e.slowT>0?.5:1);e.q=turnToward(e.q,want,turn*dt);e.spd=lerp(e.spd,spd*(e.slowT>0?.35:1),damp(1.5,dt));const nf=FWD(e.q);e.vel=scl(nf,e.spd);e.pos=add(e.pos,scl(e.vel,dt));
 e.shT+=dt;if(e.shT>5)e.shield=Math.min(e.maxSh,e.shield+dt*6);e.shieldFx=Math.max(0,e.shieldFx-dt*3);
 // damage states: smoke & hot spots
 if(e.hull<e.max*.5&&Math.random()<dt*(e.hull<e.max*.25?14:6))part(add(e.pos,qrot(e.q,[rnd(-2,2),rnd(0,1.5),rnd(-3,1)])),add(scl(e.vel,.3),scl(rndDir(),3)),rnd(.8,1.6),[.3,.3,.32],rnd(1.5,3),true);
 for(const h of e.hot){h.t-=dt;if(Math.random()<dt*8)part(add(e.pos,qrot(e.q,h.l)),scl(e.vel,.9),.25,[1,.5,.2],1.2)}e.hot=e.hot.filter(h=>h.t>0)}
function fireEnemy(e,dt,f){const d=ENEMY_CLS[e.cls];e.cd-=dt;if(e.cd>0)return;
 if(e.cls==='interceptor'){e.burst++;e.cd=.09;if(e.burst>=5){e.burst=0;e.bursts++;e.cd=1.1}}else if(e.cls==='flanker'){e.burst++;e.cd=.14;if(e.burst>=3){e.burst=0;e.cd=.9}}else e.cd=e.cls==='guard'?.22:.32;
 const a=enemyAsset(e.cls);const g=a.guns[e.burst%a.guns.length];const gp=add(e.pos,qrot(e.q,g));const dir=norm(add(f,scl(rndDir(),.012)));
 W.shots.push({p:gp,v:add(scl(dir,d.shotSpeed),e.vel),life:1.8,owner:'e',dmg:d.dmg,kind:'epulse',src:e,r:1,shieldMul:1,hullMul:1});if(dist(e.pos,P.pos)<1200)sfx('enemyShot')}
// capital ship: slow, turret nodes fire, nodes destroyable
function updateCapital(e,dt){const eng=e.nodes.find(n=>n.id==='eng');const spd=eng&&eng.hp>0?ENEMY_CLS.capital.speed:0;
 if(e.route){const to=sub(e.route,e.pos);if(len(to)>50)e.q=turnToward(e.q,norm(to),.08*dt)}e.vel=scl(FWD(e.q),spd);e.pos=add(e.pos,scl(e.vel,dt));e.spd=spd;
 e.shT+=dt;if(e.shT>6)e.shield=Math.min(e.maxSh,e.shield+dt*10);e.shieldFx=Math.max(0,e.shieldFx-dt*2);
 for(const n of e.nodes){if(n.hp<=0)continue;n.cd=(n.cd||rnd(0,1))-dt;const np=add(e.pos,qrot(e.q,n.pos));const dd=dist(np,P.pos);
  if(n.id.startsWith('t')&&n.id!=='t3'&&n.cd<=0&&dd<1300&&P.alive&&!(P.stealthT>0)){n.cd=.45;const lt=leadTime(np,e.vel,480,P.pos,P.vel);const dir=norm(add(sub(add(P.pos,scl(P.vel,lt)),np),scl(rndDir(),8)));
   W.shots.push({p:np,v:scl(dir,480),life:3,owner:'e',dmg:6,kind:'epulse',src:e,r:1.2,shieldMul:1,hullMul:1});if(dd<1500)sfx('enemyShot')}
  if(n.id==='t3'&&n.cd<=0&&dd<1600&&P.alive&&!(P.stealthT>0)){n.cd=9;P.warnLock=e;P.warnT=1;setTimeout(()=>{if(!e.dead&&n.hp>0&&W&&W.enemies.includes(e))enemyMissile({pos:np,q:qLook(sub(P.pos,np)),spd:30,r:2,name:e.name})},1500)}}
 if(e.hull<e.max*.5&&Math.random()<dt*10)part(add(e.pos,qrot(e.q,[rnd(-30,30),rnd(0,20),rnd(-80,60)])),scl(rndDir(),5),rnd(1,2),[.3,.3,.32],rnd(4,8),true)}
function hitCapital(e,a,b,s){for(const n of e.nodes){if(n.hp<=0)continue;const np=add(e.pos,qrot(e.q,n.pos));if(segSphere(a,b,np,n.r+s.r)){n.hp-=s.dmg*(s.hullMul||1);damage(e,s.dmg*.25,b,null,{shieldMul:s.shieldMul,hullMul:s.hullMul,noFx:false});
  if(n.hp<=0){explode(np,1.2,e.vel);uiNote('Уничтожен узел: '+n.name);if(W.onNode)W.onNode(e,n)}return true}}
 for(const sp of capSpheres(e))if(segSphere(a,b,sp.c,sp.r)){damage(e,s.dmg,b,null,{shieldMul:s.shieldMul,hullMul:s.hullMul});return true}return false}
// ---- damage & effects ----
function damage(t,amt,pt,src,o={}){const isP=t===P;const sm=o.shieldMul||1,hm=o.hullMul||1;
 if(t.shield>0){t.shield-=amt*sm;t.shieldFx=1;t.hitPt=pt;if(t.shield<0){t.hull+=t.shield/sm*hm;t.shield=0}if(!o.beam&&(isP||dist(t.pos,P.pos)<900))sfx('shieldHit');
  if(!o.beam||Math.random()<.3)for(let i=0;i<5;i++)part(pt,scl(rndDir(),rnd(5,20)),.3,[.4,.8,1],1.1)}
 else{t.hull-=amt*hm;if(!o.beam&&(isP||dist(t.pos,P.pos)<900))sfx('hullHit');const dir=src&&src.pos?norm(sub(pt,src.pos)):norm(sub(pt,P.pos));
  for(let i=0;i<(o.beam?2:10);i++)part(pt,add(scl(dir,rnd(15,45)),scl(rndDir(),12)),rnd(.25,.6),[1,.75,.35],.8);
  if(!o.beam)for(let i=0;i<3;i++)part(pt,add(scl(dir,8),scl(rndDir(),6)),rnd(1,2),[.35,.33,.3],1.2,true);
  if(t.hot&&t.max>=110&&!o.beam){t.hot.push({l:qrot(qconj(t.q),sub(pt,t.pos)),t:1.6});if(t.hot.length>6)t.hot.shift()}}
 if(isP){P.shieldT=0;P.repT=0;P.shake=Math.min(1,P.shake+(t.shield>0?.2:.45));if(src){P.dmgDirs.push({from:src.pos?[...src.pos]:src,t:1.2});P.lastSrc=src.name||'огонь противника'}
  if(P.hull<=0)playerDied(src&&src.name?'Корабль уничтожен: '+src.name.toLowerCase():'Корабль уничтожен')}
 else{t.shT=0;if(t.hull<=0&&!t.dead){t.dead=true;onKill(t)}}}
function onKill(t){explode(t.pos,t.cls==='heavy'?1.3:t.cls==='capital'?3:1,t.vel);sfx('explode');
 if(t.kind==='enemy'&&W&&!G.duel&&t.faction==='wake'){const ow=REG.systems[W.id].owner;if(ow!=='wake'&&ow!=='none')addRep(ow,1)}
 if(t.kind==='enemy'){if(P.target===t)P.target=null;if(P.locked===t){P.locked=null;P.lockT=0}if(S&&S.stats)S.stats.kills=(S.stats.kills||0)+1;
  const chance=t.cls==='heavy'?.75:t.cls==='capital'?1:.45;if(Math.random()<chance&&!G.duel){const g=Math.random()<.5?'parts':'elec';W.conts.push(makeCont(t.pos,g,1+Math.floor(Math.random()*2),scl(t.vel||[0,0,0],.05)))}
  if(t.bounty&&!G.duel){S.cr+=t.bounty;uiNote('Награда за цель: +'+t.bounty+' кр.')}if(W.onKill)W.onKill(t)}
 if(t.kind==='transport'&&W.m4){W.m4.phase='failed';uiM4Failed()}}
// multi-phase explosion: flash -> fireball -> debris along the old velocity -> smoke
function explode(p,s,vel=[0,0,0]){part(p,scl(vel,.5),.14,[1,1,.95],26*s);part(p,scl(vel,.6),.45,[1,.6,.25],16*s);part(p,scl(vel,.6),.7,[1,.4,.15],10*s);
 const n=G.low?16:36;for(let i=0;i<n;i++)part(p,add(scl(vel,.8),scl(rndDir(),rnd(10,55)*s)),rnd(.25,.7),Math.random()<.5?[1,.6,.2]:[1,.85,.5],rnd(1.5,3.2)*s);
 for(let i=0;i<10;i++)part(p,add(scl(vel,.9),scl(rndDir(),rnd(5,22))),rnd(1.2,2.4),[.3,.28,.26],rnd(1,2),true);
 for(let i=0;i<(G.low?3:7);i++)part(add(p,scl(rndDir(),3*s)),add(scl(vel,.4),scl(rndDir(),4)),rnd(1.4,2.4),[.35,.34,.34],rnd(4,7)*s,true)}
function part(p,v,life,c,s,dark){if(!W||W.parts.length>=G.maxParts)return;W.parts.push({p:[...p],v,life,max:life,c,s,dark})}

// ---- allied frigates (campaign) ----
function updateAllies(dt){if(!W.allies||!W.allies.length)return;for(const a of W.allies){if(a.hull<=0){if(!a.dead){a.dead=true;explode(a.pos,1,a.vel)}continue}
 let tgt=null,bd=1500;for(const e of W.enemies){const d=dist(e.pos,a.pos);if(d<bd){bd=d;tgt=e}}
 const want=tgt?norm(sub(tgt.pos,a.pos)):norm(sub(add(P.pos,qrot(P.q,[0,30,-120])),a.pos));a.q=turnToward(a.q,want,1*dt);const spd=tgt?110:clamp(dist(a.pos,P.pos)*.6,20,130);
 a.vel=scl(FWD(a.q),spd);a.pos=add(a.pos,scl(a.vel,dt));a.cd-=dt;
 if(tgt&&a.cd<=0&&bd<800&&dot(FWD(a.q),want)>.97){a.cd=.5;const gp=add(a.pos,qrot(a.q,[0,0,8]));W.shots.push({p:gp,v:add(scl(want,560),a.vel),life:1.6,owner:'p',dmg:5,kind:'pulse',r:1,shieldMul:1,hullMul:1,ally:true})}}
 W.allies=W.allies.filter(a=>!a.dead)}
