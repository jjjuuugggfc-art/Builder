'use strict';
let lastT=performance.now();
(function boot(){
 if(!glInit($('gl'))){document.body.innerHTML='<p style="padding:30px">WebGL недоступен на этом устройстве</p>';return}
 if(!localStorage.getItem(SET_KEY)&&G.touch)SET.quality='low';
 G.low=SET.quality==='low';G.maxParts=G.low?700:2500;
 renderInit();buildModels();inputInit();menuInit();resizeGL();addEventListener('resize',resizeGL);
 // menu backdrop: Amber system from the hangar
 S=defaultSave();buildSystem('yantar');newPlayer();P.pos=stationWorld(STATIONS.kromka.spot);cam.mode='hangar';
 const s=readSave();S=s||defaultSave();
 uiMenu();
 function frame(now){let dt=(now-lastT)/1000;lastT=now;dt=Math.min(dt,.05);
  if(G.mode==='fly')readInput(dt);
  if(G.mode!=='pause'&&G.mode!=='map'&&G.mode!=='menu')update(dt);else if(W)ambient(dt*.3);
  render(dt);drawHUD(dt);requestAnimationFrame(frame)}
 requestAnimationFrame(frame);
 window.__G={G,get S(){return S},get W(){return W},get P(){return P}};
})();
