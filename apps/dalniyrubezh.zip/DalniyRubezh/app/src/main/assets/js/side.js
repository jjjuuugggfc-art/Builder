'use strict';
// ================= SIDE CONTENT: reputation, traffic, bars, secrets, side chains, contracts, home dock =================
// ---------- reputation ----------
function rep(f){return (S.rep&&S.rep[f])||0}
function addRep(f,v,why){if(!f||f==='none')return;S.rep=S.rep||{};S.rep[f]=clamp((S.rep[f]||0)+v,-100,100);if(why&&Math.abs(v)>=5)uiNote((v>0?'Отношения улучшились: ':'Отношения ухудшились: ')+REG.factions[f].short+' ('+(v>0?'+':'')+v+')')}
function repLabel(v){return v>=50?'союзник':v>=20?'дружелюбно':v>-20?'нейтрально':v>-40?'настороженно':'враждебно'}
const SHIP_REP={teira_hunt:['teira',20],teira_ark:['teira',20],essen_wave:['essen',10],bastion:['league',15],bezymyanny:['wake',0]};
function shipLocked(id){const r=SHIP_REP[id];if(id==='bezymyanny'&&!S.bhAccess)return 'Продаётся только своим в Гавани';if(r&&rep(r[0])<r[1])return 'Нужны отношения «'+REG.factions[r[0]].short+'» не ниже '+r[1]+' (сейчас '+rep(r[0])+')';return ''}
function dockBlocked(stId){const f=REG.stations[stId].faction;if(stId.startsWith('bh_')&&!S.bhAccess&&!S.bhPending)return 'Гавань не принимает без разрешения патруля';
 if(stId.startsWith('bh_')&&S.bhHanded&&!S.bhForgiven)return 'Гавань помнит предательство: нужна компенсация';if(f&&f!=='none'&&rep(f)<=-40)return 'Порт закрыт для вас: отношения '+rep(f);return ''}
function compensation(stId){const f=REG.stations[stId].faction;return stId.startsWith('bh_')&&S.bhHanded?2500:Math.max(500,(-rep(f)-30)*60)}
function payCompensation(stId){return atomic(()=>{const c=compensation(stId);if(S.cr<c)return 'Нужно '+c+' кр.';S.cr-=c;const f=REG.stations[stId].faction;if(stId.startsWith('bh_'))S.bhForgiven=true;else S.rep[f]=-20;saveGame();return ''})}
// ---------- civilian traffic, patrols, convoys ----------
function spawnTraffic(){W.npcs=[];const sys=REG.systems[W.id];if(sys.hidden&&W.id!=='black_harbor')return;const fac=W.id==='black_harbor'?'wake':sys.owner;if(!W.station)return;const R=srand(hashStr(W.orbit)+9);
 const n=fac==='wake'||fac==='none'?1:2;for(let i=0;i<n;i++){const a=R()*6.28;W.npcs.push({kind:'npc',role:'patrol',faction:fac,name:'Патруль «'+REG.factions[fac==='none'?'league':fac].short+'»',cls:'guard',pos:[Math.cos(a)*1400,200+i*80,Math.sin(a)*1400],q:[0,0,0,1],vel:[0,0,0],spd:90,hull:200,max:200,shield:120,maxSh:120,r:8,ang:a,cd:1,shieldFx:0})}
 const exit=W.gates[0]?W.gates[0].pos:W.beacon?W.beacon.pos:null;if(exit&&fac!=='wake'){const t={kind:'npc',role:'convoy',faction:fac,name:'Конвой «'+(R()<.5?'Северный ветер':'Тихая вода')+'»',mesh:'transport',pos:add(exit,[0,80,300]),q:qLook(sub([0,0,0],exit)),vel:[0,0,0],spd:45,hull:400,max:400,shield:60,maxSh:60,r:30,to:stationWorld(STATIONS[W.orbit].entrance),shieldFx:0,escortT:0};W.npcs.push(t);
  W.npcs.push({kind:'npc',role:'guard',faction:fac,name:'Охрана конвоя',cls:'guard',pos:add(t.pos,[60,30,0]),q:t.q,vel:[0,0,0],spd:45,hull:180,max:180,shield:100,maxSh:100,r:8,follow:t,cd:1,shieldFx:0})}}
function npcHostile(n,why){if(n.dead)return;const e=spawnEnemy(n.cls||'guard',n.pos,P,{name:n.name,faction:n.faction});if(n.mesh==='transport'){e.cls='guard'}e.hull=n.hull;W.npcs=W.npcs.filter(x=>x!==n);
 for(const o of W.npcs)if(o.faction===n.faction&&o.role!=='convoy'){const e2=spawnEnemy('guard',o.pos,P,{name:o.name,faction:o.faction});W.npcs=W.npcs.filter(x=>x!==o)}
 addRep(n.faction,-15,true);uiDialog([['Диспетчер','Борт открыл огонь по патрулю. Объявлен нарушителем.']],true)}
function npcHit(n,dmg,pt){n.shieldFx=1;if(n.shield>0)n.shield-=dmg;else n.hull-=dmg;for(let i=0;i<4;i++)part(pt,scl(rndDir(),12),.3,[.4,.8,1],1);
 G.ffT=G.ffT||0;if(G.time-G.ffT<30){npcHostile(n)}else{G.ffT=G.time;uiDialog([[n.name,'Прекратить огонь! Следующий выстрел — и мы ответим.']],true);sfx('deny')}}
function updateNPCs(dt){if(!W.npcs)return;let alarm=false;for(const n of W.npcs){let near=null,nd=1500;for(const e of W.enemies){const d=dist(e.pos,n.pos);if(d<nd){nd=d;near=e}}
  if(n.role==='patrol'||n.role==='guard'){let want;if(near){want=norm(sub(near.pos,n.pos));alarm=true;n.cd-=dt;if(n.cd<=0&&nd<800&&dot(FWD(n.q),want)>.97){n.cd=.5;W.shots.push({p:add(n.pos,qrot(n.q,[0,0,8])),v:add(scl(want,560),n.vel),life:1.6,owner:'p',dmg:5,kind:'pulse',r:1,shieldMul:1,hullMul:1,ally:true})}}
   else if(n.follow&&!n.follow.dead){want=norm(sub(add(n.follow.pos,[60,30,0]),n.pos))}else if(rep(n.faction)>=30&&W.enemies.length&&dist(P.pos,n.pos)<3000){want=norm(sub(add(P.pos,qrot(P.q,[40,20,-80])),n.pos))}
   else{n.ang+=dt*.05;want=norm(sub([Math.cos(n.ang)*1400,n.pos[1],Math.sin(n.ang)*1400],n.pos))}
   const sp=near?110:n.follow?Math.max(30,(n.follow.spd||40)+10):70;n.q=turnToward(n.q,want,.9*dt);n.vel=scl(FWD(n.q),sp);n.pos=add(n.pos,scl(n.vel,dt))}
  else if(n.role==='convoy'){const to=sub(n.to,n.pos);const d=len(to);const fleeing=W.enemies.some(e=>dist(e.pos,n.pos)<1500);n.spd=lerp(n.spd,d<300?15:fleeing?80:45,damp(.5,dt));n.q=turnToward(n.q,norm(to),.25*dt);n.vel=scl(FWD(n.q),n.spd);n.pos=add(n.pos,scl(n.vel,dt));
   if(dist(P.pos,n.pos)<600&&P.alive)n.escortT+=dt;if(d<200){if(n.escortT>40){S.cr+=150;addRep(n.faction,2);uiNote('Конвой благодарит за сопровождение: +150 кр.')}n.dead=true}}
  n.shieldFx=Math.max(0,(n.shieldFx||0)-dt*3);if(n.hull<=0&&!n.dead){n.dead=true;explode(n.pos,1,n.vel)}}
 W.npcs=W.npcs.filter(n=>!n.dead);if(alarm&&(!G.alarmT||G.time-G.alarmT>60)){G.alarmT=G.time;uiDialog([['Диспетчер «'+W.station.name+'»','Всем бортам: в секторе противник. Грузовым — укрыться у причала.']],true)}}
// ---------- bars, rumors, clues ----------
const CLUES={};
Object.assign(CLUES,{bh_complaint:'Перевозчица в баре «Последний Ход»: пираты заплатили за медконтейнер старыми портовыми жетонами.',bh_lights:'На обороте жетона — схема трёх огней: смотреть так, чтобы они сложились в одну точку.',
 bh_corridor:'Створ трёх огней у погасшего ретранслятора Гари открыл коридор к старым воротам.',sg_rumor:'В Шёпоте Дуги на трёх орбитах «поют» буи. Говорят, вместе они открывают тишину.',sg_note1:'Нота буя заставы: один красный импульс.',sg_note2:'Нота буя обсерватории: два зелёных импульса.',sg_note3:'Нота буя обители: три синих импульса.',
 ark_manifest:'Манифест пропавшего медгруза: последний сигнал — Пустошь Верна.',wp_bear1:'Маяк K-3: пеленг искривлён к северу.',wp_bear2:'Маяк K-9: пеленг искривлён к востоку.',s9_inv1:'Накладная №1: «Девятый склад, кольцо три».',s9_inv2:'Накладная №2: «…за Ржавым Рейдом, по пеленгу цеха».',s9_inv3:'Накладная №3: «Код доступа: девятка трижды».',
 izn_cradle:'В Изнанке осталась «Колыбель» — узел, мимо которого пришлось пролететь.'});
function addClue(k){S.clues=S.clues||[];if(!S.clues.includes(k)){S.clues.push(k);uiNote('Новая улика в журнале');saveGame();checkDiscoveries()}}
function hasClue(k){return (S.clues||[]).includes(k)}
function keyItem(k){return (S.keyItems||[]).includes(k)}
function giveKey(k){S.keyItems=S.keyItems||[];if(!S.keyItems.includes(k))S.keyItems.push(k)}
function discover(sys,msg){S.discovered=S.discovered||[];if(S.discovered.includes(sys))return;S.discovered.push(sys);S.marks=S.marks||[];if(!S.marks.includes(sys))S.marks.push(sys);saveGame();
 uiDialog([['Бортовой ИИ',msg||'На карте появилась система «'+REG.systems[sys].name+'».']],G.mode!=='hangar');if(W&&G.mode==='fly'){const keep={pos:P.pos,q:P.q};rebuildGates()}}
function rebuildGates(){if(!W||!W.sys.main)return;const sys=W.sys;const nb=neighbours(W.id);for(const to of nb){if(gateTo(to))continue;let pos=sys.gatePos[to]||HIDDEN_GATE[W.id+'>'+to];if(!pos){const m0=REG.systems[W.id].map,m1=REG.systems[to].map;const a=Math.atan2(m1[1]-m0[1],m1[0]-m0[0]);pos=[Math.cos(a)*5200,-300,Math.sin(a)*5200+1500]}
 const dir=norm(sub([0,0,0],pos));W.gates.push({kind:'gate',name:'Ворота → '+REG.systems[to].name,pos,dir,q:qLook(dir),to,r:110,nav:true,old:REG.systems[to].hidden})}}
const HIDDEN_GATE={'gar>black_harbor':[-6600,400,5600],'shepot>silent_garden':[-4200,-300,-3600],'pustosh>ark':[-4800,600,-3600],'kobalt>white_pocket':[4400,900,-4200],'rzhavy>sklad9':[5200,-400,4400],'mezha>iznanka':[0,1200,-6200]};
function checkDiscoveries(){if(hasClue('sg_note1')&&hasClue('sg_note2')&&hasClue('sg_note3'))discover('silent_garden','Три ноты сложились в аккорд. Мёртвые ворота у Шёпота Дуги отозвались.');
 if(hasClue('wp_bear1')&&hasClue('wp_bear2')&&hasClue('wp_bear3'))discover('white_pocket','Пеленги маяков сошлись: искривление указывает на скрытые ворота в Кобальте.');
 if(hasClue('s9_inv1')&&hasClue('s9_inv2')&&hasClue('s9_inv3'))discover('sklad9','Накладные расшифрованы: старые ворота за Ржавым Рейдом ведут на Склад Девять.')}
CLUES.wp_bear3='Маяк K-7 (повторно): эхо указывает вниз по эклиптике.';
// bar talk per station: [id,text,action]
function barTopics(){const st=S.station,out=[];
 if(st==='raz_bar'){out.push({who:'Мира Сайт',text:'Пираты отпустили меня пустой, представляешь? Зато за медконтейнер заплатили — старыми портовыми жетонами. Кому они нужны?',fn:()=>addClue('bh_complaint')});
  if(hasClue('bh_lights')&&!hasClue('bh_corridor')&&(S.bhTries||0)>=1)out.push({who:'Барный навигатор',text:'Огни, говоришь? Встань за дальним огнём так, чтобы все три слились в одну точку, и сбавь ход до нуля. Тогда сканер увидит коридор.'})}
 if(st==='kil_pena'||st==='kil_bazaar'){if(hasClue('bh_complaint')&&!keyItem('token'))out.push({who:'Посредник',text:'Портовый жетон? Есть один. 800 кредитов, и я тебя не видел.',buy:800,fn:()=>{giveKey('token');uiNote('Получен предмет: старый портовый жетон')}});
  if(!hasClue('s9_inv2')&&st==='kil_pena')out.push({who:'Старый грузчик',text:'Накладные со старых рейсов? Одна завалялась. 200 — и она твоя.',buy:200,fn:()=>addClue('s9_inv2')})}
 if(st==='rzh_port'&&!hasClue('s9_inv1'))out.push({who:'Разборщик',text:'Нашёл в обломке пачку накладных. Одна — с чужим шифром. Возьмёшь за 200?',buy:200,fn:()=>addClue('s9_inv1')});
 if(st==='pus_shel'){if(!hasClue('s9_inv3'))out.push({who:'Беженка',text:'Мой муж возил грузы на какой-то «девятый склад». Вот его последняя накладная. Денег не надо — пусть хоть кому-то пригодится.',fn:()=>addClue('s9_inv3')})}
 if(st==='shp_hab'&&!hasClue('sg_rumor'))out.push({who:'Отшельник Хора',text:'Буи на трёх орбитах поют, но никто не слушает. Сложи их песню — и тишина откроется.',fn:()=>addClue('sg_rumor')});
 if(st==='kob_port'&&!hasClue('wp_bear1')&&!S.side?.done?.s_sig1)out.push({who:'Смотритель маяков',text:'Маяки врут. Пеленги гнутся, будто рядом что-то тяжёлое и горячее. Поговори с обсерваторией.'});
 if(!out.length)out.push({who:'Бармен',text:'Тихо сегодня. Возьми что-нибудь и слушай эфир.'});return out}
// ---------- Black Harbor ----------
const BH_RELAY=[-3600,200,3400];const BH_AXIS=norm([-.55,.12,.83]);
function bhLights(){return [0,1,2].map(i=>add(BH_RELAY,add(scl(BH_AXIS,260+i*340),[i===1?14:i===2?-10:0,i*6,0])))}
function bhAlign(){const L=bhLights();const d=L.map(l=>norm(sub(l,P.pos)));const a1=Math.acos(clamp(dot(d[0],d[1]),-1,1)),a2=Math.acos(clamp(dot(d[0],d[2]),-1,1));const behind=dot(sub(P.pos,L[0]),BH_AXIS)<-200;return behind?Math.max(a1,a2):1}
function secretsUpdate(dt){if(!W||G.mode!=='fly')return;
 if(W.id==='gar'&&W.sys.main){const L=bhLights();const near=dist(P.pos,BH_RELAY)<5000;if(near&&hasClue('bh_lights')&&!hasClue('bh_corridor')){G.bhStay=(G.bhStay||0)+dt;if(G.bhStay>60&&!G.bhTried){G.bhTried=true;S.bhTries=(S.bhTries||0)+1}}
  W.bhAlign=near?bhAlign():1}
 if(W.id==='black_harbor')bhArrival(dt);
 if(W.id==='white_pocket'){let shadow=false;const sun=W.sys.sun;for(const a of W.asts){const oc=sub(a.pos,P.pos);const t=dot(oc,sun);if(t<0||t>900)continue;if(dot(oc,oc)-t*t<a.r*a.r){shadow=true;break}}
  P.starHeat=clamp((P.starHeat||0)+(shadow?-18:7)*dt,0,110);W.inShadow=shadow;if(P.starHeat>=100){P.hull-=8*dt;P.shake=.2;if(P.hull<=0)playerDied('Корабль сгорел у карликовой звезды')}}
 else P.starHeat=0;
 if(S.home&&S.home.level>=1&&W.orbit===S.home.st&&dist(P.pos,W.station.pos)<2200)playScene('home')}
function secretsAction(){if(W.id==='gar'&&W.sys.main&&hasClue('bh_lights')&&!hasClue('bh_corridor')&&dist(P.pos,BH_RELAY)<4000){const a=W.bhAlign;if(a<.025)return {label:P.spd>15?'Сбавьте ход для скана':'Сканировать створ',fn:()=>{if(P.spd>15){uiNote('Огни дрожат — сбавьте ход до нуля');return}addClue('bh_corridor');discover('black_harbor','Огни сложились в створ. Сканер видит узкий коридор к старым воротам.')}}}
 for(const p of W.secretPois||[]){if(dist(P.pos,p.pos)<p.r&&!p.done&&(!p.need||p.need()))return {label:p.label,fn:()=>{p.fn();p.done=true}}}return null}
// secret POIs spawned per orbit
function spawnSecretPois(){W.secretPois=[];const o=W.orbit;const sp=(pos,label,r,fn,need,vis)=>W.secretPois.push({pos,label,r,fn,need,vis});
 const buoy=(k,col,n)=>{const pos=qrot(qaxis([0,1,0],hashStr(o)%6),[2200,300,-1400]);W.statics.push({mesh:'buoy',pos,q:[0,0,0,1],s:2.5,sing:{col,n}});W.pois.push({kind:'poi',id:'sing_'+o,name:'Поющий буй',pos,nav:true});sp(pos,'Записать ноту',400,()=>{addClue(k);uiNote('Нота записана: '+n+' × импульс')},()=>hasClue('sg_rumor'))};
 if(o==='shp_post')buoy('sg_note1',[1,.3,.25],1);if(o==='shp_obs')buoy('sg_note2',[.3,1,.4],2);if(o==='shp_hab')buoy('sg_note3',[.3,.5,1],3);
 if(W.id==='gar'&&W.sys.main){W.pois.push({kind:'poi',id:'relay',name:'Погасший ретранслятор',pos:BH_RELAY,nav:true});W.statics.push({mesh:'wreck',pos:BH_RELAY,q:qaxis([0,1,0],1),s:1.3});
  for(let i=0;i<9;i++)W.asts.push({kind:'debris',pos:add(BH_RELAY,[rnd(-900,900),rnd(-200,200),rnd(-900,900)]),r:rnd(10,24),q:qrand(),spin:qaxis(rndDir(),.05),ore:0,mesh:M.debris[i%2],tint:.6,name:'Остов'})}
 if(o==='izn_core'&&S.ending){const pos=[-1800,-400,1200];W.pois.push({kind:'poi',id:'cradle',name:'Колыбель',pos,nav:true});sp(pos,'Исследовать Колыбель',400,()=>{addClue('izn_cradle');if(!S.ships.includes('izn_relic')){S.ships.push('izn_relic');fitOf('izn_relic');saveGame();uiDialog([['Бортовой ИИ','В Колыбели дремал корабль без экипажа. Он откликнулся на ваш позывной.'],['Бортовой ИИ','«Эхо Изнанки» ждёт вас в любом ангаре.']],true)}})}
 if(o==='izn_core'&&!S.ending)W.pois.push({kind:'poi',id:'cradle_hint',name:'Неизвестный узел',pos:[-1800,-400,1200],nav:true})}
function bhArrival(dt){if(S.bhAccess&&!S.bhHanded)return;if(!W.bhPatrol){W.bhPatrol={t:0,comply:0,state:'meet'};if(S.bhHanded&&!S.bhForgiven){for(let i=0;i<3;i++)spawnEnemy('interceptor',add(P.pos,scl(rndDir(),900)),P,{name:'Патруль Гавани'});uiDialog([['Патруль Гавани','Предатель вернулся. Огонь!']],true);W.bhPatrol.state='hostile';return}
  W.npcs=W.npcs||[];for(const sd of [1,-1])W.npcs.push({kind:'npc',role:'bhpatrol',faction:'wake',name:'Перехватчик Гавани',cls:'interceptor',pos:add(P.pos,qrot(P.q,[sd*180,30,250])),q:P.q,vel:[0,0,0],spd:70,hull:55,max:55,shield:30,maxSh:30,r:6.5,shieldFx:0});
  uiDialog([['Патруль Гавани','Неопознанный борт. Выключить форсаж, скорость ниже восьмидесяти. Идёшь за нами.']],true)}
 const bp=W.bhPatrol;if(bp.state!=='meet'&&bp.state!=='escort')return;bp.t+=dt;const pats=W.npcs.filter(n=>n.role==='bhpatrol');
 for(const n of pats){const slot=bp.state==='escort'?add(P.pos,qrot(P.q,[n.pos[0]>P.pos[0]?120:-120,20,260])):add(P.pos,qrot(P.q,[n.pos[0]>P.pos[0]?160:-160,30,200]));n.q=turnToward(n.q,norm(sub(bp.state==='escort'?stationWorld(STATIONS.bh_cyl.entrance):slot,n.pos)),1.5*dt);n.spd=clamp(dist(n.pos,slot)*.5,40,150);n.vel=scl(FWD(n.q),n.spd);n.pos=add(n.pos,scl(n.vel,dt))}
 if(bp.state==='meet'){if(P.boosting||P.spd>85){bp.warn=(bp.warn||0)+dt;if(bp.warn>3){bp.state='hostile';S.bhFled=(S.bhFled||0)+1;for(const n of pats){spawnEnemy('interceptor',n.pos,P,{name:'Перехватчик Гавани'})}W.npcs=W.npcs.filter(n=>n.role!=='bhpatrol');uiDialog([['Патруль Гавани','Беглец. Не уйдёшь.']],true);saveGame()}}
  else{bp.comply+=dt;if(bp.comply>5){bp.state='escort';S.bhPending=true;playScene('harbor');uiDialog([['Патруль Гавани','Так-то лучше. Док — внутри расколотого цилиндра. За нами.']],true);P.nav=W.station}}}}
function bhDockChoice(){if(!S.bhPending||S.bhAccess)return null;return {t:'choice',title:'Вход в Чёрную Гавань',opts:[
  ...(keyItem('token')?[{label:'Предъявить жетон',desc:'Старый портовый жетон Гавани',eff:{fn:'bhToken'}}]:[]),
  {label:'Заплатить за вход 1500 кр.',cost:1500,eff:{fn:'bhPay'}},{label:'Отказаться и улететь',desc:'Гавань запомнит, но вернуться можно',eff:{fn:'bhRefuse'}}]}}
Object.assign(SIDE_FX,{bhToken(){S.bhAccess=true;S.bhPending=false;addRep('wake',10);uiDialog([['Смотритель дока','Жетон старый, но настоящий. Добро пожаловать в Гавань.'],['Смотритель дока','Здесь свои законы. Не стреляй в доке.']]);G.scene='harbor'},
 bhPay(){S.bhAccess=true;S.bhPending=false;uiDialog([['Смотритель дока','Деньги не пахнут. Проходи.']]);G.scene='harbor'},
 bhRefuse(){S.bhPending=false;S.bhFled=(S.bhFled||0)+1;uiDialog([['Смотритель дока','Как знаешь. Ворота открыты в обе стороны — пока.']])},
 bhSecret(){S.bhSecret=true;addRep('wake',20,true)},bhHand(){S.bhHanded=true;S.cr+=3000;addRep('league',20,true);addRep('wake',-40,true)},
 debtPay(){S.discounts=S.discounts||{};S.discounts.stp_north=.9},debtExpose(){addRep('union',20,true);S.discounts=S.discounts||{};S.discounts.stp_north=.9},
 illReport(){addRep('union',10,true);S.illReported=true},illBribe(){S.cr+=1500;addRep('union',-10,true);S.illBribed=true}});
// ---------- side chains (8 × 3) ----------
function SM(id,chain,n,title,giver,from,reward,desc,steps,o={}){MM(id,0,n,title,giver,from,reward,desc,steps,{side:true,chain,...o})}
const CHAIN_NAME={bh:'Чёрная Гавань',crew:'Исчезнувший экипаж',debt:'Долг семейной верфи',teira:'Спорное наследство Тейра',hosp:'Больничный конвой',ill:'Незаконная добыча',coll:'Коллекционер довоенных кораблей',sig:'Сигнал без отправителя'};
SM('bh_1','bh',1,'Ремонт под охраной','mira','bh_cyl',900,'Гражданский транспорт чинят под пиратской охраной. Нужны 6 запчастей.',[{t:'have',good:'parts',qty:6,st:'bh_cyl',say:[L('mira','Ты здесь? Значит, жетон сработал. Помоги людям — привези запчасти.')]}],{next:['bh_2'],after:[L('mira','Транспорт снова на ходу. Его экипаж улетит отсюда свободным.')]});
SM('bh_2','bh',2,'Госпитальный рейс','mira','bh_med',1200,'Госпитальному отсеку нужны 5 ед. медикаментов.',[{t:'have',good:'meds',qty:5,st:'bh_med'}],{next:['bh_3'],after:[L('mira','Это мои люди. Спасибо. Теперь самое трудное.')]});
SM('bh_3','bh',3,'Чужие флаги','mira','bh_tx',2000,'Охотники за наградой ищут Гавань. Встретить их у ворот и решить, что делать с координатами.',[
 {t:'kill',sys:'black_harbor',orbit:'bh_cyl',pos:[3200,200,-2600],spawn:['guard','guard','flanker'],name:'Охотники у ворот'},
 {t:'dock',st:'bh_tx',say:[L('mira','Охотники несли координаты Гавани. Их можно стереть — или продать Лиге.')]},
 {t:'choice',title:'Координаты Гавани',opts:[{label:'Сохранить тайну',desc:'Гавань останется вольной; здесь вам рады и делают скидку',eff:{fn:'bhSecret'}},{label:'Передать Лиге',desc:'3000 кр. и благодарность Лиги; Гавань станет враждебной',eff:{fn:'bhHand'}}]}],{after:[L('mira','Что бы ты ни выбрал — это было твоё решение.')]});
SM('s_crew1','crew',1,'Позывной «Ласточка»','vera','kromka',500,'Записать слабый позывной на тёмном краю пояса.',[{t:'scan',sys:'yantar',orbit:'kromka',pos:[-5600,200,8000],r:450,time:5,name:'Слабый позывной',say:[L('vera','Порт «Кромка». Борт, прошу… найдите источник позывного «Ласточка-3».')]},{t:'dock',st:'kromka'}],{next:['s_crew2'],after:[L('vera','Это его голос. Запись старая — но это он.')]});
SM('s_crew2','crew',2,'Бортовой журнал','vera','kromka',900,'Забрать бортовой журнал «Ласточки-3» у Кровной Мели.',[{t:'pickup',sys:'krov',orbit:'krv_ring',pos:[2600,0,2600],item:'crate',name:'Журнал «Ласточки-3»',fight:['interceptor','interceptor']},{t:'deliver',item:'crate',st:'kromka'}],{next:['s_crew3'],after:[L('vera','Последняя запись: «уходим к Последнему Причалу, капсулы целы».')]});
SM('s_crew3','crew',3,'Капсулы у Края','vera','kromka',1500,'Найти спасательные капсулы экипажа у Последнего Причала.',[{t:'pickup',sys:'posledny',orbit:'pos_ring',pos:[-2600,300,-2400],item:'pod',name:'Капсулы «Ласточки-3»'},{t:'deliver',item:'pod',st:'kromka'}],
 {after:[L('vera','Порт «Кромка»… Нет. Сынок. Ты дома.'),L('vera','Капитан, его экипаж оставил вам свой старый док на Сирине. Он ваш.')],onDone(){S.home={st:'sir_mine',level:0};S.discounts=S.discounts||{};S.discounts.kromka=.9}});
SM('s_debt1','debt',1,'Сплавы для стапеля','taras','stp_north',700,'Семейной верфи нужны 5 сплавов, чтобы закончить заказ.',[{t:'have',good:'alloy',qty:5,st:'stp_north',say:[['Мастер Ольга Стапельная','Верфь тонет в долгах. Привезёшь сплавы — успеем сдать заказ.']]}],{next:['s_debt2']});
SM('s_debt2','debt',2,'Сборщики долгов','taras','stp_north',1100,'Сборщики долгов пришли к стапелю. Отогнать их.',[{t:'kill',sys:'stapel',orbit:'stp_north',pos:[1600,200,2200],spawn:['heavy','interceptor'],name:'Сборщики долгов'},{t:'dock',st:'stp_north'}],{next:['s_debt3']});
SM('s_debt3','debt',3,'Последний платёж','taras','stp_north',1200,'Решить, как закрыть долг семейной верфи.',[{t:'dock',st:'stp_north'},{t:'choice',title:'Долг верфи',opts:[{label:'Внести 2000 кр.',cost:2000,desc:'Верфь спасена, вам — скидка 10%',eff:{fn:'debtPay'}},{label:'Разоблачить кредитора',desc:'Союз благодарен; скидка 10% на этой верфи',eff:{fn:'debtExpose'}}]}],{after:[['Мастер Ольга Стапельная','Пока верфь жива — для вас всегда скидка.']]});
SM('teira_side1','teira',1,'Архив предков','kae','ven_nest',800,'Спор о наследстве: найти запись предков в Обсерватории Предков.',[{t:'dock',st:'ven_obs',say:[L('kae','Два дома спорят о корабле. Запись предков решит спор.')]}],{next:['teira_side2']});
SM('teira_side2','teira',2,'Реликвия Мели','kae','ven_nest',1200,'Осмотреть реликвию на отмели Кровной Мели.',[{t:'scan',sys:'krov',orbit:'krv_gate',pos:[-2200,300,2400],r:450,time:5,name:'Реликвия дома'},{t:'dock',st:'ven_nest'}],{next:['teira_side3']});
SM('teira_side3','teira',3,'Поединок наследника','kae','ven_nest',2000,'Чемпион соперничающего дома вызывает на поединок у Ашкета.',[{t:'kill',sys:'ashket',orbit:'ash_post',pos:[1800,300,-2200],spawn:['heavy'],name:'Чемпион дома'},{t:'dock',st:'ven_nest'}],
 {rewardShip:'teira_keel',after:[L('kae','Спор решён. Дом Ашкет передаёт тебе «Старший Киль». Носи его узоры с честью.')],onDone(){addRep('teira',25,true)}});
SM('s_hosp1','hosp',1,'Медгруз для Пустоши','vera','pol_med',900,'Доставить 6 ед. медикаментов в Приют Верна.',[{t:'have',good:'meds',qty:6,st:'pus_shel',say:[['Врач «Полудня»','Три наших медгруза пропали. Этот должен дойти.']]}],{next:['s_hosp2']});
SM('s_hosp2','hosp',2,'Дрейфующий манифест','vera','pus_shel',1100,'Найти контейнер пропавшего медгруза у шахты Пустоши.',[{t:'pickup',sys:'pustosh',orbit:'pus_mine',pos:[-3200,400,-2200],item:'crate',name:'Контейнер медгруза'},{t:'deliver',item:'crate',st:'pus_shel'}],{next:['s_hosp3'],onDone(){addClue('ark_manifest')}});
SM('s_hosp3','hosp',3,'Тёмная планета','mira','pus_shel',1500,'Проследить транспондер медгруза.',[{t:'scan',sys:'pustosh',orbit:'pus_mine',pos:[-4000,600,-3000],r:500,time:6,name:'Пинг транспондера'}],
 {onDone(){discover('ark','Транспондер ведёт к старым воротам: за ними флот беженцев у тёмной планеты — Ковчег.')},after:[L('mira','Медгрузы не воровали. Их везли туда, где они нужнее всего.')]});
SM('s_ill1','ill',1,'Чужая буровая','taras','kob_mine',700,'Найти незаконную буровую в поясе Кобальта.',[{t:'goto',sys:'kobalt',orbit:'kob_mine',pos:[-3200,-300,3000],r:700,name:'Незаконная буровая'}],{next:['s_ill2']});
SM('s_ill2','ill',2,'Предложение','taras','kob_mine',800,'Хозяева буровой предлагают долю.',[{t:'dock',st:'kob_mine'},{t:'choice',title:'Незаконная добыча',opts:[{label:'Доложить Союзу',eff:{fn:'illReport'}},{label:'Взять 1500 кр. и молчать',eff:{fn:'illBribe'}}]}],{next:['s_ill3']});
SM('s_ill3','ill',3,'Закрыть буровую','taras','kob_mine',1300,'Охрана буровой не сдаётся.',[{t:'kill',sys:'kobalt',orbit:'kob_mine',pos:[-3200,-300,3000],spawn:['guard','missileer'],name:'Охрана буровой'},{t:'dock',st:'kob_mine'}],{after:[L('taras','Кобальт снова пойдёт честным людям.')],onDone(){S.discounts=S.discounts||{};S.discounts.kob_mine=.85}});
SM('collector1','coll',1,'Обшивка «Прадеда»','ilan','lira_hab',800,'Коллекционер ищет обломки довоенного корабля: первый — у Сирина.',[{t:'pickup',sys:'sirin',orbit:'sir_obs',pos:[2400,200,-2000],item:'crate',name:'Довоенная обшивка'},{t:'deliver',item:'crate',st:'lira_hab'}],{next:['collector2']});
SM('collector2','coll',2,'Сердце «Прадеда»','ilan','lira_hab',1100,'Второй обломок — у Полдня.',[{t:'pickup',sys:'polden',orbit:'pol_dock',pos:[-2400,300,2200],item:'crate',name:'Довоенный реактор'},{t:'deliver',item:'crate',st:'lira_hab'}],{next:['collector3']});
SM('collector3','coll',3,'Крылья «Прадеда»','ilan','lira_hab',1500,'Последний обломок — на Перекрёстке.',[{t:'pickup',sys:'perekr',orbit:'per_ring',pos:[2600,-200,2600],item:'crate',name:'Довоенное крыло',fight:['flanker']},{t:'deliver',item:'crate',st:'lira_hab'}],
 {rewardShip:'prototip',after:[['Коллекционер Брамс','По этим обломкам КБ «Пустельга» собрало опытный образец. Он ваш — летайте на истории.']]});
SM('s_sig1','sig',1,'Сигнал без отправителя','ilan','kob_obs',700,'Записать эхо маяка K-3 у заставы Кобальта.',[{t:'scan',sys:'kobalt',orbit:'kob_post',pos:[2400,300,2400],r:450,time:5,name:'Маяк K-3'}],{next:['s_sig2'],onDone(){addClue('wp_bear1')}});
SM('s_sig2','sig',2,'Два пеленга','ilan','kob_obs',1000,'Снять пеленги маяков K-9 и K-7.',[{t:'scan',sys:'kobalt',orbit:'kob_mine',pos:[2600,-200,-2200],r:450,time:5,name:'Маяк K-9'},{t:'scan',sys:'kobalt',orbit:'kob_obs',pos:[-2600,300,-2000],r:450,time:5,name:'Маяк K-7 (эхо)'}],{next:['s_sig3'],onDone(){addClue('wp_bear2');addClue('wp_bear3')}});
SM('s_sig3','sig',3,'Белый Карман','ilan','kob_obs',2200,'Добыть 2 ед. звёздной руды у карликовой звезды. Держитесь в тени астероидов.',[{t:'mine',good:'rare',qty:2,sys:'white_pocket'},{t:'have',good:'rare',qty:2,st:'wp_station'}],{after:[L('ilan','Звёздная руда. Из неё делают реакторы, о которых Лига только мечтает.')]});
const SIDE_START={bh_1:()=>S.bhAccess&&!S.bhHanded,s_crew1:()=>S.ms.m1.st==='done',s_debt1:()=>S.ms.m4.st==='done',teira_side1:()=>!!slotState('camp').done.a2_1,s_hosp1:()=>S.ms.m2.st==='done',s_ill1:()=>S.ms.m4.st==='done',collector1:()=>S.ms.m3.st==='done',s_sig1:()=>!!slotState('camp').done.a1_5};
function syncSide(){const s=slotState('side');for(const id in SIDE_START){if(s.done[id]||s.cur===id||s.avail.includes(id))continue;if(SIDE_START[id]())s.avail.push(id)}}
// ---------- repeatable contracts (8 types, validated) ----------
const JOB_T=['transport','mining','intercept','bounty','escort','recon','rescue','lost'];const JOB_NAME={transport:'Перевозка',mining:'Добыча',intercept:'Перехват',bounty:'Охота за целью',escort:'Эскорт',recon:'Разведка',rescue:'Спасение',lost:'Поиск груза'};
function genJobs(stId){S.jobs=S.jobs||{};const cur=S.jobs[stId];const day=Math.floor(Date.now()/36e5);if(cur&&cur.day===day&&cur.list.length)return cur.list;const R=srand(hashStr(stId)+day);const sys=REG.stations[stId].sys;const list=[];
 for(let k=0;k<12&&list.length<3;k++){const t=JOB_T[Math.floor(R()*JOB_T.length)];const j=makeJob(t,stId,sys,R);if(j&&validJob(j)&&!list.some(x=>x.type===t))list.push(j)}S.jobs[stId]={day,list};return list}
function makeJob(t,stId,sys,R){const id='job_'+t+'_'+stId+'_'+Math.floor(R()*1e6);const st=REG.stations[stId];const near=neighbours(sys).filter(s=>!REG.systems[s].hidden);const pos=qrot(qaxis([0,1,0],R()*6.28),[0,250,2400+R()*900]);
 const base={id,from:stId,type:t,act:0,n:0,giver:'vera',side:false,job:true};
 if(t==='transport'){const dsys=near[Math.floor(R()*near.length)];if(!dsys)return null;const dst=REG.systems[dsys].stations[Math.floor(R()*REG.systems[dsys].stations.length)];const goods=STATIONS[stId].goods.filter(g=>!illegalHere(g,dst)&&REG.goods[g].cat!=='contra'&&priceAt(g,'buy',stId));const g=goods[Math.floor(R()*goods.length)];if(!g)return null;const q=4+Math.floor(R()*4);
  return {...base,title:JOB_NAME[t]+': '+GOODS[g]+' ×'+q+' → '+STATIONS[dst].name,desc:'Купите груз и доставьте в порт назначения.',reward:Math.round(150+q*REG.goods[g].base*.35),dst,good:g,qty:q,steps:[{t:'have',good:g,qty:q,st:dst}]}}
 if(t==='mining'){const fams=famOfBelt(sys);const g=AST_FAM[fams[0]].good;const q=3+Math.floor(R()*3);return {...base,title:JOB_NAME[t]+': '+GOODS[g]+' ×'+q,desc:'Добудьте буром и сдайте здесь.',reward:Math.round(200+q*REG.goods[g].base*.6),good:g,qty:q,steps:[{t:'mine',good:g,qty:q,sys},{t:'have',good:g,qty:q,st:stId}]}}
 if(t==='intercept')return {...base,title:JOB_NAME[t]+': рейдеры у '+st.name,desc:'Перехватите рейдеров на подходе.',reward:700,steps:[{t:'kill',sys,orbit:stId,pos,spawn:['interceptor','flanker'],name:'Рейдеры'},{t:'dock',st:stId}]};
 if(t==='bounty')return {...base,title:JOB_NAME[t]+': главарь «Ржавый Зуб»',desc:'Цель с охраной. Награда за голову.',reward:1300,steps:[{t:'kill',sys,orbit:stId,pos,spawn:['heavy','support'],name:'«Ржавый Зуб»'},{t:'dock',st:stId}]};
 if(t==='escort')return {...base,title:JOB_NAME[t]+': грузовик до причала',desc:'Проведите грузовик до станции.',reward:900,steps:[{t:'escort',sys,orbit:stId,from:pos,to:STATIONS[stId].entrance,hull:360,name:'Грузовик',enemies:[[8,'interceptor','conv'],[20,'interceptor','p']]}]};
 if(t==='recon')return {...base,title:JOB_NAME[t]+': странный сигнал',desc:'Подлетите и просканируйте источник.',reward:500,steps:[{t:'scan',sys,orbit:stId,pos,r:450,time:5,name:'Источник сигнала'},{t:'dock',st:stId}]};
 if(t==='rescue')return {...base,title:JOB_NAME[t]+': капсула пилота',desc:'Подберите капсулу и доставьте сюда.',reward:650,steps:[{t:'pickup',sys,orbit:stId,pos,item:'pod',name:'Спасательная капсула'},{t:'deliver',item:'pod',st:stId}]};
 if(t==='lost')return {...base,title:JOB_NAME[t]+': сорванный контейнер',desc:'Найдите контейнер и верните владельцу.',reward:600,steps:[{t:'pickup',sys,orbit:stId,pos,item:'crate',name:'Сорванный контейнер',fight:R()<.5?['interceptor']:null},{t:'deliver',item:'crate',st:stId}]};
 return null}
function validJob(j){const sys=REG.stations[j.from].sys;if(j.dst&&!findRoute(sys,REG.stations[j.dst].sys))return false;if(j.qty&&j.qty>statsFor(S.active,fitOf(S.active)).cargo)return false;if(j.good&&j.dst&&illegalHere(j.good,j.dst))return false;
 for(const s of j.steps){if(s.orbit&&!REG.stations[s.orbit])return false;if(s.st&&!REG.stations[s.st])return false}return true}
function acceptJob(i){const list=genJobs(S.station);const j=list[i];if(!j)return 'Контракт недоступен';const s=slotState('job');if(s.cur)return 'Сначала выполните текущий контракт';
 s.def=j;s.avail=[j.id];list.splice(i,1);return withSlot('job',()=>campAccept0(j.id))}
function dropJob(){const s=slotState('job');s.cur=null;s.def=null;s.step=0;withSlot('job',()=>cmSet(null));saveGame()}
// ---------- home dock ----------
const HOME_LV=[{cost:0,mats:{},name:'Заброшенный док'},{cost:2000,mats:{alloy:4},name:'Восстановленный причал',adds:'хранение груза, бесплатный ремонт'},{cost:3000,mats:{robots:2,parts:4},name:'Мастерская и галерея',adds:'стоянка флота с видом из ангара, стена трофеев'},{cost:5000,mats:{engines:2,sensors:2},name:'Дом капитана',adds:'скидка 15% на оборудование здесь, огни дока в цветах капитана'}];
function isHome(st){return S.home&&S.home.st===(st||S.station)}
function homeUpgrade(){return atomic(()=>{const h=S.home;if(!h)return 'Дока нет';const nx=HOME_LV[h.level+1];if(!nx)return 'Док восстановлен полностью';if(!isHome())return 'Работы ведутся на месте, в вашем доке';if(S.cr<nx.cost)return 'Нужно '+nx.cost+' кр.';
 for(const g in nx.mats)if((S.cargo[g]||0)+(storageOf(S.station)[g]||0)<nx.mats[g])return 'Не хватает: '+GOODS[g]+' ×'+nx.mats[g];
 for(const g in nx.mats){let need=nx.mats[g];const t=Math.min(need,S.cargo[g]||0);S.cargo[g]-=t;need-=t;if(need>0)storageOf(S.station)[g]-=need}S.cr-=nx.cost;h.level++;saveGame();return ''})}
function trophies(){const t=[];if(keyItem('token'))t.push('Портовый жетон Чёрной Гавани');if(S.ships.includes('teira_keel'))t.push('Узоры клятвы Дома Ашкет');if(S.ships.includes('izn_relic'))t.push('Осколок Колыбели');if(S.ships.includes('prototip'))t.push('Табличка «Прадеда»');
 if(slotState('camp').ending)t.push('Ключ ядра («Последний створ»)');if(slotState('side').done.s_crew3)t.push('Позывной «Ласточка-3»');if((S.stats.kills||0)>=50)t.push('50 сбитых рейдеров');return t}
STATIONS.sir_mine.homeName='Ваш док «Сирин-2»';
