'use strict';
// ================= fits, stats and equipment operations =================
function defaultFit(id){const s=REG.ships[id];return {w:Array(s.wslots).fill('p_iskra'),m:[],mis:null}}
function fitOf(id){if(!S.fits)S.fits={};if(!S.fits[id])S.fits[id]=defaultFit(id);const f=S.fits[id];const s=REG.ships[id];
 while(f.w.length<s.wslots)f.w.push(null);if(f.w.length>s.wslots)f.w.length=s.wslots;return f}
function invOf(){if(!S.inv)S.inv={w:[],m:[]};return S.inv}
function statsFor(id,fit){const b=REG.ships[id];const mods=fit.m.map(k=>REG.modules[k]).filter(Boolean);const e={};let draw=0,mass=0;
 for(const m of mods){draw+=m.draw;mass+=m.mass;for(const k in m.eff)e[k]=(e[k]||0)+m.eff[k]}
 const mp=Math.max(0,mass-2);
 return {id,name:b.name,cls:b.cls,desc:b.tradeoff,maker:b.maker,hull:b.hull+(e.hull||0),shield:b.shield+(e.shield||0),cargo:b.cargo+(e.cargo||0),energy:b.energy+(e.energy||0),
  regen:Math.round((22*(1+(e.regen||0))-draw)*10)/10,speed:Math.round(b.speed-mp*.8),boost:Math.round(b.boost+(e.boost||0)-mp*.8),boostT:3+(e.boostT||0),accel:b.accel,
  turn:+(b.turn*(1+(e.turn||0))*(1-mp*.01)).toFixed(2),cool:18*(1+(e.cool||0)),scan:!!e.scan,drill:e.drill||0,tractor:e.tractor||0,repair:e.repair||0,jam:e.jam||0,stealth:e.stealth||0,
  wslots:b.wslots,mslots:b.mslots,missile:b.missile,mass:b.mass+mass,draw}}
function shipStats(){return statsFor(S.active,fitOf(S.active))}
function weaponGroups(){return [...new Set(fitOf(S.active).w.filter(Boolean))]}
function syncLegacyMods(){S.mods=S.mods||{};S.mods.shield=Object.values(S.fits||{}).some(f=>f.m.includes('shield_p'))||invOf().m.includes('shield_p');
 S.mods.plasma=Object.values(S.fits||{}).some(f=>f.w.includes('pl_sgustok'))}
// migrate v1/v2-early fields (mods) into fits
function migrateFits(s){const prevS=S;S=s;if(!S.fits){S.fits={};for(const id of S.ships)fitOf(id);
  if(S.mods&&S.mods.shield)fitOf(S.active).m.push('shield_p');if(S.mods&&S.mods.plasma){const f=fitOf(S.active);if(f.w.length>1)f.w[1]='pl_sgustok';else invOf().w.push('pl_sgustok')}}
 invOf();syncLegacyMods();S=prevS;return s}
// ---- equipment operations (atomic; return '' or a reason) ----
let opLock=false;function atomic(fn){if(opLock)return 'Подождите, операция выполняется';opLock=true;try{return fn()}finally{opLock=false}}
function previewWith(type,id){const f=JSON.parse(JSON.stringify(fitOf(S.active)));if(type==='m'){if(f.m.length>=REG.ships[S.active].mslots)return null;f.m.push(id)}
 else{const i=f.w.indexOf(null);if(i<0)return null;f.w[i]=id}return statsFor(S.active,f)}
function moduleProblem(id){const s=REG.ships[S.active],f=fitOf(S.active);if(f.m.includes(id)&&['stealth','jammer','tractor','scanner','drill','repair_drone'].includes(id))return 'Такой прибор уже стоит на корабле';
 const p=statsFor(S.active,{...f,m:[...f.m,id]});if(p.regen<3)return 'Реактор не потянет: энергия будет уходить в ноль';return ''}
function discPrice(p){const d=(S.discounts&&S.discounts[S.station])||1;const h=S.home&&S.home.st===S.station&&S.home.level>=3?.85:1;return Math.round(p*d*h)}
function buyModule(id){return atomic(()=>{const m=REG.modules[id];if(!m)return 'Нет такого модуля';const mp=discPrice(m.price);if(S.cr<mp)return 'Не хватает '+(mp-S.cr)+' кр.';
 const prob=moduleProblem(id);const f=fitOf(S.active);const fits=f.m.length<REG.ships[S.active].mslots&&!prob;
 S.cr-=mp;if(fits)f.m.push(id);else invOf().m.push(id);syncLegacyMods();if(id.startsWith('shield')&&P)P.shield=shipStats().shield;saveGame();
 return fits?'':'Куплено и убрано на склад: '+(prob||'нет свободного слота')})}
function buyWeapon(id){return atomic(()=>{const w=REG.weapons[id];if(!w)return 'Нет такого оружия';const wp=discPrice(w.price);if(S.cr<wp)return 'Не хватает '+(wp-S.cr)+' кр.';
 if(w.fam==='missile'){if(!REG.ships[S.active].missile)return 'У этого корабля нет ракетного узла';const f=fitOf(S.active);if(f.mis&&f.mis.id===id)return 'Уже установлено — докупите боезапас';
  S.cr-=wp;if(f.mis)invOf().w.push(f.mis.id);f.mis={id,ammo:w.ammo};saveGame();return ''}
 const f=fitOf(S.active);const i=f.w.indexOf(null);S.cr-=wp;if(i>=0)f.w[i]=id;else invOf().w.push(id);syncLegacyMods();saveGame();return i>=0?'':'Куплено и убрано на склад: все оружейные узлы заняты'})}
function buyAmmo(){return atomic(()=>{const f=fitOf(S.active);if(!f.mis)return 'Ракет нет';const w=REG.weapons[f.mis.id];const need=w.ammo-f.mis.ammo;if(need<=0)return 'Боезапас полон';
 const n=Math.min(need,Math.floor(S.cr/w.ammoPrice));if(n<=0)return 'Не хватает кредитов: ракета стоит '+w.ammoPrice;S.cr-=n*w.ammoPrice;f.mis.ammo+=n;saveGame();return ''})}
function unequip(type,i){return atomic(()=>{const f=fitOf(S.active);if(type==='w'){if(!f.w[i])return 'Узел пуст';if(f.w.filter(Boolean).length<=1)return 'Нужно оставить хотя бы одно орудие';invOf().w.push(f.w[i]);f.w[i]=null}
 else if(type==='m'){const id=f.m[i];if(!id)return 'Слот пуст';f.m.splice(i,1);invOf().m.push(id);const st=shipStats();if(P){P.shield=Math.min(P.shield,st.shield);P.hull=Math.min(P.hull,st.hull)}}
 else if(type==='mis'){if(!f.mis)return 'Ракет нет';invOf().w.push(f.mis.id);f.mis=null}syncLegacyMods();saveGame();return ''})}
function equip(type,invIdx){return atomic(()=>{const inv=invOf(),f=fitOf(S.active);
 if(type==='w'){const id=inv.w[invIdx];if(!id)return 'Нет предмета';const w=REG.weapons[id];
  if(w.fam==='missile'){if(!REG.ships[S.active].missile)return 'У этого корабля нет ракетного узла';if(f.mis)inv.w.push(f.mis.id);f.mis={id,ammo:0};inv.w.splice(invIdx,1);saveGame();return 'Ракетный узел установлен — купите боезапас'}
  const i=f.w.indexOf(null);if(i<0)return 'Все оружейные узлы заняты: сначала снимите орудие';f.w[i]=id;inv.w.splice(invIdx,1)}
 else{const id=inv.m[invIdx];if(!id)return 'Нет предмета';if(f.m.length>=REG.ships[S.active].mslots)return 'Нет свободного слота модуля';const pr=moduleProblem(id);if(pr)return pr;f.m.push(id);inv.m.splice(invIdx,1)}
 syncLegacyMods();saveGame();return ''})}
// ---- ships ----
function buyShip(id){return atomic(()=>{const s=REG.ships[id];if(!s)return 'Нет такого корабля';if(S.ships.includes(id))return 'Корабль уже ваш';
 if(!s.shops.includes(S.station))return 'Этот корабль здесь не продаётся';const lk=typeof shipLocked==='function'?shipLocked(id):'';if(lk)return lk;const pr=discPrice(s.price);if(S.cr<pr)return 'Не хватает '+(pr-S.cr)+' кр.';
 S.cr-=pr;S.ships.push(id);fitOf(id);const need=cargoUsed()-statsFor(id,fitOf(id)).cargo;if(need<=0){S.active=id;const st=shipStats();if(P){P.hull=st.hull;P.shield=st.shield}}
 saveGame();return need>0?'Куплен. Чтобы пересесть, разгрузите '+need+' ед.':''})}
function switchShip(id){return atomic(()=>{if(!S.ships.includes(id))return 'Корабль не куплен';const need=cargoUsed()-statsFor(id,fitOf(id)).cargo;if(need>0)return 'Сначала разгрузитесь: лишних '+need+' ед. груза';
 S.active=id;const st=shipStats();if(P){P.hull=st.hull;P.shield=st.shield}saveGame();return ''})}
// legacy v1 API used by old tests/UI
function buyMod(id){if(id==='shield')return buyModule('shield_p');if(id==='plasma'){const r=buyWeapon('pl_sgustok');if(r.startsWith('Куплено и убрано')){const inv=invOf();const f=fitOf(S.active);const k=inv.w.indexOf('pl_sgustok');if(k>=0&&f.w.length>1){inv.w[k]=f.w[1];f.w[1]='pl_sgustok';syncLegacyMods();saveGame()}return ''}return r}return 'Нет такого модуля'}
