'use strict';
// Synthesised sounds and an original ambient pad. Starts after the first user gesture.
const SND={ctx:null,master:null,vol:.7,eng:null,engG:null,engF:null,drill:null,drillG:null,music:null,musicG:null};
function sndInit(){if(SND.ctx)return;try{const A=window.AudioContext||window.webkitAudioContext;if(!A)return;const c=new A();SND.ctx=c;
 SND.master=c.createGain();SND.master.gain.value=.9;SND.master.connect(c.destination);SND.sfxBus=c.createGain();SND.sfxBus.connect(SND.master);SND.musBus=c.createGain();SND.musBus.connect(SND.master);SND.radBus=c.createGain();SND.radBus.connect(SND.master);sndApplyVolumes();
 // engine: two detuned saws through lowpass
 SND.engG=c.createGain();SND.engG.gain.value=0;SND.engF=c.createBiquadFilter();SND.engF.type='lowpass';SND.engF.frequency.value=400;SND.engF.connect(SND.engG);SND.engG.connect(SND.sfxBus);
 SND.eng=[c.createOscillator(),c.createOscillator()];SND.eng[0].type='sawtooth';SND.eng[1].type='triangle';SND.eng.forEach((o,i)=>{o.frequency.value=48+i*0.7;o.connect(SND.engF);o.start()});
 SND.drillG=c.createGain();SND.drillG.gain.value=0;SND.drillG.connect(SND.sfxBus);SND.drill=c.createOscillator();SND.drill.type='square';SND.drill.frequency.value=90;const df=c.createBiquadFilter();df.type='bandpass';df.frequency.value=700;SND.drill.connect(df);df.connect(SND.drillG);SND.drill.start();
 SND.noise=c.createBuffer(1,c.sampleRate,c.sampleRate);const d=SND.noise.getChannelData(0);for(let i=0;i<d.length;i++)d[i]=Math.random()*2-1;
 SND.cabin=c.createBufferSource();SND.cabin.buffer=SND.noise;SND.cabin.loop=true;const cf=c.createBiquadFilter();cf.type='lowpass';cf.frequency.value=380;SND.cabinG=c.createGain();SND.cabinG.gain.value=0;SND.cabin.connect(cf);cf.connect(SND.cabinG);SND.cabinG.connect(SND.sfxBus);SND.cabin.start();
 startMusic()}catch(e){SND.ctx=null}}
function sndVolume(v){sndApplyVolumes()}
function sndApplyVolumes(){if(!SND.ctx||!SND.sfxBus)return;SND.sfxBus.gain.value=SET.volSfx;SND.musBus.gain.value=SET.volMusic;SND.radBus.gain.value=SET.volRadio}
function sndSuspend(on){if(!SND.ctx)return;try{on?SND.ctx.suspend():SND.ctx.resume()}catch(e){}}
function sndEngine(thr,boost,on){if(!SND.ctx)return;const t=SND.ctx.currentTime;const mass=(S&&REG.ships[S.active])?REG.ships[S.active].mass:10;const base=46*clamp(14/mass,.7,1.3);const f=base+thr*42+(boost?38:0);
 if(boost&&!SND.wasBoost&&on){noise(.5,.12,800,1,'bandpass',3000);blip('sawtooth',90,240,.4,.05,1200)}SND.wasBoost=boost&&on;
 SND.eng[0].frequency.setTargetAtTime(f,t,.12);SND.eng[1].frequency.setTargetAtTime(f*1.503,t,.12);SND.engF.frequency.setTargetAtTime(260+thr*500+(boost?700:0),t,.15);
 SND.engG.gain.setTargetAtTime(on?.05+thr*.06+(boost?.05:0):0,t,.2)}
function sndDrill(on,heat){if(!SND.ctx)return;const t=SND.ctx.currentTime;SND.drillG.gain.setTargetAtTime(on?.035:0,t,.05);SND.drill.frequency.setTargetAtTime(80+heat*160,t,.05)}
function env(g,t,a,peak,dur){g.gain.setValueAtTime(0.0001,t);g.gain.linearRampToValueAtTime(peak,t+a);g.gain.exponentialRampToValueAtTime(0.0001,t+dur)}
function blip(type,f0,f1,dur,vol,filt){const c=SND.ctx;if(!c)return;const t=c.currentTime;const o=c.createOscillator(),g=c.createGain();o.type=type;o.frequency.setValueAtTime(f0,t);o.frequency.exponentialRampToValueAtTime(Math.max(20,f1),t+dur);
 env(g,t,.005,vol,dur);if(filt){const f=c.createBiquadFilter();f.type='lowpass';f.frequency.value=filt;o.connect(f);f.connect(g)}else o.connect(g);g.connect(SND.curBus||SND.sfxBus);o.start(t);o.stop(t+dur+.05)}
function noise(dur,vol,fr,q=1,type='lowpass',sweep){const c=SND.ctx;if(!c)return;const t=c.currentTime;const s=c.createBufferSource();s.buffer=SND.noise;const f=c.createBiquadFilter();f.type=type;f.frequency.setValueAtTime(fr,t);if(sweep)f.frequency.exponentialRampToValueAtTime(sweep,t+dur);f.Q.value=q;
 const g=c.createGain();env(g,t,.005,vol,dur);s.connect(f);f.connect(g);g.connect(SND.curBus||SND.sfxBus);s.start(t);s.stop(t+dur+.05)}
const SFX={
 pulse(){blip('square',1100,320,.09,.07,2400)},
 plasma(){blip('sawtooth',260,55,.45,.16,900);noise(.35,.12,1800,1,'lowpass',200)},
 enemyShot(){blip('square',700,250,.1,.035,1500)},
 charge(){blip('sine',200,1400,.5,.06)},
 shieldHit(){blip('sine',1500,600,.18,.08);blip('sine',2100,900,.12,.04)},
 hullHit(){noise(.22,.22,900,2,'bandpass',300);blip('square',140,60,.15,.06,600)},
 explode(){noise(.8,.35,1400,1,'lowpass',90);blip('sine',90,30,.7,.2)},
 pickup(){blip('triangle',660,660,.09,.09);setTimeout(()=>blip('triangle',990,990,.12,.09),90)},
 dock(){blip('sine',220,220,.6,.08);blip('sine',330,330,.6,.06);setTimeout(()=>blip('sine',440,440,.5,.06),250)},
 jump(){blip('sawtooth',80,1600,1.3,.09,3000);noise(1.4,.15,300,1,'bandpass',4000)},
 ore(){blip('triangle',520,780,.15,.1)},
 overheat(){blip('square',300,120,.4,.08,1200)},
 click(){blip('sine',900,900,.04,.04)},
 deny(){blip('square',220,180,.15,.05,800)},
 hit(){blip('square',1800,1400,.04,.03,3000)},
 kinetic(){noise(.07,.12,2200,1,'highpass');blip('square',180,90,.06,.05,900)},
 ion(){blip('sine',300,1800,.12,.06);noise(.1,.04,4000,2,'bandpass')},
 missile(){noise(.6,.12,700,1,'lowpass',2400);blip('sawtooth',90,160,.5,.04,600)},
 lock(){blip('square',1300,1300,.05,.05);setTimeout(()=>blip('square',1700,1700,.06,.05),80)},
 jam(){noise(.4,.1,3000,1,'highpass')},
 whiz(){noise(.18,.05,2500,3,'bandpass',900)},
 radio(){SND.curBus=SND.radBus;noise(.12,.05,2500,3,'bandpass');blip('sine',1200,1200,.06,.05);SND.curBus=null}};
const SFX_LAST={};let SFX_WIN=[];
function sfx(n){if(!SND.ctx||!SFX[n])return;const now=performance.now();if(SFX_LAST[n]&&now-SFX_LAST[n]<35)return;SFX_WIN=SFX_WIN.filter(t=>now-t<200);if(SFX_WIN.length>=14&&n!=='explode'&&n!=='radio')return;SFX_LAST[n]=now;SFX_WIN.push(now);try{SFX[n]()}catch(e){}}
// ================= original adaptive music =================
// four themes as layers (calm, frontier, combat, mystery) + a short Black Harbor motif; crossfaded by game state
const MUS={state:'calm',groups:{},t:0,next:0,step:0,motifDone:false};
const NOTE=n=>440*Math.pow(2,(n-69)/12);
const THEMES={
 calm:{pad:[[45,52,57,61],[43,50,55,59],[41,48,53,57],[44,51,56,60]],scale:[57,59,61,64,66,69],pluck:2.2,wave:'triangle',bpm:0},
 frontier:{pad:[[40,47,52,55],[38,45,50,53],[36,43,48,52],[38,45,50,55]],scale:[52,55,57,59,62,64],pluck:1.6,wave:'sine',bpm:0},
 combat:{pad:[[40,47,52],[41,48,53],[38,45,50],[40,47,52]],scale:[64,67,69,71],pluck:0,wave:'sawtooth',bpm:132},
 mystery:{pad:[[48,54,58,62],[50,56,60,64],[46,52,56,60],[48,54,58,62]],scale:[72,74,76,78,80,82],pluck:3,wave:'sine',bpm:0}};
function startMusic(){const c=SND.ctx;SND.musicG=c.createGain();SND.musicG.gain.value=.9;SND.musicG.connect(SND.musBus);
 for(const k in THEMES){const th=THEMES[k];const g=c.createGain();g.gain.value=k==='calm'?1:0;const f=c.createBiquadFilter();f.type='lowpass';f.frequency.value=k==='combat'?1400:900;f.connect(g);g.connect(SND.musicG);
  const voices=th.pad[0].map(()=>{const o=c.createOscillator();o.type=k==='combat'?'sawtooth':'triangle';const vg=c.createGain();vg.gain.value=k==='combat'?.05:.12;o.connect(vg);vg.connect(f);o.start();return o});
  MUS.groups[k]={g,f,voices,th}}
 musicChord(0)}
function musicChord(i){const c=SND.ctx;if(!c)return;const t=c.currentTime;for(const k in MUS.groups){const G2=MUS.groups[k];const ch=G2.th.pad[i%4];G2.voices.forEach((o,j)=>o.frequency.setTargetAtTime(NOTE(ch[j%ch.length]-12),t,2))}}
function pluck(freq,dur,vol,type,dest){const c=SND.ctx;const t=c.currentTime;const o=c.createOscillator(),g=c.createGain();o.type=type;o.frequency.value=freq;env(g,t,.01,vol,dur);o.connect(g);g.connect(dest);o.start(t);o.stop(t+dur+.05)}
function musicState(){if(!W||!P||G.mode==='menu')return 'calm';if(W.enemies&&W.enemies.some(e=>e.tgt===P&&dist(e.pos,P.pos)<2200))return 'combat';
 const sys=REG.systems[W.id];if(sys.hidden||W.id==='iznanka')return 'mystery';if(sys.region==='border'||sys.region==='free')return 'frontier';return 'calm'}
function musicTick(dt){if(!SND.ctx||!MUS.groups.calm)return;MUS.t+=dt;const st=musicState();const c=SND.ctx,t=c.currentTime;
 if(st!==MUS.state){MUS.state=st}for(const k in MUS.groups)MUS.groups[k].g.gain.setTargetAtTime(k===st?1:0,t,k==='combat'?.6:2.5);
 if(MUS.t>=MUS.next){const th=THEMES[st];const dest=MUS.groups[st].f;
  if(th.bpm){const beat=60/th.bpm/2;MUS.next=MUS.t+beat;MUS.step++;if(MUS.step%2===0)pluck(NOTE(40+(MUS.step%16<8?0:-2)),beat*.9,.09,'sawtooth',dest);if(MUS.step%4===2){const s=c.createBufferSource();s.buffer=SND.noise;const g=c.createGain();env(g,t,.002,.05,.06);const f=c.createBiquadFilter();f.type='highpass';f.frequency.value=6000;s.connect(f);f.connect(g);g.connect(dest);s.start(t);s.stop(t+.08)}
   if(MUS.step%32===0)musicChord(MUS.step/32)}
  else{MUS.next=MUS.t+th.pluck*(.6+Math.random()*.8);if(Math.random()<.7)pluck(NOTE(th.scale[Math.floor(Math.random()*th.scale.length)]),1.6,.035,th.wave,dest);if(Math.random()<.12)musicChord(Math.floor(Math.random()*4))}}
 // Black Harbor motif (once per visit)
 if(W&&W.id==='black_harbor'&&!W.motif){W.motif=true;[62,65,69,68,64].forEach((n,i)=>setTimeout(()=>{if(SND.ctx)pluck(NOTE(n),.6,.06,'square',SND.musBus)},i*260))}
 // engine cabin layer
 if(SND.cabin&&P){SND.cabinG.gain.setTargetAtTime(G.mode==='fly'?.01+Math.min(1,P.spd/200)*.03:0,t,.3)}}
