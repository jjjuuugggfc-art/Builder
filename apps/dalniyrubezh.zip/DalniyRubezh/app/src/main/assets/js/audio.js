'use strict';
// Synthesised sounds and an original ambient pad. Starts after the first user gesture.
const SND={ctx:null,master:null,vol:.7,eng:null,engG:null,engF:null,drill:null,drillG:null,music:null,musicG:null};
function sndInit(){if(SND.ctx)return;try{const A=window.AudioContext||window.webkitAudioContext;if(!A)return;const c=new A();SND.ctx=c;
 SND.master=c.createGain();SND.master.gain.value=SND.vol;SND.master.connect(c.destination);
 // engine: two detuned saws through lowpass
 SND.engG=c.createGain();SND.engG.gain.value=0;SND.engF=c.createBiquadFilter();SND.engF.type='lowpass';SND.engF.frequency.value=400;SND.engF.connect(SND.engG);SND.engG.connect(SND.master);
 SND.eng=[c.createOscillator(),c.createOscillator()];SND.eng[0].type='sawtooth';SND.eng[1].type='triangle';SND.eng.forEach((o,i)=>{o.frequency.value=48+i*0.7;o.connect(SND.engF);o.start()});
 SND.drillG=c.createGain();SND.drillG.gain.value=0;SND.drillG.connect(SND.master);SND.drill=c.createOscillator();SND.drill.type='square';SND.drill.frequency.value=90;const df=c.createBiquadFilter();df.type='bandpass';df.frequency.value=700;SND.drill.connect(df);df.connect(SND.drillG);SND.drill.start();
 SND.noise=c.createBuffer(1,c.sampleRate,c.sampleRate);const d=SND.noise.getChannelData(0);for(let i=0;i<d.length;i++)d[i]=Math.random()*2-1;
 startMusic()}catch(e){SND.ctx=null}}
function sndVolume(v){SND.vol=v;if(SND.master)SND.master.gain.value=v}
function sndSuspend(on){if(!SND.ctx)return;try{on?SND.ctx.suspend():SND.ctx.resume()}catch(e){}}
function sndEngine(thr,boost,on){if(!SND.ctx)return;const t=SND.ctx.currentTime;const f=46+thr*42+(boost?38:0);
 SND.eng[0].frequency.setTargetAtTime(f,t,.12);SND.eng[1].frequency.setTargetAtTime(f*1.503,t,.12);SND.engF.frequency.setTargetAtTime(260+thr*500+(boost?700:0),t,.15);
 SND.engG.gain.setTargetAtTime(on?.05+thr*.06+(boost?.05:0):0,t,.2)}
function sndDrill(on,heat){if(!SND.ctx)return;const t=SND.ctx.currentTime;SND.drillG.gain.setTargetAtTime(on?.035:0,t,.05);SND.drill.frequency.setTargetAtTime(80+heat*160,t,.05)}
function env(g,t,a,peak,dur){g.gain.setValueAtTime(0.0001,t);g.gain.linearRampToValueAtTime(peak,t+a);g.gain.exponentialRampToValueAtTime(0.0001,t+dur)}
function blip(type,f0,f1,dur,vol,filt){const c=SND.ctx;if(!c)return;const t=c.currentTime;const o=c.createOscillator(),g=c.createGain();o.type=type;o.frequency.setValueAtTime(f0,t);o.frequency.exponentialRampToValueAtTime(Math.max(20,f1),t+dur);
 env(g,t,.005,vol,dur);if(filt){const f=c.createBiquadFilter();f.type='lowpass';f.frequency.value=filt;o.connect(f);f.connect(g)}else o.connect(g);g.connect(SND.master);o.start(t);o.stop(t+dur+.05)}
function noise(dur,vol,fr,q=1,type='lowpass',sweep){const c=SND.ctx;if(!c)return;const t=c.currentTime;const s=c.createBufferSource();s.buffer=SND.noise;const f=c.createBiquadFilter();f.type=type;f.frequency.setValueAtTime(fr,t);if(sweep)f.frequency.exponentialRampToValueAtTime(sweep,t+dur);f.Q.value=q;
 const g=c.createGain();env(g,t,.005,vol,dur);s.connect(f);f.connect(g);g.connect(SND.master);s.start(t);s.stop(t+dur+.05)}
const SFX={
 pulse(){blip('square',1100,320,.09,.07,2400)},
 plasma(){blip('sawtooth',260,55,.45,.16,900);noise(.35,.12,1800,1,'lowpass',200)},
 enemyShot(){blip('square',700,250,.1,.035,1500)},
 charge(){blip('sine',200,1400,.5,.06)},
 shieldHit(){blip('sine',1500,600,.18,.08);blip('sine',2100,900,.12,.04)},
 hullHit(){noise(.22,.22,900,2,'bandpass',300);blip('square',140,60,.15,.06,600)},
 explode(){noise(.8,.35,1400,1,'lowpass',90);blip('sine',90,30,.7,.2)},
 pickup(){blip('triangle',660,660,.09,.09);setTimeout(()=>blip('triangle',990,990,.12,.09),90)},
 dock(){blip('sine',220,220,.6,.08);blip('sine',330,330,.6,.06);setTimeout(()=>blip('sine',440,440,.5,.06),250)},
 jump(){blip('sawtooth',80,1600,1.3,.09,3000);noise(1.4,.15,300,1,'bandpass',4000)},
 ore(){blip('triangle',520,780,.15,.1)},
 overheat(){blip('square',300,120,.4,.08,1200)},
 click(){blip('sine',900,900,.04,.04)},
 deny(){blip('square',220,180,.15,.05,800)},
 hit(){blip('square',1800,1400,.04,.03,3000)}};
function sfx(n){if(SND.ctx&&SFX[n])try{SFX[n]()}catch(e){}}
// original ambient pad: slow chord cycle
function startMusic(){const c=SND.ctx;SND.musicG=c.createGain();SND.musicG.gain.value=.05;SND.musicG.connect(SND.master);
 const f=c.createBiquadFilter();f.type='lowpass';f.frequency.value=900;f.connect(SND.musicG);
 const voices=[0,1,2,3].map(()=>{const o=c.createOscillator();o.type='triangle';const g=c.createGain();g.gain.value=.25;o.connect(g);g.connect(f);o.start();return o});
 const chords=[[110,164.8,220,277.2],[98,146.8,196,246.9],[87.3,130.8,174.6,220],[103.8,155.6,207.7,261.6]];let i=0;
 const step=()=>{if(!SND.ctx)return;const t=c.currentTime;chords[i%4].forEach((fr,k)=>voices[k].frequency.setTargetAtTime(fr,t,2.5));i++};step();setInterval(step,9000)}
