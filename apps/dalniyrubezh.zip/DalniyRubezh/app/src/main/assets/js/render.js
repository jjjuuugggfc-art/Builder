'use strict';
const cam={mode:'hangar',q:[0,0,0,1],reset:true,h:1,eye:[0,0,0],look:[0,0,1],up:[0,1,0],fov:1};
let VP=null,camEye=[0,0,0],camF=1,SW=1,SH=1,DPR=1;
let starBuf,starN=0;const PMAX=7000,pdat=new Float32Array(PMAX*8);let pn=0,pbuf;
function renderInit(){glPrograms();pbuf=gl.createBuffer();buildStars('yantar')}
function buildStars(id){const sys=SYSTEMS[id];const R=srand(id=='yantar'?3:8);const arr=[];
 for(let i=0;i<1600;i++){const d=scl(norm([R()*2-1,R()*2-1,R()*2-1]),5000);const k=R(),tn=R();arr.push(...d,.75+tn*.25,.8+R()*.2,1-tn*.25,.3+k*k*.7,1+k*k*2.4)}
 for(let i=0;i<70;i++){const c=sys.neb[i%2];const base=norm(i%2?[-.7,.3,.5]:[.6,-.2,.7]);const d=scl(norm(add(base,scl(rndDirS(R),.45))),5000);arr.push(...d,...c,.09,R()*260+140)}
 arr.push(...scl(sys.sun,5000),1,.95,.85,1,46,...scl(sys.sun,5000),...sys.sunCol.map(x=>x*.8),.45,150);
 starN=arr.length/8;starBuf=gl.createBuffer();gl.bindBuffer(gl.ARRAY_BUFFER,starBuf);gl.bufferData(gl.ARRAY_BUFFER,new Float32Array(arr),gl.STATIC_DRAW);starsFor=id}
let starsFor=null;
function rndDirS(R){let v;do{v=[R()*2-1,R()*2-1,R()*2-1]}while(len(v)>1||len(v)<.1);return norm(v)}
function pt(p,c,a,s){if(pn>=PMAX)return;const o=pn++*8;pdat[o]=p[0];pdat[o+1]=p[1];pdat[o+2]=p[2];pdat[o+3]=c[0];pdat[o+4]=c[1];pdat[o+5]=c[2];pdat[o+6]=a;pdat[o+7]=s}
function resizeGL(){DPR=Math.min(window.devicePixelRatio||1,G.low?.8:1.5);SW=innerWidth;SH=innerHeight;glc.width=Math.round(SW*DPR);glc.height=Math.round(SH*DPR);gl.viewport(0,0,glc.width,glc.height);const h=document.getElementById('hud');const hd=Math.min(window.devicePixelRatio||1,2);h.width=Math.round(SW*hd);h.height=Math.round(SH*hd);HDPR=hd}
let HDPR=1;
function computeCamera(dt){if(!P)return;
 const st=W.station?STATIONS[W.station.id]:null;
 // hangar view
 let hEye=[0,0,0],hLook=[0,0,1];if(st){const sp=stationWorld(st.spot);hEye=add(sp,[13,5.5,-24]);hLook=add(sp,[-3,2,40])}
 // chase view
 if(cam.reset){cam.q=[...P.q];cam.reset=false}
 cam.q=qslerp(cam.q,P.q,damp(G.mode==='fly'?5:3,dt||.016));
 const sa=S?shipAsset(S.active):{camDist:19,camUp:4.6};const bk=sa.camDist+clamp((P.spd-60)*.025,0,4);let cEye=add(P.pos,qrot(cam.q,[0,sa.camUp,-bk]));const cLook=add(P.pos,qrot(cam.q,[0,sa.camUp*.56,40]));
 const sh=((P.shake||0)+(P.kick||0)*.5)*(SET.shake==null?1:SET.shake);if(sh>0)cEye=add(cEye,scl(rndDir(),sh*.5));
 const hT=G.mode==='hangar'||(G.mode==='docking'&&G.anim>1.7)?1:0;if(G.mode==='launch'&&cam.h>0)cam.h=Math.max(0,1-G.anim/2);else cam.h=lerp(cam.h,hT,damp(hT?3:2.5,dt||.016));
 if(G.mode==='hangar')cam.h=1;
 const k=cam.h*cam.h*(3-2*cam.h);cam.eye=vlerp(cEye,hEye,k);cam.look=vlerp(cLook,hLook,k);cam.up=norm(vlerp(UP(cam.q),[0,1,0],k));
 if(G.mode==='scene'&&G.scene){const sc=sceneCamera();cam.eye=sc.eye;cam.look=sc.look;cam.up=[0,1,0]}
 const fovT=(G.mode==='fly'&&P.boosting?1.12:1)*(55/180*Math.PI)*(1-k*.08);cam.fov=lerp(cam.fov||fovT,fovT,damp(3,dt||.016))}
function drawMesh(m,q,p,s,o={}){gl.uniformMatrix4fv(MS.u.uM,false,mModel(q,p,s));gl.uniform3fv(MS.u.uEm,o.em||[0,0,0]);gl.uniform4fv(MS.u.uRim,o.rim||[.3,.45,.7,.25]);
 gl.uniform1f(MS.u.uTwo,o.smooth?0:1);gl.uniform1f(MS.u.uTerm,o.smooth?1:0);gl.uniform1f(MS.u.uSpec,o.spec==null?.35:o.spec);
 gl.bindBuffer(gl.ARRAY_BUFFER,m.buf);gl.vertexAttribPointer(MS.a.aPos,3,gl.FLOAT,false,40,0);gl.vertexAttribPointer(MS.a.aNor,3,gl.FLOAT,false,40,12);gl.vertexAttribPointer(MS.a.aCol,4,gl.FLOAT,false,40,24);gl.drawArrays(gl.TRIANGLES,0,m.n)}
function meshAttr(on){for(const n of ['aPos','aNor','aCol'])on?gl.enableVertexAttribArray(MS.a[n]):gl.disableVertexAttribArray(MS.a[n])}
function ptsAttr(b,on=true){gl.bindBuffer(gl.ARRAY_BUFFER,b);for(const [n,s,o] of [['aPos',3,0],['aCol',4,12],['aSize',1,28]]){if(on){gl.enableVertexAttribArray(PS.a[n]);gl.vertexAttribPointer(PS.a[n],s,gl.FLOAT,false,32,o)}else gl.disableVertexAttribArray(PS.a[n])}}
function glow(q,p,s,col,a,hit,hitR){gl.uniformMatrix4fv(GS.u.uM,false,mModel(q,p,s));gl.uniform3fv(GS.u.uCol,col);gl.uniform1f(GS.u.uA,a);gl.uniform3fv(GS.u.uHit,hit||[0,0,0]);gl.uniform1f(GS.u.uHitR,hitR||0);
 gl.bindBuffer(gl.ARRAY_BUFFER,M.bubble.buf);gl.vertexAttribPointer(GS.a.aPos,3,gl.FLOAT,false,40,0);gl.vertexAttribPointer(GS.a.aNor,3,gl.FLOAT,false,40,12);gl.drawArrays(gl.TRIANGLES,0,M.bubble.n)}
function flames(e,meshName,thr,boost,q,pos,nozArr,scaleK){const noz=nozArr||NOZZLES[meshName];if(!noz)return;const f=FWD(q);const L=(1.2+thr*5+(boost?7:0))*(meshName==='transport'?2.5:1)*(scaleK||1);
 for(const n of noz){const b=add(pos,qrot(q,n));const k=(meshName==='transport'?2.2:meshName==='heavy'?1.5:1)*(scaleK||1);
  for(let i=0;i<7;i++){const t=i/6;pt(sub(b,scl(f,t*L)),boost?[.55,.75,1]:[1,.62,.3],.55*(1-t),(1.4-t*.9)*k)}
  pt(b,[1,.9,.75],.5,1.2*k)}}
function render(dt){if(!W||!P)return;computeCamera(dt);if(starsFor!==W.id)buildStars(W.id);
 const sys=W.sys,eye=cam.eye,asp=SW/SH;camEye=eye;
 const view=mLook(eye,cam.look,cam.up);const shift=cam.h*cam.h*(3-2*cam.h)*(document.getElementById('station').classList.contains('hide')?0:.62);const pj=(n,f)=>{const m=mPersp(cam.fov,asp,n,f);m[8]=shift;return m};const bgVP=mMul(pj(300,800000),view);VP=mMul(pj(.8,60000),view);camF=1/Math.tan(cam.fov/2);
 gl.clearColor(sys.bg[0],sys.bg[1],sys.bg[2],1);gl.clear(gl.COLOR_BUFFER_BIT|gl.DEPTH_BUFFER_BIT);
 // stars & nebula
 gl.disable(gl.DEPTH_TEST);gl.enable(gl.BLEND);gl.blendFunc(gl.ONE,gl.ONE);gl.useProgram(PS.p);
 gl.uniformMatrix4fv(PS.u.uVP,false,bgVP);gl.uniform3fv(PS.u.uOff,eye);gl.uniform1f(PS.u.uFixed,1);ptsAttr(starBuf);gl.drawArrays(gl.POINTS,0,starN);ptsAttr(starBuf,false);
 gl.disable(gl.BLEND);gl.enable(gl.DEPTH_TEST);
 // background bodies
 gl.useProgram(MS.p);meshAttr(true);gl.uniform3fv(MS.u.uL,sys.sun);gl.uniform3fv(MS.u.uSun,sys.sunCol);gl.uniform3fv(MS.u.uAmb,scl(sys.amb,.35));gl.uniform3fv(MS.u.uCam,eye);
 gl.uniformMatrix4fv(MS.u.uVP,false,bgVP);const pl=sys.planet;
 gl.uniform3fv(MS.u.uNight,PLANET_NIGHT[pl.cls]||[0,0,0]);gl.uniform1f(MS.u.uLava,PLANET_LAVA[pl.cls]||0);
 drawMesh(planetMesh(pl.cls),qaxis(norm([.2,1,0]),G.time*pl.spin),pl.pos,pl.r,{smooth:true,rim:pl.rim||PLANET_RIM[pl.cls],spec:.05});gl.uniform3fv(MS.u.uNight,[0,0,0]);gl.uniform1f(MS.u.uLava,0);
 if(pl.ring)drawMesh(M.giantRing,qaxis(norm([1,0,.3]),.38),pl.pos,pl.r,{spec:0});
 drawMesh(M.moon,[0,0,0,1],sys.moon.pos,sys.moon.r,{smooth:true,rim:[.6,.6,.7,.3],spec:0});
 {const cm=cloudMesh(pl.cls);if(cm){meshAttr(false);gl.useProgram(CS.p);gl.enable(gl.BLEND);gl.blendFunc(gl.SRC_ALPHA,gl.ONE_MINUS_SRC_ALPHA);gl.depthMask(false);gl.uniformMatrix4fv(CS.u.uVP,false,bgVP);gl.uniform3fv(CS.u.uL,sys.sun);gl.uniform3fv(CS.u.uSun,sys.sunCol);
  gl.uniformMatrix4fv(CS.u.uM,false,mModel(qaxis(norm([.1,1,.1]),G.time*pl.spin*1.4),pl.pos,pl.r*1.012));gl.bindBuffer(gl.ARRAY_BUFFER,cm.buf);for(const [n,sz,o] of [['aPos',3,0],['aNor',3,12],['aCol',4,24]]){gl.enableVertexAttribArray(CS.a[n]);gl.vertexAttribPointer(CS.a[n],sz,gl.FLOAT,false,40,o)}
  gl.drawArrays(gl.TRIANGLES,0,cm.n);for(const n of ['aPos','aNor','aCol'])gl.disableVertexAttribArray(CS.a[n]);gl.depthMask(true);gl.disable(gl.BLEND);gl.useProgram(MS.p);meshAttr(true)}}
 gl.clear(gl.DEPTH_BUFFER_BIT);
 // foreground
 gl.uniformMatrix4fv(MS.u.uVP,false,VP);gl.uniform3fv(MS.u.uAmb,sys.amb);
 const sid=W.station.id;if(sid==='kromka'){drawMesh(M.kromka,[0,0,0,1],W.station.pos,1);drawMesh(M.ring,qaxis([0,0,1],W.ringRot),[0,0,-60],1);drawMesh(M.ring,qaxis([0,0,1],-W.ringRot*1.3+.4),[0,0,-140],1)}
 else if(sid==='verf9')drawMesh(M.verf,[0,0,0,1],W.station.pos,1);
 else if(W.stMesh){drawMesh(W.stMesh.mesh,[0,0,0,1],W.station.pos,1);for(const rr of W.stMesh.rot)drawMesh(rr.mesh,qaxis([0,0,1],W.ringRot*rr.speed*20),[0,0,rr.z],1)}
 for(const g of W.gates)drawMesh(M.gate,g.q,g.pos,1);
 for(const s of W.statics)drawMesh(M[s.mesh],s.q,s.pos,s.s);
 for(const t of W.traffic)drawMesh(M[t.mesh],t.q,t.pos,t.s||1,t.aged?{em:[-.08,-.07,-.05],spec:0}:{});
 const far=G.low?7000:11000;
 for(const a of W.asts){const d=dist(a.pos,eye);if(d-a.r>far)continue;drawMesh(a.mesh,a.q,a.pos,a.r,{spec:.12,em:a===P.target?[.05,.04,.02]:[0,0,0]})}
 for(const c of W.conts)drawMesh(M.container,c.q,c.pos,1);
 if(W.transport)drawMesh(M.transport,W.transport.q,W.transport.pos,1);
 for(const n of W.npcs||[])drawMesh(n.mesh?M[n.mesh]:enemyAsset(n.cls).mesh,n.q,n.pos,1);
 if(G.mode==='hangar'&&isHome()&&S.home.level>=2){S.ships.filter(id=>id!==S.active).slice(0,3).forEach((id,i)=>drawMesh(shipAsset(id).mesh,qaxis([0,1,0],.4),stationWorld([(i%2?-1:1)*(22+Math.floor(i/2)*10),-14,95-i*12]),1))}
 for(const e of W.enemies){const fl=e.shieldFx>0&&e.shield<=0?.3:0;const dmgDark=e.hull<e.max*.25&&Math.sin(G.time*17+e.idx)>.3?-.06:0;drawMesh(enemyAsset(e.cls).mesh,e.q,e.pos,1,{em:[fl+dmgDark,fl*.4+dmgDark,fl*.2+dmgDark]})}
 for(const a of (W.allies||[]))drawMesh(a.mesh?M[a.mesh]:enemyAsset(a.cls).mesh,a.q,a.pos,1);
 const pq=qmul(P.q,qaxis([0,0,1],P.bank));const showId=G.mode==='hangar'&&G.preview?G.preview:S.active;const pa=shipAsset(showId);
 const shownQ=G.mode==='hangar'?qaxis([0,1,0],G.prevRot||0):pq;const heatG=pa.heatGlow?Math.min(1,(P.heat||0)/100*.6+(P.boosting?.35:0)):0;
 if(P.alive&&!(P.stealthT>0&&Math.sin(G.time*20)>.6))drawMesh(pa.mesh,shownQ,P.pos,1,{em:P.hitFx>0?[.3,.1,.05]:heatG?[heatG*.45,heatG*.12,0]:[0,0,0]});
 meshAttr(false);
 // additive pass
 gl.enable(gl.BLEND);gl.blendFunc(gl.ONE,gl.ONE);gl.depthMask(false);
 gl.useProgram(GS.p);gl.uniformMatrix4fv(GS.u.uVP,false,VP);gl.uniform3fv(GS.u.uCam,eye);gl.enableVertexAttribArray(GS.a.aPos);gl.enableVertexAttribArray(GS.a.aNor);
 const bub=(t,r)=>{if(t.shieldFx>0.01)glow(t.q||[0,0,0,1],t.pos,r,[.3,.65,1],t.shieldFx*.35,t.hitPt,r*1.2)};
 if(P.alive)bub(P,8.5);for(const e of W.enemies)bub(e,e.r*1.35);
 if(G.mode==='jump')glow([0,0,0,1],G.jumpGate.pos,90,[.3,.7,1],.25*Math.min(1,G.anim));if(G.mode==='transit')glow([0,0,0,1],P.pos,30,[.5,.9,1],.3*Math.min(1,G.anim));
 gl.disableVertexAttribArray(GS.a.aPos);gl.disableVertexAttribArray(GS.a.aNor);
 pn=0;
 if(P.alive&&G.mode!=='hangar')flames(P,S.active,P.thr,P.boosting,pq,P.pos,pa.nozzles,clamp(pa.radius/8,1,1.8));else if(P.alive)flames(P,showId,.05,false,shownQ,P.pos,pa.nozzles);
 if(pa.scanArcs&&G.mode==='fly'&&P.target&&shipStats().scan){const k=(G.time*1.5)%1;for(let i=0;i<8;i++){const a2=-.4+(Math.PI+.8)*((k+i/8)%1);pt(add(P.pos,qrot(pq,[Math.cos(a2)*2.2,.5+Math.sin(a2)*2.2,1.3])),[.4,1,.9],.8,.6)}}
 if(P.beam){const w=REG.weapons[P.beam.fam];const n=Math.ceil(dist(P.beam.from,P.beam.to)/6);const c=P.beam.fam==='b_rezak'?[1,.4,.3]:P.beam.fam==='b_nit'?[.6,1,.6]:[1,.85,.4];for(let i=0;i<=n;i++)pt(vlerp(P.beam.from,P.beam.to,i/n),c,.75,P.beam.fam==='b_rezak'?1.4:.8);if(P.beam.hitE)pt(P.beam.to,[1,1,.9],1,3)}
 for(const m of W.missiles){const f2=FWD(m.q);pt(m.p,[1,.9,.7],1,1.6);pt(sub(m.p,scl(f2,1.2)),[1,.6,.25],.9,2.2)}
 for(const e of W.enemies){if(e.cls==='capital'){for(const n of e.nodes)if(n.hp>0&&Math.sin(G.time*3+n.r)>0)pt(add(e.pos,qrot(e.q,n.pos)),[1,.3,.2],.9,4)}
  const ea=enemyAsset(e.cls);const stut=e.hull<e.max*.25&&Math.random()<.4;if(!stut)flames(e,e.cls==='capital'?'heavy':e.type,.8,false,e.q,e.pos,ea.nozzles,e.cls==='capital'?6:1);if(e.charge>0){const n=add(e.pos,qrot(e.q,[0,.1,9]));pt(n,[.5,.85,1],1,4+(.5-e.charge)*14);pt(n,[1,1,1],.8,2)}}
 for(const t of W.traffic)flames(t,t.mesh==='transport'?'transport':'tug',t.kind==='hauler'?0:.4,false,t.q,t.pos);
 if(W.transport)flames(W.transport,'transport',.7,false,W.transport.q,W.transport.pos);
 for(const p of W.parts){const k=p.life/p.max;if(p.dark)pt(p.p,[.25,.23,.2],.5*k,p.s);else pt(p.p,p.c,Math.min(1,k*1.4),p.s*(.6+k*.4))}
 for(const s of W.shots){const d=norm(s.v);if(s.kind==='plasma'){pt(s.p,[.55,1,.7],1,4.2);pt(s.p,[1,1,1],.9,1.8);for(let i=1;i<6;i++)pt(sub(s.p,scl(d,i*2.2)),[.4,1,.6],.6-i*.1,3-i*.4)}
  else if(s.kind==='echarge'){pt(s.p,[.5,.85,1],1,5);pt(s.p,[1,1,1],.9,2);for(let i=1;i<5;i++)pt(sub(s.p,scl(d,i*2.5)),[.4,.7,1],.6-i*.12,3.5-i*.5)}
  else{const c=s.owner==='p'?[.45,.85,1]:[1,.35,.2];for(let i=0;i<5;i++)pt(sub(s.p,scl(d,i*1.5)),c,1-i*.18,i?.9:1.3)}}
 const blink=t=>(Math.sin((G.time+t)*Math.PI*1.4)>.4);
 for(const L of W.lights)if(blink(L.ph))pt(L.p,L.c,.9,6);
 for(const s of W.statics){if(s.buoy&&blink(0))pt(add(s.pos,[0,15,0]),[1,.5,.2],1,8);if(s.beacon){pt(add(s.pos,[0,20,0]),[.4,.9,1],.8,10+Math.sin(G.time*3)*3);if(blink(.5))pt(add(s.pos,[0,-14,0]),[.4,.9,1],.8,5)}}
 for(const n of W.npcs||[]){const nz=n.mesh?NOZZLES.transport:enemyAsset(n.cls).nozzles;flames(n,n.mesh?'transport':'guard',.6,false,n.q,n.pos,nz,n.mesh?1:1)}
 for(const s of W.statics)if(s.sing){const ph=(G.time*.8)%3;for(let k=0;k<s.sing.n;k++){const rr=20+((ph+k*.33)%1)*120;for(let i=0;i<16;i++){const a=i/16*6.283;pt(add(s.pos,[Math.cos(a)*rr,10,Math.sin(a)*rr]),s.sing.col,.5*(1-((ph+k*.33)%1)),3)}}}
 if(W.id==='gar'&&W.sys.main){const L=bhLights();const al=W.bhAlign??1;const k=clamp(1-al/.25,0,1);for(const l of L)pt(l,[1,.35+k*.6,.2+k*.8],.9,16+k*12);
  if(hasClue('bh_corridor')){const g=gateTo('black_harbor');if(g)for(let i=0;i<24;i++)if(Math.sin(G.time*3-i*.5)>0)pt(vlerp(BH_RELAY,g.pos,i/24),[1,.5,.3],.7,5)}}
 for(const c of W.conts)if(blink(.3))pt(add(c.pos,[0,2.5,0]),c.item in CITEMS?[1,.85,.2]:[.4,1,.5],.9,2.2);
 // gate inner glow when route chosen
 const nh=routeNext();for(const g of W.gates){if(!(g.to===nh||(G.mode==='jump'&&g===G.jumpGate)))continue;for(let i=0;i<40;i++){const a=i/40*Math.PI*2+G.time*.6;pt(add(g.pos,qrot(g.q,[Math.cos(a)*80,Math.sin(a)*80,0])),[.4,.8,1],.5,5)}}
 // drill beam
 if(DR&&DR.hold&&DR.lock<=0){const a=add(P.pos,qrot(P.q,[0,-.5,6.5])),b=veinPos(DR.ast);for(let i=0;i<=20;i++){pt(vlerp(a,b,i/20),[1,.55+DR.heat*.3,.25],.7,1.1)}}
 // space dust (shows speed)
 if(G.mode==='fly'||G.mode==='launch'){let near=0;for(const a of W.asts){const d=dist(a.pos,P.pos)-a.r;if(d<600)near=Math.max(near,1-d/600)}
  const A=.22+near*.4;for(const d of W.dust){const p=[0,1,2].map(i=>eye[i]-150+(((d[i]-eye[i])%300)+300)%300);const dd=dist(p,eye);pt(p,[.8,.8,.85],A*clamp(1-dd/150,0,1),.35)}}
 gl.useProgram(PS.p);gl.uniformMatrix4fv(PS.u.uVP,false,VP);gl.uniform3fv(PS.u.uOff,[0,0,0]);gl.uniform1f(PS.u.uFixed,0);gl.uniform1f(PS.u.uScale,camF*SH*DPR*.5);
 gl.bindBuffer(gl.ARRAY_BUFFER,pbuf);gl.bufferData(gl.ARRAY_BUFFER,pdat.subarray(0,pn*8),gl.DYNAMIC_DRAW);ptsAttr(pbuf);gl.drawArrays(gl.POINTS,0,pn);ptsAttr(pbuf,false);
 gl.depthMask(true);gl.disable(gl.BLEND)}
function proj(p){const m=VP,x=p[0],y=p[1],z=p[2];const cx=m[0]*x+m[4]*y+m[8]*z+m[12],cy=m[1]*x+m[5]*y+m[9]*z+m[13],cw=m[3]*x+m[7]*y+m[11]*z+m[15];
 return {x:(cx/cw*.5+.5)*SW,y:(1-(cy/cw*.5+.5))*SH,w:cw}}
