'use strict';
const cam={mode:'hangar',q:[0,0,0,1],reset:true,h:1,eye:[0,0,0],look:[0,0,1],up:[0,1,0],fov:1};
let VP=null,camEye=[0,0,0],camF=1,SW=1,SH=1,DPR=1;
let starBuf,starN=0;const PMAX=7000,pdat=new Float32Array(PMAX*8);let pn=0,pbuf;
function renderInit(){glPrograms();pbuf=gl.createBuffer();buildStars('yantar')}
function buildStars(id){const sys=SYSTEMS[id];const R=srand(id=='yantar'?3:8);const arr=[];
 for(let i=0;i<1600;i++){const d=scl(norm([R()*2-1,R()*2-1,R()*2-1]),5000);const k=R(),tn=R();arr.push(...d,.75+tn*.25,.8+R()*.2,1-tn*.25,.3+k*k*.7,1+k*k*2.4)}
 for(let i=0;i<70;i++){const c=sys.neb[i%2];const base=norm(i%2?[-.7,.3,.5]:[.6,-.2,.7]);const d=scl(norm(add(base,scl(rndDirS(R),.45))),5000);arr.push(...d,...c,.09,R()*260+140)}
 arr.push(...scl(sys.sun,5000),1,.95,.85,1,46,...scl(sys.sun,5000),...sys.sunCol.map(x=>x*.8),.45,150);
 starN=arr.length/8;starBuf=gl.createBuffer();gl.bindBuffer(gl.ARRAY_BUFFER,starBuf);gl.bufferData(gl.ARRAY_BUFFER,new Float32Array(arr),gl.STATIC_DRAW);starsFor=id}
let starsFor=null;
function rndDirS(R){let v;do{v=[R()*2-1,R()*2-1,R()*2-1]}while(len(v)>1||len(v)<.1);return norm(v)}
function pt(p,c,a,s){if(pn>=PMAX)return;const o=pn++*8;pdat[o]=p[0];pdat[o+1]=p[1];pdat[o+2]=p[2];pdat[o+3]=c[0];pdat[o+4]=c[1];pdat[o+5]=c[2];pdat[o+6]=a;pdat[o+7]=s}
function resizeGL(){DPR=Math.min(window.devicePixelRatio||1,G.low?.8:1.5);SW=innerWidth;SH=innerHeight;glc.width=Math.round(SW*DPR);glc.height=Math.round(SH*DPR);gl.viewport(0,0,glc.width,glc.height);const h=document.getElementById('hud');const hd=Math.min(window.devicePixelRatio||1,2);h.width=Math.round(SW*hd);h.height=Math.round(SH*hd);HDPR=hd}
let HDPR=1;
function computeCamera(dt){if(!P)return;
 const st=W.station?STATIONS[W.station.id]:null;
 // hangar view
 let hEye=[0,0,0],hLook=[0,0,1];if(st){const sp=stationWorld(st.spot);hEye=add(sp,[13,5.5,-24]);hLook=add(sp,[-3,2,40])}
 // chase view
 if(cam.reset){cam.q=[...P.q];cam.reset=false}
 cam.q=qslerp(cam.q,P.q,damp(G.mode==='fly'?5:3,dt||.016));
 const bk=19+clamp((P.spd-60)*.025,0,4);let cEye=add(P.pos,qrot(cam.q,[0,4.6,-bk]));const cLook=add(P.pos,qrot(cam.q,[0,2.6,40]));
 const sh=(P.shake||0)+(P.kick||0)*.5;if(sh>0)cEye=add(cEye,scl(rndDir(),sh*.5));
 const hT=G.mode==='hangar'||(G.mode==='docking'&&G.anim>1.7)?1:0;if(G.mode==='launch'&&cam.h>0)cam.h=Math.max(0,1-G.anim/2);else cam.h=lerp(cam.h,hT,damp(hT?3:2.5,dt||.016));
 if(G.mode==='hangar')cam.h=1;
 const k=cam.h*cam.h*(3-2*cam.h);cam.eye=vlerp(cEye,hEye,k);cam.look=vlerp(cLook,hLook,k);cam.up=norm(vlerp(UP(cam.q),[0,1,0],k));
 const fovT=(G.mode==='fly'&&P.boosting?1.12:1)*(55/180*Math.PI)*(1-k*.08);cam.fov=lerp(cam.fov||fovT,fovT,damp(3,dt||.016))}
function drawMesh(m,q,p,s,o={}){gl.uniformMatrix4fv(MS.u.uM,false,mModel(q,p,s));gl.uniform3fv(MS.u.uEm,o.em||[0,0,0]);gl.uniform4fv(MS.u.uRim,o.rim||[.3,.45,.7,.25]);
 gl.uniform1f(MS.u.uTwo,o.smooth?0:1);gl.uniform1f(MS.u.uTerm,o.smooth?1:0);gl.uniform1f(MS.u.uSpec,o.spec==null?.35:o.spec);
 gl.bindBuffer(gl.ARRAY_BUFFER,m.buf);gl.vertexAttribPointer(MS.a.aPos,3,gl.FLOAT,false,40,0);gl.vertexAttribPointer(MS.a.aNor,3,gl.FLOAT,false,40,12);gl.vertexAttribPointer(MS.a.aCol,4,gl.FLOAT,false,40,24);gl.drawArrays(gl.TRIANGLES,0,m.n)}
function meshAttr(on){for(const n of ['aPos','aNor','aCol'])on?gl.enableVertexAttribArray(MS.a[n]):gl.disableVertexAttribArray(MS.a[n])}
function ptsAttr(b,on=true){gl.bindBuffer(gl.ARRAY_BUFFER,b);for(const [n,s,o] of [['aPos',3,0],['aCol',4,12],['aSize',1,28]]){if(on){gl.enableVertexAttribArray(PS.a[n]);gl.vertexAttribPointer(PS.a[n],s,gl.FLOAT,false,32,o)}else gl.disableVertexAttribArray(PS.a[n])}}
function glow(q,p,s,col,a,hit,hitR){gl.uniformMatrix4fv(GS.u.uM,false,mModel(q,p,s));gl.uniform3fv(GS.u.uCol,col);gl.uniform1f(GS.u.uA,a);gl.uniform3fv(GS.u.uHit,hit||[0,0,0]);gl.uniform1f(GS.u.uHitR,hitR||0);
 gl.bindBuffer(gl.ARRAY_BUFFER,M.bubble.buf);gl.vertexAttribPointer(GS.a.aPos,3,gl.FLOAT,false,40,0);gl.vertexAttribPointer(GS.a.aNor,3,gl.FLOAT,false,40,12);gl.drawArrays(gl.TRIANGLES,0,M.bubble.n)}
function flames(e,meshName,thr,boost,q,pos){const noz=NOZZLES[meshName];if(!noz)return;const f=FWD(q);const L=(1.2+thr*5+(boost?7:0))*(meshName==='transport'?2.5:1);
 for(const n of noz){const b=add(pos,qrot(q,n));const k=meshName==='transport'?2.2:meshName==='heavy'?1.5:1;
  for(let i=0;i<7;i++){const t=i/6;pt(sub(b,scl(f,t*L)),boost?[.55,.75,1]:[1,.62,.3],.55*(1-t),(1.4-t*.9)*k)}
  pt(b,[1,.9,.75],.5,1.2*k)}}
function render(dt){if(!W||!P)return;computeCamera(dt);if(starsFor!==W.id)buildStars(W.id);
 const sys=W.sys,eye=cam.eye,asp=SW/SH;camEye=eye;
 const view=mLook(eye,cam.look,cam.up);const shift=cam.h*cam.h*(3-2*cam.h)*(document.getElementById('station').classList.contains('hide')?0:.62);const pj=(n,f)=>{const m=mPersp(cam.fov,asp,n,f);m[8]=shift;return m};const bgVP=mMul(pj(300,800000),view);VP=mMul(pj(.8,60000),view);camF=1/Math.tan(cam.fov/2);
 gl.clearColor(sys.bg[0],sys.bg[1],sys.bg[2],1);gl.clear(gl.COLOR_BUFFER_BIT|gl.DEPTH_BUFFER_BIT);
 // stars & nebula
 gl.disable(gl.DEPTH_TEST);gl.enable(gl.BLEND);gl.blendFunc(gl.ONE,gl.ONE);gl.useProgram(PS.p);
 gl.uniformMatrix4fv(PS.u.uVP,false,bgVP);gl.uniform3fv(PS.u.uOff,eye);gl.uniform1f(PS.u.uFixed,1);ptsAttr(starBuf);gl.drawArrays(gl.POINTS,0,starN);ptsAttr(starBuf,false);
 gl.disable(gl.BLEND);gl.enable(gl.DEPTH_TEST);
 // background bodies
 gl.useProgram(MS.p);meshAttr(true);gl.uniform3fv(MS.u.uL,sys.sun);gl.uniform3fv(MS.u.uSun,sys.sunCol);gl.uniform3fv(MS.u.uAmb,scl(sys.amb,.35));gl.uniform3fv(MS.u.uCam,eye);
 gl.uniformMatrix4fv(MS.u.uVP,false,bgVP);const pl=sys.planet;
 drawMesh(M[pl.mesh],qaxis(norm([.2,1,0]),G.time*pl.spin),pl.pos,pl.r,{smooth:true,rim:pl.rim,spec:.05});
 if(pl.ring)drawMesh(M.giantRing,qaxis(norm([1,0,.3]),.38),pl.pos,pl.r,{spec:0});
 drawMesh(M.moon,[0,0,0,1],sys.moon.pos,sys.moon.r,{smooth:true,rim:[.6,.6,.7,.3],spec:0});
 gl.clear(gl.DEPTH_BUFFER_BIT);
 // foreground
 gl.uniformMatrix4fv(MS.u.uVP,false,VP);gl.uniform3fv(MS.u.uAmb,sys.amb);
 const sid=W.station.id;if(sid==='kromka'){drawMesh(M.kromka,[0,0,0,1],W.station.pos,1);drawMesh(M.ring,qaxis([0,0,1],W.ringRot),[0,0,-60],1);drawMesh(M.ring,qaxis([0,0,1],-W.ringRot*1.3+.4),[0,0,-140],1)}
 else drawMesh(M.verf,[0,0,0,1],W.station.pos,1);
 drawMesh(M.gate,W.gate.q,W.gate.pos,1);
 for(const s of W.statics)drawMesh(M[s.mesh],s.q,s.pos,s.s);
 for(const t of W.traffic)drawMesh(M[t.mesh],t.q,t.pos,t.s||1);
 const far=G.low?7000:11000;
 for(const a of W.asts){const d=dist(a.pos,eye);if(d-a.r>far)continue;drawMesh(a.mesh,a.q,a.pos,a.r,{spec:.12,em:a===P.target?[.05,.04,.02]:[0,0,0]})}
 for(const c of W.conts)drawMesh(M.container,c.q,c.pos,1);
 if(W.transport)drawMesh(M.transport,W.transport.q,W.transport.pos,1);
 for(const e of W.enemies){const fl=e.shieldFx>0&&e.shield<=0?.3:0;drawMesh(M[e.type],e.q,e.pos,1,{em:[fl,fl*.4,fl*.2]})}
 const pq=qmul(P.q,qaxis([0,0,1],P.bank));
 if(P.alive)drawMesh(M[S.active],pq,P.pos,1,{em:P.hitFx>0?[.3,.1,.05]:[0,0,0]});
 meshAttr(false);
 // additive pass
 gl.enable(gl.BLEND);gl.blendFunc(gl.ONE,gl.ONE);gl.depthMask(false);
 gl.useProgram(GS.p);gl.uniformMatrix4fv(GS.u.uVP,false,VP);gl.uniform3fv(GS.u.uCam,eye);gl.enableVertexAttribArray(GS.a.aPos);gl.enableVertexAttribArray(GS.a.aNor);
 const bub=(t,r)=>{if(t.shieldFx>0.01)glow(t.q||[0,0,0,1],t.pos,r,[.3,.65,1],t.shieldFx*.35,t.hitPt,r*1.2)};
 if(P.alive)bub(P,8.5);for(const e of W.enemies)bub(e,e.r*1.35);
 if(G.mode==='jump')glow([0,0,0,1],W.gate.pos,90,[.3,.7,1],.25*Math.min(1,G.anim));
 gl.disableVertexAttribArray(GS.a.aPos);gl.disableVertexAttribArray(GS.a.aNor);
 pn=0;
 if(P.alive&&G.mode!=='hangar')flames(P,S.active,P.thr,P.boosting,pq,P.pos);else if(P.alive)flames(P,S.active,.05,false,pq,P.pos);
 for(const e of W.enemies){flames(e,e.type,.8,false,e.q,e.pos);if(e.charge>0){const n=add(e.pos,qrot(e.q,[0,.1,9]));pt(n,[.5,.85,1],1,4+(.5-e.charge)*14);pt(n,[1,1,1],.8,2)}}
 for(const t of W.traffic)flames(t,t.mesh==='transport'?'transport':'tug',t.kind==='hauler'?0:.4,false,t.q,t.pos);
 if(W.transport)flames(W.transport,'transport',.7,false,W.transport.q,W.transport.pos);
 for(const p of W.parts){const k=p.life/p.max;if(p.dark)pt(p.p,[.25,.23,.2],.5*k,p.s);else pt(p.p,p.c,Math.min(1,k*1.4),p.s*(.6+k*.4))}
 for(const s of W.shots){const d=norm(s.v);if(s.kind==='plasma'){pt(s.p,[.55,1,.7],1,4.2);pt(s.p,[1,1,1],.9,1.8);for(let i=1;i<6;i++)pt(sub(s.p,scl(d,i*2.2)),[.4,1,.6],.6-i*.1,3-i*.4)}
  else if(s.kind==='echarge'){pt(s.p,[.5,.85,1],1,5);pt(s.p,[1,1,1],.9,2);for(let i=1;i<5;i++)pt(sub(s.p,scl(d,i*2.5)),[.4,.7,1],.6-i*.12,3.5-i*.5)}
  else{const c=s.owner==='p'?[.45,.85,1]:[1,.35,.2];for(let i=0;i<5;i++)pt(sub(s.p,scl(d,i*1.5)),c,1-i*.18,i?.9:1.3)}}
 const blink=t=>(Math.sin((G.time+t)*Math.PI*1.4)>.4);
 for(const L of W.lights)if(blink(L.ph))pt(L.p,L.c,.9,6);
 for(const s of W.statics)if(s.buoy&&blink(0))pt(add(s.pos,[0,15,0]),[1,.5,.2],1,8);
 for(const c of W.conts)if(blink(.3))pt(add(c.pos,[0,2.5,0]),c.item in CITEMS?[1,.85,.2]:[.4,1,.5],.9,2.2);
 // gate inner glow when route chosen
 if(S.route&&S.route!==W.id||G.mode==='jump'){const g=W.gate;for(let i=0;i<40;i++){const a=i/40*Math.PI*2+G.time*.6;pt(add(g.pos,qrot(g.q,[Math.cos(a)*80,Math.sin(a)*80,0])),[.4,.8,1],.5,5)}}
 // drill beam
 if(DR&&DR.hold&&DR.lock<=0){const a=add(P.pos,qrot(P.q,[0,-.5,6.5])),b=veinPos(DR.ast);for(let i=0;i<=20;i++){pt(vlerp(a,b,i/20),[1,.55+DR.heat*.3,.25],.7,1.1)}}
 // space dust (shows speed)
 if(G.mode==='fly'||G.mode==='launch'){let near=0;for(const a of W.asts){const d=dist(a.pos,P.pos)-a.r;if(d<600)near=Math.max(near,1-d/600)}
  const A=.22+near*.4;for(const d of W.dust){const p=[0,1,2].map(i=>eye[i]-150+(((d[i]-eye[i])%300)+300)%300);const dd=dist(p,eye);pt(p,[.8,.8,.85],A*clamp(1-dd/150,0,1),.35)}}
 gl.useProgram(PS.p);gl.uniformMatrix4fv(PS.u.uVP,false,VP);gl.uniform3fv(PS.u.uOff,[0,0,0]);gl.uniform1f(PS.u.uFixed,0);gl.uniform1f(PS.u.uScale,camF*SH*DPR*.5);
 gl.bindBuffer(gl.ARRAY_BUFFER,pbuf);gl.bufferData(gl.ARRAY_BUFFER,pdat.subarray(0,pn*8),gl.DYNAMIC_DRAW);ptsAttr(pbuf);gl.drawArrays(gl.POINTS,0,pn);ptsAttr(pbuf,false);
 gl.depthMask(true);gl.disable(gl.BLEND)}
function proj(p){const m=VP,x=p[0],y=p[1],z=p[2];const cx=m[0]*x+m[4]*y+m[8]*z+m[12],cy=m[1]*x+m[5]*y+m[9]*z+m[13],cw=m[3]*x+m[7]*y+m[11]*z+m[15];
 return {x:(cx/cw*.5+.5)*SW,y:(1-(cy/cw*.5+.5))*SH,w:cw}}
