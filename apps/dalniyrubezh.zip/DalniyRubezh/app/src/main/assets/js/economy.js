'use strict';
// ================= ECONOMY: 30 goods, markets, law, storage, blueprints, asteroid families =================
const GOOD_CATS={ore:'Руда',mat:'Материалы',parts:'Запчасти',tech:'Техника',med:'Медицина',home:'Быт',lux:'Роскошь',contra:'Запрещённое'};
// id,name,cat,base,producers(families/regions/systems),consumers
const GOOD_DEFS=[
 ['ore','Руда','ore',52,'mining,yantar,inei','dock,military,union'],
 ['ice','Лёд','ore',30,'mining,ice','habitat,dry,volcanic'],
 ['cobalt','Кобальт','ore',95,'kobalt,union-mining','dock,teira'],
 ['crystal','Кристаллы резонанса','ore',160,'essen-mining,tikhy','essen,observatory,league'],
 ['rare','Звёздная руда','ore',420,'white_pocket','lira,sklad9,essen_oi'],
 ['alloy','Сплавы','mat',88,'gorn,union-dock,ashket','dock,military,teira'],
 ['polymer','Полимеры','mat',60,'league-habitat,sirin','union,dock'],
 ['fuel','Топливные элементы','mat',45,'inei,giant,union','military,free,border'],
 ['glass','Кварцевое стекло','mat',70,'dry,polden','observatory,habitat'],
 ['parts','Запчасти','parts',66,'union,dock','mining,military,free'],
 ['engines','Узлы двигателей','parts',190,'stapel,nakov','free,border,dock'],
 ['plates','Обшивка','parts',120,'gorn,ashket','military,dock,border'],
 ['elec','Электроника','tech',112,'league,verf9','union,teira,free'],
 ['sensors','Сенсоры','tech',210,'lira,essen','military,observatory,border'],
 ['robots','Дроны-ремонтники','tech',260,'perekr,stapel','mining,dock,free'],
 ['reson','Резонаторы','tech',300,'essen','league,teira'],
 ['meds','Медикаменты','med',70,'polden,league,lo_unna','border,free,mining'],
 ['serum','Сыворотки','med',180,'lo_unna,polden','free,border,hidden'],
 ['biogel','Биогель','med',140,'essen-habitat,lo_unna','league,military'],
 ['food','Продовольствие','home',28,'sirin,ocean,lira','mining,military,free,border'],
 ['water','Вода','home',18,'ice,ocean','dry,volcanic,mining'],
 ['textiles','Ткани','home',40,'teira,sirin','union,free'],
 ['tools','Инструменты','home',55,'union','mining,free,border'],
 ['wine','Вино Лиры','lux',240,'lira','teira,union,free'],
 ['relics','Реликвии Тейра','lux',520,'venec,teira','league,essen'],
 ['art','Голоискусство','lux',380,'essen_oi,lira','league,union'],
 ['spice','Пряности Кильватера','lux',150,'kilvater,free','league,teira'],
 ['stims','Стимуляторы','contra',200,'free,hidden','border,military,mining'],
 ['guns','Незарегистрированное оружие','contra',340,'black_harbor,sklad9','kilvater,pustosh,ark,posledny'],
 ['transp','Чистые транспондеры','contra',280,'black_harbor,rzhavy','free,hidden']];
REG.goods={};for(const [id,name,cat,base,prod,cons] of GOOD_DEFS)REG.goods[id]={id,name,cat,base,prod:prod.split(','),cons:cons.split(',')};
// replace the 4-good tables from v1 data with the full catalogue (ids of the first 4 are unchanged)
for(const id in REG.goods)GOODS[id]=REG.goods[id].name;GOOD_IDS.length=0;GOOD_IDS.push(...Object.keys(REG.goods));
// ---- jurisdiction ----
function lawOf(sysId){const s=REG.systems[sysId];if(s.region==='hidden'||s.owner==='wake')return {name:'Вольный порт',banned:[]};
 if(s.owner==='none')return {name:'Пограничный закон',banned:['guns']};return {name:REG.factions[s.owner].name,banned:['stims','guns','transp']}}
function illegalHere(g,stId){return lawOf(REG.stations[stId||S.station].sys).banned.includes(g)}
function illegalCargo(stId){return Object.keys(S.cargo).filter(g=>S.cargo[g]>0&&illegalHere(g,stId))}
// ---- markets ----
function tagsOf(stId){const st=REG.stations[stId],sys=REG.systems[st.sys];const fam=st.bespoke?BESPOKE_FAMILY[st.bespoke]:st.family;
 return [fam,sys.region,sys.id,sys.planet,sys.owner,stId,st.bespoke||'',(REG.regions[sys.region].faction||'')+'-'+fam,sys.region+'-'+fam,sys.owner+'-'+fam,sys.hidden?'hidden':'']}
function buildMarket(stId){const tags=tagsOf(stId);const R=srand(hashStr(stId)+77);const law=lawOf(REG.stations[stId].sys);const prices={},stock={},list=[];
 for(const g of Object.values(REG.goods)){const prod=g.prod.some(t=>tags.includes(t)),cons=g.cons.some(t=>tags.includes(t));
  const legal=!law.banned.includes(g.id);const black=REG.stations[stId].services.includes('black');
  if(!legal)continue;if(g.cat==='contra'&&!(black||prod||cons))continue;
  const keep=prod||cons||R()<.22||['ore','elec','meds','parts','food','fuel'].includes(g.id);if(!keep)continue;
  const m=prod&&!cons?.68:cons&&!prod?1.32:1;const buy=Math.max(4,Math.round(g.base*m*(.94+R()*.12)));prices[g.id]=[buy,Math.round(buy*.86)];
  stock[g.id]=prod?Math.round(40+R()*60):cons?Math.round(R()*6):Math.round(8+R()*20);list.push(g.id)}
 return {prices,stock,list}}
for(const id in REG.stations){const mk=buildMarket(id);const s=STATIONS[id];
 if(id==='kromka'||id==='verf9'){for(const g of mk.list)if(!s.prices[g]){s.prices[g]=mk.prices[g];s.stock[g]=mk.stock[g]}s.goods=[...new Set(['ore','elec','meds','parts',...mk.list])]}
 else{s.prices=mk.prices;s.stock=mk.stock;s.goods=mk.list}}
// player may always sell what is legal here even if the port does not list it (at a low price)
function marketGoods(stId){const s=STATIONS[stId];const extra=Object.keys(S.cargo).filter(g=>S.cargo[g]>0&&!s.goods.includes(g)&&!illegalHere(g,stId));return [...s.goods,...extra]}
function priceAt(g,side,stId){const s=STATIONS[stId];if(s.prices[g]){const v=s.prices[g][side==='buy'?0:1];return side==='buy'&&stId.startsWith('bh_')&&S&&S.bhSecret?Math.round(v*.85):v}const b=REG.goods[g].base;return side==='buy'?null:Math.round(b*.6)}
// ---- station storage ----
function storageOf(id){if(!S.storage)S.storage={};if(!S.storage[id])S.storage[id]={};return S.storage[id]}
function storeGood(g,n){return atomic(()=>{n=Math.min(n,S.cargo[g]||0);if(n<=0)return 'Нечего сдавать на склад';S.cargo[g]-=n;const st=storageOf(S.station);st[g]=(st[g]||0)+n;saveGame();return ''})}
function takeGood(g,n){return atomic(()=>{const st=storageOf(S.station);n=Math.min(n,st[g]||0,cargoFree());if(n<=0)return cargoFree()<=0?'В трюме нет места':'На складе пусто';st[g]-=n;if(!st[g])delete st[g];S.cargo[g]=(S.cargo[g]||0)+n;saveGame();return ''})}
// ---- blueprints (12) ----
const BP_DEFS=[
 ['bp_shield','Чертёж: усиленный щит',{t:'m',id:'shield_p'},{alloy:2,elec:2},150,'kromka',400],
 ['bp_drill','Чертёж: бур «Глубина»',{t:'m',id:'drill'},{cobalt:3,parts:2},200,'gorn_mine',600],
 ['bp_cooler','Чертёж: теплоотвод',{t:'m',id:'cooler'},{ice:4,alloy:2},200,'verf9',700],
 ['bp_battery','Чертёж: аккумулятор',{t:'m',id:'battery'},{crystal:2,elec:2},150,'ess_spire',650],
 ['bp_osa','Чертёж: ракеты «Оса» ×8',{t:'ammo',id:'m_osa'},{fuel:2,elec:1},50,'nak_ars',500],
 ['bp_armor','Чертёж: бронеплиты',{t:'m',id:'armor'},{alloy:4,plates:2},150,'stp_north',600],
 ['bp_reactor','Чертёж: реактор «Пламя»',{t:'m',id:'reactor'},{crystal:3,rare:1,elec:2},400,'wp_station',1800],
 ['bp_tractor','Чертёж: притягивающий луч',{t:'m',id:'tractor'},{sensors:2,parts:2},250,'yan_obs',900],
 ['bp_drone','Чертёж: ремонтный дрон',{t:'m',id:'repair_drone'},{robots:2,parts:2},300,'lira_ex',1400],
 ['bp_jammer','Чертёж: постановщик помех',{t:'m',id:'jammer'},{transp:1,elec:2},250,'kil_bazaar',1100],
 ['bp_igla','Чертёж: рельсотрон «Игла»',{t:'w',id:'k_igla'},{alloy:3,cobalt:2,engines:1},400,'raz_fort',2200],
 ['bp_mayak','Чертёж: корабль «Маяк»',{t:'ship',id:'mayak'},{sensors:4,alloy:6,engines:2,crystal:2},3000,'mez_obs',4000]];
REG.blueprints={};for(const [id,name,res,mats,fee,where,price] of BP_DEFS)REG.blueprints[id]={id,name,res,mats,fee,where,price};
for(const b of Object.values(REG.blueprints)){const st=REG.stations[b.where];if(st&&!st.services.includes('equip'))st.services.push('equip')}
function bpMissing(id){const b=REG.blueprints[id];const miss=[];for(const g in b.mats){const have=(S.cargo[g]||0)+(storageOf(S.station)[g]||0);if(have<b.mats[g])miss.push(GOODS[g]+' '+have+'/'+b.mats[g])}return miss}
function buyBlueprint(id){return atomic(()=>{const b=REG.blueprints[id];S.bps=S.bps||[];if(S.bps.includes(id))return 'Чертёж уже ваш';if(b.where!==S.station)return 'Этот чертёж продают на станции '+REG.stations[b.where].name;
 if(S.cr<b.price)return 'Не хватает '+(b.price-S.cr)+' кр.';S.cr-=b.price;S.bps.push(id);saveGame();return ''})}
function craft(id){return atomic(()=>{const b=REG.blueprints[id];if(!(S.bps||[]).includes(id))return 'Нет чертежа';if(!svcHere('equip'))return 'Здесь нет мастерской: нужна станция с оборудованием';
 const miss=bpMissing(id);if(miss.length)return 'Не хватает: '+miss.join(', ');if(S.cr<b.fee)return 'Работа мастерской стоит '+b.fee+' кр.';
 if(b.res.t==='ship'&&S.ships.includes(b.res.id))return 'Такой корабль у вас уже есть';
 for(const g in b.mats){let need=b.mats[g];const take=Math.min(need,S.cargo[g]||0);S.cargo[g]-=take;need-=take;if(need>0){const st=storageOf(S.station);st[g]-=need;if(!st[g])delete st[g]}}
 S.cr-=b.fee;const inv=invOf();let msg='';
 if(b.res.t==='m'){const f=fitOf(S.active);if(f.m.length<REG.ships[S.active].mslots&&!moduleProblem(b.res.id)){f.m.push(b.res.id);msg='Изготовлено и установлено: '+REG.modules[b.res.id].name}else{inv.m.push(b.res.id);msg='Изготовлено, лежит на складе снаряжения'}}
 else if(b.res.t==='w'){const f=fitOf(S.active);const i=f.w.indexOf(null);if(i>=0){f.w[i]=b.res.id;msg='Изготовлено и установлено'}else{inv.w.push(b.res.id);msg='Изготовлено, лежит на складе снаряжения'}}
 else if(b.res.t==='ammo'){const f=fitOf(S.active);if(f.mis&&f.mis.id===b.res.id){f.mis.ammo=REG.weapons[b.res.id].ammo;msg='Боезапас изготовлен'}else{inv.w.push(b.res.id);msg='Ракетный узел «Оса» изготовлен, лежит на складе снаряжения'}}
 else if(b.res.t==='ship'){S.ships.push(b.res.id);fitOf(b.res.id);msg='Корабль «'+REG.ships[b.res.id].name+'» построен и ждёт в ангаре'}
 syncLegacyMods();saveGame();return '✓'+msg})}
function svcHere(s){return REG.stations[S.station].services.includes(s)}
// ---- asteroid families ----
const AST_FAM={copper:{name:'Медная жила',good:'ore',col:C(.82,.45,.2,.14)},ice:{name:'Ледяной астероид',good:'ice',col:C(.8,.92,1,.12)},
 cobalt:{name:'Кобальтовая жила',good:'cobalt',col:C(.25,.45,1,.25)},crystal:{name:'Кристаллы резонанса',good:'crystal',col:C(.4,1,.85,.4)},rare:{name:'Звёздная руда',good:'rare',col:C(1,.95,.7,.6)}};
function famOfBelt(sysId){if(sysId==='white_pocket')return ['rare','crystal'];const s=REG.systems[sysId];if(sysId==='yantar')return ['copper'];
 if(s.region==='essen'||sysId==='silent_garden')return ['crystal','ice'];if(s.planet==='ice')return ['ice','cobalt'];if(s.region==='union'||sysId==='kobalt')return ['cobalt','copper'];return ['copper','ice']}
const AST_MESH={};
function astMesh(fam,k){const key=fam+k;if(AST_MESH[key])return AST_MESH[key];const F=AST_FAM[fam];const seed=hashStr(key);
 const base=fam==='ice'?(n,r)=>{const v=.55+r()*.15;return C(v*.85,v*.95,v*1.1)}:fam==='crystal'||fam==='rare'?(n,r)=>{const v=.16+r()*.05;return C(v*.9,v,v*1.1)}:fam==='cobalt'?(n,r)=>{const v=.2+r()*.05;return C(v,v,v*1.1)}:(n,r)=>{const v=.2+r()*.06;return C(v*1.05,v,v*.95)};
 const t=rockTris(1,.3,1,(n,r)=>{const vein=n[1]>.45&&Math.abs(n[0]-n[2]*.4)<.42;return vein?tone(F.col,.85+r()*.3):base(n,r)},I,seed);
 if(fam==='crystal'||fam==='rare')for(let i=0;i<6;i++){const d=norm([Math.sin(i*2.1),.6+Math.cos(i*1.3)*.3,Math.cos(i*2.1)]);const q=qLook(d);for(const tri of (()=>{const tt=[];cyl(tt,0,.55,.1,0,5,()=>F.col,v=>add(qrot(q,v),scl(d,.75)));return tt})())t.push(tri)}
 return AST_MESH[key]=makeMesh(t)}
const RICH=['бедная','средняя','богатая'];
