'use strict';
// ================= input =================
const IN={yaw:0,pitch:0,roll:0,thrDelta:0,thrSet:null,fire:false,boost:false,actionEdge:false,actionHeld:false,targetEdge:false,weaponEdge:false};
const KB={};const PTR={};let JOY=null;let MOUSE={x:0,y:0,on:false,down:false};G.touch=matchMedia('(pointer:coarse)').matches;
let hc,hx;const $=id=>document.getElementById(id);
function layout(){const w=SW,h=SH;const L={};
 L.thr=[0,1,2].map(i=>({x:10,y:h-58-i*48,w:54,h:42,v:[0,.5,1][i],label:['0','50%','100%'][i]}));
 L.joy={x:Math.max(190,w*.22),y:h-96,r:Math.min(64,h*.18)};
 L.fire={x:w-80,y:h-82,r:Math.min(56,h*.16)};L.boost={x:w-190,y:h-54,r:Math.min(36,h*.1)};L.weapon={x:w-198,y:h-136,r:26};
 L.action={x:w-112,y:h-190,w:200,h:46};
 L.pause={x:w-28,y:28,r:21};L.map={x:w-78,y:28,r:21};L.target={x:w-128,y:28,r:21};return L}
function inRect(r,x,y){return x>r.x-r.w/2&&x<r.x+r.w/2&&y>r.y-r.h/2&&y<r.y+r.h/2}
function inCirc(c,x,y,k=1.15){return Math.hypot(x-c.x,y-c.y)<c.r*k}
function hudHit(x,y){const L=layout();if(!G.touch)return null;
 if(inCirc(L.pause,x,y,1.3))return 'pause';if(inCirc(L.map,x,y,1.3))return 'map';if(inCirc(L.target,x,y,1.3))return 'target';
 const act=currentAction();if(act&&inRect(L.action,x,y))return 'action';
 if(S&&S.mods.plasma&&inCirc(L.weapon,x,y))return 'weapon';
 if(inCirc(L.fire,x,y))return 'fire';if(inCirc(L.boost,x,y))return 'boost';
 for(const b of L.thr)if(x>b.x-4&&x<b.x+b.w+4&&y>b.y-3&&y<b.y+b.h+3)return 'thr'+b.v;
 if(x<SW*.45&&y>SH*.28)return 'joy';return null}
function resetInput(){for(const k in PTR)delete PTR[k];for(const k in KB)KB[k]=false;JOY=null;Object.assign(IN,{yaw:0,pitch:0,roll:0,thrDelta:0,fire:false,boost:false,actionHeld:false});MOUSE.down=false}
function inputInit(){hc=$('hud');hx=hc.getContext('2d');
 const first=()=>{sndInit();sndVolume(SET.vol)};addEventListener('pointerdown',first,{capture:true});addEventListener('keydown',first,{capture:true});
 hc.addEventListener('pointerdown',e=>{e.preventDefault();if(e.pointerType!=='mouse'){G.touch=true}
  if(G.mode!=='fly')return;const x=e.clientX,y=e.clientY;
  if(e.pointerType==='mouse'){if(e.button===0){MOUSE.down=true}return}
  const h=hudHit(x,y);if(!h)return;try{hc.setPointerCapture(e.pointerId)}catch(_){}
  if(h==='pause'){uiPause();return}if(h==='map'){uiMap();return}if(h==='target'){IN.targetEdge=true;return}if(h==='weapon'){IN.weaponEdge=true;return}
  if(h.startsWith('thr')){IN.thrSet=+h.slice(3);uiHintCheck();return}
  if(h==='action'){IN.actionEdge=true;PTR[e.pointerId]='action';return}
  if(h==='joy'){if(!JOY){const L=layout();const cx=clamp(x,90,SW*.45),cy=clamp(y,SH*.35,SH-40);JOY={id:e.pointerId,ox:cx,oy:cy,x,y,r:L.joy.r};PTR[e.pointerId]='joy'}return}
  PTR[e.pointerId]=h},{passive:false});
 hc.addEventListener('pointermove',e=>{if(e.pointerType==='mouse'){MOUSE.x=e.clientX;MOUSE.y=e.clientY;MOUSE.on=true;return}
  if(JOY&&JOY.id===e.pointerId){JOY.x=e.clientX;JOY.y=e.clientY}});
 const up=e=>{if(e.pointerType==='mouse'){if(e.button===0)MOUSE.down=false;return}if(JOY&&JOY.id===e.pointerId)JOY=null;delete PTR[e.pointerId]};
 hc.addEventListener('pointerup',up);hc.addEventListener('pointercancel',up);hc.addEventListener('lostpointercapture',up);
 addEventListener('mousemove',e=>{MOUSE.x=e.clientX;MOUSE.y=e.clientY;MOUSE.on=true});
 addEventListener('keydown',e=>{if(e.code==='Tab'){e.preventDefault()}if(e.repeat){KB[e.code]=true;return}KB[e.code]=true;
  if(G.mode==='fly'){if(e.code==='KeyE')IN.actionEdge=true;if(e.code==='Tab')IN.targetEdge=true;if(e.code==='KeyQ'||e.code==='Digit1'||e.code==='Digit2')IN.weaponEdge=true;
   if(e.code==='KeyM')uiMap();if(e.code==='Escape')uiPause()}
  else if(e.code==='Escape'){if(!$('pause').classList.contains('hide'))uiResume();else if(!$('map').classList.contains('hide'))uiCloseMap()}});
 addEventListener('keyup',e=>{KB[e.code]=false});
 addEventListener('blur',resetInput);
 document.addEventListener('visibilitychange',()=>{if(document.hidden){resetInput();if(G.mode==='fly')uiPause();sndSuspend(true)}else{sndSuspend(false);lastT=performance.now()}});
 hc.addEventListener('contextmenu',e=>e.preventDefault())}
function readInput(dt){let yaw=0,pitch=0;
 const held=v=>Object.values(PTR).includes(v);
 if(JOY){let dx=JOY.x-JOY.ox,dy=JOY.y-JOY.oy;const l=Math.hypot(dx,dy);if(l>JOY.r){JOY.ox+=dx*(1-JOY.r/l);JOY.oy+=dy*(1-JOY.r/l);dx=JOY.x-JOY.ox;dy=JOY.y-JOY.oy}yaw=dx/JOY.r;pitch=-dy/JOY.r}
 else if(!G.touch&&MOUSE.on){const R=Math.min(SW,SH)*.42;yaw=(MOUSE.x-SW/2)/R;pitch=-(MOUSE.y-SH/2)/R}
 const dz=v=>{const a=Math.abs(v);return a<.06?0:Math.sign(v)*Math.min(1,(a-.06)/.94)};yaw=dz(yaw);pitch=dz(pitch);
 if(KB.ArrowLeft)yaw=-1;if(KB.ArrowRight)yaw=1;if(KB.ArrowUp)pitch=1;if(KB.ArrowDown)pitch=-1;
 IN.yaw=yaw;IN.pitch=pitch;IN.roll=(KB.KeyD?1:0)-(KB.KeyA?1:0);IN.thrDelta=(KB.KeyW?1:0)-(KB.KeyS?1:0);
 IN.fire=held('fire')||MOUSE.down;IN.boost=held('boost')||!!KB.ShiftLeft||!!KB.ShiftRight;IN.actionHeld=held('action')||!!KB.KeyE;
 if(Math.abs(yaw)+Math.abs(pitch)>.3)G.turnAcc=(G.turnAcc||0)+dt;uiHintCheck()}

// ================= HUD =================
let noteT=0,noteTxt='',toast=null;
function uiNote(t){noteTxt=t;noteT=3.2}
const HINTS=[{id:'turn',t:()=>G.touch?'Поворот: тяните джойстик слева':'Поворот: ведите мышью от центра экрана',done:()=>(G.turnAcc||0)>1},
 {id:'thrust',t:()=>G.touch?'Тяга: нажмите «100%» слева от джойстика':'Тяга: удерживайте W до максимума',done:()=>P&&P.thr>=.95},
 {id:'pickup',t:()=>'Подлетите к контейнеру и нажмите «Подобрать»'+(G.touch?'':' (E)'),done:()=>S.citems.includes('recorder')||!msActive('m1')},
 {id:'dock',t:()=>'Летите к Кромке. У створок ангара нажмите «Стыковаться»'+(G.touch?'':' (E)'),done:()=>!msActive('m1')}];
let hintI=-1;
function uiFlightStart(){if(!S.tut&&!G.duel){hintI=0;G.turnAcc=0}else hintI=-1}
function uiHintCheck(){if(hintI<0||!S)return;while(hintI<HINTS.length&&HINTS[hintI].done())hintI++;if(hintI>=HINTS.length){hintI=-1;S.tut=true}}
function uiHintDone(){uiHintCheck()}
function drawHUD(dt){const w=SW,h=SH;hx.setTransform(HDPR,0,0,HDPR,0,0);hx.clearRect(0,0,w,h);if(!P||!W)return;
 if(G.mode==='hangar'||G.mode==='menu')return;
 if(G.mode==='jump'){const k=G.anim/1.6;hx.fillStyle=`rgba(180,220,255,${Math.max(0,k-.6)*2.2})`;hx.fillRect(0,0,w,h);hx.strokeStyle='rgba(160,210,255,.5)';hx.lineWidth=2;
  for(let i=0;i<40;i++){const a=i/40*Math.PI*2,r0=60+((G.time*600+i*37)%400)*k;hx.beginPath();hx.moveTo(w/2+Math.cos(a)*r0,h/2+Math.sin(a)*r0);hx.lineTo(w/2+Math.cos(a)*(r0+60*k),h/2+Math.sin(a)*(r0+60*k));hx.stroke()}return}
 const st=shipStats(),f=FWD(P.q),L=layout();
 if(P.alive&&G.mode==='fly'){
  // crosshair
  const c=proj(add(P.pos,scl(f,400)));const cx=c.w>0?c.x:w/2,cy=c.w>0?c.y:h/2;
  hx.lineWidth=2;hx.strokeStyle='rgba(0,0,0,.55)';drawCross(cx+1,cy+1);hx.strokeStyle='rgba(170,235,255,.95)';hx.lineWidth=1.6;drawCross(cx,cy);
  // damage direction arcs
  for(const d of P.dmgDirs){const rel=sub(d.from,P.pos);const x=dot(rel,RIGHT(P.q)),y=dot(rel,UP(P.q));const a=Math.atan2(-y,x);hx.strokeStyle=`rgba(255,70,50,${Math.min(1,d.t)})`;hx.lineWidth=5;hx.beginPath();hx.arc(cx,cy,46,a-.45,a+.45);hx.stroke()}
  // objective & target markers
  const ob=objective();const tg=P.target;
  if(ob.target&&ob.target!==tg)marker(ob.target,'#ffd166',ob.target.name||'',14,true);
  if(P.nav&&P.nav!==tg&&P.nav!==ob.target)marker(P.nav,'#7fe3ff',P.nav.name,12,true);
  for(const e of W.enemies)if(e!==tg){const q=proj(e.pos);if(q.w>0&&q.x>0&&q.x<w&&q.y>0&&q.y<h){hx.strokeStyle='rgba(255,90,70,.8)';hx.lineWidth=1.5;hx.strokeRect(q.x-7,q.y-7,14,14)}}
  if(tg){const col=tg.kind==='enemy'?'#ff5a46':'#e8f1ff';marker(tg,col,'',18,true);
   if(tg.kind==='enemy'){const wp=WEAPONS[P.weapon];const lt=leadTime(P.pos,P.vel,wp.speed,tg.pos,tg.vel);const lp=add(tg.pos,scl(sub(tg.vel,P.vel),lt));const q=proj(lp);
    if(q.w>0){hx.strokeStyle='#ffcf5a';hx.lineWidth=2;hx.beginPath();hx.arc(q.x,q.y,6,0,7);hx.moveTo(q.x-10,q.y);hx.lineTo(q.x-4,q.y);hx.moveTo(q.x+4,q.y);hx.lineTo(q.x+10,q.y);hx.stroke()}}}
  // transport marker
  if(W.transport&&W.transport!==tg&&W.transport!==ob.target)marker(W.transport,'#9dff9d','',14,true);
  // bars
  bar(12,12,150,12,P.shield/st.shield,'#3aa7ff','Щит '+Math.ceil(P.shield));bar(12,28,150,12,P.hull/st.hull,P.hull/st.hull<.3?'#ff4a3a':'#e2a33a','Корпус '+Math.ceil(P.hull));
  hx.fillStyle='rgba(8,16,32,.6)';hx.fillRect(12,44,150,6);hx.fillStyle=P.boostT<.3?'#567':'#9fd4ff';hx.fillRect(12,44,150*P.boostT/3,6);
  txt(Math.round(P.spd)+' м/с',12,66,'#e8f1ff',14,'left',true);txt('тяга '+Math.round(P.thr*100)+'%'+(P.boosting?' · ФОРСАЖ':''),78,66,'#9fb6d8',11);
  if(S.mods.plasma)txt(WEAPONS[P.weapon].name,12,82,'#a8ffb8',11);
  // mission line
  txt(ob.text,w/2,20,'#ffd98a',13,'center',true);
  // target info
  if(tg){const x=w-212,y=52;hx.fillStyle='rgba(6,12,26,.6)';hx.fillRect(x,y,200,tg.hull!=null?42:28);txt(tg.name||'',x+8,y+16,'#e8f1ff',12);txt(fmtD(dist(tg.pos,P.pos)),x+192,y+16,'#9fd0ff',12,'right');
   if(tg.hull!=null){bar(x+8,y+24,90,7,(tg.shield||0)/(tg.maxSh||1),'#3aa7ff','');bar(x+102,y+24,90,7,tg.hull/tg.max,'#e2a33a','')}
   else if(tg.kind==='ast'&&tg.ore!=null&&tg.maxOre)txt('Жила: '+tg.ore+'/'+tg.maxOre+' · трюм '+cargoUsed()+'/'+st.cargo,x+8,y+24+2,'#d9b48a',11)}
  // hint
  if(hintI>=0&&hintI<HINTS.length){const t=HINTS[hintI].t();hx.font='bold 14px system-ui';const tw=hx.measureText(t).width+28;hx.fillStyle='rgba(20,40,80,.82)';rr(w/2-tw/2,38,tw,30,8);hx.fill();hx.strokeStyle='#5aa0ff';hx.stroke();txt(t,w/2,58,'#fff',14,'center')}
  // drilling
  if(DR){const bw=Math.min(260,w*.34),x=w/2-bw/2,y=h*.7;hx.fillStyle='rgba(6,12,26,.75)';hx.fillRect(x-8,y-24,bw+16,48);
   hx.fillStyle='#253348';hx.fillRect(x,y,bw,12);hx.fillStyle='rgba(80,220,120,.55)';hx.fillRect(x+bw*.55,y,bw*.25,12);
   hx.fillStyle=DR.lock>0?'#f44':'#ffb347';hx.fillRect(x+bw*clamp(DR.heat,0,1)-2,y-4,4,20);
   hx.fillStyle='#6f6';hx.fillRect(x,y+15,bw*DR.zone/2,3);
   txt(DR.lock>0?'ПЕРЕГРЕВ':DR.full?'Трюм полон — освободите место':'Бур · жила '+DR.ast.ore+' · трюм '+cargoUsed()+'/'+st.cargo,w/2,y-8,'#e8f1ff',12,'center')}
  // touch controls
  if(G.touch){for(const b of L.thr){const on=Math.abs(P.thr-b.v)<.05;hx.fillStyle=on?'rgba(90,160,255,.55)':'rgba(30,55,100,.4)';rr(b.x,b.y,b.w,b.h,7);hx.fill();hx.strokeStyle='rgba(160,200,255,.5)';hx.stroke();txt(b.label,b.x+b.w/2,b.y+b.h/2+5,'#e8f1ff',13,'center')}
   txt('ТЯГА',37,L.thr[2].y-6,'rgba(200,220,255,.6)',10,'center');
   const j=JOY||{ox:L.joy.x,oy:L.joy.y,x:L.joy.x,y:L.joy.y,r:L.joy.r};hx.strokeStyle='rgba(150,200,255,.4)';hx.lineWidth=2;hx.beginPath();hx.arc(j.ox,j.oy,j.r,0,7);hx.stroke();
   hx.fillStyle=JOY?'rgba(150,200,255,.45)':'rgba(150,200,255,.2)';hx.beginPath();hx.arc(j.x,j.y,j.r*.4,0,7);hx.fill();
   circBtn(L.fire,'ОГОНЬ',IN.fire,'rgba(255,90,60,.6)');circBtn(L.boost,'ФОРСАЖ',IN.boost,'rgba(90,160,255,.6)');
   if(S.mods.plasma)circBtn(L.weapon,P.weapon?'ПЛЗ':'ИМП',false,'');
   for(const [b,ic] of [[L.pause,'II'],[L.map,'⌖'],[L.target,'◎']]){hx.fillStyle='rgba(30,55,100,.6)';hx.beginPath();hx.arc(b.x,b.y,b.r,0,7);hx.fill();txt(ic,b.x,b.y+6,'#e8f1ff',16,'center')}}
  const act=currentAction();if(act){const r=L.action;const on=Object.values(PTR).includes('action')||KB.KeyE;hx.fillStyle=on?'rgba(60,200,120,.75)':'rgba(30,140,80,.6)';rr(r.x-r.w/2,r.y-r.h/2,r.w,r.h,22);hx.fill();hx.strokeStyle='#7fffb0';hx.lineWidth=1.5;hx.stroke();
   txt(act.label+(G.touch?'':' [E]'),r.x,r.y+6,'#fff',15,'center',true)}
  if(P.hull/st.hull<.25&&Math.sin(G.time*8)>0){hx.fillStyle='rgba(255,30,20,.1)';hx.fillRect(0,0,w,h)}
 }
 if(noteT>0){noteT-=dt;hx.globalAlpha=Math.min(1,noteT*2);hx.font='bold 14px system-ui';const tw=hx.measureText(noteTxt).width+24;hx.fillStyle='rgba(6,12,26,.75)';rr(w/2-tw/2,h-34,tw,26,8);hx.fill();txt(noteTxt,w/2,h-16,'#fff',14,'center');hx.globalAlpha=1}
 if(toast){toast.t-=dt;if(toast.t<=0)toast=null;else{const [who,line]=toast.lines[0];hx.globalAlpha=Math.min(1,toast.t);hx.font='13px system-ui';const tw=Math.min(w*.6,hx.measureText(line).width+30);
  hx.fillStyle='rgba(10,24,48,.85)';rr(w/2-tw/2,74,tw,44,8);hx.fill();txt(who,w/2-tw/2+12,90,'#ffd98a',11);txt(line,w/2-tw/2+12,108,'#e8f1ff',13);hx.globalAlpha=1;
  if(toast.t<.5&&toast.lines.length>1){toast.lines.shift();toast.t=5}}}}
function drawCross(x,y){hx.beginPath();hx.arc(x,y,13,0,7);for(const [a,b,c,d] of [[-26,0,-15,0],[15,0,26,0],[0,-26,0,-15],[0,15,0,26]]){hx.moveTo(x+a,y+b);hx.lineTo(x+c,y+d)}hx.stroke();hx.fillRect(x-1,y-1,2,2)}
function marker(o,col,label,size,arrow){const q=proj(o.pos);const m=46;const d=dist(o.pos,P.pos);
 if(q.w>0&&q.x>m&&q.x<SW-m&&q.y>m&&q.y<SH-m){const r=Math.max(size,Math.min(60,(o.r||10)*camF*SH*.5/q.w));hx.strokeStyle=col;hx.lineWidth=2;hx.beginPath();
  for(const [sx,sy] of [[-1,-1],[1,-1],[1,1],[-1,1]]){hx.moveTo(q.x+sx*r,q.y+sy*r*.45);hx.lineTo(q.x+sx*r,q.y+sy*r);hx.lineTo(q.x+sx*r*.45,q.y+sy*r)}hx.stroke();
  txt((label?label+' · ':'')+fmtD(d),q.x,q.y+r+14,col,11,'center',true);return}
 if(!arrow)return;const rel=sub(o.pos,P.pos);let x=dot(rel,RIGHT(P.q)),y=dot(rel,UP(P.q));if(Math.abs(x)+Math.abs(y)<1e-3)y=1;
 const a=Math.atan2(-y,x);const rx=SW/2-58,ry=SH/2-58;const k=Math.min(rx/Math.abs(Math.cos(a)||1e-6),ry/Math.abs(Math.sin(a)||1e-6));
 const px=SW/2+Math.cos(a)*k,py=SH/2+Math.sin(a)*k;hx.save();hx.translate(px,py);hx.rotate(a);hx.fillStyle=col;hx.beginPath();hx.moveTo(16,0);hx.lineTo(-7,-10);hx.lineTo(-7,10);hx.fill();hx.restore();
 txt(fmtD(d),px-Math.cos(a)*24,py-Math.sin(a)*24+4,col,11,'center',true)}
function bar(x,y,w,h,v,c,l){hx.fillStyle='rgba(8,16,32,.65)';hx.fillRect(x,y,w,h);hx.fillStyle=c;hx.fillRect(x,y,w*clamp(v,0,1),h);hx.strokeStyle='rgba(150,190,255,.35)';hx.lineWidth=1;hx.strokeRect(x,y,w,h);if(l)txt(l,x+4,y+h-2,'#fff',10)}
function txt(t,x,y,c,s,a='left',sh=false){hx.font=(sh?'bold ':'')+s+'px system-ui';hx.textAlign=a;if(sh){hx.fillStyle='rgba(0,0,0,.6)';hx.fillText(t,x+1,y+1)}hx.fillStyle=c;hx.fillText(t,x,y);hx.textAlign='left'}
function rr(x,y,w,h,r){hx.beginPath();hx.moveTo(x+r,y);hx.arcTo(x+w,y,x+w,y+h,r);hx.arcTo(x+w,y+h,x,y+h,r);hx.arcTo(x,y+h,x,y,r);hx.arcTo(x,y,x+w,y,r);hx.closePath()}
function circBtn(b,t,on,col){hx.fillStyle=on?col:'rgba(30,55,100,.42)';hx.strokeStyle='rgba(170,205,255,.6)';hx.lineWidth=2;hx.beginPath();hx.arc(b.x,b.y,b.r,0,7);hx.fill();hx.stroke();txt(t,b.x,b.y+5,'#e8f1ff',Math.max(10,Math.round(b.r*.3)),'center',true)}

// ================= screens =================
function show(id,on){$(id).classList.toggle('hide',!on)}
function hideAll(){for(const id of ['menu','station','pause','map','dead','dlg','confirm','win','m4fail'])show(id,false)}
function uiMenu(){hideAll();show('menu',true);G.mode='menu';$('contBtn').style.display=hasSave()?'':'none'}
let stTab='hangar',stMsg='';
function uiShowStation(){hideAll();show('station',true);renderStation()}
function uiHideStation(){show('station',false)}
function head(){const st=shipStats();return `<div class="sthead"><b>${STATIONS[S.station].name}</b><span>💰 ${S.cr} кр.</span><span>Трюм ${cargoUsed()}/${st.cargo}</span></div>`}
function renderStation(){const tabs=[['hangar','Ангар'],['market','Рынок'],['equip','Оборудование'],['jobs','Контракты']];
 let html=head()+'<div class="tabs">'+tabs.map(([k,n])=>`<button class="tab${stTab==k?' on':''}" data-tab="${k}">${n}${k==='jobs'&&hasOffer()?' •':''}</button>`).join('')+'</div><div class="stbody">';
 const st=shipStats();
 if(stTab==='hangar'){html+=`<div class="shipcard"><div class="big">«${st.name}»</div><div class="dim">${st.desc}</div>
   <div class="stats">Корпус ${st.hull} · Щит ${st.shield} · Трюм ${st.cargo} · Скорость ${st.speed} м/с</div>
   <div class="stats">Оружие: ${WEAPONS[0].name}${S.mods.plasma?' + '+WEAPONS[1].name:''}</div></div>
   <div class="cargo">${cargoList()}</div>
   <div class="obj">Задание: ${objectiveText()}</div>
   <button id="launchBtn" class="huge">Вылет</button>`}
 else if(stTab==='market'){html+='<div class="mk">';for(const g of GOOD_IDS){const b=bat[g]||1;html+=`<div class="good"><div class="gn">${GOODS[g]}</div>
   <div class="gp">купить <b>${price(g,'buy')}</b> · продать <b>${price(g,'sell')}</b></div><div class="gs">склад ${S.stocks[S.station][g]} · у вас ${S.cargo[g]}</div>
   <div class="row"><button data-dec="${g}">−</button><span class="bat">${b}</span><button data-inc="${g}">+</button><button data-max="${g}">Максимум</button>
   <button class="buy" data-buy="${g}">Купить ×${b}</button><button class="sell" data-sell="${g}">Продать ×${b}</button></div></div>`}
  html+='</div>';if(S.citems.length)html+=`<div class="dim">Контрактный груз (не продаётся): ${S.citems.map(c=>CITEMS[c]).join(', ')}</div>`}
 else if(stTab==='equip'){for(const [id,m] of Object.entries(MODS)){html+=`<div class="item"><div><b>${m.name}</b> — ${m.price} кр.<div class="dim">${m.desc}</div></div>${S.mods[id]?'<span class="ok">Установлено</span>':`<button data-mod="${id}">Купить</button>`}</div>`}
  for(const [id,s] of Object.entries(SHIPS)){const own=S.ships.includes(id),act=S.active===id;html+=`<div class="item"><div><b>Корабль «${s.name}»</b>${s.price?' — '+s.price+' кр.':''}<div class="dim">Корпус ${s.hull}, трюм ${s.cargo}, скорость ${s.speed} м/с. ${s.desc}</div></div>
   ${act?'<span class="ok">Активный</span>':own?`<button data-ship="${id}">Пересесть</button>`:`<button data-buyship="${id}">Купить</button>`}</div>`}
  html+='<div class="dim">Ремонт и перезарядка щита бесплатны при стыковке. Модули переходят на любой ваш корабль.</div>'}
 else if(stTab==='jobs'){for(const m of MISSIONS){const s=S.ms[m.id];if(s.st==='locked')continue;
   html+=`<div class="item"><div><b>${m.name}</b> — ${m.reward} кр.<div class="dim">${m.desc}</div></div>${s.st==='done'?'<span class="ok">Выполнено'+(s.paid?' · оплачено':'')+'</span>':s.st==='active'?'<span class="act">Выполняется</span>':
   S.station===m.from?`<button data-accept="${m.id}">Принять</button>`:`<span class="dim">на ${STATIONS[m.from].name}</span>`}</div>`}
  if(S.ms.m4.st==='done'){if(S.contract){const c=S.contract;html+=`<div class="item"><div><b>${c.name}</b> — ${c.reward} кр.<div class="dim">${c.type==='mine'?'Добыто '+c.mined+'/'+c.qty+'. ':''}Сдать на станции ${STATIONS[c.to].name}.</div></div><button data-drop="1">Отказаться</button></div>`}
   else{genOffers();(S.offers[S.station]||[]).forEach((c,i)=>{html+=`<div class="item"><div><b>${c.name}</b> — ${c.reward} кр.<div class="dim">${c.type==='mine'?'Руду нужно добыть буром.':'Товар купите сами.'}</div></div><button data-contract="${i}">Принять</button></div>`})}}}
 html+=`</div><div class="stmsg">${stMsg}</div>`;$('station').innerHTML=html;stMsg='';
 $('station').onclick=onStationClick;const lb=$('launchBtn');if(lb)lb.onclick=()=>{sfx('click');launch()}}
const bat={};
function hasOffer(){return ['m2','m3','m4'].some(k=>S.ms[k].st==='offered'&&MISSIONS.find(m=>m.id==k).from===S.station)}
function objectiveText(){if(!W)return '';const o=objective();return o.text}
function cargoList(){const items=GOOD_IDS.filter(g=>S.cargo[g]>0).map(g=>GOODS[g]+' ×'+S.cargo[g]);const ci=S.citems.map(c=>'<span class="ci">'+CITEMS[c]+' (контракт)</span>');return 'Трюм: '+([...items,...ci].join(', ')||'пусто')}
function onStationClick(e){const b=e.target.closest('button');if(!b)return;sfx('click');const d=b.dataset;
 if(d.tab){stTab=d.tab;renderStation();return}
 if(d.inc){bat[d.inc]=(bat[d.inc]||1)+1;renderStation();return}if(d.dec){bat[d.dec]=Math.max(1,(bat[d.dec]||1)-1);renderStation();return}
 if(d.max){const m=maxBuy(d.max);bat[d.max]=Math.max(1,m);stMsg=m?'Максимум для покупки: '+m:'Купить нельзя: '+(S.cr<price(d.max,'buy')?'нет денег':cargoFree()<=0?'трюм полон':'склад пуст');renderStation();return}
 if(d.buy){const r=buy(d.buy,bat[d.buy]||1);stMsg=r||'Куплено: '+GOODS[d.buy]+' ×'+(bat[d.buy]||1);if(r)sfx('deny');renderStation();return}
 if(d.sell){const r=sell(d.sell,bat[d.sell]||1);stMsg=r||'Продано: '+GOODS[d.sell]+' ×'+(bat[d.sell]||1);if(r)sfx('deny');renderStation();return}
 if(d.mod){const m=MODS[d.mod];const st=shipStats();const change=d.mod==='shield'?'Щит: '+st.shield+' → '+(st.shield+35):'Новое оружие: плазмомёт (переключение '+(G.touch?'кнопкой ИМП/ПЛЗ':'клавишей Q')+')';
  confirmBox(`Купить «${m.name}» за ${m.price} кр.?`,`Останется: ${S.cr-m.price} кр.<br>${change}`,S.cr>=m.price,()=>{const r=buyMod(d.mod);stMsg=r||'Установлено: '+m.name;renderStation()});return}
 if(d.buyship){const s=SHIPS[d.buyship],c=shipStats();confirmBox(`Купить корабль «${s.name}» за ${s.price} кр.?`,`Останется: ${S.cr-s.price} кр.<br>Корпус ${c.hull} → ${s.hull} · Трюм ${c.cargo} → ${s.cargo} · Скорость ${c.speed} → ${s.speed} м/с<br>Модули сохранятся.`,S.cr>=s.price,()=>{const r=buyShip(d.buyship);stMsg=r||'Вы пересели на «'+s.name+'»';renderStation()});return}
 if(d.ship){const r=switchShip(d.ship);stMsg=r||'Вы пересели на «'+SHIPS[d.ship].name+'»';renderStation();return}
 if(d.accept){const r=acceptMission(d.accept);stMsg=r||'Поручение принято';if(!r&&d.accept==='m3')stMsg='Анализатор в трюме. Маршрут на Иней проложен.';renderStation();return}
 if(d.contract){const r=acceptContract(+d.contract);stMsg=r||'Контракт принят';renderStation();return}
 if(d.drop){dropContract();stMsg='Контракт отменён';renderStation()}}
function confirmBox(title,body,ok,fn){$('confirm').innerHTML=`<div class="box"><h3>${title}</h3><p>${body}</p>${ok?'':'<p class="bad">Недостаточно кредитов</p>'}<div><button id="cYes" ${ok?'':'disabled'}>Подтвердить</button><button id="cNo">Отмена</button></div></div>`;
 show('confirm',true);$('cYes').onclick=()=>{show('confirm',false);sfx('click');fn()};$('cNo').onclick=()=>{show('confirm',false);sfx('click')}}
let dlgQ=[];
function uiDialog(lines,inFlight){if(inFlight&&G.mode!=='hangar'){toast={lines:[...lines],t:5};return}dlgQ=[...lines];nextDlg()}
function nextDlg(){if(!dlgQ.length){show('dlg',false);if(G.mode==='hangar')renderStation();return}const [who,line]=dlgQ.shift();$('dlg').innerHTML=`<div class="box"><div class="who">${who}</div><p>${line}</p><button id="dlgOk">${dlgQ.length?'Дальше':'Понятно'}</button></div>`;show('dlg',true);$('dlgOk').onclick=()=>{sfx('click');nextDlg()}}
function uiPause(){if(G.mode!=='fly')return;G.mode='pause';resetInput();renderPause('main');show('pause',true);sndEngine(0,false,false)}
function uiResume(){show('pause',false);show('map',false);if(G.mode==='pause'||G.mode==='map')G.mode='fly';lastT=performance.now()}
function renderPause(view){let h='<div class="box">';
 if(view==='main')h+=`<h2>Пауза</h2><button data-p="resume">Продолжить</button><button data-p="cargo">Трюм</button><button data-p="map">Карта</button><button data-p="settings">Настройки</button><button data-p="menu">Главное меню</button>`;
 if(view==='cargo'){h+=`<h2>Трюм ${cargoUsed()}/${shipStats().cargo}</h2>`;let any=false;for(const g of GOOD_IDS)if(S.cargo[g]>0){any=true;h+=`<div class="item"><span>${GOODS[g]} ×${S.cargo[g]}</span><button data-j="${g}">Выбросить 1</button></div>`}
  for(const c of S.citems){any=true;h+=`<div class="item"><span>${CITEMS[c]}</span><span class="dim">контракт</span></div>`}if(!any)h+='<p class="dim">Трюм пуст</p>';h+=`<button data-p="main">Назад</button>`}
 if(view==='settings')h+=settingsHTML()+`<button data-p="main">Назад</button>`;
 h+='</div>';$('pause').innerHTML=h;bindSettings();
 $('pause').onclick=e=>{const b=e.target.closest('button');if(!b)return;sfx('click');const d=b.dataset;
  if(d.p==='resume')uiResume();else if(d.p==='cargo')renderPause('cargo');else if(d.p==='settings')renderPause('settings');else if(d.p==='main')renderPause('main');
  else if(d.p==='map'){show('pause',false);G.mode='fly';uiMap()}else if(d.p==='menu'){confirmBox('Выйти в меню?','Прогресс после последней стыковки будет потерян.',true,()=>{show('pause',false);if(G.duel)G.duel=false;uiMenu()})}
  else if(d.j){jettison(d.j);renderPause('cargo')}}}
function settingsHTML(){return `<h2>Настройки</h2><label>Громкость <input id="vol" type="range" min="0" max="1" step="0.05" value="${SET.vol}"></label>
 <button id="qBtn">Качество: ${SET.quality==='low'?'низкое (телефон)':'высокое'}</button><button id="iBtn">Инверсия по вертикали: ${SET.invert?'вкл':'выкл'}</button>`}
function bindSettings(){const v=$('vol');if(v)v.oninput=()=>{SET.vol=+v.value;sndVolume(SET.vol);storeSettings()};
 const q=$('qBtn');if(q)q.onclick=e=>{e.stopPropagation();SET.quality=SET.quality==='low'?'high':'low';applyQuality();storeSettings();q.textContent='Качество: '+(SET.quality==='low'?'низкое (телефон)':'высокое')};
 const i=$('iBtn');if(i)i.onclick=e=>{e.stopPropagation();SET.invert=!SET.invert;storeSettings();i.textContent='Инверсия по вертикали: '+(SET.invert?'вкл':'выкл')}}
function applyQuality(){G.low=SET.quality==='low';G.maxParts=G.low?700:2500;resizeGL()}
// ----- map -----
function uiMap(){if(G.mode!=='fly'&&G.mode!=='pause')return;G.mode='map';resetInput();renderMap();show('map',true)}
function uiCloseMap(){show('map',false);G.mode='fly';lastT=performance.now()}
function renderMap(){const other=W.gate.to;const pts=[W.station,W.gate,...W.pois];
 let h=`<div class="box wide"><h2>Карта сектора</h2><div class="mapgrid"><div><svg viewBox="0 0 220 120" class="sysmap">
  <line x1="55" y1="60" x2="165" y2="60" stroke="${S.route===other?'#7fe3ff':'#456'}" stroke-width="3" stroke-dasharray="6 4"/>
  ${['yantar','inei'].map((id,i)=>`<g data-sys="${id}"><circle cx="${55+i*110}" cy="60" r="${id===W.id?24:20}" fill="${id==='yantar'?'#c9852f':'#5f9fd6'}" stroke="${id===W.id?'#fff':'none'}" stroke-width="2"/>
   <text x="${55+i*110}" y="102" fill="#e8f1ff" font-size="11" text-anchor="middle">${SYSTEMS[id].name}${id===W.id?' (вы здесь)':''}</text></g>`).join('')}</svg>
  <button data-route="${other}" class="${S.route===other?'on':''}">Проложить маршрут в «${SYSTEMS[other].name}»</button></div>
  <div class="mplist"><div class="dim">Система «${W.sys.name}» — выберите цель:</div>${pts.map((p,i)=>`<button data-pt="${i}">${p.name} · ${fmtD(dist(p.pos,P.pos))}</button>`).join('')}</div></div>
  <button data-close="1">Закрыть</button></div>`;$('map').innerHTML=h;
 $('map').onclick=e=>{const b=e.target.closest('button,g');if(!b)return;sfx('click');const d=b.dataset;
  if(d.route||d.sys&&d.sys!==W.id){S.route=other;P.nav=W.gate;uiNote('Маршрут: ворота → '+SYSTEMS[other].name);renderMap();return}
  if(d.pt){P.nav=pts[+d.pt];P.target=pts[+d.pt];uiCloseMap();uiNote('Цель: '+P.nav.name);return}if(d.close)uiCloseMap()}}
function uiDeath(cause){hideAll();$('dead').innerHTML=`<div class="box"><h2 class="bad">Корабль потерян</h2><p>${cause}</p><button id="rtd">${G.duel?'Повторить дуэль':'Вернуться к последней стыковке'}</button>${G.duel?'<button id="dmenu">В меню</button>':''}</div>`;show('dead',true);
 $('rtd').onclick=()=>{sfx('click');hideAll();returnToDock()};if($('dmenu'))$('dmenu').onclick=()=>{hideAll();exitDuel()}}
function uiM4Failed(){$('m4fail').innerHTML=`<div class="box"><h2 class="bad">Рудовоз уничтожен</h2><p>Задание можно повторить: вернитесь к обломкам конвоя.</p><button id="m4r">Повторить сопровождение</button></div>`;show('m4fail',true);
 G.mode='pause';resetInput();$('m4r').onclick=()=>{show('m4fail',false);retryM4();G.mode='fly';lastT=performance.now()}}
function uiDuelWin(){$('win').innerHTML=`<div class="box"><h2>Победа!</h2><p>Оба пирата уничтожены.</p><button id="dAgain">Ещё раз</button><button id="dMenu">В меню</button></div>`;show('win',true);G.mode='pause';resetInput();
 $('dAgain').onclick=()=>{show('win',false);startDuel()};$('dMenu').onclick=()=>{show('win',false);exitDuel()}}
function menuInit(){$('contBtn').onclick=()=>{sfx('click');hideAll();continueGame()};
 $('newBtn').onclick=()=>{sfx('click');if(hasSave())confirmBox('Начать новую игру?','Текущее сохранение будет удалено.',true,()=>{hideAll();newGame()});else{hideAll();newGame()}};
 $('duelBtn').onclick=()=>{sfx('click');hideAll();startDuel()};
 $('setBtn').onclick=()=>{sfx('click');$('menuSet').innerHTML=settingsHTML();bindSettings();$('menuSet').classList.toggle('hide')}}
