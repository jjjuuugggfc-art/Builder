'use strict';
// All models are original designs. Units: metres. Ships face +z.
const M={};
const GUNS={strizh:[[3.15,-.32,2.2],[-3.15,-.32,2.2]],tyagach:[[2.4,1.3,6.2],[-2.4,1.3,6.2]]};
const NOZZLES={strizh:[[1.05,-.15,-6.9],[-1.05,-.15,-6.9]],tyagach:[[2.2,0,-7.6],[-2.2,0,-7.6]],
 interceptor:[[.8,0,-4.6],[-.8,0,-4.6]],heavy:[[2.4,.2,-8.2],[-2.4,.2,-8.2]],transport:[[3,0,-33],[-3,0,-33]],tug:[[0,0,-6.4]]};
function engineNacelle(t,x,y,z0,z1,r,metal,xf=I){
 const n=10;const ring=(rr)=>circ(rr,n,x,y,Math.PI/n);
 loft(t,[{z:z1,p:ring(r*.8)},{z:z1-.4,p:ring(r)},{z:z0+.3,p:ring(r)},{z:z0,p:ring(r*1.12)}],(s,i)=>tone(metal,s==1?(i%2?.85:.95):.7),xf);
 // nozzle interior: dark wall going in, glowing disc recessed
 loft(t,[{z:z0,p:ring(r*1.0)},{z:z0+.55,p:ring(r*.78)}],()=>C(.08,.08,.1),xf);
 const g=C(1,.62,.28,1);loft(t,[{z:z0+.55,p:ring(r*.78)},{z:z0+.56,p:ring(r*.2)}],()=>g,xf);
 for(let i=0;i<n;i++){const j=(i+1)%n,p=ring(r*.2);T(t,[x,y,z0+.57],[p[i][0],p[i][1],z0+.56],[p[j][0],p[j][1],z0+.56],C(1,.85,.55,1),xf)}}

function buildStrizh(){const t=[];
 const L=C(.74,.77,.82),Md=C(.52,.56,.63),D=C(.28,.3,.36),acc=C(.95,.48,.12),glass=C(.06,.09,.14);
 const sec=(z,w,h,b)=>({z,p:[[0,h],[-w*.75,h*.55],[-w,-.1],[-w*.6,-b],[w*.6,-b],[w,-.1],[w*.75,h*.55]]});
 const S=[{z:7,p:Array(7).fill([0,-.05])},sec(4.4,.75,.55,.45),sec(1.5,1.25,.9,.75),sec(-2.5,1.45,1,.85),sec(-5.4,1.3,.85,.75),sec(-6,1.05,.7,.6)];
 loft(t,S,(s,i)=>{if(i==2||i==3)return tone(D,1);if(i==0||i==6)return s==1&&false?acc:tone(L,s%2?.96:1.04);if(s==0&&(i==1||i==5))return acc;return tone(Md,s%2?.95:1.05)},I,tone(D,.8));
 // canopy (dark, raised)
 loft(t,[{z:3.6,p:[[0,.56],[-.05,.5],[.05,.5]]},{z:2.1,p:[[0,1.35],[-.62,.82],[.62,.82]]},{z:-.6,p:[[0,1.42],[-.7,.92],[.7,.92]]},{z:-1.8,p:[[0,1.02],[-.5,.9],[.5,.9]]}],(s,i)=>i==0?glass:tone(glass,1.5),I,D);
 box(t,[0,1.48,-.2],[.12,.06,2.2],tone(D,1.2));
 // wings: swept, thick root, thin tip, dihedral down
 for(const sd of [1,-1]){const X=v=>[v[0]*sd,v[1],v[2]];
  const rt=.62,tt=.2,ry=-.2,ty=-.55;
  const RL=[1.2,ry,1.2],TL=[5.5,ty,-3.5],TT=[5.85,ty,-4.9],RT=[1.2,ry,-4.8];
  const up=(p,th)=>[p[0],p[1]+th/2,p[2]],dn=(p,th)=>[p[0],p[1]-th/2,p[2]];
  const a=[up(RL,rt),up(TL,tt),up(TT,tt),up(RT,rt)],b=[dn(RL,rt),dn(TL,tt),dn(TT,tt),dn(RT,rt)];
  const mid=(p,q)=>scl(add(p,q),.5);
  // top split in two panels of different tone
  Q(t,a[0],mid(a[0],a[1]),mid(a[3],a[2]),a[3],tone(L,1.02),X);Q(t,mid(a[0],a[1]),a[1],a[2],mid(a[3],a[2]),tone(Md,1.08),X);
  Q(t,b[0],b[3],b[2],b[1],D,X);
  Q(t,a[0],b[0],b[1],a[1],acc,X); // leading edge accent
  Q(t,a[1],b[1],b[2],a[2],acc,X);Q(t,a[2],b[2],b[3],a[3],tone(D,.8),X);
  // wing gun: housing + barrel
  box(t,[3.15,-.32,-.9],[.55,.48,2.4],tone(Md,.9),X);box(t,[3.15,-.32,1.1],[.2,.2,2.2],C(.2,.2,.24),X);box(t,[3.15,-.32,2.15],[.28,.28,.2],C(.12,.12,.14),X);
  // small vertical fin
  const f0=[.95,.75,-3.8],f1=[1.25,2.0,-5.6],f2=[1.0,.7,-5.8];T(t,f0,f1,f2,tone(Md,1.1),X);T(t,f0,f2,f1,tone(Md,1.1),X);
  engineNacelle(t,1.05*sd,-.15,-6.9,-3.4,.62,Md);
 }
 // intakes
 box(t,[0,-.82,-.5],[1.2,.25,2.6],C(.1,.1,.12));
 return t}
function buildTyagach(){const t=[];
 const Y=C(.86,.68,.2),G=C(.5,.53,.56),D=C(.25,.27,.3),glass=C(.06,.09,.14);
 box(t,[0,0,-.5],[5.4,3.4,12],G);box(t,[0,.2,6.2],[4,2.6,2.6],tone(G,1.1));box(t,[0,1.2,6.4],[3,1.0,2.4],glass);
 for(const sd of [1,-1]){box(t,[4.3*sd,-.2,-1],[3,3,10],tone(D,1.25));for(let k=0;k<4;k++)box(t,[4.3*sd,-.2,3.2-k*2.6],[3.1,3.1,.4],Y);
  box(t,[2.4*sd,1.3,4.8],[.5,.5,2.6],C(.18,.18,.2));engineNacelle(t,2.2*sd,0,-7.6,-6,1.05,G)}
 box(t,[0,1.9,-2],[1.6,.5,7],tone(D,1.3));box(t,[0,-1.8,-1],[4,.3,9],D);
 return t}
function buildInterceptor(){const t=[];
 const R=C(.62,.14,.12),D=C(.18,.18,.2),M2=C(.35,.33,.34),Yl=C(.95,.75,.15),gl2=C(.9,.2,.1,1);
 const sec=(z,w,h)=>({z,p:[[0,h],[-w,0],[0,-h*.8],[w,0]]});
 loft(t,[{z:5,p:Array(4).fill([0,0])},sec(2.5,.7,.55),sec(-1.5,1,.8),sec(-4.2,.8,.6)],(s,i)=>i==0||i==3?tone(R,s%2?1:.85):tone(D,1.2),I,D);
 box(t,[0,.55,.6],[.7,.35,1.4],C(.9,.35,.1,.6));
 for(const sd of [1,-1]){const X=v=>[v[0]*sd,v[1],v[2]];
  const a=[.8,.1,-2.6],b=[4.6,.3,.9],c=[4.6,.3,-.4],d=[.8,.1,-3.8];Q(t,a,b,c,d,M2,X);Q(t,a,d,c,b,D,X);
  T(t,b,[4.9,.3,2.2],c,Yl,X);T(t,b,c,[4.9,.3,2.2],Yl,X);
  box(t,[4.4,.3,1.4],[.18,.18,2],C(.15,.15,.15),X);engineNacelle(t,.8*sd,0,-4.6,-2.4,.45,M2)}
 return t}
function buildHeavy(){const t=[];
 const O=C(.36,.34,.26),D=C(.2,.19,.17),R=C(.6,.16,.12);
 loft(t,[{z:8,p:[[0,.4],[-1.4,0],[0,-.7],[1.4,0]]},{z:4,p:[[0,1.8],[-2.6,.3],[0,-1.5],[2.6,.3]]},{z:-3,p:[[0,2.4],[-3.6,.4],[0,-2],[3.6,.4]]},{z:-7.6,p:[[0,2],[-3,.4],[0,-1.6],[3,.4]]}],(s,i)=>i<2?tone(O,s%2?1:.88):tone(D,1.1),I,D);
 box(t,[0,2.6,-1.5],[2.2,1,3],tone(O,.8));box(t,[0,2.9,.4],[.4,.4,3],C(.15,.15,.15));
 box(t,[0,.1,8.3],[1.2,.9,.8],C(.3,.8,1,.25)); // nose capacitor
 for(const sd of [1,-1]){box(t,[4.6*sd,0,-2.5],[3.2,1.1,7],tone(D,1.2));box(t,[6.2*sd,0,-1],[.6,1.6,5],R);engineNacelle(t,2.4*sd,.2,-8.2,-6.5,1.0,O)}
 return t}
function buildTransport(){const t=[];
 const W=C(.7,.62,.45),D=C(.3,.28,.26),Bl=C(.25,.35,.5);
 box(t,[0,0,-6],[2.2,2.2,52],D);box(t,[0,.8,22],[7,5,7],W);box(t,[0,2,25.4],[5,1.4,.6],C(.08,.1,.14));
 for(let k=0;k<6;k++){const z=14-k*7.5;for(const sd of [1,-1])box(t,[3.2*sd,0,z],[4,4.2,6.4],k%2?tone(W,.85):Bl)}
 box(t,[0,0,-30],[8,4,4],tone(D,1.3));for(const sd of [1,-1])engineNacelle(t,3*sd,0,-33,-31,1.5,D);
 return t}
function buildTug(){const t=[];const Y=C(.9,.7,.18),G=C(.45,.47,.5);
 box(t,[0,0,0],[4,3,8],G);box(t,[0,1,3.4],[3,1.4,1.6],C(.06,.09,.14));
 for(const sd of [1,-1]){box(t,[2.6*sd,0,4.5],[.6,.6,5],Y);box(t,[2.6*sd,0,7],[1.4,.6,.6],Y)}engineNacelle(t,0,0,-6.4,-4,1.1,G);return t}
function buildContainer(){const t=[];const O=C(.85,.45,.12),D=C(.22,.22,.24);
 box(t,[0,0,0],[3.6,3.6,3.6],D);for(const y of [-1.2,1.2])box(t,[0,y,0],[3.7,.5,3.7],O);box(t,[0,0,0],[.6,3.8,3.8],tone(O,.8));return t}
function buildBuoy(){const t=[];const G=C(.55,.57,.6),R=C(.85,.25,.1);
 cyl(t,-5,5,1.2,.9,8,(s,i)=>tone(G,i%2?.9:1.05),qx(),R,R);for(let k=0;k<3;k++){const a=k/3*Math.PI*2;box(t,[Math.cos(a)*1.8,-4,Math.sin(a)*1.8],[.3,3,1.6],R,I,qaxis([0,1,0],-a))}
 box(t,[0,6,0],[.3,2,.3],G);return t}
function qx(){return v=>[v[0],v[2],v[1]]} // z-axis -> y-axis
function buildDebris(seed){const R=srand(seed);const t=rockTris(1,.35,1,(n,r)=>{const k=.3+r()*.12;return C(k,k*.95,k*.9)},I,seed);
 for(let i=0;i<4;i++){const d=[R()*2-1,R()*2-1,R()*2-1];box(t,scl(norm(d),.8),[.9,.15,1.4],C(.45,.4,.36),I,qrand(R))}return t}
function buildWreck(){const t=[];const R=srand(77);const B=C(.22,.2,.19),Rs=C(.4,.26,.16),W=C(.48,.42,.34);
 const parts=[[[0,0,0],[2.4,2.4,40],B],[[0,1,24],[7,5,7],W],[[3.4,.5,8],[4,4.2,6.4],Rs],[[-3.2,-1,-2],[4,4.2,6.4],B],[[4,2,-14],[4,4,6],Rs]];
 for(const [c,s,col] of parts)box(t,c,s,col,I,qrand(R));
 for(let i=0;i<16;i++)box(t,[R()*60-30,R()*24-12,R()*80-40],[R()*4+1,R()*2+.5,R()*6+1],R()<.5?B:Rs,I,qrand(R));
 // broken spine continuation, scorched
 box(t,[2,-1,-30],[2.2,2.2,16],tone(B,.7),I,qaxis([1,.2,0],.5));return t}
function buildGate(){const t=[];const G=C(.42,.45,.52),D=C(.2,.22,.26),L=C(.45,.85,1,1);
 const n=28,R=95;for(let i=0;i<n;i++){const a=i/n*Math.PI*2,b=(i+1)/n*Math.PI*2;
  const p=(ang,r,z)=>[Math.cos(ang)*r,Math.sin(ang)*r,z];
  for(const [r0,r1,z0,z1,col] of [[R-8,R+8,-6,-6,G],[R-8,R+8,6,6,G],[R+8,R+8,-6,6,D],[R-8,R-8,-6,6,tone(G,.8)]])Q(t,p(a,r0,z0),p(b,r0,z0),p(b,r1,z1),p(a,r1,z1),col);
  if(i%4==0){box(t,[Math.cos(a)*(R+14),Math.sin(a)*(R+14),0],[10,10,18],D,I,qaxis([0,0,1],a));box(t,[Math.cos(a)*(R-9),Math.sin(a)*(R-9),0],[2,2,10],L,I,qaxis([0,0,1],a))}}
 return t}
// hangar module (interior open at +z). Local: interior x[-45,45], y[-22,22], z[0,100]
function hangar(t,xf){const W=C(.45,.47,.52),Fl=C(.3,.31,.34),Lt=C(1,.92,.7,1),Bl=C(.3,.6,1,1),Ac=C(.95,.55,.15);
 box(t,[0,-25,50],[100,6,100],W,xf);box(t,[0,25,50],[100,6,100],W,xf);box(t,[-48,0,50],[6,56,100],W,xf);box(t,[48,0,50],[6,56,100],W,xf);box(t,[0,0,-3],[100,56,6],tone(W,.8),xf);
 box(t,[0,-21.9,50],[86,.2,96],Fl,xf);
 for(let z=12;z<100;z+=16){box(t,[0,21.8,z],[60,.3,1.2],Lt,xf);box(t,[-44.8,8,z],[.3,1.2,8],Lt,xf);box(t,[44.8,8,z],[.3,1.2,8],Lt,xf)}
 box(t,[0,-21.7,60],[1.2,.1,60],Ac,xf);for(let z=20;z<100;z+=10)box(t,[0,-21.7,z],[8,.1,.6],Ac,xf);
 box(t,[0,-21.7,60],[24,.12,24],tone(Fl,1.25),xf);
 // open doors slid outward
 box(t,[-62,0,101],[30,52,3],tone(W,.9),xf);box(t,[62,0,101],[30,52,3],tone(W,.9),xf);
 for(const y of [-23,23])box(t,[0,y,101],[100,2,2],Bl,xf);for(const x of [-46,46])box(t,[x,0,101],[2,48,2],Bl,xf);
 // window strip of control room
 box(t,[-30,12,1],[30,6,.5],C(.9,.8,.55,1),xf)}
function windows(t,c,w,h,nx,ny,col,xf,face='z',R=Math.random){for(let i=0;i<nx;i++)for(let j=0;j<ny;j++){if(R()<.3)continue;const x=c[0]+(i-(nx-1)/2)*w/nx,y=c[1]+(j-(ny-1)/2)*h/ny;
 const s=face=='z'?[w/nx*.55,h/ny*.45,.3]:[.3,h/ny*.45,w/nx*.55];const p=face=='z'?[x,y,c[2]]:[c[0],y,c[2]+(i-(nx-1)/2)*w/nx];box(t,p,s,tone(col,.75+R()*.25),xf,null,false)}}
function buildKromkaHub(){const t=[];const R=srand(5);const G=C(.55,.56,.6),D=C(.3,.31,.35),Hb=C(.62,.58,.5),Win=C(1,.85,.55,1),Sol=C(.1,.15,.32),Am=C(.9,.6,.2);
 // hub cylinder along z (-200..40)
 cyl(t,-200,40,48,48,12,(s,i)=>tone(i%3?G:D,1+(i%2)*.06),I,D,D);
 cyl(t,-240,-200,22,40,12,(s,i)=>tone(D,i%2?1:.9),I,D,D);
 // hangar block in front
 box(t,[0,0,55],[110,66,30],tone(G,.9));hangar(t,v=>add(v,[0,0,70]));
 // habitation modules with windows
 for(const [x,y,z] of [[0,58,-30],[0,-58,-60],[58,0,-100],[-58,0,-20]]){const s=[Math.abs(x)>0?30:46,Math.abs(y)>0?30:46,60];box(t,[x,y,z],s,Hb);
  windows(t,[x+(x>0?15.2:x<0?-15.2:0),y,z],60,x?24:0,8,3,Win,I,'x',R);
  if(!x)for(const fz of [z-30.2,z+30.2])windows(t,[x,y,fz],40,24,6,3,Win,I,'z',R)}
 // trusses with solar panels
 for(const sd of [1,-1]){beam(t,[sd*48,0,-170],[sd*200,0,-170],4,D);beam(t,[sd*48,10,-170],[sd*200,10,-170],2,D);for(let k=0;k<3;k++)box(t,[sd*(90+k*40),5,-170],[34,1,60],Sol)}
 // antenna mast
 beam(t,[0,48,-150],[0,150,-150],3,D);box(t,[0,150,-150],[24,2,24],Am);
 // amber accent bands
 for(const z of [-190,-120,30])cyl(t,z,z+4,49,49,12,()=>Am);
 return t}
function buildRing(){const t=[];const R=srand(9);const G=C(.6,.6,.63),D=C(.32,.33,.37),Win=C(1,.85,.55,1);const n=28,Rr=170;
 for(let i=0;i<n;i++){const a=i/n*Math.PI*2;const q=qaxis([0,0,1],a+Math.PI/2);const c=[Math.cos(a)*Rr,Math.sin(a)*Rr,0];
  box(t,c,[40,18,26],i%4?G:D,I,q);
  if(i%4){for(let k=-2;k<=2;k++){if(R()<.25)continue;const o=qrot(q,[k*7,-9.2,0]);box(t,add(c,o),[3.5,.3,2.4],Win,I,q,false);const o2=qrot(q,[k*7,-9.2,8]);if(R()<.6)box(t,add(c,o2),[3.5,.3,2.4],Win,I,q,false)}}}
 for(let i=0;i<4;i++){const a=i/4*Math.PI*2+.3;beam(t,[Math.cos(a)*48,Math.sin(a)*48,0],[Math.cos(a)*Rr,Math.sin(a)*Rr,0],5,D)}
 return t}
function buildVerf(){const t=[];const R=srand(11);const G=C(.5,.53,.58),D=C(.24,.26,.3),Wh=C(.75,.78,.82),Win=C(.65,.85,1,1),Rd=C(.8,.18,.12);
 // long spine truss along x
 for(const [y,z] of [[30,-30],[30,30],[-10,-30],[-10,30]])beam(t,[-620,y,z],[620,y,z],4,D);
 for(let x=-600;x<=600;x+=60){beam(t,[x,30,-30],[x,-10,-30],2.5,G);beam(t,[x,30,30],[x,-10,30],2.5,G);beam(t,[x,30,-30],[x,30,30],2.5,G);beam(t,[x,-10,-30],[x,-10,30],2.5,G);
  if(x<600){beam(t,[x,30,-30],[x+60,-10,-30],1.6,D);beam(t,[x,30,30],[x+60,-10,30],1.6,D)}}
 // central control block + hangar
 box(t,[0,10,-20],[120,80,60],G);windows(t,[0,30,10.2],100,20,14,3,Win,I,'z',R);windows(t,[0,10,-50.2],100,40,14,4,Win,I,'z',R);
 box(t,[0,0,40],[110,66,40],tone(G,.9));hangar(t,v=>add(v,[0,0,60]));
 // open dock frames with a hull under construction
 for(const x of [-360,-200,220,400]){const w=90,h=70,d=140,y0=-60;
  for(const [a,b] of [[[-w,0,-d],[w,0,-d]],[[-w,0,d],[w,0,d]],[[-w,-h,-d],[w,-h,-d]],[[-w,-h,d],[w,-h,d]],[[-w,0,-d],[-w,0,d]],[[w,0,-d],[w,0,d]],[[-w,-h,-d],[-w,-h,d]],[[w,-h,-d],[w,-h,d]],[[-w,0,-d],[-w,-h,-d]],[[w,0,-d],[w,-h,-d]],[[-w,0,d],[-w,-h,d]],[[w,0,d],[w,-h,d]]])
   beam(t,add([x,y0,0],scl(a,.5)),add([x,y0,0],scl(b,.5)),3,D);
  beam(t,[x,y0,0],[x,-10,0],3,G);
  if(x==-200||x==400){box(t,[x,y0-18,0],[22,14,90],tone(Wh,.9));for(let k=-3;k<=3;k++)box(t,[x,y0-18,k*12],[24,16,1.5],D)}}
 // radiators
 for(const x of [-520,520]){box(t,[x,60,0],[60,1.5,120],C(.7,.72,.76));beam(t,[x,30,0],[x,60,0],3,D)}
 // signal masts at ends
 for(const x of [-620,620]){beam(t,[x,-10,0],[x,80,0],3,D);box(t,[x,82,0],[6,4,6],Rd)}
 return t}
function verfLights(){const L=[];for(const x of [-620,620])L.push({p:[x,86,0],c:[1,.2,.15],ph:x>0?0:.5});
 for(const x of [-360,-200,220,400])for(const sx of [-1,1])for(const sz of [-1,1])L.push({p:[x+sx*45,-60,sz*70],c:sx>0?[.2,1,.4]:[1,.25,.2],ph:Math.random()});
 for(let x=-600;x<=600;x+=200)L.push({p:[x,32,0],c:[1,.8,.3],ph:Math.random()});return L}
function kromkaLights(){const L=[{p:[0,153,-150],c:[1,.25,.2],ph:0}];for(const sd of [1,-1])L.push({p:[sd*200,6,-170],c:sd>0?[.2,1,.4]:[1,.25,.2],ph:.3});
 for(const [x,y] of [[-55,-33],[55,-33],[-55,33],[55,33]])L.push({p:[x,y,171],c:[1,.75,.3],ph:Math.random()});return L}
function buildAsteroids(){const shapes=[];
 for(let s=0;s<4;s++)shapes.push(makeMesh(rockTris(1,.32,1,(n,r)=>{const k=.22+r()*.07;return C(k*1.08,k,k*.92)},I,100+s)));
 const ore=[];for(let s=0;s<2;s++)ore.push(makeMesh(rockTris(1,.3,1,(n,r)=>{const vein=n[1]>.5&&Math.abs(n[0]-n[2]*.4)<.38;return vein?C(.78,.44,.2,.14+r()*.08):(()=>{const k=.2+r()*.06;return C(k*1.05,k,k*.95)})()},I,200+s)));
 const ice=[];for(let s=0;s<3;s++)ice.push(makeMesh(rockTris(1,.3,1,(n,r)=>{const k=.4+r()*.12;return C(k*.85,k*.95,k*1.1)},I,300+s)));
 return {shapes,ore,ice}}
function buildPlanetAmber(){return sphereTris(4,v=>{const n=fbm(scl(v,3.2),4),b=Math.sin(v[1]*7+n*5);
 const c=b>.3?[.78,.52,.24]:b>-.4?[.66,.42,.2]:[.52,.33,.18];const s=fbm(scl(v,9),3);return C(c[0]*(.85+s*.3),c[1]*(.85+s*.3),c[2]*(.85+s*.3))})}
function buildGiant(){return sphereTris(4,v=>{const n=fbm(scl(v,2.5),3);const b=Math.sin(v[1]*11+n*3.5);
 const c=b>.4?[.62,.78,.92]:b>-.2?[.4,.6,.84]:[.3,.46,.72];return C(...c)})}
function buildGiantRing(){const t=[];const n=120;const bands=[[1.35,1.55,C(.55,.65,.75)],[1.58,1.8,C(.7,.78,.86)],[1.84,1.9,C(.4,.48,.58)],[1.93,2.15,C(.6,.68,.78)]];
 for(const [r0,r1,col] of bands)for(let i=0;i<n;i++){const a=i/n*Math.PI*2,b=(i+1)/n*Math.PI*2;
  Q(t,[Math.cos(a)*r0,0,Math.sin(a)*r0],[Math.cos(b)*r0,0,Math.sin(b)*r0],[Math.cos(b)*r1,0,Math.sin(b)*r1],[Math.cos(a)*r1,0,Math.sin(a)*r1],tone(col,.92+(i%3)*.05))}return t}
function buildModels(){
 M.strizh=makeMesh(buildStrizh());M.tyagach=makeMesh(buildTyagach());M.interceptor=makeMesh(buildInterceptor());M.heavy=makeMesh(buildHeavy());
 M.transport=makeMesh(buildTransport());M.tug=makeMesh(buildTug());M.container=makeMesh(buildContainer());M.buoy=makeMesh(buildBuoy());
 M.debris=[makeMesh(buildDebris(3)),makeMesh(buildDebris(4))];M.wreck=makeMesh(buildWreck());M.gate=makeMesh(buildGate());
 M.kromka=makeMesh(buildKromkaHub());M.ring=makeMesh(buildRing());M.verf=makeMesh(buildVerf());
 M.ast=buildAsteroids();M.amber=makeMesh(buildPlanetAmber());M.giant=makeMesh(buildGiant());M.giantRing=makeMesh(buildGiantRing());
 M.moon=makeMesh(sphereTris(3,v=>{const k=.4+fbm(scl(v,6),3)*.3;return C(k,k*.97,k*.95)}));
 M.bubble=makeMesh(sphereTris(2,()=>C(1,1,1)));
}
