'use strict';
// ================= station & planet generator =================
// Every station: hangar module at z 70..170 (entrance [0,0,190], spot [0,-14,120]), body behind (z<40).
const STYLE={
 league:{hull:C(.78,.8,.86),dark:C(.34,.38,.46),acc:C(.3,.55,.95),win:C(1,.88,.62,1),glow:C(.4,.7,1,1)},
 union:{hull:C(.55,.53,.5),dark:C(.27,.26,.25),acc:C(.95,.58,.15),win:C(1,.82,.45,1),glow:C(1,.6,.2,1)},
 teira:{hull:C(.6,.42,.32),dark:C(.3,.18,.14),acc:C(.92,.45,.2),win:C(1,.62,.3,1),glow:C(1,.45,.2,1)},
 essen:{hull:C(.7,.82,.85),dark:C(.3,.4,.45),acc:C(.45,.95,.85,.6),win:C(.6,1,.9,1),glow:C(.5,1,.9,1)},
 border:{hull:C(.5,.52,.5),dark:C(.25,.27,.25),acc:C(.8,.3,.2),win:C(1,.85,.6,1),glow:C(1,.4,.3,1)},
 wake:{hull:C(.45,.37,.31),dark:C(.21,.18,.16),acc:C(.85,.25,.2),win:C(1,.7,.4,1),glow:C(1,.35,.25,1)},
 ancient:{hull:C(.17,.15,.21),dark:C(.08,.07,.1),acc:C(.9,.75,.35,.8),win:C(.9,.75,.4,1),glow:C(1,.8,.4,1)}};
function stationStyle(st){const sys=REG.systems[st.sys];if(st.bespoke==='iznanka'||st.bespoke==='garden')return st.bespoke==='iznanka'?'ancient':'essen';
 if(sys.region==='hidden')return sys.owner==='essen'?'essen':'wake';return REG.regions[sys.region].style}
function hangarBlock(t,S){box(t,[0,0,55],[110,66,30],tone(S.hull,.9));hangar(t,v=>add(v,[0,0,70]))}
function hangarColliders(A){A(-56,-44,-33,33,40,172);A(44,56,-33,33,40,172);A(-56,56,22,33,40,172);A(-56,56,-33,-22,40,172)}
function ringTris(R,n,seg,col,dark,win,rnd,gap=0){const t=[];for(let i=0;i<n;i++){const a=i/n*Math.PI*2;if(gap&&a>Math.PI*2-gap)continue;const q=qaxis([0,0,1],a+Math.PI/2);const c=[Math.cos(a)*R,Math.sin(a)*R,0];
 box(t,c,[seg[0],seg[1],seg[2]],i%4?col:dark,I,q);if(i%3!==1&&win)for(let k=-1;k<=1;k++){if(rnd()<.3)continue;box(t,add(c,qrot(q,[k*seg[0]*.28,-seg[1]/2-.2,0])),[seg[0]*.16,.3,seg[2]*.2],win,I,q,false)}}return t}
// open arc (Essen): thin segments along a partial circle
function arc(t,c,R,a0,a1,w,col,xf=I,plane='xy'){const n=Math.max(6,Math.round((a1-a0)*R/40));for(let i=0;i<n;i++){const u=a0+(a1-a0)*i/n,v=a0+(a1-a0)*(i+1)/n;
 const P=a=>plane==='xy'?add(c,[Math.cos(a)*R,Math.sin(a)*R,0]):plane==='xz'?add(c,[Math.cos(a)*R,0,Math.sin(a)*R]):add(c,[0,Math.cos(a)*R,Math.sin(a)*R]);beam(t,P(u),P(v),w,col,xf)}}
function buildStation(st){const t=[],L=[],COL=[],rot=[];const R=srand(hashStr(st.id));const styleK=stationStyle(st);const S=STYLE[styleK];
 const A=(x0,x1,y0,y1,z0,z1)=>COL.push({t:'box',min:[x0,y0,z0],max:[x1,y1,z1]});
 const light=(p,c,ph)=>L.push({p,c,ph:ph==null?R():ph});
 hangarBlock(t,S);hangarColliders(A);for(const [x,y] of [[-55,-33],[55,-33],[-55,33],[55,33]])light([x,y,171],[S.win[0],S.win[1],S.win[2]]);
 const fam=st.bespoke?BESPOKE_FAMILY[st.bespoke]:st.family;
 // ---- family body ----
 if(fam==='dock'){box(t,[0,0,-200],[34,34,480],S.dark);A(-17,17,-17,17,-440,40);
  for(const sx of [-1,1]){const x=sx*95;for(const z of [-60,-200,-340]){beam(t,[x-40,-40,z],[x+40,-40,z],4,S.hull);beam(t,[x-40,40,z],[x+40,40,z],4,S.hull);beam(t,[x-40,-40,z],[x-40,40,z],4,S.hull);beam(t,[x+40,-40,z],[x+40,40,z],4,S.hull)}
   for(const [y,xx] of [[-40,-40],[40,-40],[-40,40],[40,40]])beam(t,[x+xx,y,-60],[x+xx,y,-340],3,S.dark);beam(t,[sx*17,0,-120],[x-sx*40,0,-120],5,S.dark);beam(t,[sx*17,0,-280],[x-sx*40,0,-280],5,S.dark);
   light([x+40,40,-60],[1,.3,.2]);light([x-40,40,-340],[.3,1,.4]);
   if(R()<.7){box(t,[x,0,-200],[30,22,200],tone(S.hull,.8));A(x-15,x+15,-11,11,-300,-100)}}
  box(t,[0,40,-420],[20,50,20],S.dark);light([0,68,-420],[1,.25,.2],0)}
 else if(fam==='habitat'){cyl(t,40,-220,42,42,12,(s,i)=>tone(i%3?S.hull:S.dark,1+(i%2)*.06),I,S.dark,S.dark);A(-42,42,-42,42,-225,40);
  windows(t,[0,30,-80],100,0,0,0,S.win,I,'z',R);for(let k=0;k<6;k++){const a=k/6*Math.PI*2;box(t,[Math.cos(a)*43,Math.sin(a)*43,-150],[6,6,90],S.win,I,qaxis([0,0,1],a),false)}
  rot.push({tris:ringTris(160,30,[38,16,24],S.hull,S.dark,S.win,R),z:-90,speed:.05});COL.push({t:'ring',c:[0,0,-90],R:160,r:16});
  for(let i=0;i<4;i++){const a=i/4*Math.PI*2+.4;beam(t,[Math.cos(a)*42,Math.sin(a)*42,-90],[Math.cos(a)*150,Math.sin(a)*150,-90],5,S.dark)}
  if(R()<.6){rot.push({tris:ringTris(110,24,[28,12,18],tone(S.hull,.9),S.dark,S.win,R),z:-180,speed:-.07});COL.push({t:'ring',c:[0,0,-180],R:110,r:12});for(let i=0;i<3;i++){const a=i/3*Math.PI*2;beam(t,[Math.cos(a)*42,Math.sin(a)*42,-180],[Math.cos(a)*100,Math.sin(a)*100,-180],4,S.dark)}}}
 else if(fam==='mining'){box(t,[0,0,-40],[90,70,140],S.hull);A(-45,45,-35,35,-110,30);
  for(const sx of [-1,1]){beam(t,[sx*45,10,-40],[sx*230,-20,-60],8,S.dark);box(t,[sx*240,-20,-60],[40,40,40],tone(S.acc,.8));A(Math.min(sx*220,sx*260),Math.max(sx*220,sx*260),-40,0,-80,-40);
   for(let k=0;k<3;k++)box(t,[sx*(80+k*45),14,-40-k*6],[24,30,30],tone(S.dark,1.3))}
  const rock=rockTris(1,.3,1,(n,r)=>{const k=.25+r()*.06;return n[1]>.4?C(.8,.45,.2,.15):C(k,k*.95,k*.9)},v=>add(scl(v,70),[0,-30,-210]),hashStr(st.id));t.push(...rock);COL.push({t:'sphere',c:[0,-30,-210],r:62});
  box(t,[0,60,-40],[12,50,12],S.dark);light([0,88,-40],[1,.6,.2],0);windows(t,[0,0,-110.4],60,40,6,3,S.win,I,'z',R)}
 else if(fam==='observatory'){box(t,[0,0,-30],[70,60,110],S.hull);A(-35,35,-30,30,-85,30);beam(t,[0,30,-40],[0,300,-40],8,S.dark);A(-6,6,30,300,-46,-34);
  const dish=v=>add([v[0],v[2],v[1]],[0,300,-40]);cyl(t,0,30,8,70,16,(s,i)=>tone(S.hull,i%2?1:.9),dish,null,tone(S.dark,1.2));COL.push({t:'sphere',c:[0,315,-40],r:60});
  for(const sx of [-1,1]){const c=[sx*60,10,-70];t.push(...sphereTris(1,()=>tone(S.hull,1.1)).map(q=>[add(scl(q[0],26),c),add(scl(q[1],26),c),add(scl(q[2],26),c),q[3]]));COL.push({t:'sphere',c,r:26});windows(t,[sx*60,10,-43.5],30,10,4,1,S.glow,I,'z',R)}
  light([0,335,-40],[1,.3,.2],0)}
 else if(fam==='military'){loft(t,[{z:40,p:[[0,40],[-70,0],[0,-30],[70,0]]},{z:-80,p:[[0,55],[-95,5],[0,-40],[95,5]]},{z:-260,p:[[0,35],[-60,5],[0,-25],[60,5]]}],(s,i)=>tone(i<2?S.hull:S.dark,s?1:.9),I,S.dark);
  A(-80,80,-35,50,-260,40);for(const sx of [-1,1]){box(t,[sx*60,40,-60],[16,12,30],S.dark);beam(t,[sx*60,46,-60],[sx*60,46,-20],3,C(.15,.15,.15));for(let k=0;k<4;k++)box(t,[sx*96,5,-30-k*40],[2,10,24],S.win,I,null,false)}
  beam(t,[0,50,-200],[0,190,-200],3,S.dark);light([0,190,-200],[1,.2,.2],0);box(t,[0,0,-270],[50,30,20],tone(S.acc,.9))}
 else if(fam==='ring'){cyl(t,40,-120,30,30,10,(s,i)=>tone(S.hull,i%2?1:.9),I,S.dark,S.dark);A(-30,30,-30,30,-125,40);
  const gap=.9;t.push(...ringTris(260,40,[46,22,30],tone(S.hull,.85),S.dark,null,R,gap));COL.push({t:'ring',c:[0,0,-60],R:260,r:22,shift:true});
  for(let i=0;i<40;i++){const a=i/40*Math.PI*2;if(a>Math.PI*2-gap||R()<.35)continue;const c=[Math.cos(a)*260,Math.sin(a)*260,-60];const q=qaxis([0,0,1],a+Math.PI/2);
   box(t,add(c,qrot(q,[0,14,0])),[10+R()*10,8,10],R()<.5?C(.9,.5,.2,.4):R()<.5?C(.3,.7,1,.4):C(.95,.85,.3,.4),I,q,false)}
  for(let i=0;i<3;i++){const a=i/3*Math.PI*2+.3;beam(t,[Math.cos(a)*30,Math.sin(a)*30,-60],[Math.cos(a)*240,Math.sin(a)*240,-60],6,S.dark)}}
 // ring colliders use z offset
 for(const c of COL)if(c.shift){c.c=[0,0,-60];delete c.shift}
 // ---- style add-ons ----
 if(styleK==='teira'){for(const sx of [-1,1]){loft(t,[{z:40,p:[[sx*58,30],[sx*72,30],[sx*72,-30],[sx*58,-30]]},{z:260,p:[[sx*62,8],[sx*66,8],[sx*66,-8],[sx*62,-8]]}],(s,i)=>i%2?S.acc:S.hull);
   const k=v=>[v[0]+sx*40,v[1],v[2]];T(t,[0,-33,40],[0,-110,-40],[0,-33,-120],tone(S.dark,1.2),k);T(t,[0,-33,40],[0,-33,-120],[0,-110,-40],tone(S.dark,1.2),k);
   for(let z=60;z<250;z+=40)box(t,[sx*67,0,z],[7,18,5],S.acc,I,null,false)}A(-74,-56,-30,30,40,260);A(56,74,-30,30,40,260)}
 if(styleK==='essen'||styleK==='ancient'){const n=styleK==='ancient'?3:2;for(let i=0;i<n;i++)arc(t,[0,0,-60-i*70],180+i*55,.3+i,.3+i+4.6,5,i%2?S.acc:S.glow);}
 if(styleK==='union'){for(let z=30;z>-200;z-=40){beam(t,[-60,48,z],[60,48,z],2.5,S.dark);beam(t,[-60,48,z],[-60,48,z-40],2.5,S.dark);beam(t,[60,48,z],[60,48,z-40],2.5,S.dark)}
  for(let i=0;i<4;i++)box(t,[0,46,-20-i*45],[50,1.5,4],S.acc,I,null,false)}
 if(styleK==='league'){cyl(t,40,46,58,58,16,()=>tone(S.hull,1.1));for(let i=0;i<3;i++)box(t,[0,34,20-i*30],[40,.6,14],S.acc,I,null,false)}
 if(styleK==='wake'||styleK==='border'){for(let i=0;i<9;i++){const p=[R()*120-60,R()*80-40,-R()*160];box(t,p,[R()*30+10,R()*4+2,R()*30+10],R()<.5?tone(S.hull,.7+R()*.5):S.acc,I,qrand(R))}
  beam(t,[30,33,20],[60,110,-30],2,S.dark);light([60,110,-30],[1,.3,.2])}
 // ---- bespoke signature ----
 const bes=st.bespoke;
 if(bes==='lira'){for(const sx of [-1,1]){box(t,[sx*50,140,-60],[34,240,40],S.hull);windows(t,[sx*50,140,-39.6],30,220,3,16,S.win,I,'z',R);A(sx*50-17,sx*50+17,20,260,-80,-40);light([sx*50,264,-60],[.4,.7,1],0)}
  rot.push({tris:ringTris(240,40,[44,14,22],S.hull,S.dark,S.win,R),z:-160,speed:.035});COL.push({t:'ring',c:[0,0,-160],R:240,r:14});}
 if(bes==='perekr'){for(let i=0;i<5;i++){const a=i/5*Math.PI*2+Math.PI/2;const d=[Math.cos(a),Math.sin(a),0];beam(t,scl(d,40),scl(d,330),10,S.dark);
  const c=add(scl(d,360),[0,0,-40]);for(let k=0;k<12;k++){const u=k/12*Math.PI*2,v=(k+1)/12*Math.PI*2;const P=w=>add(c,qrot(qLook(d),[Math.cos(w)*30,Math.sin(w)*30,0]));beam(t,P(u),P(v),4,S.acc)}light(c,[.4,.8,1])}}
 if(bes==='gorn'){box(t,[0,0,-120],[120,120,140],S.dark);A(-60,60,-60,60,-190,-50);box(t,[0,0,-48],[70,70,4],C(1,.45,.1,1),I,null,false);for(const sx of [-1,1])for(const sy of [-1,1]){cyl(t,-60,-60,10,10,8,()=>S.dark);beam(t,[sx*40,sy*40,-190],[sx*40,sy*40+sy*90,-190],14,tone(S.dark,1.3));light([sx*40,sy*130,-190],[1,.5,.2])}}
 if(bes==='teira_hall'){for(const sx of [-1,1]){loft(t,[{z:-40,p:[[sx*90,50],[sx*140,50],[sx*140,-50],[sx*90,-50]]},{z:420,p:[[sx*105,14],[sx*112,14],[sx*112,-14],[sx*105,-14]]}],(s,i)=>i%2?S.acc:tone(S.hull,1.1));A(Math.min(sx*90,sx*140),Math.max(sx*90,sx*140),-50,50,-40,420);
   for(let z=0;z<400;z+=50)box(t,[sx*118,0,z],[6,40,8],C(1,.6,.25,.6),I,null,false)}box(t,[0,0,-150],[200,90,160],S.hull);A(-100,100,-45,45,-230,-70)}
 if(bes==='essen_choir'){beam(t,[0,0,-40],[0,420,-40],18,S.hull);A(-10,10,0,420,-50,-30);for(let i=0;i<4;i++){const y=120+i*90,r=150-i*28;arc(t,[0,y,-40],r,i,i+4.9,4,i%2?S.glow:S.acc,I,'xz')}light([0,430,-40],[.5,1,.9],0)}
 if(bes==='razlom_fort'){for(const sx of [-1,1]){box(t,[sx*140,0,-60],[40,140,260],S.dark);A(sx*140-20,sx*140+20,-70,70,-190,70);beam(t,[sx*140,74,0],[sx*140,74,120],10,C(.15,.15,.15));box(t,[sx*140,74,-20],[26,16,30],S.hull)}box(t,[0,-80,-60],[300,20,260],tone(S.dark,1.2));A(-150,150,-90,-70,-190,70)}
 if(bes==='kilvater'){for(let i=0;i<8;i++){const a=i/8*Math.PI*2;const c=[Math.cos(a)*300,Math.sin(a)*300,-60];box(t,c,[30,14,60],R()<.5?C(.5,.35,.3):C(.35,.4,.45),I,qaxis([0,0,1],a));light(add(c,[0,0,32]),[R(),.6,.3])}}
 if(bes==='harbor_cyl'){for(const sx of [-1,1]){const xf=v=>add([v[0],v[1],v[2]],[sx*95,0,-150]);cyl(t,170,-420,80,80,10,(s,i)=>tone(i%3?S.hull:S.dark,.8+(i%2)*.2),xf,S.dark,S.dark);A(sx*95-80,sx*95+80,-80,80,-420,170)}
  for(let z=-380;z<150;z+=50){box(t,[0,-60,z],[40,4,8],C(1,.6,.3,1),I,null,false);light([0,60,z],[1,.5,.25])}}
 if(bes==='garden'){for(let i=0;i<3;i++)arc(t,[0,0,-120-i*60],120+i*70,i*1.3,i*1.3+4,6,tone(S.dark,1.4));beam(t,[0,0,-40],[0,-300,-40],10,S.dark)}
 if(bes==='ark'){for(let i=0;i<6;i++){const a=i/6*Math.PI*2;const c=[Math.cos(a)*170,Math.sin(a)*120,-160-R()*80];const q=qaxis([0,1,0],R()*.6-.3);
   const tr=buildTransport();for(const tri of tr)t.push([add(qrot(q,scl(tri[0],2)),c),add(qrot(q,scl(tri[1],2)),c),add(qrot(q,scl(tri[2],2)),c),tri[3]]);COL.push({t:'sphere',c,r:55});beam(t,[0,0,-120],c,4,S.dark);light(c,[.9,.8,.5])}}
 if(bes==='sklad9'){t.push(...rockTris(1,.25,1,(n,r)=>{const k=.18+r()*.06;return C(k,k*.95,k*.9)},v=>add(scl(v,230),[0,0,-260]),99));COL.push({t:'sphere',c:[0,0,-260],r:210});
  for(const sx of [-1,1]){beam(t,[sx*120,-60,-40],[sx*170,-60,200],6,S.acc);light([sx*170,-60,200],[.7,.5,1])}}
 if(bes==='iznanka'){for(let i=0;i<5;i++)arc(t,[0,0,-200],260+i*60,i*.7,i*.7+5,10+i*2,i%2?S.acc:S.hull,v=>qrot(qaxis([1,0,0],i*.5),v));box(t,[0,0,-200],[80,300,80],S.dark);COL.push({t:'sphere',c:[0,0,-200],r:120})}
 if(bes==='kromka'||bes==='verf9')return null;
 return {tris:t,colliders:COL,lights:L,rot}}
const BESPOKE_FAMILY={lira:'habitat',perekr:'ring',gorn:'mining',teira_hall:'military',essen_choir:'observatory',razlom_fort:'military',kilvater:'ring',harbor_cyl:'dock',garden:'ring',ark:'habitat',sklad9:'dock',iznanka:'observatory'};
function hashStr(s){let h=2166136261;for(let i=0;i<s.length;i++){h^=s.charCodeAt(i);h=Math.imul(h,16777619)}return h>>>0}
// ---- planets by class ----
const PLANET_CLS={
 ocean:v=>{const n=fbm(scl(v,3),4);const land=n>.55;const city=land&&fbm(scl(v,22),2)>.62?.9:0;return land?C(.25,.45,.28,city):C(.1,.28,.58)},
 dry:v=>{const n=fbm(scl(v,3.2),4),b=Math.sin(v[1]*7+n*5);const c=b>.3?[.78,.52,.24]:b>-.4?[.66,.42,.2]:[.52,.33,.18];const city=fbm(scl(v,20),2)>.66?.8:0;return C(...c,city)},
 ice:v=>{const n=fbm(scl(v,4),4);return n>.5?C(.9,.94,1):C(.65,.75,.88)},
 volcanic:v=>{const n=fbm(scl(v,5),4);return n>.62?C(1,.4,.1,.85):C(.18,.14,.13)},
 giant:v=>{const n=fbm(scl(v,2.5),3);const b=Math.sin(v[1]*11+n*3.5);return b>.4?C(.62,.78,.92):b>-.2?C(.4,.6,.84):C(.3,.46,.72)},
 ringed:v=>{const n=fbm(scl(v,2.5),3);const b=Math.sin(v[1]*9+n*3);return b>.3?C(.86,.78,.6):C(.7,.6,.45)},
 rock:v=>{const k=.35+fbm(scl(v,6),4)*.3;return C(k,k*.97,k*.94)},
 damaged:v=>{const n=fbm(scl(v,4),4);const crack=Math.abs(Math.sin(v[0]*9+n*6))<.05;return crack?C(1,.5,.2,.9):n>.5?C(.4,.33,.3):C(.28,.24,.22)}};
const PLANET_RIM={ocean:[.4,.7,1,1.2],dry:[1,.62,.32,1.1],ice:[.7,.85,1,.8],volcanic:[1,.4,.2,.6],giant:[.5,.75,1,1.1],ringed:[1,.85,.6,.9],rock:[.6,.6,.7,.25],damaged:[1,.5,.3,.5]};
const PLANET_NIGHT={ocean:[1,.85,.5],dry:[1,.8,.45],volcanic:[1,.45,.15],damaged:[1,.5,.2]};const PLANET_LAVA={volcanic:.45,damaged:.35};
const CLOUDY={ocean:.75,dry:.25,ice:.4,ringed:.15};const cloudCache={};
function cloudMesh(cls){if(cloudCache[cls])return cloudCache[cls];const k=CLOUDY[cls]||0;if(!k)return null;const t=sphereTris(3,v=>{const n=fbm(add(scl(v,3.5),[7,3,1]),4);const a=clamp((n-.48)*3,0,1)*k;return [1,1,1,a]});return cloudCache[cls]=makeMesh(t)}
const planetMeshCache={};
function planetMesh(cls){if(cls==='dry'&&M.amber)return M.amber;if(cls==='giant'&&M.giant)return M.giant;if(!planetMeshCache[cls])planetMeshCache[cls]=makeMesh(sphereTris(4,PLANET_CLS[cls]));return planetMeshCache[cls]}
