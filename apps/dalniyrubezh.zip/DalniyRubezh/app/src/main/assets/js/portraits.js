'use strict';
// ================= original vector portraits, emblems and icons =================
// Each hero: distinct age/face/pose/clothing/lighting; alt = second emotional state for key scenes.
const PORTRAIT={
 vera:{skin:'#d9a882',hair:'#6b6b70',coat:'#3d4a5e',acc:'#c98a4f',bg:['#2a2030','#4a3a2a'],face:'oval',age:55,hairStyle:'bun',extra:'headset'},
 taras:{skin:'#c58f6a',hair:'#3a2a20',coat:'#5a4a2a',acc:'#e0a040',bg:['#2a1e10','#4a3010'],face:'square',age:48,hairStyle:'short',extra:'beard'},
 ilan:{skin:'#e3c2a0',hair:'#1e1e28',coat:'#2e3e5e',acc:'#7fb0ff',bg:['#101a30','#20305a'],face:'narrow',age:31,hairStyle:'side',extra:'glasses'},
 kae:{skin:'#9a5a3a',hair:'#2a1410',coat:'#5a2a18',acc:'#d0603a',bg:['#2a0e08','#5a2010'],face:'teira',age:40,hairStyle:'crest',extra:'pattern'},
 sun:{skin:'#bfe8e4',hair:'#7fe0d0',coat:'#1e4a4a',acc:'#7fe0d0',bg:['#081e22','#0e3a3a'],face:'essen',age:0,hairStyle:'none',extra:'lights'},
 mira:{skin:'#d6a07a',hair:'#8a2a20',coat:'#2a2a2a',acc:'#c05050',bg:['#200a0a','#3a1414'],face:'oval',age:34,hairStyle:'long',extra:'scar'},
 kassar:{skin:'#e0b494',hair:'#cfcfd4',coat:'#1e2e4e',acc:'#5fa8ff',bg:['#0a1428','#1a2a4a'],face:'square',age:62,hairStyle:'short',extra:'medals'}};
function heroAlt(id){const c=S&&S.camp||{},sd=S&&S.side||{};const f=(c.flags)||{};
 return {vera:!!(sd.done&&sd.done.s_crew3),taras:!!(c.done&&c.done.a3_2),ilan:!!(c.done&&c.done.a2_6),kae:!!f.oathAshket,sun:!!f.savedExpedition,mira:!!(c.done&&c.done.a3_4),kassar:!!(c.ending)}[id]||false}
function portraitSVG(id,alt){const p=PORTRAIT[id];if(!p)return '';alt=alt||heroAlt(id);const u='p'+id+(alt?'a':'');
 const eyesY=alt&&id!=='sun'?31:30;let face='',hair='',extra='',body='';
 // body / clothing
 body=`<path d="M8 64 Q10 46 32 44 Q54 46 56 64 Z" fill="${p.coat}"/><path d="M26 45 L32 54 L38 45" fill="none" stroke="${p.acc}" stroke-width="2"/>`;
 if(id==='kassar')body+=`<rect x="38" y="51" width="3" height="5" fill="#ffd166"/><rect x="42" y="51" width="3" height="5" fill="#c0c0c8"/><rect x="18" y="47" width="10" height="2" fill="#ffd166"/>`;
 if(id==='taras')body+=`<rect x="12" y="52" width="40" height="3" fill="#e0a040" opacity=".7"/>`;
 // head shapes
 const sk=p.skin;
 if(p.face==='teira'){face=`<path d="M20 30 Q20 12 32 10 Q44 12 44 30 Q44 44 32 48 Q20 44 20 30Z" fill="${sk}"/><path d="M22 20 L18 8 M42 20 L46 8 M32 10 L32 4" stroke="${p.hair}" stroke-width="3"/>`;
  extra=`<path d="M24 36 Q32 40 40 36" stroke="#f0a060" stroke-width="1.2" fill="none" opacity=".8"/><path d="M23 26 l4 2 M41 26 l-4 2 M30 44 l2 -3 l2 3" stroke="#ffcf7a" stroke-width="1.3"/>`}
 else if(p.face==='essen'){face=`<ellipse cx="32" cy="28" rx="13" ry="17" fill="${sk}" opacity=".9"/><ellipse cx="32" cy="28" rx="13" ry="17" fill="url(#g${u})"/>`;
  const lines=alt?[[22,20,42,36],[24,36,40,18],[32,12,32,44]]:[[22,24,42,24],[24,32,40,32],[26,18,38,40]];
  extra=`<g class="essenLights">${lines.map(([a,b,c,d],i)=>`<line x1="${a}" y1="${b}" x2="${c}" y2="${d}" stroke="#7fffe8" stroke-width="1.4" opacity=".9"><animate attributeName="opacity" values=".2;1;.2" dur="${1.2+i*.4}s" repeatCount="indefinite"/></line>`).join('')}</g>`}
 else{const w=p.face==='square'?14:p.face==='narrow'?11:12.5;face=`<path d="M${32-w} 28 Q${32-w} 13 32 13 Q${32+w} 13 ${32+w} 28 Q${32+w} ${p.face==='square'?44:42} 32 46 Q${32-w} ${p.face==='square'?44:42} ${32-w} 28Z" fill="${sk}"/>`;
  if(p.age>45)face+=`<path d="M24 22 h5 M35 22 h5" stroke="#00000033" stroke-width="1"/><path d="M25 38 q2 2 4 1 M35 39 q2 1 4 -1" stroke="#00000030" stroke-width="1" fill="none"/>`}
 // hair
 const hc=p.hair;if(p.hairStyle==='bun')hair=`<path d="M19 26 Q18 10 32 10 Q46 10 45 26 Q42 15 32 15 Q22 15 19 26Z" fill="${hc}"/><circle cx="32" cy="9" r="5" fill="${hc}"/>`;
 if(p.hairStyle==='short')hair=`<path d="M18 24 Q18 10 32 10 Q46 10 46 24 Q44 14 32 14 Q20 14 18 24Z" fill="${hc}"/>`;
 if(p.hairStyle==='side')hair=`<path d="M20 26 Q18 9 34 10 Q46 11 44 24 Q38 13 26 18 Q22 20 20 26Z" fill="${hc}"/>`;
 if(p.hairStyle==='long')hair=`<path d="M17 44 Q14 10 32 9 Q50 10 47 44 Q44 22 32 15 Q20 22 17 44Z" fill="${hc}"/>`;
 // eyes, mouth (expression: alt = softened or troubled)
 const eye=id==='sun'?'#eafffb':'#1a1a20';const brow=alt?'M24 25 l6 1 M34 26 l6 -1':'M24 26 l6 -1 M34 25 l6 1';
 let eyes=`<ellipse cx="27" cy="${eyesY}" rx="2.2" ry="${id==='kae'?1.4:1.8}" fill="${eye}"/><ellipse cx="37" cy="${eyesY}" rx="2.2" ry="${id==='kae'?1.4:1.8}" fill="${eye}"/>`;
 if(id!=='sun')eyes+=`<path d="${brow}" stroke="${p.face==='essen'?'none':'#2a1a14'}" stroke-width="1.4"/>`;
 const mouth=id==='sun'?'':alt?(id==='vera'||id==='mira'?`<path d="M28 39 Q32 42 36 39" stroke="#7a3a30" stroke-width="1.5" fill="none"/>`:`<path d="M28 40 Q32 38 36 40" stroke="#7a3a30" stroke-width="1.5" fill="none"/>`):`<path d="M28 39 L36 39" stroke="#7a3a30" stroke-width="1.4"/>`;
 if(p.extra==='headset')extra=`<path d="M19 28 Q19 12 32 11 Q45 12 45 28" stroke="#333" stroke-width="2" fill="none"/><rect x="16" y="26" width="5" height="7" rx="2" fill="#444"/><path d="M18 33 Q20 40 27 40" stroke="#444" stroke-width="1.5" fill="none"/>`+(alt?`<path d="M27 33 q0 3 1 5" stroke="#9fd0ff" stroke-width="1" opacity=".8"/>`:'');
 if(p.extra==='beard')extra=`<path d="M20 34 Q22 48 32 48 Q42 48 44 34 Q40 42 32 42 Q24 42 20 34Z" fill="${hc}"/>`;
 if(p.extra==='glasses')extra=`<rect x="22.5" y="${eyesY-3}" width="9" height="6" rx="2" fill="none" stroke="#9fb6d8" stroke-width="1.2"/><rect x="32.5" y="${eyesY-3}" width="9" height="6" rx="2" fill="none" stroke="#9fb6d8" stroke-width="1.2"/><line x1="31.5" y1="${eyesY}" x2="32.5" y2="${eyesY}" stroke="#9fb6d8"/>`;
 if(p.extra==='scar')extra=`<path d="M38 20 L42 30" stroke="#a0504a" stroke-width="1.3"/>`;
 // lighting: key light from the side, rim of accent colour
 const light=`<path d="M${id==='taras'?46:18} 12 Q${id==='taras'?52:12} 30 ${id==='taras'?44:20} 48" stroke="${p.acc}" stroke-width="2" fill="none" opacity=".55"/>`;
 return `<svg viewBox="0 0 64 64" width="60" height="60" style="flex:none;border-radius:10px;border:2px solid ${p.acc}"><defs><linearGradient id="b${u}" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="${p.bg[0]}"/><stop offset="1" stop-color="${p.bg[1]}"/></linearGradient>
 <radialGradient id="g${u}" cx=".4" cy=".35" r=".7"><stop offset="0" stop-color="#ffffff" stop-opacity=".45"/><stop offset="1" stop-color="#7fe0d0" stop-opacity="0"/></radialGradient></defs>
 <rect width="64" height="64" fill="url(#b${u})"/>${body}${hair&&p.hairStyle==='long'?hair:''}${face}${eyes}${mouth}${hair&&p.hairStyle!=='long'?hair:''}${extra}${light}</svg>`}
// ---- faction emblems ----
function emblemSVG(f,s=20){const c=(REG.factions[f]||{}).color||'#888';const shapes={league:`<circle cx="12" cy="12" r="8" fill="none" stroke="${c}" stroke-width="2"/><path d="M6 12h12M12 6v12" stroke="${c}" stroke-width="2"/>`,
 union:`<rect x="5" y="5" width="14" height="14" fill="none" stroke="${c}" stroke-width="2"/><path d="M5 12h14M9 5v14M15 5v14" stroke="${c}" stroke-width="1.4"/>`,
 teira:`<path d="M12 3 L18 12 L12 21 L6 12Z" fill="none" stroke="${c}" stroke-width="2"/><path d="M9 5 L12 1 L15 5" stroke="${c}" stroke-width="2" fill="none"/>`,
 essen:`<path d="M5 14 A7 7 0 1 1 19 14" fill="none" stroke="${c}" stroke-width="2"/><path d="M8 15 A4 4 0 1 1 16 15" fill="none" stroke="${c}" stroke-width="2"/>`,
 wake:`<path d="M4 16 Q12 4 20 16" fill="none" stroke="${c}" stroke-width="2.4"/><path d="M8 18 l4 -5 l4 5" stroke="${c}" stroke-width="2" fill="none"/>`,none:`<circle cx="12" cy="12" r="6" fill="none" stroke="${c}" stroke-width="2" stroke-dasharray="3 2"/>`};
 return `<svg viewBox="0 0 24 24" width="${s}" height="${s}" style="vertical-align:middle">${shapes[f]||shapes.none}</svg>`}
// ---- category / weapon / module icons (readable at 16 px) ----
const ICON_PATH={ore:'M4 16 L8 6 L16 4 L20 12 L14 20 Z',mat:'M4 8h16v8H4z M8 8v8 M16 8v8',parts:'M12 4 l2 3h3l-2 3 2 3h-3l-2 3-2-3H7l2-3-2-3h3z',tech:'M5 5h14v10H5z M9 19h6 M12 15v4',
 med:'M9 4h6v5h5v6h-5v5H9v-5H4V9h5z',home:'M4 12 L12 4 L20 12 V20 H4Z',lux:'M12 3 L15 9 L21 10 L16 14 L18 21 L12 17 L6 21 L8 14 L3 10 L9 9Z',contra:'M12 3 L21 20 H3Z M12 9v5 M12 16v2',
 pulse:'M3 12 h4 l2 -5 l3 10 l3 -7 l2 2 h4',kinetic:'M4 12 h10 M14 8 l6 4 -6 4z',plasma:'M12 5 a7 7 0 1 0 .1 0 M12 9 a3 3 0 1 0 .1 0',beam:'M3 12 H21 M3 9 H21 M3 15 H21',ion:'M12 3 L8 13 h4 l-2 8 8-12 h-5 l3-6z',missile:'M4 20 L14 10 L18 4 L20 6 L14 10 M8 14 l-3 -1 M10 16 l1 3',module:'M5 5h14v14H5z M9 9h6v6H9z'};
function iconSVG(k,col='#cfe0ff',s=16){return `<svg viewBox="0 0 24 24" width="${s}" height="${s}" style="vertical-align:-3px"><path d="${ICON_PATH[k]||ICON_PATH.module}" fill="none" stroke="${col}" stroke-width="2" stroke-linejoin="round" stroke-linecap="round"/></svg>`}
