package tj.builder.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ServiceInfo;
import android.os.Build;
import android.os.IBinder;

import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;

/**
 * Фоновая сборка: загружает архив, ждёт GitHub, скачивает APK.
 * Работает, даже если «Сборщик» закрыт. Всё состояние хранится в настройках,
 * поэтому приложение после открытия видит, что происходит.
 */
public class BuildService extends Service {
    static final String CH_PROGRESS = "progress", CH_DONE = "done";
    static final int ID_PROGRESS = 1, ID_DONE = 2;
    static volatile boolean running = false;

    SharedPreferences prefs;
    NotificationManager nm;
    String label = "";
    long start;

    static File pendingZip(Context c) {
        return new File(c.getFilesDir(), "pending.zip");
    }

    static File apkDir(Context c) {
        File d = new File(c.getFilesDir(), "apk");
        d.mkdirs();
        return d;
    }

    static void start(Context c) {
        Intent i = new Intent(c, BuildService.class);
        try {
            if (Build.VERSION.SDK_INT >= 26) c.startForegroundService(i);
            else c.startService(i);
        } catch (Exception ignored) {
        }
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        prefs = getSharedPreferences("builder", MODE_PRIVATE);
        nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        channels();
        JSONObject job = loadJob();
        if (job == null) {
            stopSelf();
            return START_NOT_STICKY;
        }
        label = job.optString("label");
        start = job.optLong("start", System.currentTimeMillis());
        Notification n = progress(prefs.getString("job_status", "Готовлю сборку…"));
        try {
            if (Build.VERSION.SDK_INT >= 29) startForeground(ID_PROGRESS, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC);
            else startForeground(ID_PROGRESS, n);
        } catch (Exception e) {
            stopSelf();
            return START_NOT_STICKY;
        }
        if (!running) {
            running = true;
            new Thread(this::work).start();
        }
        return START_STICKY;
    }

    void channels() {
        if (Build.VERSION.SDK_INT < 26 || nm == null) return;
        NotificationChannel p = new NotificationChannel(CH_PROGRESS, "Идёт сборка", NotificationManager.IMPORTANCE_LOW);
        p.setShowBadge(false);
        nm.createNotificationChannel(p);
        nm.createNotificationChannel(new NotificationChannel(CH_DONE, "Сборка готова", NotificationManager.IMPORTANCE_HIGH));
    }

    Notification.Builder builder(String channel) {
        Notification.Builder b = Build.VERSION.SDK_INT >= 26
                ? new Notification.Builder(this, channel)
                : new Notification.Builder(this);
        b.setSmallIcon(R.drawable.ic_stat);
        Intent open = new Intent(this, MainActivity.class);
        open.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        b.setContentIntent(PendingIntent.getActivity(this, 0, open,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE));
        return b;
    }

    Notification progress(String text) {
        Notification.Builder b = builder(CH_PROGRESS);
        b.setContentTitle("Сборка «" + label + "»");
        b.setContentText(text);
        b.setOngoing(true);
        b.setOnlyAlertOnce(true);
        b.setUsesChronometer(true);
        b.setWhen(start);
        b.setProgress(0, 0, true);
        return b.build();
    }

    void status(String s) {
        prefs.edit().putString("job_status", s).apply();
        if (nm != null) nm.notify(ID_PROGRESS, progress(s));
    }

    JSONObject loadJob() {
        try {
            String s = prefs.getString("job", null);
            return s == null ? null : new JSONObject(s);
        } catch (Exception e) {
            return null;
        }
    }

    void saveJob(JSONObject j) {
        prefs.edit().putString("job", j.toString()).apply();
    }

    Gh gh() {
        return new Gh(prefs.getString("token", ""), prefs.getString("owner", ""), prefs.getString("repo", "Builder"));
    }

    static byte[] readFile(File f) throws Exception {
        FileInputStream in = new FileInputStream(f);
        ByteArrayOutputStream bo = new ByteArrayOutputStream();
        byte[] buf = new byte[65536];
        int n;
        while ((n = in.read(buf)) > 0) bo.write(buf, 0, n);
        in.close();
        return bo.toByteArray();
    }

    void work() {
        JSONObject job = loadJob();
        try {
            if (job == null) return;
            String slug = job.getString("slug");
            Gh g = gh();

            // 1. загрузка
            if (job.optString("sha", "").isEmpty()) {
                status("Загружаю на GitHub…");
                byte[] data = readFile(pendingZip(this));
                String sha = null;
                Exception last = null;
                for (int i = 0; i < 4 && sha == null; i++) {
                    try {
                        sha = g.upload("apps/" + slug + ".zip", data, "Сборка " + slug);
                    } catch (Exception e) {
                        last = e;
                        if (e.getMessage() != null && e.getMessage().startsWith("GitHub не дал")) throw e;
                        status("Нет связи, пробую ещё раз…");
                        Thread.sleep(10000);
                    }
                }
                if (sha == null) throw last;
                job.put("sha", sha);
                job.put("uploaded", System.currentTimeMillis());
                saveJob(job);
                pendingZip(this).delete();
            }

            // 2. ждём, когда GitHub начнёт
            long runId = job.optLong("runId", 0);
            while (runId == 0) {
                status("Жду, когда GitHub начнёт сборку…");
                Thread.sleep(5000);
                try {
                    JSONObject r = g.findRun(job.getString("sha"));
                    if (r != null) {
                        runId = r.getLong("id");
                        job.put("runId", runId);
                        job.put("runUrl", r.optString("html_url", ""));
                        saveJob(job);
                    }
                } catch (Exception ignored) {
                }
                if (runId == 0 && System.currentTimeMillis() - job.optLong("uploaded", start) > 5 * 60000L)
                    throw new Exception("Сборка не запустилась. Проверь, что в репозитории есть файл .github/workflows/build.yml.");
            }

            // 3. ждём окончания
            JSONObject run = null;
            while (true) {
                try {
                    JSONObject r = g.run(runId);
                    if (r != null) run = r;
                } catch (Exception ignored) {
                }
                if (run != null && "completed".equals(run.optString("status"))) break;
                String s = run == null ? "" : run.optString("status");
                status("queued".equals(s) || "waiting".equals(s) || "pending".equals(s)
                        ? "В очереди на GitHub…" : "Собирается… (обычно 3–6 минут)");
                if (System.currentTimeMillis() - start > 50 * 60000L)
                    throw new Exception("Сборка идёт слишком долго. Открой её на GitHub.");
                Thread.sleep(8000);
            }
            if (!"success".equals(run.optString("conclusion"))) {
                String step = g.failedStep(runId);
                throw new Exception("Сборка не удалась" + (step != null ? " на шаге «" + step + "»" : "")
                        + ". Нажми «Открыть сборку на GitHub» и пришли скриншот ошибки.");
            }

            // 4. скачиваем APK
            status("Скачиваю APK…");
            File apk = null;
            Exception last = null;
            for (int i = 0; i < 4 && apk == null; i++) {
                try {
                    apk = g.downloadApk(slug, apkDir(this));
                } catch (Exception e) {
                    last = e;
                    Thread.sleep(8000);
                }
            }
            if (apk == null) throw last;
            finish(job, true, "«" + label + "» готово!", apk.getAbsolutePath());
        } catch (Exception e) {
            String msg = e.getMessage() == null ? e.toString() : e.getMessage();
            if (job != null) finish(job, false, msg, null);
        } finally {
            running = false;
            if (Build.VERSION.SDK_INT >= 24) stopForeground(STOP_FOREGROUND_REMOVE);
            else stopForeground(true);
            stopSelf();
        }
    }

    void finish(JSONObject job, boolean ok, String msg, String apkPath) {
        try {
            JSONObject r = new JSONObject();
            r.put("slug", job.optString("slug"));
            r.put("label", job.optString("label"));
            r.put("ok", ok);
            r.put("msg", msg);
            r.put("runUrl", job.optString("runUrl", ""));
            r.put("time", System.currentTimeMillis());
            if (apkPath != null) r.put("apk", apkPath);
            prefs.edit()
                    .remove("job")
                    .remove("job_status")
                    .putString("result", r.toString())
                    .putBoolean("result_handled", false)
                    .putString("note", "")
                    .apply();
            if (ok) MainActivity.addHistory(prefs, job.optString("slug"), job.optString("label"));
        } catch (Exception ignored) {
        }
        if (nm == null) return;
        Notification.Builder b = builder(CH_DONE);
        b.setAutoCancel(true);
        if (ok) {
            b.setContentTitle("✅ «" + label + "» готово");
            b.setContentText("Нажми, чтобы установить");
        } else {
            b.setContentTitle("❌ Сборка «" + label + "» не удалась");
            b.setContentText(msg);
            b.setStyle(new Notification.BigTextStyle().bigText(msg));
        }
        if (Build.VERSION.SDK_INT < 26) {
            b.setPriority(Notification.PRIORITY_HIGH);
            b.setDefaults(Notification.DEFAULT_ALL);
        }
        nm.notify(ID_DONE, b.build());
    }
}
