package tj.builder.app;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageInstaller;
import android.widget.Toast;

/** Получает ответ системного установщика. */
public class InstallReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context ctx, Intent intent) {
        int status = intent.getIntExtra(PackageInstaller.EXTRA_STATUS, PackageInstaller.STATUS_FAILURE);
        if (status == PackageInstaller.STATUS_PENDING_USER_ACTION) {
            Intent confirm = intent.getParcelableExtra(Intent.EXTRA_INTENT);
            if (confirm != null) {
                confirm.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                try {
                    ctx.startActivity(confirm);
                } catch (Exception e) {
                    Toast.makeText(ctx, "Не удалось открыть установку: " + e.getMessage(), Toast.LENGTH_LONG).show();
                }
            }
            return;
        }
        String msg;
        if (status == PackageInstaller.STATUS_SUCCESS) {
            msg = "Приложение установлено ✓";
        } else if (status == PackageInstaller.STATUS_FAILURE_ABORTED) {
            msg = "Установка отменена";
        } else if (status == PackageInstaller.STATUS_FAILURE_CONFLICT) {
            msg = "Уже установлена версия с другой подписью. Удали старое приложение и нажми «Установить» ещё раз.";
        } else if (status == PackageInstaller.STATUS_FAILURE_STORAGE) {
            msg = "Не хватает памяти для установки";
        } else {
            String m = intent.getStringExtra(PackageInstaller.EXTRA_STATUS_MESSAGE);
            msg = "Установка не удалась" + (m != null ? ": " + m : "");
        }
        Toast.makeText(ctx, msg, Toast.LENGTH_LONG).show();
        MainActivity.onInstallResult(ctx, msg);
    }
}
