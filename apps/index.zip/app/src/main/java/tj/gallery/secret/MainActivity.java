package tj.gallery.secret;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.app.PendingIntent;
import android.content.ContentResolver;
import android.content.ContentUris;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.IntentSender;
import android.content.SharedPreferences;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.ImageDecoder;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.GradientDrawable;
import android.media.MediaPlayer;
import android.media.MediaScannerConnection;
import android.media.ThumbnailUtils;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.provider.MediaStore;
import android.provider.Settings;
import android.text.Editable;
import android.text.InputType;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.LruCache;
import android.util.Size;
import android.util.TypedValue;
import android.view.GestureDetector;
import android.view.Gravity;
import android.view.HapticFeedbackConstants;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.GridView;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.VideoView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {

    static final int BG = 0xFF0F1012, CARD = 0xFF1B1C20, INK = 0xFFF2F2F0, MUTE = 0xFF9A9AA2,
            ACC = 0xFFFF5A4E, HID = 0xFF7C5CFF;
    static final int REQ_PERM = 7, REQ_HIDE = 11, REQ_DEL = 12, REQ_MOVE = 13;
    static final int A_FAV = 0, A_USER = 1, A_BUCKET = 2, A_ADD = 3;
    static final Locale RU = new Locale("ru");

    static class Item {
        String key;
        boolean vault, video;
        long id;
        Uri uri;
        File file;
        String name0 = "", bucket = "", mime = "", rel = "";
        long date, dur, size;
        int w, h;
    }

    static class AlbumRef {
        int type;
        int index;
        String name;
        String rel = "";
        int count;
        Item cover;
    }

    static class Holder {
        ImageView img;
        TextView badge, fav, title, count, check;
        View dim;
        String key;
        int idx;
    }

    static class RowHolder {
        int cols;
        FrameLayout[] frames;
        Holder[] cells;
    }

    static class SquareFrame extends FrameLayout {
        SquareFrame(Context c) { super(c); }

        @Override
        protected void onMeasure(int w, int h) { super.onMeasure(w, w); }
    }

    SharedPreferences prefs;
    final List<Item> device = new ArrayList<>();
    final List<Item> vault = new ArrayList<>();
    final List<Item> shown = new ArrayList<>();
    final List<Object> rows = new ArrayList<>();
    final List<AlbumRef> albumCards = new ArrayList<>();
    final Set<String> selected = new HashSet<>();
    boolean hiddenMode = false, goSettings = false, selecting = false;
    int tab = 0, cols = 4;
    AlbumRef curAlbum = null;

    // drag selection
    boolean dragActive = false;
    int dragAnchor = -1;
    Set<String> dragBase = new HashSet<>();

    LinearLayout titleRow, selRow, searchRow, hidBar, tabsRow, selActions, albumHits;
    HorizontalScrollView albumHitsScroll;
    EditText search;
    TextView title, info, empty, selCount;
    Button backBtn, menuBtn, tabPhotos, tabAlbums, permBtn;
    GridView grid;
    DragList list;
    RowAdapter rowAdapter;
    AlbumAdapter albumAdapter;

    final ExecutorService loader = Executors.newSingleThreadExecutor();
    final ExecutorService pool = Executors.newFixedThreadPool(3);
    final Handler ui = new Handler(Looper.getMainLooper());
    LruCache<String, Bitmap> cache;

    // pending operations
    List<Item> pendHide, pendDelete, pendMove;
    List<JSONObject> pendMeta;
    List<File> pendFiles;
    String pendMoveRel;
    AlertDialog progress;
    TextView progressText;

    // ================= helpers =================

    int dp(float v) {
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, getResources().getDisplayMetrics());
    }

    GradientDrawable round(int color, float r) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(r));
        return g;
    }

    Button btn(String t, int bg, int fg) {
        Button b = new Button(this);
        b.setText(t);
        b.setAllCaps(false);
        b.setTextColor(fg);
        b.setTextSize(15);
        b.setTypeface(Typeface.DEFAULT_BOLD);
        b.setBackground(round(bg, 12));
        b.setPadding(dp(14), 0, dp(14), 0);
        b.setMinHeight(dp(44));
        b.setMinimumHeight(dp(44));
        b.setMinWidth(0);
        b.setMinimumWidth(0);
        b.setStateListAnimator(null);
        return b;
    }

    /** Icon on top, small label below; fills an equal share of a row. */
    LinearLayout action(String icon, String label) {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setGravity(Gravity.CENTER);
        l.setPadding(dp(2), dp(6), dp(2), dp(6));
        l.setClickable(true);
        l.setFocusable(true);
        TextView i = new TextView(this);
        i.setText(icon);
        i.setTextSize(20);
        i.setTextColor(Color.WHITE);
        i.setGravity(Gravity.CENTER);
        l.addView(i);
        TextView t = new TextView(this);
        t.setText(label);
        t.setTextSize(11);
        t.setTextColor(Color.WHITE);
        t.setSingleLine(true);
        t.setGravity(Gravity.CENTER);
        l.addView(t);
        l.setTag(i);
        return l;
    }

    void setActionIcon(LinearLayout a, String icon) { ((TextView) a.getTag()).setText(icon); }

    LinearLayout.LayoutParams lp(int w, int h, float weight) {
        return new LinearLayout.LayoutParams(w, h, weight);
    }

    void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_SHORT).show(); }

    AlertDialog.Builder dlg() {
        return new AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert);
    }

    static String fmtDur(long ms) {
        long s = ms / 1000;
        if (s >= 3600) return String.format(Locale.US, "%d:%02d:%02d", s / 3600, (s / 60) % 60, s % 60);
        return String.format(Locale.US, "%d:%02d", s / 60, s % 60);
    }

    static String fmtSize(long b) {
        if (b <= 0) return "—";
        if (b < 1024 * 1024) return String.format(Locale.US, "%.0f КБ", b / 1024.0);
        if (b < 1024L * 1024 * 1024) return String.format(Locale.US, "%.1f МБ", b / 1048576.0);
        return String.format(Locale.US, "%.2f ГБ", b / 1073741824.0);
    }

    void showProgress(String t) {
        hideProgress();
        progressText = new TextView(this);
        progressText.setText(t);
        progressText.setTextSize(16);
        progressText.setPadding(dp(24), dp(20), dp(24), dp(20));
        progress = dlg().setView(progressText).setCancelable(false).create();
        progress.show();
    }

    void progressMsg(String t) { ui.post(() -> { if (progressText != null) progressText.setText(t); }); }

    void hideProgress() {
        if (progress != null) {
            try { progress.dismiss(); } catch (Exception e) { /* ignore */ }
        }
        progress = null;
        progressText = null;
    }

    // ================= lifecycle =================

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        if (Build.VERSION.SDK_INT >= 33) setRecentsScreenshotEnabled(false);
        prefs = getSharedPreferences("g", MODE_PRIVATE);
        cols = prefs.getInt("cols", 4);
        int mem = (int) (Runtime.getRuntime().maxMemory() / 1024 / 8);
        cache = new LruCache<String, Bitmap>(mem) {
            @Override
            protected int sizeOf(String k, Bitmap v) { return v.getByteCount() / 1024; }
        };
        buildUi();
        loadVault();
        if (!prefs.contains("code")) askCode(true);
        else checkPermAndLoad();
    }

    @Override
    protected void onRestart() {
        super.onRestart();
        if (hasPerm()) loadDevice();
        else render();
    }

    /** Leave hidden mode as soon as the app goes to the background (before Android takes its screenshot). */
    void leaveHiddenIfIdle() {
        if (hiddenMode && pendHide == null && pendDelete == null && pendMove == null && progress == null) {
            closeViewer();
            hiddenMode = false;
            curAlbum = null;
            tab = 0;
            clearSelection();
            render();
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        leaveHiddenIfIdle();
    }

    @Override
    protected void onStop() {
        super.onStop();
        if (hiddenMode && pendHide == null && pendDelete == null && pendMove == null && progress == null) {
            closeViewer();
            hiddenMode = false;
            curAlbum = null;
            tab = 0;
            clearSelection();
            render();
        }
    }

    @Override
    public void onBackPressed() {
        if (selecting) { clearSelection(); render(); return; }
        if (curAlbum != null) { curAlbum = null; render(); return; }
        if (hiddenMode) { hiddenMode = false; tab = 0; render(); return; }
        super.onBackPressed();
    }

    @Override
    public void onConfigurationChanged(Configuration c) {
        super.onConfigurationChanged(c);
        if (list != null) rowAdapter.notifyDataSetChanged();
    }

    // ================= UI =================

    void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(BG);

        LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.VERTICAL);
        top.setPadding(dp(12), dp(10), dp(12), 0);
        root.addView(top);

        titleRow = new LinearLayout(this);
        titleRow.setGravity(Gravity.CENTER_VERTICAL);
        backBtn = btn("←", CARD, INK);
        titleRow.addView(backBtn, lp(dp(46), dp(44), 0));
        title = new TextView(this);
        title.setTextColor(INK);
        title.setTextSize(26);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        title.setSingleLine(true);
        title.setEllipsize(TextUtils.TruncateAt.END);
        title.setPadding(dp(8), dp(4), dp(8), dp(4));
        titleRow.addView(title, lp(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        menuBtn = btn("⋯", CARD, INK);
        titleRow.addView(menuBtn, lp(dp(46), dp(44), 0));
        top.addView(titleRow);

        selRow = new LinearLayout(this);
        selRow.setGravity(Gravity.CENTER_VERTICAL);
        Button selClose = btn("✕", CARD, INK);
        selRow.addView(selClose, lp(dp(46), dp(44), 0));
        selCount = new TextView(this);
        selCount.setTextColor(INK);
        selCount.setTextSize(20);
        selCount.setTypeface(Typeface.DEFAULT_BOLD);
        selCount.setPadding(dp(12), 0, dp(8), 0);
        selRow.addView(selCount, lp(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        Button selAll = btn("Все", CARD, INK);
        selRow.addView(selAll, lp(ViewGroup.LayoutParams.WRAP_CONTENT, dp(44), 0));
        selRow.setVisibility(View.GONE);
        top.addView(selRow);

        searchRow = new LinearLayout(this);
        searchRow.setPadding(0, dp(8), 0, 0);
        search = new EditText(this);
        search.setHint("Поиск фото и альбомов");
        search.setHintTextColor(MUTE);
        search.setTextColor(INK);
        search.setTextSize(16);
        search.setSingleLine(true);
        search.setImeOptions(EditorInfo.IME_ACTION_SEARCH);
        search.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        search.setBackground(round(CARD, 12));
        search.setPadding(dp(14), 0, dp(14), 0);
        searchRow.addView(search, lp(0, dp(46), 1));
        Button go = btn("Поиск", ACC, Color.WHITE);
        LinearLayout.LayoutParams gp = lp(ViewGroup.LayoutParams.WRAP_CONTENT, dp(46), 0);
        gp.leftMargin = dp(8);
        searchRow.addView(go, gp);
        top.addView(searchRow);

        albumHitsScroll = new HorizontalScrollView(this);
        albumHitsScroll.setHorizontalScrollBarEnabled(false);
        albumHits = new LinearLayout(this);
        albumHits.setPadding(0, dp(8), 0, 0);
        albumHitsScroll.addView(albumHits);
        albumHitsScroll.setVisibility(View.GONE);
        top.addView(albumHitsScroll);

        hidBar = new LinearLayout(this);
        hidBar.setGravity(Gravity.CENTER_VERTICAL);
        hidBar.setBackground(round(HID, 12));
        hidBar.setPadding(dp(14), dp(5), dp(5), dp(5));
        LinearLayout.LayoutParams hbp = lp(-1, ViewGroup.LayoutParams.WRAP_CONTENT, 0);
        hbp.topMargin = dp(8);
        TextView ht = new TextView(this);
        ht.setText("Скрытый режим");
        ht.setTextColor(Color.WHITE);
        ht.setTypeface(Typeface.DEFAULT_BOLD);
        hidBar.addView(ht, lp(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        Button chg = btn("Сменить код", 0x33FFFFFF, Color.WHITE);
        chg.setTextSize(13);
        hidBar.addView(chg, lp(ViewGroup.LayoutParams.WRAP_CONTENT, dp(38), 0));
        Button exit = btn("Выйти", 0x33FFFFFF, Color.WHITE);
        exit.setTextSize(13);
        LinearLayout.LayoutParams ep = lp(ViewGroup.LayoutParams.WRAP_CONTENT, dp(38), 0);
        ep.leftMargin = dp(6);
        hidBar.addView(exit, ep);
        top.addView(hidBar, hbp);

        tabsRow = new LinearLayout(this);
        tabsRow.setPadding(0, dp(8), 0, 0);
        tabPhotos = btn("Фото", CARD, INK);
        tabAlbums = btn("Альбомы", CARD, INK);
        tabsRow.addView(tabPhotos, lp(0, dp(42), 1));
        LinearLayout.LayoutParams tp = lp(0, dp(42), 1);
        tp.leftMargin = dp(8);
        tabsRow.addView(tabAlbums, tp);
        top.addView(tabsRow);

        info = new TextView(this);
        info.setTextColor(MUTE);
        info.setTextSize(13);
        info.setPadding(dp(4), dp(8), 0, dp(4));
        top.addView(info);

        FrameLayout content = new FrameLayout(this);
        list = new DragList(this);
        list.setDivider(null);
        list.setDividerHeight(0);
        list.setSelector(new ColorDrawable(Color.TRANSPARENT));
        list.setClipToPadding(false);
        list.setPadding(dp(4), 0, dp(4), dp(24));
        list.setFastScrollEnabled(true);
        rowAdapter = new RowAdapter();
        list.setAdapter(rowAdapter);
        content.addView(list, new FrameLayout.LayoutParams(-1, -1));

        grid = new GridView(this);
        grid.setNumColumns(2);
        grid.setHorizontalSpacing(dp(10));
        grid.setVerticalSpacing(dp(14));
        grid.setStretchMode(GridView.STRETCH_COLUMN_WIDTH);
        grid.setSelector(new ColorDrawable(Color.TRANSPARENT));
        grid.setClipToPadding(false);
        grid.setPadding(dp(12), dp(4), dp(12), dp(24));
        albumAdapter = new AlbumAdapter();
        grid.setAdapter(albumAdapter);
        grid.setVisibility(View.GONE);
        content.addView(grid, new FrameLayout.LayoutParams(-1, -1));

        LinearLayout emptyBox = new LinearLayout(this);
        emptyBox.setOrientation(LinearLayout.VERTICAL);
        emptyBox.setGravity(Gravity.CENTER);
        empty = new TextView(this);
        empty.setTextColor(MUTE);
        empty.setTextSize(16);
        empty.setGravity(Gravity.CENTER);
        empty.setPadding(dp(24), 0, dp(24), dp(16));
        emptyBox.addView(empty);
        permBtn = btn("Дать доступ", ACC, Color.WHITE);
        permBtn.setVisibility(View.GONE);
        emptyBox.addView(permBtn, lp(ViewGroup.LayoutParams.WRAP_CONTENT, dp(48), 0));
        content.addView(emptyBox, new FrameLayout.LayoutParams(-1, -2, Gravity.CENTER));
        root.addView(content, lp(-1, 0, 1));

        selActions = new LinearLayout(this);
        selActions.setBackgroundColor(CARD);
        selActions.setPadding(dp(4), dp(2), dp(4), dp(6));
        selActions.setVisibility(View.GONE);
        root.addView(selActions, lp(-1, ViewGroup.LayoutParams.WRAP_CONTENT, 0));

        setContentView(root);

        search.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence s, int a, int c, int d) { }
            public void onTextChanged(CharSequence s, int a, int c, int d) { }
            public void afterTextChanged(Editable s) { if (!hiddenMode) render(); }
        });
        search.setOnEditorActionListener((v, a, e) -> { doSearch(); return true; });
        go.setOnClickListener(v -> doSearch());
        exit.setOnClickListener(v -> { hiddenMode = false; curAlbum = null; tab = 0; clearSelection(); render(); });
        chg.setOnClickListener(v -> askCode(false));
        backBtn.setOnClickListener(v -> { curAlbum = null; clearSelection(); render(); });
        menuBtn.setOnClickListener(v -> albumMenu());
        tabPhotos.setOnClickListener(v -> { tab = 0; curAlbum = null; clearSelection(); render(); });
        tabAlbums.setOnClickListener(v -> { tab = 1; curAlbum = null; clearSelection(); render(); });
        selClose.setOnClickListener(v -> { clearSelection(); render(); });
        selAll.setOnClickListener(v -> {
            boolean all = true;
            for (Item it : shown) if (!selected.contains(it.key)) { all = false; break; }
            if (all) selected.clear();
            else for (Item it : shown) selected.add(it.key);
            updateSelection();
        });
        permBtn.setOnClickListener(v -> {
            if (goSettings) {
                startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                        Uri.fromParts("package", getPackageName(), null)));
            } else {
                requestPermissions(perms(), REQ_PERM);
            }
        });
        grid.setOnItemClickListener((p, v, pos, id) -> {
            if (pos >= albumCards.size()) return;
            AlbumRef r = albumCards.get(pos);
            if (r.type == A_ADD) newAlbum(null);
            else openAlbum(r);
        });
        list.handler = new DragList.Handler() {
            public boolean dragging() { return dragActive; }

            public void dragTo(float x, float y) {
                if (y < dp(56)) list.scrollListBy(-dp(14));
                else if (y > list.getHeight() - dp(56)) list.scrollListBy(dp(14));
                int idx = cellAt(x, y);
                if (idx < 0 || dragAnchor < 0) return;
                selected.clear();
                selected.addAll(dragBase);
                int a = Math.min(dragAnchor, idx), b = Math.max(dragAnchor, idx);
                for (int i = a; i <= b && i < shown.size(); i++) selected.add(shown.get(i).key);
                updateSelection();
            }

            public void dragEnd() { dragActive = false; }

            public void zoom(int delta) {
                int n = Math.max(2, Math.min(6, cols + delta));
                if (n == cols) return;
                cols = n;
                prefs.edit().putInt("cols", cols).apply();
                buildRows();
                rowAdapter.notifyDataSetChanged();
            }
        };
    }

    void openAlbum(AlbumRef r) {
        curAlbum = r;
        clearSelection();
        render();
        list.setSelection(0);
    }

    int cellAt(float x, float y) {
        for (int i = 0; i < list.getChildCount(); i++) {
            View row = list.getChildAt(i);
            if (y < row.getTop() || y > row.getBottom()) continue;
            Object t = row.getTag();
            if (!(t instanceof RowHolder)) return -1;
            RowHolder rh = (RowHolder) t;
            float rx = x - row.getLeft();
            for (int c = 0; c < rh.frames.length; c++) {
                FrameLayout f = rh.frames[c];
                if (f.getVisibility() != View.VISIBLE) continue;
                if (rx >= f.getLeft() - dp(2) && rx <= f.getRight() + dp(2)) return rh.cells[c].idx;
            }
            return -1;
        }
        return -1;
    }

    boolean showingAlbums() { return tab == 1 && curAlbum == null; }

    void render() {
        boolean perm = hasPerm();
        title.setText(curAlbum != null ? curAlbum.name : (hiddenMode ? "Скрытые" : "Галерея"));
        backBtn.setVisibility(curAlbum != null ? View.VISIBLE : View.GONE);
        menuBtn.setVisibility(curAlbum != null && curAlbum.type == A_USER ? View.VISIBLE : View.GONE);
        searchRow.setVisibility(!hiddenMode && tab == 0 && curAlbum == null && !selecting ? View.VISIBLE : View.GONE);
        hidBar.setVisibility(hiddenMode && !selecting ? View.VISIBLE : View.GONE);
        tabsRow.setVisibility(curAlbum == null && !selecting ? View.VISIBLE : View.GONE);
        titleRow.setVisibility(selecting ? View.GONE : View.VISIBLE);
        selRow.setVisibility(selecting ? View.VISIBLE : View.GONE);
        styleTab(tabPhotos, tab == 0);
        styleTab(tabAlbums, tab == 1);
        if (hiddenMode) getWindow().addFlags(WindowManager.LayoutParams.FLAG_SECURE);
        else getWindow().clearFlags(WindowManager.LayoutParams.FLAG_SECURE);
        permBtn.setVisibility(View.GONE);
        albumHitsScroll.setVisibility(View.GONE);

        if (!hiddenMode && !perm) {
            shown.clear();
            rows.clear();
            rowAdapter.notifyDataSetChanged();
            list.setVisibility(View.VISIBLE);
            grid.setVisibility(View.GONE);
            info.setText("");
            empty.setText("Разрешите доступ к фото и видео, чтобы галерея их показала.");
            empty.setVisibility(View.VISIBLE);
            permBtn.setText(goSettings ? "Открыть настройки" : "Дать доступ");
            permBtn.setVisibility(View.VISIBLE);
            return;
        }

        if (showingAlbums()) {
            buildAlbumCards();
            albumAdapter.notifyDataSetChanged();
            list.setVisibility(View.GONE);
            grid.setVisibility(View.VISIBLE);
            info.setText("Альбомов: " + (albumCards.size() - 1));
            empty.setVisibility(View.GONE);
            updateSelection();
            return;
        }

        List<Item> src = curAlbum != null ? albumItems(curAlbum) : modeItems();
        String q = (!hiddenMode && curAlbum == null) ? search.getText().toString().trim().toLowerCase() : "";
        shown.clear();
        for (Item it : src) {
            if (q.isEmpty() || name(it).toLowerCase().contains(q)) shown.add(it);
        }
        if (!q.isEmpty() && !isCode(q)) showAlbumHits(q);
        buildRows();
        rowAdapter.notifyDataSetChanged();
        list.setVisibility(View.VISIBLE);
        grid.setVisibility(View.GONE);
        info.setText(src.isEmpty() ? "" : (q.isEmpty() ? "Всего: " + src.size() : "Найдено фото: " + shown.size()));
        if (shown.isEmpty()) {
            empty.setVisibility(View.VISIBLE);
            if (!q.isEmpty()) empty.setText("Фото не найдены");
            else if (curAlbum != null) empty.setText("В этом альбоме пока пусто");
            else if (hiddenMode) empty.setText("Здесь пока пусто.\nЧтобы скрыть: выберите фото (зажмите), нажмите «Переместить» и введите код в поиске.");
            else empty.setText("Фото и видео не найдены");
        } else {
            empty.setVisibility(View.GONE);
        }
        updateSelection();
    }

    void showAlbumHits(String q) {
        albumHits.removeAllViews();
        buildAlbumCards();
        int n = 0;
        for (AlbumRef r : albumCards) {
            if (r.type == A_ADD || r.name == null) continue;
            if (!r.name.toLowerCase().contains(q)) continue;
            Button b = btn("📁 " + r.name, CARD, INK);
            b.setTextSize(14);
            LinearLayout.LayoutParams p = lp(ViewGroup.LayoutParams.WRAP_CONTENT, dp(40), 0);
            p.rightMargin = dp(8);
            albumHits.addView(b, p);
            final AlbumRef fr = r;
            b.setOnClickListener(v -> { tab = 1; openAlbum(fr); });
            n++;
        }
        albumHitsScroll.setVisibility(n > 0 ? View.VISIBLE : View.GONE);
    }

    void styleTab(Button b, boolean on) {
        b.setBackground(round(on ? (hiddenMode ? HID : ACC) : CARD, 12));
        b.setTextColor(on ? Color.WHITE : INK);
    }

    // ---------- date rows ----------

    static long dayKey(long ms) {
        Calendar c = Calendar.getInstance();
        c.setTimeInMillis(ms);
        return c.get(Calendar.YEAR) * 1000L + c.get(Calendar.DAY_OF_YEAR);
    }

    static String dayLabel(long ms) {
        long k = dayKey(ms);
        long now = System.currentTimeMillis();
        if (k == dayKey(now)) return "Сегодня";
        if (k == dayKey(now - 86400000L)) return "Вчера";
        Calendar c = Calendar.getInstance();
        c.setTimeInMillis(ms);
        int year = c.get(Calendar.YEAR);
        String pat = year == Calendar.getInstance().get(Calendar.YEAR) ? "d MMMM, EE" : "d MMMM yyyy";
        return new SimpleDateFormat(pat, RU).format(new Date(ms));
    }

    void buildRows() {
        rows.clear();
        int i = 0;
        while (i < shown.size()) {
            long k = dayKey(shown.get(i).date);
            rows.add(dayLabel(shown.get(i).date));
            int j = i;
            while (j < shown.size() && dayKey(shown.get(j).date) == k) j++;
            for (int s = i; s < j; s += cols) rows.add(new int[]{s, Math.min(j, s + cols)});
            i = j;
        }
    }

    // ---------- selection ----------

    void startSelection(int idx) {
        if (idx < 0 || idx >= shown.size()) return;
        if (!selecting) {
            selecting = true;
            selected.clear();
            buildSelActions();
            render();
        }
        dragBase = new HashSet<>(selected);
        dragBase.add(shown.get(idx).key);
        selected.add(shown.get(idx).key);
        dragAnchor = idx;
        dragActive = true;
        updateSelection();
    }

    void clearSelection() {
        selecting = false;
        dragActive = false;
        selected.clear();
        selActions.setVisibility(View.GONE);
    }

    void updateSelection() {
        if (selecting) {
            selCount.setText("Выбрано: " + selected.size());
            selActions.setVisibility(View.VISIBLE);
        } else {
            selActions.setVisibility(View.GONE);
        }
        for (int i = 0; i < list.getChildCount(); i++) {
            Object t = list.getChildAt(i).getTag();
            if (!(t instanceof RowHolder)) continue;
            for (Holder h : ((RowHolder) t).cells) bindSel(h);
        }
    }

    void bindSel(Holder h) {
        boolean on = selecting && h.key != null && selected.contains(h.key);
        h.check.setVisibility(selecting ? View.VISIBLE : View.GONE);
        h.check.setText(on ? "✓" : "");
        h.check.setBackground(on ? oval(ACC, Color.WHITE) : oval(0x44000000, Color.WHITE));
        h.dim.setVisibility(on ? View.VISIBLE : View.GONE);
    }

    GradientDrawable oval(int fill, int stroke) {
        GradientDrawable g = new GradientDrawable();
        g.setShape(GradientDrawable.OVAL);
        g.setColor(fill);
        g.setStroke(dp(2), stroke);
        return g;
    }

    List<Item> selectedItems() {
        List<Item> out = new ArrayList<>();
        for (Item it : shown) if (selected.contains(it.key)) out.add(it);
        return out;
    }

    void buildSelActions() {
        selActions.removeAllViews();
        LinearLayout move = action("📁", "Переместить");
        LinearLayout fav = action("♡", "Избранное");
        LinearLayout del = action("🗑", "Удалить");
        if (hiddenMode) {
            LinearLayout ret = action("↩", "Вернуть");
            selActions.addView(ret, lp(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
            ret.setOnClickListener(v -> {
                List<Item> l = selectedItems();
                if (l.isEmpty()) return;
                restoreItems(l);
            });
        }
        selActions.addView(move, lp(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        selActions.addView(fav, lp(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        if (!hiddenMode) {
            LinearLayout share = action("📤", "Отправить");
            selActions.addView(share, lp(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
            share.setOnClickListener(v -> shareItems(selectedItems()));
        }
        selActions.addView(del, lp(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        for (int i = 0; i < selActions.getChildCount(); i++) {
            View c = selActions.getChildAt(i);
            ((TextView) c.getTag()).setTextColor(INK);
            ((TextView) ((LinearLayout) c).getChildAt(1)).setTextColor(INK);
        }
        move.setOnClickListener(v -> {
            List<Item> l = selectedItems();
            if (!l.isEmpty()) moveDialog(l);
        });
        fav.setOnClickListener(v -> {
            List<Item> l = selectedItems();
            if (l.isEmpty()) return;
            Set<String> s = favs();
            boolean all = true;
            for (Item it : l) if (!s.contains(it.key)) { all = false; break; }
            for (Item it : l) { if (all) s.remove(it.key); else s.add(it.key); }
            prefs.edit().putStringSet("fav", s).apply();
            toast(all ? "Убрано из избранного" : "Добавлено в избранное");
            clearSelection();
            render();
        });
        del.setOnClickListener(v -> {
            List<Item> l = selectedItems();
            if (!l.isEmpty()) deleteItems(l);
        });
    }

    // ================= code =================

    static String hash(String s) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] d = md.digest(("gal-v1:" + s.trim()).getBytes(StandardCharsets.UTF_8));
            StringBuilder sb = new StringBuilder();
            for (byte x : d) sb.append(String.format("%02x", x));
            return sb.toString();
        } catch (Exception e) {
            return String.valueOf(s.trim().hashCode());
        }
    }

    boolean isCode(String s) {
        if (s == null || s.trim().isEmpty()) return false;
        return hash(s).equals(prefs.getString("code", null));
    }

    EditText field(String hint, boolean password) {
        EditText e = new EditText(this);
        e.setHint(hint);
        e.setSingleLine(true);
        e.setInputType(password ? InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD
                : InputType.TYPE_CLASS_TEXT);
        return e;
    }

    void askCode(boolean first) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(20), dp(8), dp(20), 0);
        EditText a = field(first ? "Код" : "Новый код", true);
        EditText b = field("Повторите код", true);
        TextView err = new TextView(this);
        err.setTextColor(ACC);
        err.setPadding(0, dp(4), 0, 0);
        box.addView(a);
        box.addView(b);
        box.addView(err);
        AlertDialog.Builder bld = dlg()
                .setTitle(first ? "Придумайте код" : "Сменить код")
                .setView(box)
                .setPositiveButton("Сохранить", null);
        if (first) {
            bld.setMessage("Введите его дважды и запомните.");
            bld.setCancelable(false);
        } else {
            bld.setNegativeButton("Отмена", null);
        }
        AlertDialog d = bld.create();
        if (first) d.setCanceledOnTouchOutside(false);
        d.setOnShowListener(x -> d.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
            String s1 = a.getText().toString(), s2 = b.getText().toString();
            if (s1.trim().length() < 3) { err.setText("Минимум 3 символа"); return; }
            if (!s1.equals(s2)) { err.setText("Коды не совпадают"); return; }
            prefs.edit().putString("code", hash(s1)).apply();
            d.dismiss();
            if (first) checkPermAndLoad();
            else toast("Сохранено");
        }));
        d.show();
    }

    void hideKb(View v) {
        InputMethodManager imm = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
        if (imm != null) imm.hideSoftInputFromWindow(v.getWindowToken(), 0);
    }

    void doSearch() {
        String v = search.getText().toString();
        hideKb(search);
        search.clearFocus();
        if (isCode(v)) {
            hiddenMode = true;
            tab = 0;
            curAlbum = null;
            clearSelection();
            search.setText("");
        }
        render();
    }

    // ================= permissions =================

    String[] perms() {
        if (Build.VERSION.SDK_INT >= 33)
            return new String[]{"android.permission.READ_MEDIA_IMAGES", "android.permission.READ_MEDIA_VIDEO"};
        if (Build.VERSION.SDK_INT <= 29)
            return new String[]{"android.permission.READ_EXTERNAL_STORAGE", "android.permission.WRITE_EXTERNAL_STORAGE"};
        return new String[]{"android.permission.READ_EXTERNAL_STORAGE"};
    }

    boolean granted(String p) { return checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED; }

    boolean hasPerm() {
        if (Build.VERSION.SDK_INT >= 33) {
            return granted("android.permission.READ_MEDIA_IMAGES") || granted("android.permission.READ_MEDIA_VIDEO")
                    || (Build.VERSION.SDK_INT >= 34 && granted("android.permission.READ_MEDIA_VISUAL_USER_SELECTED"));
        }
        return granted("android.permission.READ_EXTERNAL_STORAGE");
    }

    void checkPermAndLoad() {
        if (hasPerm()) loadDevice();
        else {
            render();
            requestPermissions(perms(), REQ_PERM);
        }
    }

    @Override
    public void onRequestPermissionsResult(int rc, String[] p, int[] r) {
        super.onRequestPermissionsResult(rc, p, r);
        if (hasPerm()) loadDevice();
        else {
            goSettings = !shouldShowRequestPermissionRationale(perms()[0]);
            render();
        }
    }

    // ================= data =================

    File vaultDir() {
        File d = new File(getFilesDir(), "vault");
        if (!d.exists()) d.mkdirs();
        return d;
    }

    JSONArray vaultMeta() {
        try { return new JSONArray(prefs.getString("vault", "[]")); } catch (Exception e) { return new JSONArray(); }
    }

    void saveVaultMeta(JSONArray a) { prefs.edit().putString("vault", a.toString()).apply(); }

    static long toMs(long t) { return t > 0 && t < 100000000000L ? t * 1000L : t; }

    void loadVault() {
        vault.clear();
        JSONArray a = vaultMeta();
        File dir = vaultDir();
        for (int i = 0; i < a.length(); i++) {
            JSONObject o = a.optJSONObject(i);
            if (o == null) continue;
            File f = new File(dir, o.optString("file"));
            if (!f.exists()) continue;
            Item it = new Item();
            it.vault = true;
            it.file = f;
            it.uri = Uri.fromFile(f);
            it.key = "f" + o.optString("file");
            it.video = o.optBoolean("video");
            it.name0 = o.optString("name");
            it.mime = o.optString("mime");
            it.date = toMs(o.optLong("date"));
            it.dur = o.optLong("dur");
            it.size = f.length();
            it.w = o.optInt("w");
            it.h = o.optInt("h");
            it.bucket = o.optString("bucket");
            vault.add(it);
        }
        Collections.sort(vault, (x, y) -> Long.compare(y.date, x.date));
    }

    void loadDevice() {
        loader.execute(() -> {
            List<Item> l = new ArrayList<>();
            query(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, false, l);
            query(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, true, l);
            Collections.sort(l, (x, y) -> Long.compare(y.date, x.date));
            ui.post(() -> {
                device.clear();
                device.addAll(l);
                render();
            });
        });
    }

    static int col(Cursor c, String n) { return c.getColumnIndex(n); }

    void query(Uri table, boolean video, List<Item> out) {
        List<String> p = new ArrayList<>();
        Collections.addAll(p, "_id", "_display_name", "bucket_display_name", "date_added", "mime_type",
                "datetaken", "_size", "width", "height");
        if (video) p.add("duration");
        if (Build.VERSION.SDK_INT >= 29) p.add("relative_path");
        try (Cursor c = getContentResolver().query(table, p.toArray(new String[0]), null, null, null)) {
            if (c == null) return;
            int cId = col(c, "_id"), cName = col(c, "_display_name"), cBucket = col(c, "bucket_display_name"),
                    cAdded = col(c, "date_added"), cMime = col(c, "mime_type"), cTaken = col(c, "datetaken"),
                    cSize = col(c, "_size"), cW = col(c, "width"), cH = col(c, "height"),
                    cDur = col(c, "duration"), cRel = col(c, "relative_path");
            while (c.moveToNext()) {
                Item it = new Item();
                it.id = c.getLong(cId);
                String f = cName >= 0 ? c.getString(cName) : null;
                if (f == null) f = "";
                int dot = f.lastIndexOf('.');
                it.name0 = dot > 0 ? f.substring(0, dot) : f;
                it.bucket = cBucket >= 0 ? c.getString(cBucket) : null;
                if (it.bucket == null) it.bucket = "Другое";
                long taken = cTaken >= 0 ? c.getLong(cTaken) : 0;
                long added = cAdded >= 0 ? c.getLong(cAdded) : 0;
                it.date = taken > 0 ? taken : added * 1000L;
                it.mime = cMime >= 0 ? c.getString(cMime) : null;
                if (it.mime == null) it.mime = video ? "video/mp4" : "image/jpeg";
                it.video = video;
                if (cDur >= 0) it.dur = c.getLong(cDur);
                if (cSize >= 0) it.size = c.getLong(cSize);
                if (cW >= 0) it.w = c.getInt(cW);
                if (cH >= 0) it.h = c.getInt(cH);
                if (cRel >= 0) {
                    String r = c.getString(cRel);
                    it.rel = r == null ? "" : r;
                }
                it.uri = ContentUris.withAppendedId(table, it.id);
                it.key = (video ? "v" : "i") + it.id;
                out.add(it);
            }
        } catch (Exception e) {
            // ignore
        }
    }

    List<Item> modeItems() { return hiddenMode ? vault : device; }

    String name(Item it) {
        String n = prefs.getString("n_" + it.key, null);
        return n != null ? n : it.name0;
    }

    Set<String> favs() { return new HashSet<>(prefs.getStringSet("fav", new HashSet<>())); }

    boolean isFav(Item it) { return favs().contains(it.key); }

    void toggleFav(Item it) {
        Set<String> s = favs();
        if (!s.remove(it.key)) s.add(it.key);
        prefs.edit().putStringSet("fav", s).apply();
    }

    String albumsKey() { return hiddenMode ? "alb_h" : "alb_n"; }

    JSONArray albums() {
        try { return new JSONArray(prefs.getString(albumsKey(), "[]")); } catch (Exception e) { return new JSONArray(); }
    }

    void saveAlbums(JSONArray a) { prefs.edit().putString(albumsKey(), a.toString()).apply(); }

    boolean inAlbum(JSONObject al, String key) {
        JSONArray k = al.optJSONArray("items");
        if (k == null) return false;
        for (int i = 0; i < k.length(); i++) if (key.equals(k.optString(i))) return true;
        return false;
    }

    /** Move items into user album #index: remove them from the other albums of this mode first. */
    void moveToUserAlbum(int index, List<Item> items) {
        try {
            Set<String> keys = new HashSet<>();
            for (Item it : items) keys.add(it.key);
            JSONArray a = albums();
            for (int i = 0; i < a.length(); i++) {
                JSONObject al = a.getJSONObject(i);
                JSONArray k = al.optJSONArray("items");
                JSONArray nk = new JSONArray();
                if (k != null) for (int j = 0; j < k.length(); j++) if (!keys.contains(k.optString(j))) nk.put(k.optString(j));
                if (i == index) for (Item it : items) nk.put(it.key);
                al.put("items", nk);
            }
            saveAlbums(a);
            toast("Перемещено в «" + a.getJSONObject(index).optString("name") + "»: " + items.size());
        } catch (Exception e) {
            toast("Ошибка");
        }
    }

    int createAlbum(String n) {
        try {
            JSONArray a = albums();
            JSONObject o = new JSONObject();
            o.put("name", n);
            o.put("items", new JSONArray());
            a.put(o);
            saveAlbums(a);
            return a.length() - 1;
        } catch (Exception e) {
            return -1;
        }
    }

    /** Remove a key from favourites, names and all albums (both modes). */
    void forgetKey(String key) {
        Set<String> s = favs();
        s.remove(key);
        SharedPreferences.Editor ed = prefs.edit().putStringSet("fav", s).remove("n_" + key);
        for (String ak : new String[]{"alb_n", "alb_h"}) {
            try {
                JSONArray a = new JSONArray(prefs.getString(ak, "[]"));
                for (int i = 0; i < a.length(); i++) {
                    JSONObject al = a.getJSONObject(i);
                    JSONArray k = al.optJSONArray("items");
                    if (k == null) continue;
                    JSONArray nk = new JSONArray();
                    for (int j = 0; j < k.length(); j++) if (!key.equals(k.optString(j))) nk.put(k.optString(j));
                    al.put("items", nk);
                }
                ed.putString(ak, a.toString());
            } catch (Exception e) {
                // ignore
            }
        }
        ed.apply();
    }

    List<Item> albumItems(AlbumRef r) {
        List<Item> out = new ArrayList<>();
        List<Item> src = modeItems();
        if (r.type == A_FAV) {
            Set<String> f = favs();
            for (Item it : src) if (f.contains(it.key)) out.add(it);
        } else if (r.type == A_BUCKET) {
            for (Item it : src) if (r.name.equals(it.bucket)) out.add(it);
        } else if (r.type == A_USER) {
            JSONObject al = albums().optJSONObject(r.index);
            if (al != null) {
                Set<String> keys = new HashSet<>();
                JSONArray k = al.optJSONArray("items");
                if (k != null) for (int i = 0; i < k.length(); i++) keys.add(k.optString(i));
                for (Item it : src) if (keys.contains(it.key)) out.add(it);
                r.name = al.optString("name");
            }
        }
        return out;
    }

    void buildAlbumCards() {
        albumCards.clear();
        AlbumRef fav = new AlbumRef();
        fav.type = A_FAV;
        fav.name = "♥ Избранное";
        List<Item> fl = albumItems(fav);
        fav.count = fl.size();
        fav.cover = fl.isEmpty() ? null : fl.get(0);
        albumCards.add(fav);
        JSONArray a = albums();
        for (int i = 0; i < a.length(); i++) {
            AlbumRef r = new AlbumRef();
            r.type = A_USER;
            r.index = i;
            List<Item> l = albumItems(r);
            r.count = l.size();
            r.cover = l.isEmpty() ? null : l.get(0);
            albumCards.add(r);
        }
        if (!hiddenMode) albumCards.addAll(bucketRefs());
        AlbumRef add = new AlbumRef();
        add.type = A_ADD;
        add.name = "Новый альбом";
        albumCards.add(add);
    }

    List<AlbumRef> bucketRefs() {
        LinkedHashMap<String, AlbumRef> buckets = new LinkedHashMap<>();
        for (Item it : device) {
            AlbumRef r = buckets.get(it.bucket);
            if (r == null) {
                r = new AlbumRef();
                r.type = A_BUCKET;
                r.name = it.bucket;
                r.cover = it;
                r.rel = it.rel;
                buckets.put(it.bucket, r);
            }
            r.count++;
        }
        return new ArrayList<>(buckets.values());
    }

    void newAlbum(Item addItem) {
        EditText e = field("Название альбома", false);
        FrameLayout box = new FrameLayout(this);
        box.setPadding(dp(20), dp(8), dp(20), 0);
        box.addView(e);
        dlg().setTitle("Новый альбом").setView(box)
                .setNegativeButton("Отмена", null)
                .setPositiveButton("Создать", (x, w) -> {
                    String n = e.getText().toString().trim();
                    if (n.isEmpty() || isCode(n)) return;
                    int idx = createAlbum(n);
                    if (idx >= 0 && addItem != null) {
                        List<Item> l = new ArrayList<>();
                        l.add(addItem);
                        moveToUserAlbum(idx, l);
                    }
                    render();
                }).show();
    }

    void albumMenu() {
        if (curAlbum == null || curAlbum.type != A_USER) return;
        final int idx = curAlbum.index;
        dlg().setTitle(curAlbum.name)
                .setItems(new String[]{"Переименовать альбом", "Удалить альбом"}, (x, which) -> {
                    if (which == 0) {
                        EditText e = field("Название", false);
                        e.setText(curAlbum.name);
                        FrameLayout box = new FrameLayout(this);
                        box.setPadding(dp(20), dp(8), dp(20), 0);
                        box.addView(e);
                        dlg().setTitle("Переименовать").setView(box).setNegativeButton("Отмена", null)
                                .setPositiveButton("Сохранить", (y, w) -> {
                                    String n = e.getText().toString().trim();
                                    if (n.isEmpty() || isCode(n)) return;
                                    try {
                                        JSONArray a = albums();
                                        a.getJSONObject(idx).put("name", n);
                                        saveAlbums(a);
                                        if (curAlbum != null) curAlbum.name = n;
                                    } catch (Exception ex) {
                                        toast("Ошибка");
                                    }
                                    render();
                                }).show();
                    } else {
                        dlg().setTitle("Удалить альбом?")
                                .setMessage("Сами фото и видео останутся в галерее.")
                                .setNegativeButton("Отмена", null)
                                .setPositiveButton("Удалить", (y, w) -> {
                                    JSONArray a = albums();
                                    JSONArray na = new JSONArray();
                                    for (int i = 0; i < a.length(); i++) if (i != idx) na.put(a.opt(i));
                                    saveAlbums(na);
                                    curAlbum = null;
                                    render();
                                }).show();
                    }
                }).show();
    }

    // ================= move dialog =================

    void moveDialog(List<Item> items) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(16), dp(8), dp(16), 0);
        LinearLayout row = new LinearLayout(this);
        EditText q = field("Найти альбом", false);
        q.setImeOptions(EditorInfo.IME_ACTION_SEARCH);
        row.addView(q, lp(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        Button go = btn("Поиск", ACC, Color.WHITE);
        go.setTextSize(13);
        row.addView(go, lp(ViewGroup.LayoutParams.WRAP_CONTENT, dp(42), 0));
        box.addView(row);
        ListView lv = new ListView(this);
        box.addView(lv, lp(-1, dp(320), 0));

        final List<AlbumRef> all = new ArrayList<>();
        JSONArray a = albums();
        for (int i = 0; i < a.length(); i++) {
            AlbumRef r = new AlbumRef();
            r.type = A_USER;
            r.index = i;
            JSONObject o = a.optJSONObject(i);
            r.name = o == null ? "Альбом" : o.optString("name");
            all.add(r);
        }
        if (!hiddenMode) all.addAll(bucketRefs());
        final List<AlbumRef> vis = new ArrayList<>();
        final List<String> labels = new ArrayList<>();
        ArrayAdapter<String> ad = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, labels);
        lv.setAdapter(ad);

        AlertDialog d = dlg().setTitle("Переместить (" + items.size() + ")").setView(box)
                .setNegativeButton("Отмена", null).create();

        Runnable refill = () -> {
            String t = q.getText().toString().trim();
            String tl = t.toLowerCase();
            vis.clear();
            labels.clear();
            boolean exact = false;
            if (!isCode(t)) {
                for (AlbumRef r : all) {
                    if (tl.isEmpty() || r.name.toLowerCase().contains(tl)) {
                        vis.add(r);
                        labels.add((r.type == A_USER ? "🗂 " : "📁 ") + r.name);
                    }
                    if (r.name.equalsIgnoreCase(t)) exact = true;
                }
                if (!t.isEmpty() && !exact) {
                    AlbumRef n = new AlbumRef();
                    n.type = A_ADD;
                    n.name = t;
                    vis.add(0, n);
                    labels.add(0, "＋ Создать альбом «" + t + "»");
                }
            }
            ad.notifyDataSetChanged();
        };
        refill.run();
        q.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence s, int x, int y, int z) { }
            public void onTextChanged(CharSequence s, int x, int y, int z) { }
            public void afterTextChanged(Editable s) { refill.run(); }
        });
        Runnable submit = () -> {
            String t = q.getText().toString();
            hideKb(q);
            if (!hiddenMode && isCode(t)) {
                d.dismiss();
                clearSelection();
                render();
                hideItems(items);
            }
        };
        go.setOnClickListener(v -> submit.run());
        q.setOnEditorActionListener((v, act, ev) -> { submit.run(); return true; });
        lv.setOnItemClickListener((p, v, pos, id) -> {
            if (pos >= vis.size()) return;
            AlbumRef r = vis.get(pos);
            d.dismiss();
            if (r.type == A_ADD) {
                int idx = createAlbum(r.name);
                if (idx >= 0) moveToUserAlbum(idx, items);
            } else if (r.type == A_USER) {
                moveToUserAlbum(r.index, items);
            } else if (r.type == A_BUCKET) {
                moveToFolder(items, r);
                return;
            }
            clearSelection();
            render();
            if (vd != null) updateBars();
        });
        d.show();
    }

    void moveToFolder(List<Item> items, AlbumRef r) {
        if (Build.VERSION.SDK_INT < 29 || r.rel == null || r.rel.isEmpty()) {
            toast("На этом телефоне перенос в папки недоступен");
            return;
        }
        List<Item> l = new ArrayList<>();
        for (Item it : items) if (!it.vault && !r.rel.equals(it.rel)) l.add(it);
        if (l.isEmpty()) { toast("Уже в этой папке"); return; }
        pendMove = l;
        pendMoveRel = r.rel;
        if (Build.VERSION.SDK_INT >= 30) {
            try {
                List<Uri> uris = new ArrayList<>();
                for (Item it : l) uris.add(it.uri);
                PendingIntent pi = MediaStore.createWriteRequest(getContentResolver(), uris);
                startIntentSenderForResult(pi.getIntentSender(), REQ_MOVE, null, 0, 0, 0);
            } catch (IntentSender.SendIntentException | RuntimeException e) {
                pendMove = null;
                toast("Не удалось переместить");
            }
        } else {
            doMove();
        }
    }

    void doMove() {
        List<Item> l = pendMove;
        String rel = pendMoveRel;
        pendMove = null;
        if (l == null) return;
        showProgress("Перемещаю…");
        loader.execute(() -> {
            int ok = 0, n = 0;
            ContentResolver cr = getContentResolver();
            for (Item it : l) {
                n++;
                progressMsg("Перемещаю " + n + " из " + l.size());
                try {
                    ContentValues v = new ContentValues();
                    v.put("relative_path", rel);
                    if (cr.update(it.uri, v, null, null) > 0) ok++;
                } catch (Exception e) {
                    // ignore
                }
            }
            final int fok = ok;
            ui.post(() -> {
                hideProgress();
                toast(fok == l.size() ? "Перемещено: " + fok : "Перемещено " + fok + " из " + l.size());
                clearSelection();
                closeViewer();
                loadDevice();
            });
        });
    }

    // ================= thumbnails =================

    Bitmap thumb(Item it) {
        try {
            if (it.vault) {
                if (Build.VERSION.SDK_INT >= 29) {
                    return it.video ? ThumbnailUtils.createVideoThumbnail(it.file, new Size(320, 320), null)
                            : ThumbnailUtils.createImageThumbnail(it.file, new Size(320, 320), null);
                }
                if (it.video)
                    return ThumbnailUtils.createVideoThumbnail(it.file.getAbsolutePath(), MediaStore.Images.Thumbnails.MINI_KIND);
                return decodeFile(it.file, 320);
            }
            if (Build.VERSION.SDK_INT >= 29)
                return getContentResolver().loadThumbnail(it.uri, new Size(320, 320), null);
            if (it.video)
                return MediaStore.Video.Thumbnails.getThumbnail(getContentResolver(), it.id,
                        MediaStore.Video.Thumbnails.MINI_KIND, null);
            return MediaStore.Images.Thumbnails.getThumbnail(getContentResolver(), it.id,
                    MediaStore.Images.Thumbnails.MINI_KIND, null);
        } catch (Throwable e) {
            return null;
        }
    }

    Bitmap decodeFile(File f, int max) {
        BitmapFactory.Options o = new BitmapFactory.Options();
        o.inJustDecodeBounds = true;
        BitmapFactory.decodeFile(f.getAbsolutePath(), o);
        int sample = 1;
        while (Math.max(o.outWidth, o.outHeight) / sample > max * 2) sample *= 2;
        BitmapFactory.Options o2 = new BitmapFactory.Options();
        o2.inSampleSize = sample;
        return BitmapFactory.decodeFile(f.getAbsolutePath(), o2);
    }

    Bitmap full(Item it) {
        try {
            if (Build.VERSION.SDK_INT >= 28) {
                ImageDecoder.Source src = it.vault ? ImageDecoder.createSource(it.file)
                        : ImageDecoder.createSource(getContentResolver(), it.uri);
                return ImageDecoder.decodeBitmap(src, (dec, inf, s) -> {
                    int w = inf.getSize().getWidth(), hh = inf.getSize().getHeight();
                    int m = Math.max(w, hh);
                    if (m > 2560) {
                        float r = 2560f / m;
                        dec.setTargetSize(Math.max(1, Math.round(w * r)), Math.max(1, Math.round(hh * r)));
                    }
                });
            }
            if (it.vault) return decodeFile(it.file, 1280);
            BitmapFactory.Options o = new BitmapFactory.Options();
            o.inJustDecodeBounds = true;
            try (InputStream in = getContentResolver().openInputStream(it.uri)) {
                BitmapFactory.decodeStream(in, null, o);
            }
            int sample = 1;
            while (Math.max(o.outWidth, o.outHeight) / sample > 2560) sample *= 2;
            BitmapFactory.Options o2 = new BitmapFactory.Options();
            o2.inSampleSize = sample;
            try (InputStream in = getContentResolver().openInputStream(it.uri)) {
                return BitmapFactory.decodeStream(in, null, o2);
            }
        } catch (Throwable e) {
            return thumb(it);
        }
    }

    void bindThumb(Holder h, Item it) {
        final String k = it.key;
        h.key = k;
        Bitmap bm = cache.get(k);
        if (bm != null) {
            h.img.setImageBitmap(bm);
            return;
        }
        h.img.setImageDrawable(null);
        final Holder fh = h;
        pool.execute(() -> {
            if (!k.equals(fh.key)) return;
            Bitmap t = thumb(it);
            if (t != null) cache.put(k, t);
            ui.post(() -> { if (k.equals(fh.key) && t != null) fh.img.setImageBitmap(t); });
        });
    }

    // ================= adapters =================

    Holder makeCell(FrameLayout f) {
        f.setBackground(round(CARD, 3));
        f.setClipToOutline(true);
        Holder h = new Holder();
        h.img = new ImageView(this);
        h.img.setScaleType(ImageView.ScaleType.CENTER_CROP);
        f.addView(h.img, new FrameLayout.LayoutParams(-1, -1));
        h.dim = new View(this);
        h.dim.setBackgroundColor(0x66000000);
        h.dim.setVisibility(View.GONE);
        f.addView(h.dim, new FrameLayout.LayoutParams(-1, -1));
        h.badge = new TextView(this);
        h.badge.setTextColor(Color.WHITE);
        h.badge.setTextSize(11);
        h.badge.setTypeface(Typeface.DEFAULT_BOLD);
        h.badge.setShadowLayer(4, 0, 0, Color.BLACK);
        h.badge.setPadding(dp(5), dp(3), dp(5), dp(3));
        f.addView(h.badge, new FrameLayout.LayoutParams(-2, -2, Gravity.TOP | Gravity.END));
        h.fav = new TextView(this);
        h.fav.setText("♥");
        h.fav.setTextColor(Color.WHITE);
        h.fav.setTextSize(13);
        h.fav.setShadowLayer(4, 0, 0, Color.BLACK);
        h.fav.setPadding(dp(5), dp(3), dp(5), dp(3));
        f.addView(h.fav, new FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM | Gravity.START));
        h.check = new TextView(this);
        h.check.setTextColor(Color.WHITE);
        h.check.setTextSize(13);
        h.check.setTypeface(Typeface.DEFAULT_BOLD);
        h.check.setGravity(Gravity.CENTER);
        FrameLayout.LayoutParams cp = new FrameLayout.LayoutParams(dp(24), dp(24), Gravity.TOP | Gravity.START);
        cp.leftMargin = dp(5);
        cp.topMargin = dp(5);
        f.addView(h.check, cp);
        h.check.setVisibility(View.GONE);
        f.setTag(h);
        f.setOnClickListener(v -> onCellTap(((Holder) v.getTag()).idx));
        f.setOnLongClickListener(v -> {
            v.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS);
            startSelection(((Holder) v.getTag()).idx);
            return true;
        });
        return h;
    }

    void onCellTap(int idx) {
        if (idx < 0 || idx >= shown.size()) return;
        if (selecting) {
            String k = shown.get(idx).key;
            if (!selected.remove(k)) selected.add(k);
            updateSelection();
        } else {
            openViewer(new ArrayList<>(shown), idx);
        }
    }

    class RowAdapter extends BaseAdapter {
        public int getCount() { return rows.size(); }
        public Object getItem(int p) { return rows.get(p); }
        public long getItemId(int p) { return p; }
        public int getViewTypeCount() { return 2; }
        public int getItemViewType(int p) { return rows.get(p) instanceof String ? 0 : 1; }
        public boolean isEnabled(int p) { return false; }
        public boolean areAllItemsEnabled() { return false; }

        public View getView(int pos, View cv, ViewGroup parent) {
            Object r = rows.get(pos);
            if (r instanceof String) {
                TextView t = cv instanceof TextView ? (TextView) cv : null;
                if (t == null) {
                    t = new TextView(MainActivity.this);
                    t.setTextColor(INK);
                    t.setTextSize(15);
                    t.setTypeface(Typeface.DEFAULT_BOLD);
                    t.setPadding(dp(6), dp(16), dp(6), dp(8));
                }
                t.setText((String) r);
                return t;
            }
            int[] range = (int[]) r;
            RowHolder rh = cv != null && cv.getTag() instanceof RowHolder ? (RowHolder) cv.getTag() : null;
            if (rh == null || rh.cols != cols) {
                LinearLayout row = new LinearLayout(MainActivity.this);
                rh = new RowHolder();
                rh.cols = cols;
                rh.frames = new FrameLayout[cols];
                rh.cells = new Holder[cols];
                for (int c = 0; c < cols; c++) {
                    SquareFrame f = new SquareFrame(MainActivity.this);
                    LinearLayout.LayoutParams p = lp(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1);
                    p.setMargins(dp(1.5f), dp(1.5f), dp(1.5f), dp(1.5f));
                    row.addView(f, p);
                    rh.frames[c] = f;
                    rh.cells[c] = makeCell(f);
                }
                row.setTag(rh);
                cv = row;
            }
            for (int c = 0; c < cols; c++) {
                int idx = range[0] + c;
                Holder h = rh.cells[c];
                if (idx < range[1]) {
                    rh.frames[c].setVisibility(View.VISIBLE);
                    Item it = shown.get(idx);
                    h.idx = idx;
                    h.badge.setText(it.video ? "▶ " + fmtDur(it.dur) : "");
                    h.badge.setVisibility(it.video ? View.VISIBLE : View.GONE);
                    h.fav.setVisibility(isFav(it) ? View.VISIBLE : View.GONE);
                    bindThumb(h, it);
                    bindSel(h);
                } else {
                    rh.frames[c].setVisibility(View.INVISIBLE);
                    h.idx = -1;
                    h.key = null;
                }
            }
            return cv;
        }
    }

    class AlbumAdapter extends BaseAdapter {
        public int getCount() { return albumCards.size(); }
        public Object getItem(int p) { return albumCards.get(p); }
        public long getItemId(int p) { return p; }

        public View getView(int pos, View cv, ViewGroup parent) {
            Holder h;
            if (cv == null || !(cv.getTag() instanceof Holder)) {
                LinearLayout col = new LinearLayout(MainActivity.this);
                col.setOrientation(LinearLayout.VERTICAL);
                SquareFrame f = new SquareFrame(MainActivity.this);
                f.setBackground(round(CARD, 14));
                f.setClipToOutline(true);
                h = new Holder();
                h.img = new ImageView(MainActivity.this);
                h.img.setScaleType(ImageView.ScaleType.CENTER_CROP);
                f.addView(h.img, new FrameLayout.LayoutParams(-1, -1));
                h.badge = new TextView(MainActivity.this);
                h.badge.setTextColor(MUTE);
                h.badge.setTextSize(42);
                h.badge.setGravity(Gravity.CENTER);
                f.addView(h.badge, new FrameLayout.LayoutParams(-1, -1));
                col.addView(f, new LinearLayout.LayoutParams(-1, -2));
                h.title = new TextView(MainActivity.this);
                h.title.setTextColor(INK);
                h.title.setTextSize(15);
                h.title.setTypeface(Typeface.DEFAULT_BOLD);
                h.title.setSingleLine(true);
                h.title.setEllipsize(TextUtils.TruncateAt.END);
                h.title.setPadding(dp(2), dp(6), 0, 0);
                col.addView(h.title);
                h.count = new TextView(MainActivity.this);
                h.count.setTextColor(MUTE);
                h.count.setTextSize(13);
                h.count.setPadding(dp(2), 0, 0, 0);
                col.addView(h.count);
                col.setTag(h);
                cv = col;
            } else {
                h = (Holder) cv.getTag();
            }
            AlbumRef r = albumCards.get(pos);
            if (r.name == null) r.name = "Альбом";
            h.title.setText(r.name);
            h.count.setText(r.type == A_ADD ? "" : String.valueOf(r.count));
            if (r.cover != null) {
                h.badge.setText("");
                bindThumb(h, r.cover);
            } else {
                h.key = null;
                h.img.setImageDrawable(null);
                h.badge.setText(r.type == A_ADD ? "+" : (r.type == A_FAV ? "♥" : "▢"));
            }
            return cv;
        }
    }

    // ================= viewer =================

    Dialog vd;
    List<Item> vList;
    int vPos;
    FrameLayout stage;
    LinearLayout vTop, vBottomWrap, vControls;
    LinearLayout aFav;
    TextView vName, vTime, vSeekHint;
    Button vPlay, vMute;
    SeekBar vSeek;
    VideoView curVideo;
    MediaPlayer curMp;
    boolean barsOn = true, muted = false, landscape = false;
    final Runnable ticker = new Runnable() {
        @Override
        public void run() {
            if (curVideo != null && vd != null) {
                try {
                    int d = curVideo.getDuration();
                    int p = curVideo.getCurrentPosition();
                    if (d > 0) {
                        vSeek.setMax(d);
                        vSeek.setProgress(p);
                        vTime.setText(fmtDur(p) + " / " + fmtDur(d));
                    }
                    vPlay.setText(curVideo.isPlaying() ? "❚❚" : "▶");
                } catch (Exception e) {
                    // ignore
                }
                ui.postDelayed(this, 300);
            }
        }
    };

    Button vBtn(String t) {
        Button b = btn(t, 0x26FFFFFF, Color.WHITE);
        b.setTextSize(14);
        return b;
    }

    void openViewer(List<Item> l, int pos) {
        closeViewer();
        vList = l;
        vPos = pos;
        Dialog d = new Dialog(this, android.R.style.Theme_Black_NoTitleBar_Fullscreen);
        vd = d;
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.BLACK);
        stage = new FrameLayout(this);
        root.addView(stage, new FrameLayout.LayoutParams(-1, -1));

        vSeekHint = new TextView(this);
        vSeekHint.setTextColor(Color.WHITE);
        vSeekHint.setTextSize(18);
        vSeekHint.setTypeface(Typeface.DEFAULT_BOLD);
        vSeekHint.setBackground(round(0x88000000, 24));
        vSeekHint.setPadding(dp(16), dp(8), dp(16), dp(8));
        vSeekHint.setVisibility(View.GONE);
        root.addView(vSeekHint, new FrameLayout.LayoutParams(-2, -2, Gravity.CENTER));

        vTop = new LinearLayout(this);
        vTop.setGravity(Gravity.CENTER_VERTICAL);
        vTop.setBackgroundColor(0x88000000);
        vTop.setPadding(dp(8), dp(8), dp(8), dp(8));
        Button back = vBtn("←");
        vTop.addView(back, lp(dp(48), dp(44), 0));
        vName = new TextView(this);
        vName.setTextColor(Color.WHITE);
        vName.setTextSize(16);
        vName.setTypeface(Typeface.DEFAULT_BOLD);
        vName.setSingleLine(true);
        vName.setEllipsize(TextUtils.TruncateAt.END);
        vName.setPadding(dp(12), 0, dp(8), 0);
        vTop.addView(vName, lp(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        Button infoBtn = vBtn("ⓘ");
        vTop.addView(infoBtn, lp(dp(48), dp(44), 0));
        root.addView(vTop, new FrameLayout.LayoutParams(-1, -2, Gravity.TOP));

        vBottomWrap = new LinearLayout(this);
        vBottomWrap.setOrientation(LinearLayout.VERTICAL);
        vBottomWrap.setBackgroundColor(0x88000000);
        vControls = new LinearLayout(this);
        vControls.setGravity(Gravity.CENTER_VERTICAL);
        vControls.setPadding(dp(8), dp(6), dp(8), 0);
        vPlay = vBtn("▶");
        vControls.addView(vPlay, lp(dp(46), dp(40), 0));
        vSeek = new SeekBar(this);
        vControls.addView(vSeek, lp(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        vTime = new TextView(this);
        vTime.setTextColor(Color.WHITE);
        vTime.setTextSize(12);
        vControls.addView(vTime);
        vMute = vBtn(muted ? "🔇" : "🔊");
        LinearLayout.LayoutParams mp = lp(dp(46), dp(40), 0);
        mp.leftMargin = dp(6);
        vControls.addView(vMute, mp);
        Button rot = vBtn("⟳");
        LinearLayout.LayoutParams rp = lp(dp(46), dp(40), 0);
        rp.leftMargin = dp(6);
        vControls.addView(rot, rp);
        vBottomWrap.addView(vControls);

        LinearLayout actions = new LinearLayout(this);
        actions.setPadding(dp(4), dp(4), dp(4), dp(10));
        vBottomWrap.addView(actions);
        root.addView(vBottomWrap, new FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM));

        aFav = action("♡", "Избранное");
        LinearLayout aMove = action("📁", "Переместить");
        LinearLayout aName = action("✏", "Имя");
        LinearLayout aDel = action("🗑", "Удалить");
        LinearLayout aExtra = hiddenMode ? action("↩", "Вернуть") : action("📤", "Отправить");
        actions.addView(aFav, lp(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        if (hiddenMode) actions.addView(aExtra, lp(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        actions.addView(aMove, lp(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        actions.addView(aName, lp(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        if (!hiddenMode) actions.addView(aExtra, lp(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        actions.addView(aDel, lp(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));

        back.setOnClickListener(x -> d.dismiss());
        infoBtn.setOnClickListener(x -> showInfo());
        aFav.setOnClickListener(x -> {
            Item it = curItem();
            if (it == null) return;
            toggleFav(it);
            updateBars();
            render();
        });
        aMove.setOnClickListener(x -> {
            Item it = curItem();
            if (it == null) return;
            List<Item> one = new ArrayList<>();
            one.add(it);
            moveDialog(one);
        });
        aName.setOnClickListener(x -> rename());
        aExtra.setOnClickListener(x -> {
            Item it = curItem();
            if (it == null) return;
            List<Item> one = new ArrayList<>();
            one.add(it);
            if (hiddenMode) restoreItems(one);
            else shareItems(one);
        });
        aDel.setOnClickListener(x -> {
            Item it = curItem();
            if (it == null) return;
            List<Item> one = new ArrayList<>();
            one.add(it);
            deleteItems(one);
        });
        vPlay.setOnClickListener(x -> {
            if (curVideo == null) return;
            if (curVideo.isPlaying()) curVideo.pause(); else curVideo.start();
        });
        vMute.setOnClickListener(x -> {
            muted = !muted;
            vMute.setText(muted ? "🔇" : "🔊");
            applyMute();
        });
        rot.setOnClickListener(x -> {
            landscape = !landscape;
            setRequestedOrientation(landscape ? ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
                    : ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED);
        });
        vSeek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar s, int p, boolean user) {
                if (user && curVideo != null) curVideo.seekTo(p);
            }
            public void onStartTrackingTouch(SeekBar s) { }
            public void onStopTrackingTouch(SeekBar s) { }
        });

        d.setOnDismissListener(x -> {
            stopVideo();
            if (landscape) {
                landscape = false;
                setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED);
            }
            if (vd == d) vd = null;
        });
        d.setContentView(root);
        if (hiddenMode && d.getWindow() != null)
            d.getWindow().addFlags(WindowManager.LayoutParams.FLAG_SECURE);
        barsOn = true;
        d.show();
        showPage(0);
    }

    void applyMute() {
        if (curMp != null) {
            try {
                float v = muted ? 0f : 1f;
                curMp.setVolume(v, v);
            } catch (Exception e) {
                // ignore
            }
        }
    }

    Item curItem() {
        if (vList == null || vPos < 0 || vPos >= vList.size()) return null;
        return vList.get(vPos);
    }

    void closeViewer() {
        if (vd != null) {
            Dialog d = vd;
            vd = null;
            d.dismiss();
        }
    }

    void stopVideo() {
        if (curVideo != null) {
            try { curVideo.stopPlayback(); } catch (Exception e) { /* ignore */ }
            curVideo = null;
        }
        curMp = null;
        ui.removeCallbacks(ticker);
    }

    void toggleBars() {
        barsOn = !barsOn;
        vTop.setVisibility(barsOn ? View.VISIBLE : View.GONE);
        vBottomWrap.setVisibility(barsOn ? View.VISIBLE : View.GONE);
    }

    void swipe(int dir) {
        int np = vPos + dir;
        if (vList == null || np < 0 || np >= vList.size()) return;
        vPos = np;
        showPage(dir);
    }

    void updateBars() {
        Item it = curItem();
        if (it == null || vName == null) return;
        vName.setText(name(it) + "   " + (vPos + 1) + "/" + vList.size());
        boolean f = isFav(it);
        setActionIcon(aFav, f ? "♥" : "♡");
        ((TextView) aFav.getTag()).setTextColor(f ? ACC : Color.WHITE);
        vControls.setVisibility(it.video ? View.VISIBLE : View.GONE);
    }

    void flashHint(String t) {
        vSeekHint.setText(t);
        vSeekHint.setVisibility(View.VISIBLE);
        ui.removeCallbacks(hideHint);
        ui.postDelayed(hideHint, 700);
    }

    final Runnable hideHint = () -> { if (vSeekHint != null) vSeekHint.setVisibility(View.GONE); };

    void showPage(int dir) {
        stopVideo();
        stage.removeAllViews();
        Item it = curItem();
        if (it == null) { closeViewer(); return; }
        View page;
        if (it.video) {
            FrameLayout f = new FrameLayout(this);
            VideoView vv = new VideoView(this);
            curVideo = vv;
            if (it.vault) vv.setVideoPath(it.file.getAbsolutePath());
            else vv.setVideoURI(it.uri);
            vv.setOnPreparedListener(mpl -> {
                curMp = mpl;
                applyMute();
                vv.start();
                ui.removeCallbacks(ticker);
                ui.post(ticker);
            });
            vv.setOnCompletionListener(mpl -> vPlay.setText("▶"));
            vv.setOnErrorListener((mpl, what, extra) -> {
                toast("Не удалось воспроизвести видео");
                return true;
            });
            // MATCH_PARENT: VideoView scales the video to fit the screen and keeps its proportions
            f.addView(vv, new FrameLayout.LayoutParams(-1, -1, Gravity.CENTER));
            View touch = new View(this);
            GestureDetector gd = new GestureDetector(this, new GestureDetector.SimpleOnGestureListener() {
                @Override
                public boolean onDown(MotionEvent e) { return true; }

                @Override
                public boolean onSingleTapConfirmed(MotionEvent e) {
                    toggleBars();
                    return true;
                }

                @Override
                public boolean onDoubleTap(MotionEvent e) {
                    float w = touch.getWidth();
                    if (w <= 0) return true;
                    if (e.getX() < w / 3f) {
                        vv.seekTo(Math.max(0, vv.getCurrentPosition() - 10000));
                        flashHint("⏪ 10 с");
                    } else if (e.getX() > w * 2f / 3f) {
                        vv.seekTo(Math.min(vv.getDuration(), vv.getCurrentPosition() + 10000));
                        flashHint("10 с ⏩");
                    } else {
                        if (vv.isPlaying()) { vv.pause(); flashHint("❚❚"); }
                        else { vv.start(); flashHint("▶"); }
                    }
                    return true;
                }

                @Override
                public boolean onFling(MotionEvent e1, MotionEvent e2, float vx, float vy) {
                    if (Math.abs(vx) > Math.abs(vy) && Math.abs(vx) > 600) {
                        swipe(vx < 0 ? 1 : -1);
                        return true;
                    }
                    return false;
                }
            });
            touch.setOnTouchListener((x, e) -> gd.onTouchEvent(e));
            f.addView(touch, new FrameLayout.LayoutParams(-1, -1));
            page = f;
        } else {
            ZoomImageView iv = new ZoomImageView(this);
            iv.listener = new ZoomImageView.Listener() {
                public void onSwipe(int d) { swipe(d); }
                public void onTap() { toggleBars(); }
            };
            Bitmap t = cache.get(it.key);
            if (t != null) iv.setImageBitmap(t);
            final int myPos = vPos;
            final Dialog myD = vd;
            pool.execute(() -> {
                Bitmap bm = full(it);
                ui.post(() -> { if (bm != null && vd == myD && vPos == myPos) iv.setImageBitmap(bm); });
            });
            page = iv;
        }
        stage.addView(page, new FrameLayout.LayoutParams(-1, -1));
        if (dir != 0 && stage.getWidth() > 0) {
            page.setTranslationX(dir * stage.getWidth() * 0.35f);
            page.setAlpha(0.3f);
            page.animate().translationX(0).alpha(1f).setDuration(180).start();
        }
        updateBars();
    }

    void showInfo() {
        Item it = curItem();
        if (it == null) return;
        StringBuilder sb = new StringBuilder();
        sb.append("Имя: ").append(name(it)).append('\n');
        sb.append("Дата: ").append(new SimpleDateFormat("d MMMM yyyy, HH:mm", RU).format(new Date(it.date))).append('\n');
        sb.append("Размер: ").append(fmtSize(it.size)).append('\n');
        if (it.w > 0 && it.h > 0) sb.append("Разрешение: ").append(it.w).append(" × ").append(it.h).append('\n');
        if (it.video) sb.append("Длительность: ").append(fmtDur(it.dur)).append('\n');
        if (!it.vault) sb.append("Папка: ").append(it.bucket).append('\n');
        sb.append("Тип: ").append(it.mime);
        dlg().setTitle("Сведения").setMessage(sb.toString()).setPositiveButton("OK", null).show();
    }

    /** After items disappear from the current list. */
    void afterRemoved(List<Item> gone) {
        if (vList != null && vd != null) {
            vList.removeAll(gone);
            if (vList.isEmpty()) closeViewer();
            else {
                if (vPos >= vList.size()) vPos = vList.size() - 1;
                showPage(0);
            }
        }
    }

    void rename() {
        Item it = curItem();
        if (it == null) return;
        EditText e = field("Название", false);
        e.setText(name(it));
        e.setSelectAllOnFocus(true);
        FrameLayout box = new FrameLayout(this);
        box.setPadding(dp(20), dp(8), dp(20), 0);
        box.addView(e);
        dlg().setTitle("Изменить имя").setView(box)
                .setNegativeButton("Отмена", null)
                .setPositiveButton("Сохранить", (x, w) -> {
                    String s = e.getText().toString();
                    if (s.trim().isEmpty()) return;
                    if (isCode(s)) {
                        if (!it.vault) {
                            List<Item> l = new ArrayList<>();
                            l.add(it);
                            hideItems(l);
                        }
                        return;
                    }
                    prefs.edit().putString("n_" + it.key, s.trim()).apply();
                    updateBars();
                    render();
                }).show();
    }

    void shareItems(List<Item> items) {
        ArrayList<Uri> uris = new ArrayList<>();
        boolean allImg = true, allVid = true;
        for (Item it : items) {
            if (it.vault) continue;
            uris.add(it.uri);
            if (it.video) allImg = false; else allVid = false;
        }
        if (uris.isEmpty()) return;
        Intent i;
        if (uris.size() == 1) {
            i = new Intent(Intent.ACTION_SEND);
            i.putExtra(Intent.EXTRA_STREAM, uris.get(0));
        } else {
            i = new Intent(Intent.ACTION_SEND_MULTIPLE);
            i.putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris);
        }
        i.setType(allImg ? "image/*" : (allVid ? "video/*" : "*/*"));
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        try { startActivity(Intent.createChooser(i, "Отправить")); } catch (Exception e) { toast("Нет приложений"); }
    }

    // ================= hide / restore / delete =================

    static String extFor(Item it) {
        String m = it.mime == null ? "" : it.mime;
        if (m.contains("png")) return ".png";
        if (m.contains("webp")) return ".webp";
        if (m.contains("gif")) return ".gif";
        if (m.contains("heic") || m.contains("heif")) return ".heic";
        if (m.contains("3gp")) return ".3gp";
        if (m.contains("webm")) return ".webm";
        if (m.contains("matroska")) return ".mkv";
        if (m.contains("quicktime")) return ".mov";
        return it.video ? ".mp4" : ".jpg";
    }

    void hideItems(List<Item> items) {
        showProgress("Скрываю…");
        loader.execute(() -> {
            List<JSONObject> metas = new ArrayList<>();
            List<File> files = new ArrayList<>();
            List<Item> ok = new ArrayList<>();
            File dir = vaultDir();
            ContentResolver cr = getContentResolver();
            int n = 0;
            for (Item it : items) {
                n++;
                progressMsg("Скрываю " + n + " из " + items.size());
                if (it.vault) continue;
                String fname = UUID.randomUUID().toString().replace("-", "") + extFor(it);
                File f = new File(dir, fname);
                boolean good = false;
                try (InputStream in = cr.openInputStream(it.uri); OutputStream out = new FileOutputStream(f)) {
                    if (in != null) {
                        byte[] buf = new byte[65536];
                        int r;
                        while ((r = in.read(buf)) > 0) out.write(buf, 0, r);
                        good = true;
                    }
                } catch (Exception e) {
                    good = false;
                }
                if (!good || f.length() == 0 || (it.size > 0 && f.length() < it.size)) { f.delete(); continue; }
                try {
                    JSONObject o = new JSONObject();
                    o.put("file", fname);
                    o.put("name", name(it));
                    o.put("video", it.video);
                    o.put("mime", it.mime);
                    o.put("date", it.date);
                    o.put("dur", it.dur);
                    o.put("w", it.w);
                    o.put("h", it.h);
                    o.put("bucket", it.bucket);
                    metas.add(o);
                    files.add(f);
                    ok.add(it);
                } catch (Exception e) {
                    f.delete();
                }
            }
            ui.post(() -> {
                hideProgress();
                if (ok.isEmpty()) { toast("Не удалось скрыть"); return; }
                pendHide = ok;
                pendMeta = metas;
                pendFiles = files;
                deleteOriginals(ok, REQ_HIDE);
            });
        });
    }

    /** Ask the system to delete originals. Result arrives in onDeleteResult(req, success). */
    void deleteOriginals(List<Item> items, int req) {
        ContentResolver cr = getContentResolver();
        if (Build.VERSION.SDK_INT >= 30) {
            try {
                List<Uri> uris = new ArrayList<>();
                for (Item it : items) uris.add(it.uri);
                PendingIntent pi = MediaStore.createDeleteRequest(cr, uris);
                startIntentSenderForResult(pi.getIntentSender(), req, null, 0, 0, 0);
            } catch (IntentSender.SendIntentException | RuntimeException e) {
                onDeleteResult(req, false);
            }
            return;
        }
        boolean ok = true;
        for (Item it : items) {
            try {
                if (cr.delete(it.uri, null, null) <= 0) ok = false;
            } catch (Exception e) {
                ok = false;
            }
        }
        onDeleteResult(req, ok);
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req == REQ_HIDE || req == REQ_DEL) onDeleteResult(req, res == RESULT_OK);
        else if (req == REQ_MOVE) {
            if (res == RESULT_OK) doMove();
            else pendMove = null;
        }
    }

    void onDeleteResult(int req, boolean ok) {
        if (req == REQ_HIDE) {
            List<Item> items = pendHide;
            List<JSONObject> metas = pendMeta;
            List<File> files = pendFiles;
            pendHide = null;
            pendMeta = null;
            pendFiles = null;
            if (items == null) return;
            if (!ok) {
                for (File f : files) f.delete();
                toast("Не скрыто: нужно разрешить удаление оригинала");
                return;
            }
            JSONArray a = vaultMeta();
            for (JSONObject o : metas) a.put(o);
            saveVaultMeta(a);
            for (Item it : items) {
                forgetKey(it.key);
                device.remove(it);
            }
            afterRemoved(items);
            clearSelection();
            loadVault();
            render();
            toast("Готово: " + items.size());
        } else if (req == REQ_DEL) {
            List<Item> items = pendDelete;
            pendDelete = null;
            if (items == null || !ok) return;
            for (Item it : items) {
                forgetKey(it.key);
                device.remove(it);
            }
            afterRemoved(items);
            clearSelection();
            render();
        }
    }

    void deleteItems(List<Item> items) {
        List<Item> v = new ArrayList<>(), d = new ArrayList<>();
        for (Item it : items) { if (it.vault) v.add(it); else d.add(it); }
        if (!v.isEmpty()) {
            dlg().setTitle("Удалить навсегда?")
                    .setMessage("Выбрано: " + v.size() + ". Удалённое нельзя будет восстановить.")
                    .setNegativeButton("Отмена", null)
                    .setPositiveButton("Удалить", (x, w) -> {
                        for (Item it : v) removeFromVault(it, true);
                        afterRemoved(v);
                        clearSelection();
                        render();
                    }).show();
            return;
        }
        if (d.isEmpty()) return;
        if (Build.VERSION.SDK_INT >= 30) {
            pendDelete = d;
            deleteOriginals(d, REQ_DEL);
        } else {
            dlg().setTitle("Удалить?")
                    .setMessage("Выбрано: " + d.size() + ". Файлы будут удалены с телефона.")
                    .setNegativeButton("Отмена", null)
                    .setPositiveButton("Удалить", (x, w) -> {
                        pendDelete = d;
                        deleteOriginals(d, REQ_DEL);
                    }).show();
        }
    }

    void removeFromVault(Item it, boolean deleteFile) {
        JSONArray a = vaultMeta();
        JSONArray na = new JSONArray();
        String fname = it.file.getName();
        for (int i = 0; i < a.length(); i++) {
            JSONObject o = a.optJSONObject(i);
            if (o != null && !fname.equals(o.optString("file"))) na.put(o);
        }
        saveVaultMeta(na);
        if (deleteFile) it.file.delete();
        forgetKey(it.key);
        vault.remove(it);
    }

    void restoreItems(List<Item> items) {
        List<Item> l = new ArrayList<>();
        for (Item it : items) if (it.vault) l.add(it);
        if (l.isEmpty()) return;
        List<String> names = new ArrayList<>();
        for (Item it : l) names.add(name(it));
        showProgress("Возвращаю…");
        loader.execute(() -> {
            List<Item> done = new ArrayList<>();
            String lastErr = null;
            for (int i = 0; i < l.size(); i++) {
                progressMsg("Возвращаю " + (i + 1) + " из " + l.size());
                String err = exportToPhone(l.get(i), names.get(i));
                if (err == null) done.add(l.get(i));
                else lastErr = err;
            }
            final String fe = lastErr;
            ui.post(() -> {
                hideProgress();
                for (Item it : done) removeFromVault(it, true);
                afterRemoved(done);
                clearSelection();
                render();
                if (done.size() == l.size()) toast("Возвращено в галерею: " + done.size());
                else dlg().setTitle("Вернулось " + done.size() + " из " + l.size())
                        .setMessage("Остальные остались в тайнике, ничего не потеряно.\n\nПричина: " + fe)
                        .setPositiveButton("OK", null).show();
                loadDevice();
            });
        });
    }

    /** Copies a vault file back to the phone gallery. Returns null on success, or an error text. */
    String exportToPhone(Item it, String nm) {
        String ext = "";
        int dot = it.file.getName().lastIndexOf('.');
        if (dot > 0) ext = it.file.getName().substring(dot);
        String safe = nm.replaceAll("[\\\\/:*?\"<>|]", "_").trim();
        if (safe.isEmpty()) safe = "file";
        if (safe.length() > 80) safe = safe.substring(0, 80);
        String display = safe + ext;
        String mime = it.mime == null || it.mime.isEmpty() ? (it.video ? "video/mp4" : "image/jpeg") : it.mime;
        if (it.video && !mime.startsWith("video/")) mime = "video/mp4";
        if (!it.video && !mime.startsWith("image/")) mime = "image/jpeg";
        String err = "неизвестная ошибка";
        if (Build.VERSION.SDK_INT >= 29) {
            ContentResolver cr = getContentResolver();
            String base = it.video ? Environment.DIRECTORY_MOVIES : Environment.DIRECTORY_PICTURES;
            String[] paths = {base + "/Галерея", base + "/Gallery", base};
            Uri table = it.video ? MediaStore.Video.Media.EXTERNAL_CONTENT_URI
                    : MediaStore.Images.Media.EXTERNAL_CONTENT_URI;
            for (String path : paths) {
                Uri u = null;
                try {
                    ContentValues v = new ContentValues();
                    v.put(MediaStore.MediaColumns.DISPLAY_NAME, display);
                    v.put(MediaStore.MediaColumns.MIME_TYPE, mime);
                    v.put(MediaStore.MediaColumns.RELATIVE_PATH, path);
                    v.put(MediaStore.MediaColumns.IS_PENDING, 1);
                    if (it.date > 0) v.put("datetaken", it.date);
                    u = cr.insert(table, v);
                    if (u == null) { err = "телефон не разрешил создать файл"; continue; }
                    long written = 0;
                    try (InputStream in = new FileInputStream(it.file); OutputStream out = cr.openOutputStream(u)) {
                        if (out == null) throw new Exception("нет доступа к записи");
                        byte[] buf = new byte[65536];
                        int n;
                        while ((n = in.read(buf)) > 0) { out.write(buf, 0, n); written += n; }
                    }
                    if (written < it.file.length()) throw new Exception("файл записан не полностью");
                    ContentValues fin = new ContentValues();
                    fin.put(MediaStore.MediaColumns.IS_PENDING, 0);
                    cr.update(u, fin, null, null);
                    return null;
                } catch (Exception e) {
                    err = e.getMessage() == null ? e.getClass().getSimpleName() : e.getMessage();
                    if (u != null) {
                        try { cr.delete(u, null, null); } catch (Exception ignored) { /* ignore */ }
                    }
                }
            }
            return err;
        }
        try {
            File dir = new File(Environment.getExternalStoragePublicDirectory(
                    it.video ? Environment.DIRECTORY_MOVIES : Environment.DIRECTORY_PICTURES), "Галерея");
            if (!dir.exists() && !dir.mkdirs()) return "не удалось создать папку";
            File out = new File(dir, display);
            int i = 1;
            while (out.exists()) out = new File(dir, safe + " (" + (i++) + ")" + ext);
            try (InputStream in = new FileInputStream(it.file); OutputStream os = new FileOutputStream(out)) {
                byte[] buf = new byte[65536];
                int n;
                while ((n = in.read(buf)) > 0) os.write(buf, 0, n);
            }
            if (out.length() < it.file.length()) { out.delete(); return "файл записан не полностью"; }
            MediaScannerConnection.scanFile(this, new String[]{out.getAbsolutePath()}, new String[]{mime}, null);
            return null;
        } catch (Exception e) {
            return e.getMessage() == null ? e.getClass().getSimpleName() : e.getMessage();
        }
    }
}
