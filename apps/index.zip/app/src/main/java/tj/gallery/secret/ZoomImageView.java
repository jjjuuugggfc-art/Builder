package tj.gallery.secret;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Matrix;
import android.graphics.RectF;
import android.graphics.drawable.Drawable;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.widget.ImageView;

/** Image view with pinch zoom, pan, double-tap zoom, swipe and tap callbacks. */
public class ZoomImageView extends ImageView {

    public interface Listener {
        void onSwipe(int dir);
        void onTap();
    }

    Listener listener;
    final Matrix m = new Matrix();
    final float[] vals = new float[9];
    float base = 1f;
    final ScaleGestureDetector sgd;
    final GestureDetector gd;

    public ZoomImageView(Context c) {
        super(c);
        setScaleType(ScaleType.MATRIX);
        sgd = new ScaleGestureDetector(c, new ScaleGestureDetector.SimpleOnScaleGestureListener() {
            @Override
            public boolean onScale(ScaleGestureDetector d) {
                float cur = scale();
                float target = cur * d.getScaleFactor();
                if (target < base) target = base;
                if (target > base * 6f) target = base * 6f;
                float f = target / cur;
                m.postScale(f, f, d.getFocusX(), d.getFocusY());
                fix();
                setImageMatrix(m);
                return true;
            }
        });
        gd = new GestureDetector(c, new GestureDetector.SimpleOnGestureListener() {
            @Override
            public boolean onDown(MotionEvent e) { return true; }

            @Override
            public boolean onScroll(MotionEvent e1, MotionEvent e2, float dx, float dy) {
                if (!isZoomed()) return false;
                m.postTranslate(-dx, -dy);
                fix();
                setImageMatrix(m);
                return true;
            }

            @Override
            public boolean onFling(MotionEvent e1, MotionEvent e2, float vx, float vy) {
                if (isZoomed() || sgd.isInProgress()) return false;
                if (Math.abs(vx) > Math.abs(vy) && Math.abs(vx) > 600 && listener != null) {
                    listener.onSwipe(vx < 0 ? 1 : -1);
                    return true;
                }
                return false;
            }

            @Override
            public boolean onDoubleTap(MotionEvent e) {
                if (isZoomed()) {
                    fit();
                } else {
                    float f = 2.5f;
                    m.postScale(f, f, e.getX(), e.getY());
                    fix();
                    setImageMatrix(m);
                }
                return true;
            }

            @Override
            public boolean onSingleTapConfirmed(MotionEvent e) {
                if (listener != null) listener.onTap();
                return true;
            }
        });
    }

    float scale() {
        m.getValues(vals);
        return vals[Matrix.MSCALE_X];
    }

    public boolean isZoomed() { return scale() > base * 1.05f; }

    @Override
    public void setImageBitmap(Bitmap bm) {
        super.setImageBitmap(bm);
        fit();
    }

    @Override
    protected void onSizeChanged(int w, int h, int ow, int oh) {
        super.onSizeChanged(w, h, ow, oh);
        fit();
    }

    void fit() {
        Drawable d = getDrawable();
        int vw = getWidth(), vh = getHeight();
        if (d == null || vw == 0 || vh == 0) return;
        int dw = d.getIntrinsicWidth(), dh = d.getIntrinsicHeight();
        if (dw <= 0 || dh <= 0) return;
        float s = Math.min((float) vw / dw, (float) vh / dh);
        m.reset();
        m.postScale(s, s);
        m.postTranslate((vw - dw * s) / 2f, (vh - dh * s) / 2f);
        base = s;
        setImageMatrix(m);
    }

    void fix() {
        Drawable d = getDrawable();
        if (d == null) return;
        RectF r = new RectF(0, 0, d.getIntrinsicWidth(), d.getIntrinsicHeight());
        m.mapRect(r);
        float vw = getWidth(), vh = getHeight();
        float dx = 0, dy = 0;
        if (r.width() <= vw) dx = (vw - r.width()) / 2f - r.left;
        else if (r.left > 0) dx = -r.left;
        else if (r.right < vw) dx = vw - r.right;
        if (r.height() <= vh) dy = (vh - r.height()) / 2f - r.top;
        else if (r.top > 0) dy = -r.top;
        else if (r.bottom < vh) dy = vh - r.bottom;
        m.postTranslate(dx, dy);
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        sgd.onTouchEvent(e);
        gd.onTouchEvent(e);
        if (getParent() != null) getParent().requestDisallowInterceptTouchEvent(isZoomed());
        return true;
    }
}
