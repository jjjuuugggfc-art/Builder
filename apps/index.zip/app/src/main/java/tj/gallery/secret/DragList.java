package tj.gallery.secret;

import android.content.Context;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.widget.ListView;

/** ListView that supports drag-to-select after a long press and pinch to change grid size. */
public class DragList extends ListView {

    public interface Handler {
        boolean dragging();
        void dragTo(float x, float y);
        void dragEnd();
        void zoom(int delta);
    }

    Handler handler;
    final ScaleGestureDetector sgd;
    float acc = 1f;
    boolean cancelled = false;

    public DragList(Context c) {
        super(c);
        sgd = new ScaleGestureDetector(c, new ScaleGestureDetector.SimpleOnScaleGestureListener() {
            @Override
            public boolean onScaleBegin(ScaleGestureDetector d) {
                acc = 1f;
                return true;
            }

            @Override
            public boolean onScale(ScaleGestureDetector d) {
                acc *= d.getScaleFactor();
                if (acc > 1.3f) {
                    if (handler != null) handler.zoom(-1);
                    acc = 1f;
                } else if (acc < 0.77f) {
                    if (handler != null) handler.zoom(1);
                    acc = 1f;
                }
                return true;
            }
        });
    }

    @Override
    public boolean dispatchTouchEvent(MotionEvent ev) {
        sgd.onTouchEvent(ev);
        int a = ev.getActionMasked();
        if (a == MotionEvent.ACTION_DOWN) cancelled = false;
        boolean multi = ev.getPointerCount() > 1 || sgd.isInProgress();
        boolean drag = handler != null && handler.dragging();
        if (multi || drag || cancelled) {
            if (!cancelled) {
                MotionEvent c = MotionEvent.obtain(ev);
                c.setAction(MotionEvent.ACTION_CANCEL);
                super.dispatchTouchEvent(c);
                c.recycle();
                cancelled = true;
            }
            if (drag) {
                if (a == MotionEvent.ACTION_MOVE) handler.dragTo(ev.getX(), ev.getY());
                else if (a == MotionEvent.ACTION_UP || a == MotionEvent.ACTION_CANCEL) handler.dragEnd();
            }
            return true;
        }
        return super.dispatchTouchEvent(ev);
    }
}
