'use strict';
// ---------- static game data (all names and story are original) ----------
const GAME_VERSION='1.1.0';
const SAVE_KEY='dalniy_rubezh_v2',SAVE_BAK='dalniy_rubezh_v2_bak',SAVE_V1_KEY='dalniy_rubezh_save',SAVE_V1_BAK='dalniy_rubezh_backup_v1',SET_KEY='dalniy_rubezh_settings',SAVE_VER=2;
const GOODS={ore:'Руда',elec:'Электроника',meds:'Медикаменты',parts:'Запчасти'};
const GOOD_IDS=['ore','elec','meds','parts'];
const CITEMS={recorder:'Самописец',analyzer:'Анализатор'};
// prices: [player buys, player sells]
const STATIONS={
 kromka:{name:'Кромка',sys:'yantar',prices:{ore:[40,34],elec:[136,120],meds:[62,54],parts:[80,70]},stock:{ore:80,elec:12,meds:30,parts:18},
  spot:[0,-14,120],entrance:[0,0,190],mesh:'kromka'},
 verf9:{name:'Верфь-9',sys:'inei',prices:{ore:[84,70],elec:[96,86],meds:[86,76],parts:[58,50]},stock:{ore:6,elec:60,meds:14,parts:45},
  spot:[0,-14,110],entrance:[0,0,180],mesh:'verf'}};
const SHIPS={
 strizh:{name:'Стриж',hull:100,shield:60,cargo:12,speed:120,boost:220,turn:1.85,price:0,desc:'Лёгкий разведчик: быстрый и вёрткий'},
 tyagach:{name:'Тягач',hull:150,shield:60,cargo:28,speed:95,boost:175,turn:1.3,price:2400,desc:'Широкий грузовой корпус: больше трюм и броня'}};
const MODS={shield:{name:'Усиленный щит',price:700,desc:'Максимум щита +35'},plasma:{name:'Плазмомёт',price:1100,desc:'Второе оружие: медленный мощный заряд'}};
const WEAPONS=[{name:'Импульсные пушки',speed:620,life:1.6,dmg:6,rate:7.5,kick:.05},{name:'Плазмомёт',speed:300,life:3.2,dmg:34,rate:1.15,kick:.45}];
const ENEMY={
 interceptor:{name:'Перехватчик',hull:55,shield:30,speed:150,turn:1.2,r:6.5,shotSpeed:520,dmg:4},
 heavy:{name:'Тяжёлый налётчик',hull:170,shield:70,speed:82,turn:.6,r:10,shotSpeed:460,dmg:5}};
const MISSIONS=[
 {id:'m1',name:'Чёрный ящик',reward:350,from:'kromka',to:'kromka',desc:'Подобрать самописец у буя №3 и сдать на Кромке.'},
 {id:'m2',name:'Спектральный след',reward:500,from:'kromka',to:'kromka',desc:'Добыть 3 ед. руды в Медном поясе и доставить на Кромку.'},
 {id:'m3',name:'Посылка на верфь',reward:550,from:'kromka',to:'verf9',desc:'Доставить опечатанный анализатор через ворота на Верфь-9.'},
 {id:'m4',name:'Последний рудовоз',reward:1200,from:'verf9',to:'verf9',desc:'Провести рудовоз от обломков конвоя до Верфи-9.'}];
const DLG={
 m1start:[['Диспетчер «Кромки»','У третьего буя сорвало груз. Подбери самописец, пока его не унесло в пояс.']],
 m1done:[['Диспетчер','Запись цела: рудовоз свернул с маршрута на сигнал буя, которого нет в реестре.'],['Диспетчер','Кто-то ставит ложные буи. Лаборатории нужны пробы из Медного пояса.']],
 m2done:[['Лаборант','Пыль на самописце — из нашего пояса, но с примесью инейского льда.'],['Лаборант','Координаты ведут в Иней. Отвези анализатор на Верфь-9.']],
 m3arrive:[['Бортовой ИИ','Прямо по курсу обломки. Похоже, это пропавший конвой.']],
 m3done:[['Начальник верфи','Анализатор подтвердил: конвои уводят в засаду у обломков.'],['Начальник верфи','Там прячется последний рудовоз. Проведи его к нам.']],
 m4start:[['Рудовоз «Тихоход»','Вижу тебя! Иду к верфи, прикрой меня.']],
 m4arrived:[['Рудовоз «Тихоход»','Мы в доке. Спасибо, пилот!']],
 m4done:[['Начальник верфи','Схема с ложными буями раскрыта. Сектор снова наш.'],['Начальник верфи','Работа найдётся всегда — загляни в контракты.']]};
// star systems
const HAND={
 yantar:{name:'Янтарь',sun:norm([-.55,.45,-.5]),sunCol:[1.12,.9,.66],amb:[.15,.12,.1],bg:[.014,.009,.006],neb:[[.55,.3,.12],[.4,.2,.1]],
  planet:{mesh:'amber',pos:[-9000,-7000,46000],r:15000,rim:[1,.62,.32,1.1],spin:.003},moon:{pos:[23000,5000,52000],r:2200},
  station:'kromka',gate:{pos:[4600,500,5400],to:'inei'},bound:15000,
  pois:[{id:'buoy3',name:'Буй №3',pos:[60,80,2100]},{id:'belt',name:'Медный пояс',pos:[-3600,-100,6200]},{id:'dark',name:'Тёмный край пояса',pos:[-5600,200,8000]}],
  belt:{c:[-3600,-100,6200],R:1500,h:350,n:120,ore:.35},
  debris:[[40,15,850,22],[-230,-10,1600,26]],
  zone:{pos:[-5600,200,8000],r:1100,spawn:['interceptor'],after:'m1'}},
 inei:{name:'Иней',sun:norm([1,.12,.18]),sunCol:[.78,.92,1.2],amb:[.06,.08,.12],bg:[.004,.008,.017],neb:[[.12,.35,.55],[.1,.22,.4]],
  planet:{mesh:'giant',pos:[-30000,7000,40000],r:17000,rim:[.5,.75,1,1.1],spin:.002,ring:true},moon:{pos:[26000,-4000,30000],r:1600},
  station:'verf9',gate:{pos:[5200,300,-4200],to:'yantar'},bound:15000,
  pois:[{id:'wreck',name:'Обломки конвоя',pos:[4265,300,-2790]},{id:'zone',name:'Зона перехвата',pos:[-3800,400,-2600]}],
  belt:{c:[1800,-300,-7200],R:1600,h:400,n:70,ore:0,ice:true},
  debris:[],
  zone:{pos:[-3800,400,-2600],r:1200,spawn:['interceptor','heavy'],after:null}}};
HAND.yantar.gatePos={inei:[4600,500,5400]};HAND.inei.gatePos={yantar:[5200,300,-4200]};HAND.inei.gateDir={yantar:norm(sub([4265,300,-2790],[5200,300,-4200]))};
// ---- generated systems & stations from the registry ----
const SYSTEMS={};
const REGION_NEB={core:[[.5,.32,.15],[.25,.2,.35]],union:[[.15,.3,.5],[.3,.2,.15]],teira:[[.55,.22,.12],[.4,.15,.1]],essen:[[.1,.45,.45],[.15,.3,.5]],border:[[.35,.3,.3],[.2,.2,.3]],free:[[.45,.18,.15],[.2,.15,.3]],hidden:[[.3,.1,.35],[.1,.25,.3]]};
for(const id in REG.systems){const c=REG.systems[id];const R=srand(hashStr(id));const st=c.star;
 const sun=norm([R()*2-1,R()*.8-.1,R()*2-1]);const ring=c.planet==='ringed'||(c.planet==='giant'&&R()<.6);
 SYSTEMS[id]={name:c.name,sun,sunCol:st,amb:[st[0]*.12,st[1]*.12,st[2]*.13],bg:[.004+st[0]*.006,.004+st[1]*.005,.006+st[2]*.008],neb:REGION_NEB[c.region],
  planet:{cls:c.planet,dir:norm([R()*2-1,R()*.6-.3,R()*2-1]),dist:44000+R()*12000,r:11000+R()*7000,rim:PLANET_RIM[c.planet],spin:.002+R()*.002,ring},
  moon:{dir:norm([R()*2-1,R()*.6-.3,R()*2-1]),dist:30000,r:1200+R()*1200},station:c.stations[0],bound:15000,danger:c.danger,hand:HAND[id]||null}}
SYSTEMS.yantar.planet.cls='dry';SYSTEMS.inei.planet.cls='giant';
const BASE_PRICE={ore:52,elec:112,meds:70,parts:66};
const FAM_MOD={mining:{ore:.75,parts:1.15},dock:{parts:1.12,ore:1.2},military:{parts:1.15,meds:1.1},habitat:{meds:1.15,elec:1.05},observatory:{elec:1.12},ring:{ore:.98,elec:.98,meds:.98,parts:.98}};
const REG_MOD={core:{elec:.92,meds:.95},union:{parts:.85,ore:1.25},teira:{ore:1.1,elec:1.15},essen:{meds:.85,parts:1.2},border:{ore:1.08,elec:1.08,meds:1.12,parts:1.08},free:{elec:.9,meds:1.25,ore:1.05,parts:1.05},hidden:{meds:1.3,elec:1.1}};
for(const id in REG.stations){if(STATIONS[id])continue;const s=REG.stations[id];const sys=REG.systems[s.sys];const fam=s.bespoke?BESPOKE_FAMILY[s.bespoke]:s.family;const R=srand(hashStr(id)+3);
 const prices={},stock={};for(const g of GOOD_IDS){const m=(FAM_MOD[fam]||{})[g]||1,r=(REG_MOD[sys.region]||{})[g]||1;const buy=Math.round(BASE_PRICE[g]*m*r*(.95+R()*.1));prices[g]=[buy,Math.round(buy*.86)];stock[g]=Math.round((m*r<.95?60:m*r>1.1?6:22)*(.7+R()*.6))}
 STATIONS[id]={name:s.name,sys:s.sys,prices,stock,spot:[0,-14,120],entrance:[0,0,190],mesh:null}}
function stockOf(id){if(!S.stocks)S.stocks={};if(!S.stocks[id])S.stocks[id]={...STATIONS[id].stock};const s=S.stocks[id];for(const g in STATIONS[id].stock)if(s[g]==null)s[g]=STATIONS[id].stock[g];return s}
