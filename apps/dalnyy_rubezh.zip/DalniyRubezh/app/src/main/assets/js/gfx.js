'use strict';
// ===== Art assets: lazy textures + images, safe fallback to procedural graphics =====
const ART={base:'art/',tex:{},img:{},blocked:false,deriv:false,maxAniso:null};
function artImg(path){let r=ART.img[path];if(r)return r.ok?r.im:null;r=ART.img[path]={ok:false,im:new Image()};r.im.onload=()=>{r.ok=true};r.im.onerror=()=>{r.bad=true};r.im.src=ART.base+path;return null}
function artTex(path,opt){if(ART.blocked||!gl||G.noArt)return null;let t=ART.tex[path];if(t){t.used=G.time;return t.tx||null}
 opt=opt||{};t=ART.tex[path]={tx:null,used:G.time,group:opt.group||'misc'};const im=new Image();
 im.onload=()=>{if(ART.tex[path]!==t)return;try{const tx=gl.createTexture();gl.bindTexture(gl.TEXTURE_2D,tx);gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL,false);
   gl.texImage2D(gl.TEXTURE_2D,0,gl.RGBA,gl.RGBA,gl.UNSIGNED_BYTE,im);const mip=opt.mip!==false&&(opt.mip||ART.deriv||!opt.seam);if(mip)gl.generateMipmap(gl.TEXTURE_2D);
   gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MIN_FILTER,mip?gl.LINEAR_MIPMAP_LINEAR:gl.LINEAR);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MAG_FILTER,gl.LINEAR);
   const wr=opt.clamp?gl.CLAMP_TO_EDGE:gl.REPEAT;gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_WRAP_S,wr);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_WRAP_T,opt.clamp||opt.seam?gl.CLAMP_TO_EDGE:wr);
   if(ART.aniso&&mip)gl.texParameterf(gl.TEXTURE_2D,ART.aniso.TEXTURE_MAX_ANISOTROPY_EXT,Math.min(4,ART.maxAniso));
   t.tx=tx}catch(e){ART.blocked=true;console.warn('Текстуры недоступны, остаётся графика кодом: '+e.message)}};
 im.onerror=()=>{t.bad=true};im.src=ART.base+path;return null}
// free big per-system textures that were not used for a while
function artGC(){for(const k in ART.tex){const t=ART.tex[k];if((t.group==='sys')&&t.tx&&G.time-t.used>20){gl.deleteTexture(t.tx);delete ART.tex[k]}}}
function bindTex(unit,tx){gl.activeTexture(gl.TEXTURE0+unit);gl.bindTexture(gl.TEXTURE_2D,tx);gl.activeTexture(gl.TEXTURE0)}
// ---- which art belongs to what ----
const SKY_SPECIAL={black_harbor:1,silent_garden:1,ark:1,white_pocket:1,sklad9:1,iznanka:1};
function skyPath(id){if(SKY_SPECIAL[id])return 'sky/sky_'+id+'.jpg';const r=(REG.systems[id]||{}).region||'core';return 'sky/sky_'+(r==='hidden'?'core':r)+'.jpg'}
function planetPath(id,cls){if(id==='yantar')return 'planets/planet_yantar.jpg';if(id==='inei')return 'planets/planet_inei.jpg';if(id==='iznanka')return 'planets/planet_iznanka.jpg';return 'planets/planet_'+cls+'.jpg'}
const CLOUD_ART={ocean:'clouds_ocean',dry:'clouds_dry',ice:'clouds_ice',ringed:'clouds_ringed'};
const EMI_ART={ocean:['lights_ocean',1],dry:['lights_dry',1],volcanic:['lava_volcanic',2],damaged:['lava_damaged',2]};
const HULL_OF={league:'league',union:'union',teira:'teira',essen:'essen',wake:'wake',border:'border',exp:'station',relic:'essen',none:'border'};
function hullPath(fac){return 'hull/hull_'+(HULL_OF[fac]||'station')+'.jpg'}
function shipFac(id){const d=REG.ships[id];return d?d.fac:'league'}
const ENEMY_FAC={guard:'league'};
function stationHull(sid){const st=REG.stations[sid];const f=st?st.faction:'none';return (f==='teira'||f==='essen'||f==='wake')?hullPath(f):'hull/hull_station.jpg'}
function rockPath(a){if(a.kind==='debris')return 'rocks/debris_metal.jpg';if(a.fam)return 'rocks/rock_'+(a.fam==='copper'?'copper':a.fam)+'.jpg';if(W&&W.sys&&W.sys.belt&&W.sys.belt.ice)return 'rocks/rock_ice.jpg';return 'rocks/rock_plain.jpg'}
const ROCK_GLOW={crystal:['rocks/glow_crystal.png',[.25,1,.9]],rare:['rocks/glow_rare.png',[1,.85,.5]]};
// ---- programs ----
let PL,SK,BB,RG;
function gfxPrograms(){
 const dx=gl.getExtension('OES_standard_derivatives');ART.deriv=!!dx;ART.aniso=gl.getExtension('EXT_texture_filter_anisotropic');if(ART.aniso)ART.maxAniso=gl.getParameter(ART.aniso.MAX_TEXTURE_MAX_ANISOTROPY_EXT);

 // sky panorama (fullscreen)
 SK=prog(`attribute vec3 aPos;attribute vec2 aUV;uniform mat4 uVP;varying vec2 vT;void main(){vT=aUV;vec4 p=uVP*vec4(aPos,1.0);gl_Position=p.xyww;}`,`precision mediump float;
varying vec2 vT;uniform sampler2D uT;uniform float uB;void main(){gl_FragColor=vec4(texture2D(uT,vT).rgb*uB,1.0);}`);
 // textured planet
 PL=prog(`attribute vec3 aPos;attribute vec2 aUV;uniform mat4 uVP;uniform mat4 uM;varying vec3 vN;varying vec2 vT;varying vec3 vW;
void main(){vec4 w=uM*vec4(aPos,1.0);vW=w.xyz;vN=mat3(uM)*aPos;vT=aUV;gl_Position=uVP*w;}`,`precision mediump float;
varying vec3 vN;varying vec2 vT;varying vec3 vW;uniform sampler2D uT;uniform sampler2D uE;uniform float uEM;uniform vec3 uL;uniform vec3 uSun;uniform vec3 uAmb;uniform vec3 uCam;uniform vec4 uRim;uniform float uCloud;uniform float uRot;uniform float uB;
void main(){vec3 n=normalize(vN);vec3 v=normalize(uCam-vW);float d=dot(n,uL);
vec2 uv=vT;vec4 t=texture2D(uT,uv);
float df=smoothstep(-0.08,0.35,d)*clamp(d+0.25,0.0,1.0);
if(uCloud>0.5){float a=max(t.r,max(t.g,t.b));float l=clamp(d*1.1+0.08,0.0,1.0);gl_FragColor=vec4(uSun*l*0.95+0.03,a*uCloud*(0.25+0.75*l)*0.85);return;}
vec3 c=t.rgb*uB*(uAmb*0.6+uSun*df);
if(uEM>0.5){vec3 e=texture2D(uE,uv).rgb;float night=1.0-smoothstep(-0.12,0.18,d);c+=e*(uEM>1.5?max(night,0.55)*1.4:night*1.6);}
float rim=pow(1.0-max(dot(n,v),0.0),3.0);c+=uRim.rgb*rim*uRim.a*clamp(d+0.45,0.0,1.0);
gl_FragColor=vec4(c,1.0);}`);
 // ring of a giant: radius 1.35..2.15 in object xz
 RG=prog(`attribute vec3 aPos;uniform mat4 uVP;uniform mat4 uM;varying vec3 vO;void main(){vO=aPos;gl_Position=uVP*(uM*vec4(aPos,1.0));}`,`precision mediump float;
varying vec3 vO;uniform sampler2D uT;uniform vec3 uSun;uniform vec3 uAmb;void main(){float r=(length(vO.xz)-1.35)/0.8;vec4 t=texture2D(uT,vec2(clamp(r,0.0,1.0),0.5));
gl_FragColor=vec4(t.rgb*(uSun*0.85+uAmb),t.a*0.9);}`);
 // textured billboard / oriented quad (additive)
 BB=prog(`attribute vec2 aC;uniform mat4 uVP;uniform mat4 uM;uniform vec3 uPos;uniform vec2 uS;uniform float uOri;uniform float uRotA;uniform vec4 uUV;varying vec2 vT;
void main(){float cs=cos(uRotA),sn=sin(uRotA);vec2 c=vec2(aC.x*cs-aC.y*sn,aC.x*sn+aC.y*cs);vT=uUV.xy+(aC*vec2(0.5,-0.5)+0.5)*uUV.zw;
if(uOri>0.5){gl_Position=uVP*(uM*vec4(c*uS.x,0.0,1.0));}else{vec4 p=uVP*vec4(uPos,1.0);p.xy+=c*uS*(uOri<-0.5?1.0:p.w);gl_Position=p;}}`,`precision mediump float;
varying vec2 vT;uniform sampler2D uT;uniform vec3 uCol;uniform float uA;void main(){gl_FragColor=vec4(texture2D(uT,vT).rgb*uCol*uA,1.0);}`);
 GFX.quad=gl.createBuffer();gl.bindBuffer(gl.ARRAY_BUFFER,GFX.quad);gl.bufferData(gl.ARRAY_BUFFER,new Float32Array([-1,-1,1,-1,1,1,-1,-1,1,1,-1,1]),gl.STATIC_DRAW);
 GFX.tri=gl.createBuffer();gl.bindBuffer(gl.ARRAY_BUFFER,GFX.tri);gl.bufferData(gl.ARRAY_BUFFER,new Float32Array([-1,-1,3,-1,-1,3]),gl.STATIC_DRAW);
 // flat annulus for the ring
 const t=[];const n=160,r0=1.35,r1=2.15;for(let i=0;i<n;i++){const a=i/n*Math.PI*2,b=(i+1)/n*Math.PI*2;Q(t,[Math.cos(a)*r0,0,Math.sin(a)*r0],[Math.cos(b)*r0,0,Math.sin(b)*r0],[Math.cos(b)*r1,0,Math.sin(b)*r1],[Math.cos(a)*r1,0,Math.sin(a)*r1],[1,1,1,0])}
 GFX.ring=makeMesh(t);GFX.sphere=uvSphere(96,48);GFX.skyS=uvSphere(48,24);
 // white texture so samplers are always valid
 GFX.white=gl.createTexture();gl.bindTexture(gl.TEXTURE_2D,GFX.white);gl.texImage2D(gl.TEXTURE_2D,0,gl.RGBA,1,1,0,gl.RGBA,gl.UNSIGNED_BYTE,new Uint8Array([255,255,255,255]));
 // preload what the first screens need
 for(const p of ['hull/hull_league.jpg','hull/hull_station.jpg','fx/fx_explosion.png','fx/fx_sun.png','fx/fx_flare.png'])artTex(p,{group:'keep',clamp:p.startsWith('fx/')});
}
const GFX={fx:[]};
// lat-long sphere with seam duplicated: [x,y,z,u,v]; u matches atan(x,-z)
function uvSphere(nu,nv){const d=[];const P=(i,j)=>{const u=i/nu,v=j/nv;const th=(u-.5)*Math.PI*2,ph=v*Math.PI;const sp=Math.sin(ph);return [Math.sin(th)*sp,Math.cos(ph),-Math.cos(th)*sp,u,v]};
 for(let j=0;j<nv;j++)for(let i=0;i<nu;i++){const a=P(i,j),b=P(i+1,j),c=P(i+1,j+1),e=P(i,j+1);d.push(...a,...c,...b,...a,...e,...c)}
 const buf=gl.createBuffer();gl.bindBuffer(gl.ARRAY_BUFFER,buf);gl.bufferData(gl.ARRAY_BUFFER,new Float32Array(d),gl.STATIC_DRAW);return {buf,n:d.length/5}}
function uvAttr(pr,m,on){gl.bindBuffer(gl.ARRAY_BUFFER,m.buf);for(const [n,sz,o] of [['aPos',3,0],['aUV',2,12]]){const a=pr.a[n];if(a===undefined)continue;if(on){gl.enableVertexAttribArray(a);gl.vertexAttribPointer(a,sz,gl.FLOAT,false,20,o)}else gl.disableVertexAttribArray(a)}}
// ---- draw helpers ----
function drawSky(sysId,rotVP){const tx=artTex(skyPath(sysId),{group:'sys',mip:true});if(!tx)return false;
 gl.useProgram(SK.p);gl.disable(gl.DEPTH_TEST);gl.depthMask(false);bindTex(0,tx);gl.uniform1i(SK.u.uT,0);gl.uniformMatrix4fv(SK.u.uVP,false,rotVP);gl.uniform1f(SK.u.uB,sysId==='white_pocket'?.8:1.05);
 uvAttr(SK,GFX.skyS,true);gl.drawArrays(gl.TRIANGLES,0,GFX.skyS.n);uvAttr(SK,GFX.skyS,false);gl.depthMask(true);return true}
// draws a textured sphere; returns false if texture is not ready (caller falls back)
function drawPlanetTex(path,emi,q,pos,r,sys,rim,vp,cloud){const tx=artTex(path,{group:'sys'});if(!tx)return false;
 gl.useProgram(PL.p);gl.uniformMatrix4fv(PL.u.uVP,false,vp);gl.uniformMatrix4fv(PL.u.uM,false,mModel(q,pos,r));gl.uniform3fv(PL.u.uL,sys.sun);gl.uniform3fv(PL.u.uSun,sys.sunCol);gl.uniform3fv(PL.u.uAmb,scl(sys.amb,.35));gl.uniform3fv(PL.u.uCam,camEye);
 gl.uniform4fv(PL.u.uRim,rim||[.4,.6,.9,.6]);gl.uniform1f(PL.u.uB,1.15);bindTex(0,tx);gl.uniform1i(PL.u.uT,0);
 let em=0;if(emi){const et=artTex('planets/'+emi[0]+'.png',{group:'sys'});if(et){bindTex(1,et);em=emi[1]}}if(!em)bindTex(1,GFX.white);gl.uniform1i(PL.u.uE,1);gl.uniform1f(PL.u.uEM,em);
 gl.uniform1f(PL.u.uCloud,cloud||0);gl.uniform1f(PL.u.uRot,0);
 uvAttr(PL,GFX.sphere,true);gl.drawArrays(gl.TRIANGLES,0,GFX.sphere.n);uvAttr(PL,GFX.sphere,false);return true}
function drawCloudsTex(cls,q,pos,r,sys,vp){const nm=CLOUD_ART[cls];if(!nm)return false;const tx=artTex('planets/'+nm+'.png',{group:'sys'});if(!tx)return false;
 gl.enable(gl.BLEND);gl.blendFunc(gl.SRC_ALPHA,gl.ONE_MINUS_SRC_ALPHA);gl.depthMask(false);
 gl.useProgram(PL.p);gl.uniformMatrix4fv(PL.u.uVP,false,vp);gl.uniformMatrix4fv(PL.u.uM,false,mModel(q,pos,r));gl.uniform3fv(PL.u.uL,sys.sun);gl.uniform3fv(PL.u.uSun,sys.sunCol);gl.uniform3fv(PL.u.uCam,camEye);
 bindTex(0,tx);gl.uniform1i(PL.u.uT,0);bindTex(1,GFX.white);gl.uniform1i(PL.u.uE,1);gl.uniform1f(PL.u.uCloud,1);gl.uniform1f(PL.u.uRot,0);
 uvAttr(PL,GFX.sphere,true);gl.drawArrays(gl.TRIANGLES,0,GFX.sphere.n);uvAttr(PL,GFX.sphere,false);
 gl.depthMask(true);gl.disable(gl.BLEND);return true}
function drawRingTex(q,pos,r,sys,vp){const tx=artTex('planets/ring.png',{group:'keep',clamp:true});if(!tx)return false;
 gl.enable(gl.BLEND);gl.blendFunc(gl.SRC_ALPHA,gl.ONE_MINUS_SRC_ALPHA);gl.depthMask(false);gl.useProgram(RG.p);gl.uniformMatrix4fv(RG.u.uVP,false,vp);gl.uniformMatrix4fv(RG.u.uM,false,mModel(q,pos,r));
 gl.uniform3fv(RG.u.uSun,sys.sunCol);gl.uniform3fv(RG.u.uAmb,scl(sys.amb,.5));bindTex(0,tx);gl.uniform1i(RG.u.uT,0);
 gl.bindBuffer(gl.ARRAY_BUFFER,GFX.ring.buf);gl.enableVertexAttribArray(RG.a.aPos);gl.vertexAttribPointer(RG.a.aPos,3,gl.FLOAT,false,40,0);gl.drawArrays(gl.TRIANGLES,0,GFX.ring.n);gl.disableVertexAttribArray(RG.a.aPos);
 gl.depthMask(true);gl.disable(gl.BLEND);return true}
// billboard: mode 'px' (size in NDC, fixed on screen), 'w' (size in world units, perspective), or oriented quad with q
function bb(path,pos,size,col,a,o){o=o||{};const tx=artTex(path,{group:'keep',clamp:true});if(!tx)return false;
 gl.uniform3fv(BB.u.uPos,pos);gl.uniform3fv(BB.u.uCol,col||[1,1,1]);gl.uniform1f(BB.u.uA,a==null?1:a);gl.uniform4fv(BB.u.uUV,o.uv||[0,0,1,1]);gl.uniform1f(BB.u.uRotA,o.rot||0);
 if(o.q){gl.uniform1f(BB.u.uOri,1);gl.uniformMatrix4fv(BB.u.uM,false,mModel(o.q,pos,1));gl.uniform2f(BB.u.uS,size,size)}
 else if(o.px){gl.uniform1f(BB.u.uOri,0);gl.uniform2f(BB.u.uS,size*SH/SW,size)}
 else{gl.uniform1f(BB.u.uOri,-1);gl.uniform2f(BB.u.uS,size*camF*SH/SW,size*camF)}
 bindTex(0,tx);gl.drawArrays(gl.TRIANGLES,0,6);return true}
function bbBegin(vp){gl.useProgram(BB.p);gl.uniformMatrix4fv(BB.u.uVP,false,vp);gl.uniform1i(BB.u.uT,0);gl.bindBuffer(gl.ARRAY_BUFFER,GFX.quad);gl.enableVertexAttribArray(BB.a.aC);gl.vertexAttribPointer(BB.a.aC,2,gl.FLOAT,false,8,0);
 gl.enable(gl.BLEND);gl.blendFunc(gl.ONE,gl.ONE);gl.depthMask(false)}
function bbEnd(){gl.disableVertexAttribArray(BB.a.aC)}
// explosion sprites (spawned by explode())
function fxExplosion(p,s){if(GFX.fx.length>24)GFX.fx.shift();GFX.fx.push({p:[...p],s,t:0,dur:1.1+s*.15,rot:Math.random()*6.28})}
function fxUpdate(dt){for(const f of GFX.fx)f.t+=dt;GFX.fx=GFX.fx.filter(f=>f.t<f.dur)}
// ===== UI art (DOM <img> works from file:// in any case) =====
const UIA='art/';
function artImgTag(path,cls,fallback,extra){return `<span class="aw ${cls||''}"><img src="${UIA+path}" alt="" draggable="false" onerror="this.parentNode.classList.add('nf')" ${extra||''}><span class="fb">${fallback||''}</span></span>`}
const HERO_ALIAS={'Диспетчер':'vera','Диспетчер «Кромки»':'vera','Начальник верфи':'taras','Лаборант':'ilan'};
const NO_PORTRAIT={'Бортовой ИИ':1,'Журнал':1,'Чёрная Гавань':1,'Пространство Домов Тейра':1,'Окна прыжка':1,'Немой Сад':1,'Изнанка':1,'Дом':1,'Ваш док':1};
const NPC_BY_NAME={'Гриф':'npc_wake','Смотритель дока':'npc_old','Патруль Гавани':'npc_wake','Таможня':'npc_border','Рудовоз «Тихоход»':'npc_union','Мастер Ольга Стапельная':'npc_union','Коллекционер Брамс':'npc_league','Врач «Полудня»':'npc_league','Старый грузчик':'npc_old','Смотритель маяков':'npc_old','Отшельник Хора':'npc_essen','Разборщик':'npc_wake','Беженка':'npc_border','Барный навигатор':'npc_league','Посредник':'npc_wake','Бармен':null};
const NPC_FAC={league:'npc_league',union:'npc_union',teira:'npc_teira',essen:'npc_essen',wake:'npc_wake',none:'npc_border'};
function npcPortrait(who){if(who in NPC_BY_NAME&&NPC_BY_NAME[who])return NPC_BY_NAME[who];const st=S&&S.station&&REG.stations[S.station];return NPC_FAC[st?st.faction:'none']||'npc_border'}
function heroIdByName(who){if(HERO_ALIAS[who])return HERO_ALIAS[who];const h=Object.entries(REG.heroes).find(([k,v])=>v.name===who);return h?h[0]:null}
function portraitArt(who,alt,size){if(NO_PORTRAIT[who])return '';const id=heroIdByName(who);const fb=id&&typeof portraitSVG==='function'?portraitSVG(id,alt):'';
 const file=id?(id+((alt||heroAlt(id))?'_alt':'')):npcPortrait(who);return artImgTag('portraits/'+file+'.jpg','port'+(size==='s'?' ps':''),fb)}
const GOOD_CAT_ICON={ore:'good_ore',mat:'good_alloy',parts:'good_parts',tech:'good_elec',med:'good_meds',home:'good_food',lux:'good_wine',contra:'good_stims'};
function goodIcon(g){return artImgTag('icons/good_'+g+'.png','ic','')}
function wpnIcon(id){return artImgTag('icons/wpn_'+id+'.png','ic','')}
function modIcon(id){return artImgTag('icons/mod_'+id+'.png','ic','')}
function clsIcon(c){return artImgTag('icons/cls_'+c+'.png','ic cls','')}
function svcIcon(k){return artImgTag('icons/svc_'+k+'.png','ic svc','')}
const STBG_OF={league:'league',union:'union',teira:'teira',essen:'essen',wake:'wake',none:'border'};
function stationBg(sid,tab){if(tab==='bar')return 'bar';if(isHome&&isHome())return 'home';if(sid.startsWith('bh_'))return 'black_harbor';const st=REG.stations[sid];return STBG_OF[st?st.faction:'none']||'border'}
// HUD button icons (2D canvas)
const BTN_IMG={};function btnImg(n){return BTN_IMG[n]||(BTN_IMG[n]=(()=>{const im=new Image();im.src=UIA+'buttons/btn_'+n+'.png';return im})())}
function hudIcon(n,x,y,s,a){const im=btnImg(n);if(!im.complete||!im.naturalWidth)return false;hx.globalAlpha=a==null?.95:a;hx.drawImage(im,x-s/2,y-s/2,s,s);hx.globalAlpha=1;return true}
const MAP_IMG={};function mapImg(n){return MAP_IMG[n]||(MAP_IMG[n]=(()=>{const im=new Image();im.src=UIA+'map/'+n;return im})())}
// emblems: images for the five factions, vector for the rest
if(typeof emblemSVG==='function'){const _emb=emblemSVG;emblemSVG=function(f,s=20){if(!['league','union','teira','essen','wake'].includes(f))return _emb(f,s);return `<img src="${UIA}emblems/emblem_${f}.png" width="${s}" height="${s}" alt="" style="vertical-align:-3px" onerror="this.outerHTML=''">`}}
