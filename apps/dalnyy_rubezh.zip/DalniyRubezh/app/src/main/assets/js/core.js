'use strict';
// ================= math =================
const add=(a,b)=>[a[0]+b[0],a[1]+b[1],a[2]+b[2]];
const sub=(a,b)=>[a[0]-b[0],a[1]-b[1],a[2]-b[2]];
const scl=(a,s)=>[a[0]*s,a[1]*s,a[2]*s];
const dot=(a,b)=>a[0]*b[0]+a[1]*b[1]+a[2]*b[2];
const cross=(a,b)=>[a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0]];
const len=a=>Math.hypot(a[0],a[1],a[2]);
const dist=(a,b)=>Math.hypot(a[0]-b[0],a[1]-b[1],a[2]-b[2]);
const norm=a=>{const l=len(a)||1;return [a[0]/l,a[1]/l,a[2]/l]};
const lerp=(a,b,t)=>a+(b-a)*t;
const vlerp=(a,b,t)=>[lerp(a[0],b[0],t),lerp(a[1],b[1],t),lerp(a[2],b[2],t)];
const clamp=(v,a,b)=>v<a?a:v>b?b:v;
const rnd=(a,b)=>a+Math.random()*(b-a);
const damp=(k,dt)=>1-Math.exp(-k*dt);
function rndDir(){let v;do{v=[rnd(-1,1),rnd(-1,1),rnd(-1,1)]}while(len(v)>1||len(v)<.1);return norm(v)}
// seeded random for repeatable worlds
function srand(seed){let s=seed>>>0||1;return ()=>{s^=s<<13;s>>>=0;s^=s>>17;s^=s<<5;s>>>=0;return s/4294967296}}
function qmul(a,b){return [a[3]*b[0]+a[0]*b[3]+a[1]*b[2]-a[2]*b[1],a[3]*b[1]-a[0]*b[2]+a[1]*b[3]+a[2]*b[0],a[3]*b[2]+a[0]*b[1]-a[1]*b[0]+a[2]*b[3],a[3]*b[3]-a[0]*b[0]-a[1]*b[1]-a[2]*b[2]]}
function qaxis(ax,an){const s=Math.sin(an/2);return [ax[0]*s,ax[1]*s,ax[2]*s,Math.cos(an/2)]}
function qnorm(q){const l=Math.hypot(q[0],q[1],q[2],q[3])||1;return [q[0]/l,q[1]/l,q[2]/l,q[3]/l]}
function qrot(q,v){const u=[q[0],q[1],q[2]],t=scl(cross(u,v),2);return add(add(v,scl(t,q[3])),cross(u,t))}
function qconj(q){return [-q[0],-q[1],-q[2],q[3]]}
function qrand(r=Math.random){return qnorm([r()*2-1,r()*2-1,r()*2-1,r()*2-1])}
function qslerp(a,b,t){let d=a[0]*b[0]+a[1]*b[1]+a[2]*b[2]+a[3]*b[3];let c=b;if(d<0){d=-d;c=[-b[0],-b[1],-b[2],-b[3]]}
 if(d>.9995)return qnorm([lerp(a[0],c[0],t),lerp(a[1],c[1],t),lerp(a[2],c[2],t),lerp(a[3],c[3],t)]);
 const th=Math.acos(d),s=Math.sin(th),wa=Math.sin((1-t)*th)/s,wb=Math.sin(t*th)/s;return [a[0]*wa+c[0]*wb,a[1]*wa+c[1]*wb,a[2]*wa+c[2]*wb,a[3]*wa+c[3]*wb]}
function qFromBasis(x,y,z){const m00=x[0],m11=y[1],m22=z[2],tr=m00+m11+m22;let q;
 if(tr>0){const s=.5/Math.sqrt(tr+1);q=[(y[2]-z[1])*s,(z[0]-x[2])*s,(x[1]-y[0])*s,.25/s]}
 else if(m00>m11&&m00>m22){const s=2*Math.sqrt(1+m00-m11-m22);q=[.25*s,(y[0]+x[1])/s,(z[0]+x[2])/s,(y[2]-z[1])/s]}
 else if(m11>m22){const s=2*Math.sqrt(1+m11-m00-m22);q=[(y[0]+x[1])/s,.25*s,(z[1]+y[2])/s,(z[0]-x[2])/s]}
 else{const s=2*Math.sqrt(1+m22-m00-m11);q=[(z[0]+x[2])/s,(z[1]+y[2])/s,.25*s,(x[1]-y[0])/s]}
 return qnorm(q)}
function qLook(f,up=[0,1,0]){const z=norm(f);let x=cross(up,z);if(len(x)<1e-4)x=cross([1,0,0],z);x=norm(x);return qFromBasis(x,cross(z,x),z)}
function turnToward(q,dir,maxAng){const f=qrot(q,[0,0,1]);const ax=cross(f,dir);const s=len(ax);const ang=Math.atan2(s,dot(f,dir));
 if(s<1e-6){return ang>3?qnorm(qmul(qaxis(qrot(q,[0,1,0]),maxAng),q)):q}
 return qnorm(qmul(qaxis(scl(ax,1/s),Math.min(ang,maxAng)),q))}
const FWD=q=>qrot(q,[0,0,1]),UP=q=>qrot(q,[0,1,0]),RIGHT=q=>qrot(q,[-1,0,0]); // RIGHT = screen-right of a ship
function mModel(q,p,s){const [x,y,z,w]=q;const sx=Array.isArray(s)?s[0]:s,sy=Array.isArray(s)?s[1]:s,sz=Array.isArray(s)?s[2]:s;return new Float32Array([
 (1-2*(y*y+z*z))*sx,2*(x*y+z*w)*sx,2*(x*z-y*w)*sx,0, 2*(x*y-z*w)*sy,(1-2*(x*x+z*z))*sy,2*(y*z+x*w)*sy,0,
 2*(x*z+y*w)*sz,2*(y*z-x*w)*sz,(1-2*(x*x+y*y))*sz,0, p[0],p[1],p[2],1])}
function mPersp(fy,a,n,f){const t=1/Math.tan(fy/2);return new Float32Array([t/a,0,0,0,0,t,0,0,0,0,(f+n)/(n-f),-1,0,0,2*f*n/(n-f),0])}
function mLook(e,c,up){const z=norm(sub(e,c)),x=norm(cross(up,z)),y=cross(z,x);
 return new Float32Array([x[0],y[0],z[0],0,x[1],y[1],z[1],0,x[2],y[2],z[2],0,-dot(x,e),-dot(y,e),-dot(z,e),1])}
function mMul(a,b){const o=new Float32Array(16);for(let c=0;c<4;c++)for(let r=0;r<4;r++){let s=0;for(let k=0;k<4;k++)s+=a[k*4+r]*b[c*4+k];o[c*4+r]=s}return o}
function segSphere(a,b,c,r){const ab=sub(b,a),t=clamp(dot(sub(c,a),ab)/(dot(ab,ab)||1),0,1);return dist(add(a,scl(ab,t)),c)<r}
// intercept direction: shooter at s with velocity vs, projectile speed sp relative to shooter; target t with velocity vt
function leadTime(s,vs,sp,t,vt){const r=sub(t,s),v=sub(vt,vs);const a=dot(v,v)-sp*sp,b=2*dot(r,v),c=dot(r,r);
 if(Math.abs(a)<1e-6)return c/Math.max(1e-3,-b)>0?-c/b:len(r)/sp;const d=b*b-4*a*c;if(d<0)return len(r)/sp;
 const s1=(-b-Math.sqrt(d))/(2*a),s2=(-b+Math.sqrt(d))/(2*a);const tt=Math.min(s1,s2)>0?Math.min(s1,s2):Math.max(s1,s2);return tt>0?tt:len(r)/sp}

// ================= GL =================
let gl,glc;
const C=(r,g,b,e=0)=>[r,g,b,e];
const tone=(c,k)=>[Math.min(1,c[0]*k),Math.min(1,c[1]*k),Math.min(1,c[2]*k),c[3]];
const I=v=>v;
function glInit(cv){glc=cv;gl=cv.getContext('webgl',{antialias:true,alpha:false})||cv.getContext('experimental-webgl');return !!gl}
function prog(vs,fs){const p=gl.createProgram();for(const [t,s] of [[gl.VERTEX_SHADER,vs],[gl.FRAGMENT_SHADER,fs]]){const sh=gl.createShader(t);gl.shaderSource(sh,s);gl.compileShader(sh);if(!gl.getShaderParameter(sh,gl.COMPILE_STATUS))console.error(gl.getShaderInfoLog(sh));gl.attachShader(p,sh)}
 gl.linkProgram(p);const u={},a={};const nu=gl.getProgramParameter(p,gl.ACTIVE_UNIFORMS);for(let i=0;i<nu;i++){const n=gl.getActiveUniform(p,i).name;u[n]=gl.getUniformLocation(p,n)}
 const na=gl.getProgramParameter(p,gl.ACTIVE_ATTRIBUTES);for(let i=0;i<na;i++){const n=gl.getActiveAttrib(p,i).name;a[n]=gl.getAttribLocation(p,n)}return {p,u,a}}
let MS,PS,GS,CS;
function glPrograms(){
MS=prog(`
attribute vec3 aPos;attribute vec3 aNor;attribute vec4 aCol;
uniform mat4 uVP;uniform mat4 uM;varying vec3 vN;varying vec4 vC;varying vec3 vW;uniform float uDetS;varying vec2 vUV;
void main(){vec4 w=uM*vec4(aPos,1.0);vW=w.xyz;vN=mat3(uM)*aNor;vC=aCol;vec3 a=abs(aNor);vec3 o=aPos*uDetS;vUV=a.x>a.y&&a.x>a.z?o.yz:a.y>a.z?o.zx:o.xy;gl_Position=uVP*w;}`,`
precision mediump float;varying vec3 vN;varying vec4 vC;varying vec3 vW;varying vec2 vUV;
uniform sampler2D uDet;uniform sampler2D uGlw;uniform float uDetK;uniform float uDetM;uniform vec3 uGlwC;
uniform vec3 uL;uniform vec3 uSun;uniform vec3 uAmb;uniform vec3 uCam;uniform vec3 uEm;uniform vec4 uRim;uniform float uTwo;uniform float uSpec;uniform float uTerm;uniform vec3 uNight;uniform float uLava;
void main(){vec3 n=normalize(vN);vec3 v=normalize(uCam-vW);if(uTwo>0.5&&dot(n,v)<0.0)n=-n;
float d=dot(n,uL);float df=uTerm>0.5?smoothstep(-0.08,0.35,d)*clamp(d+0.25,0.0,1.0):max(d,0.0);
vec3 lit=uAmb*(0.65+0.35*n.y)+uSun*df;
float sp=pow(max(dot(reflect(-uL,n),v),0.0),22.0)*uSpec*step(0.0,d);
vec3 base=vC.rgb;float e=vC.a;vec3 glw=vec3(0.0);
if(uDetK>0.0){vec3 dt=texture2D(uDet,vUV).rgb;if(uDetM<0.5)base*=mix(vec3(1.0),dt*1.18,uDetK);else base=dt*mix(vec3(1.0),vC.rgb*1.6,0.25)*1.15;
 if(uGlwC.r+uGlwC.g+uGlwC.b>0.0)glw=texture2D(uGlw,vUV).rgb*uGlwC;}
vec3 c=uTerm>0.5?base*lit+uNight*e*max(1.0-smoothstep(-0.12,0.18,d),uLava):base*lit*(1.0-e)+base*e*1.35+uSun*sp;
float rim=pow(1.0-max(dot(n,v),0.0),3.0);c+=uRim.rgb*rim*uRim.a*clamp(d+0.45,0.0,1.0);
c+=uEm+glw*1.3;gl_FragColor=vec4(c,1.0);}`);
PS=prog(`
attribute vec3 aPos;attribute vec4 aCol;attribute float aSize;
uniform mat4 uVP;uniform vec3 uOff;uniform float uScale;uniform float uFixed;varying vec4 vCol;
void main(){gl_Position=uVP*vec4(aPos+uOff,1.0);vCol=aCol;
gl_PointSize=uFixed>0.5?aSize:clamp(aSize*uScale/max(gl_Position.w,0.1),1.0,180.0);}`,`
precision mediump float;varying vec4 vCol;
void main(){float d=length(gl_PointCoord-0.5)*2.0;if(d>1.0)discard;float a=pow(1.0-d,1.7);
gl_FragColor=vec4(vCol.rgb*vCol.a*a,1.0);}`);
CS=prog(`
attribute vec3 aPos;attribute vec3 aNor;attribute vec4 aCol;
uniform mat4 uVP;uniform mat4 uM;varying vec3 vN;varying float vA;
void main(){vN=mat3(uM)*aNor;vA=aCol.a;gl_Position=uVP*(uM*vec4(aPos,1.0));}`,`
precision mediump float;varying vec3 vN;varying float vA;uniform vec3 uL;uniform vec3 uSun;
void main(){float d=dot(normalize(vN),uL);float l=clamp(d*1.1+0.08,0.0,1.0);gl_FragColor=vec4(uSun*l*0.95+0.03,vA*(0.25+0.75*l));}`);
GS=prog(`
attribute vec3 aPos;attribute vec3 aNor;attribute vec4 aCol;
uniform mat4 uVP;uniform mat4 uM;uniform vec3 uCam;varying float vF;varying vec3 vW;
void main(){vec4 w=uM*vec4(aPos,1.0);vec3 n=normalize(mat3(uM)*aNor);vF=pow(1.0-abs(dot(n,normalize(uCam-w.xyz))),2.0);vW=w.xyz;gl_Position=uVP*w;}`,`
precision mediump float;varying float vF;varying vec3 vW;uniform vec3 uCol;uniform float uA;uniform vec3 uHit;uniform float uHitR;
void main(){float h=uHitR>0.0?clamp(1.0-length(vW-uHit)/uHitR,0.0,1.0):0.0;float a=uA*(vF*0.8+0.15)+h*uA*1.2;gl_FragColor=vec4(uCol*a,1.0);}`);
}
// mesh: tris [a,b,c,col] or [a,b,c,col,na,nb,nc]
function makeMesh(tris){const out=[];
 for(const t of tris){const [a,b,c,col]=t;const cr=cross(sub(b,a),sub(c,a));const l=len(cr);if(l<1e-9)continue;const fn=scl(cr,1/l);
  const ns=t[4]?[t[4],t[5],t[6]]:[fn,fn,fn];[a,b,c].forEach((v,i)=>{const n=ns[i];out.push(v[0],v[1],v[2],n[0],n[1],n[2],col[0],col[1],col[2],col[3]||0)})}
 const d=new Float32Array(out);const buf=gl.createBuffer();gl.bindBuffer(gl.ARRAY_BUFFER,buf);gl.bufferData(gl.ARRAY_BUFFER,d,gl.STATIC_DRAW);return {buf,n:d.length/10}}
// geometry helpers (all accept an xf point transform)
function T(t,a,b,c,col,xf=I){t.push([xf(a),xf(b),xf(c),col])}
function Q(t,a,b,c,d,col,xf=I){T(t,a,b,c,col,xf);T(t,a,c,d,col,xf)}
function xfm(q,p=[0,0,0],s=1){return v=>add(qrot(q,scl(v,s)),p)}
function chain(...f){return v=>f.reduce((a,g)=>g(a),v)}
function box(t,c,s,col,xf=I,rq=null,faceTones=true){const h=scl(s,.5);
 const P=(x,y,z)=>{let v=[x*h[0],y*h[1],z*h[2]];if(rq)v=qrot(rq,v);return xf(add(c,v))};
 const v=[P(-1,-1,-1),P(1,-1,-1),P(1,1,-1),P(-1,1,-1),P(-1,-1,1),P(1,-1,1),P(1,1,1),P(-1,1,1)];
 const f=[[0,1,2,3,.8],[5,4,7,6,1],[4,0,3,7,.9],[1,5,6,2,.9],[3,2,6,7,1.08],[4,5,1,0,.7]];
 for(const q of f){const cc=faceTones?tone(col,q[4]):col;t.push([v[q[0]],v[q[1]],v[q[2]],cc],[v[q[0]],v[q[2]],v[q[3]],cc])}}
// loft: sections [{z,p:[[x,y],...]}] same point count, closed loop
function loft(t,secs,colFn,xf=I,capB=null,capF=null){
 for(let s=0;s<secs.length-1;s++){const A=secs[s],B=secs[s+1],n=A.p.length;
  for(let i=0;i<n;i++){const j=(i+1)%n;const a=[A.p[i][0],A.p[i][1],A.z],b=[A.p[j][0],A.p[j][1],A.z],c=[B.p[j][0],B.p[j][1],B.z],d=[B.p[i][0],B.p[i][1],B.z];Q(t,a,b,c,d,colFn(s,i),xf)}}
 const cap=(S,col)=>{let cx=0,cy=0;for(const p of S.p){cx+=p[0];cy+=p[1]}cx/=S.p.length;cy/=S.p.length;for(let i=0;i<S.p.length;i++){const j=(i+1)%S.p.length;T(t,[cx,cy,S.z],[S.p[i][0],S.p[i][1],S.z],[S.p[j][0],S.p[j][1],S.z],col,xf)}};
 if(capB)cap(secs[secs.length-1],capB);if(capF)cap(secs[0],capF)}
function circ(r,n,ox=0,oy=0,rot=0){const p=[];for(let i=0;i<n;i++){const a=rot+i/n*Math.PI*2;p.push([ox+Math.cos(a)*r,oy+Math.sin(a)*r])}return p}
function cyl(t,z0,z1,r0,r1,n,colFn,xf=I,cap0=null,cap1=null,ox=0,oy=0){loft(t,[{z:z0,p:circ(r0,n,ox,oy)},{z:z1,p:circ(r1,n,ox,oy)}],colFn,xf,cap1,cap0)}
// beam between two points (square section)
function beam(t,a,b,w,col,xf=I){const d=sub(b,a),l=len(d);const q=qLook(d,Math.abs(norm(d)[1])>.9?[1,0,0]:[0,1,0]);box(t,scl(add(a,b),.5),[w,w,l],col,xf,q)}
function icoGeo(level){const X=.525731,Z=.850651;
 let V=[[-X,0,Z],[X,0,Z],[-X,0,-Z],[X,0,-Z],[0,Z,X],[0,Z,-X],[0,-Z,X],[0,-Z,-X],[Z,X,0],[-Z,X,0],[Z,-X,0],[-Z,-X,0]];
 let F=[[0,4,1],[0,9,4],[9,5,4],[4,5,8],[4,8,1],[8,10,1],[8,3,10],[5,3,8],[5,2,3],[2,7,3],[7,10,3],[7,6,10],[7,11,6],[11,0,6],[0,1,6],[6,1,10],[9,0,11],[9,11,2],[9,2,5],[7,2,11]];
 for(let l=0;l<level;l++){const nf=[],cache={};const mid=(a,b)=>{const k=a<b?a+'_'+b:b+'_'+a;if(cache[k]!==undefined)return cache[k];V.push(norm(scl(add(V[a],V[b]),.5)));return cache[k]=V.length-1};
  for(const [a,b,c] of F){const ab=mid(a,b),bc=mid(b,c),ca=mid(c,a);nf.push([a,ab,ca],[b,bc,ab],[c,ca,bc],[ab,bc,ca])}F=nf}
 return {V,F}}
// rock: jittered icosphere, flat shaded
function rockTris(level,jit,r,colFn,xf=I,seed=1){const R=srand(seed);const {V,F}=icoGeo(level);const VV=V.map(v=>scl(v,1+(R()*2-1)*jit));const t=[];
 for(const [a,b,c] of F){const cen=norm(add(add(VV[a],VV[b]),VV[c]));T(t,VV[a],VV[b],VV[c],colFn(cen,R),xf)}return t}
// smooth sphere with per-vertex colours
function sphereTris(level,colFn){const {V,F}=icoGeo(level);const cols=V.map(v=>colFn(v));const t=[];
 for(const [a,b,c] of F)t.push([V[a],V[b],V[c],avgCol(cols[a],cols[b],cols[c]),V[a],V[b],V[c]]);return t}
function avgCol(a,b,c){return [(a[0]+b[0]+c[0])/3,(a[1]+b[1]+c[1])/3,(a[2]+b[2]+c[2])/3,(a[3]+b[3]+c[3])/3]}
// cheap 3D value noise
function hash3(x,y,z){let h=x*374761393+y*668265263+z*2147483647;h=(h^(h>>13))*1274126177;return ((h^(h>>16))>>>0)/4294967296}
function vnoise(p){const x=Math.floor(p[0]),y=Math.floor(p[1]),z=Math.floor(p[2]);const fx=p[0]-x,fy=p[1]-y,fz=p[2]-z;const s=t=>t*t*(3-2*t);
 const u=s(fx),v=s(fy),w=s(fz);let r=0;for(let i=0;i<2;i++)for(let j=0;j<2;j++)for(let k=0;k<2;k++)r+=hash3(x+i,y+j,z+k)*(i?u:1-u)*(j?v:1-v)*(k?w:1-w);return r}
function fbm(p,o=4){let s=0,a=.5,f=1;for(let i=0;i<o;i++){s+=a*vnoise(scl(p,f));f*=2.03;a*=.5}return s}
