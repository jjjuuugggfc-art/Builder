'use strict';
let lastT=performance.now();
(function boot(){
 if(!glInit($('gl'))){document.body.innerHTML='<p style="padding:30px">WebGL недоступен на этом устройстве</p>';return}
 if(!localStorage.getItem(SET_KEY)&&G.touch)SET.quality='low';
 G.low=SET.quality==='low';G.maxParts=G.low?700:2500;
 renderInit();buildModels();inputInit();menuInit();resizeGL();addEventListener('resize',resizeGL);
 // menu backdrop: Amber system from the hangar
 S=defaultSave();buildSystem('yantar');newPlayer();P.pos=stationWorld(STATIONS.kromka.spot);cam.mode='hangar';
 const ls=loadSlot();G.bootStatus=ls.status;S=ls.save||defaultSave();
 uiMenu();
 // loading screen: wait for the first textures (max 4 s), never blocks the game if art is missing
 {const el=$('loading');const need=[[skyPath('yantar'),{group:'sys',mip:true}],['planets/planet_yantar.jpg',{group:'sys'}],['hull/hull_league.jpg',{group:'keep'}],['hull/hull_station.jpg',{group:'keep'}],['planets/planet_rock.jpg',{group:'sys'}]];const t0=performance.now();
  const done=()=>{el.style.opacity=0;setTimeout(()=>el.remove(),500)};if(window.NOSCENE){el.remove()}else{const tick=()=>{let n=0;for(const [p,o] of need)if(artTex(p,o))n++;$('lbar').style.width=Math.round(n/need.length*100)+'%';
   if(n===need.length||ART.blocked||performance.now()-t0>4000)done();else setTimeout(tick,120)};tick()}}
 function frame(now){let dt=(now-lastT)/1000;lastT=now;dt=Math.min(dt,.05);
  if(G.mode==='fly')readInput(dt);
  if(G.mode!=='pause'&&G.mode!=='map'&&G.mode!=='menu')update(dt);if(typeof musicTick==='function')musicTick(dt);else if(W)ambient(dt*.3);
  render(dt);drawHUD(dt);requestAnimationFrame(frame)}
 requestAnimationFrame(frame);
 window.__G={G,get S(){return S},get W(){return W},get P(){return P}};
})();
