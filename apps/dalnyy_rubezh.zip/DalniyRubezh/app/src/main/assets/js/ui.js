'use strict';
// ================= input =================
const IN={yaw:0,pitch:0,roll:0,thrDelta:0,thrSet:null,fire:false,boost:false,actionEdge:false,actionHeld:false,targetEdge:false,weaponEdge:false,missileEdge:false,jamEdge:false,stealthEdge:false};
const KB={};const PTR={};let JOY=null;let MOUSE={x:0,y:0,on:false,down:false};G.touch=matchMedia('(pointer:coarse)').matches;
let hc,hx;const $=id=>document.getElementById(id);
function layout(){const w=SW,h=SH;const L={};const bs=clamp(SET.btnScale||1,.8,1.3),js=clamp(SET.joySize||1,.8,1.4);
 const th=Math.round(42*Math.min(bs,1.1)),tg=th+6;L.thr=[0,1,2].map(i=>({x:10,y:h-16-th-i*tg,w:54,h:th,v:[0,.5,1][i],label:['0','50%','100%'][i]}));
 const jr=Math.min(64,h*.18)*js;L.joy={x:Math.max(80+jr,w*.22),y:h-Math.max(96,jr+24),r:jr};
 const fr=Math.min(56,h*.16)*bs;L.fire={x:w-24-fr,y:h-26-fr,r:fr};const br=Math.min(36,h*.1)*bs;L.boost={x:L.fire.x-fr-br-16,y:h-18-br,r:br};
 L.missile={x:L.fire.x-fr*.55,y:L.fire.y-fr-34*bs,r:28*bs};L.weapon={x:L.boost.x-br-30*bs,y:L.boost.y,r:24*bs};L.jam={x:L.weapon.x,y:L.weapon.y-58*bs,r:21*bs};L.stealth={x:L.weapon.x-50*bs,y:L.weapon.y-28*bs,r:21*bs};
 L.action={x:w-112,y:Math.min(h-205,L.missile.y-L.missile.r-30),w:200,h:44};
 L.pause={x:w-28,y:28,r:21};L.map={x:w-78,y:28,r:21};L.target={x:w-128,y:28,r:21};return L}
function inRect(r,x,y){return x>r.x-r.w/2&&x<r.x+r.w/2&&y>r.y-r.h/2&&y<r.y+r.h/2}
function inCirc(c,x,y,k=1.15){return Math.hypot(x-c.x,y-c.y)<c.r*k}
function hudHit(x,y){const L=layout();if(!G.touch)return null;
 if(inCirc(L.pause,x,y,1.3))return 'pause';if(inCirc(L.map,x,y,1.3))return 'map';if(inCirc(L.target,x,y,1.3))return 'target';
 const act=currentAction();if(act&&inRect(L.action,x,y))return 'action';
 const st=shipStats();if(weaponGroups().length>1&&inCirc(L.weapon,x,y))return 'weapon';if(fitOf(S.active).mis&&inCirc(L.missile,x,y))return 'missile';if(st.jam&&inCirc(L.jam,x,y))return 'jam';if(st.stealth&&inCirc(L.stealth,x,y))return 'stealth';
 if(inCirc(L.fire,x,y))return 'fire';if(inCirc(L.boost,x,y))return 'boost';
 for(const b of L.thr)if(x>b.x-4&&x<b.x+b.w+4&&y>b.y-3&&y<b.y+b.h+3)return 'thr'+b.v;
 if(x<SW*.45&&y>SH*.28)return 'joy';return null}
function resetInput(){G.rotDrag=null;for(const k in PTR)delete PTR[k];for(const k in KB)KB[k]=false;JOY=null;Object.assign(IN,{yaw:0,pitch:0,roll:0,thrDelta:0,fire:false,boost:false,actionHeld:false});MOUSE.down=false}
function inputInit(){hc=$('hud');hx=hc.getContext('2d');
 const first=()=>{sndInit();sndApplyVolumes()};addEventListener('pointerdown',first,{capture:true});addEventListener('keydown',first,{capture:true});
 hc.addEventListener('pointerdown',e=>{e.preventDefault();if(e.pointerType!=='mouse'){G.touch=true}
  if(G.mode==='scene'){if(G.scene&&G.scene.t>.4)endScene();return}
  if(G.mode==='hangar'){G.rotDrag={x:e.clientX,id:e.pointerId};return}
  if(G.mode!=='fly')return;const x=e.clientX,y=e.clientY;
  if(e.pointerType==='mouse'){if(e.button===0){MOUSE.down=true}return}
  const h=hudHit(x,y);if(!h)return;try{hc.setPointerCapture(e.pointerId)}catch(_){}
  if(h==='pause'){uiPause();return}if(h==='map'){uiMap();return}if(h==='target'){IN.targetEdge=true;return}if(h==='weapon'){IN.weaponEdge=true;return}if(h==='missile'){IN.missileEdge=true;return}if(h==='jam'){IN.jamEdge=true;return}if(h==='stealth'){IN.stealthEdge=true;return}
  if(h.startsWith('thr')){IN.thrSet=+h.slice(3);uiHintCheck();return}
  if(h==='action'){IN.actionEdge=true;PTR[e.pointerId]='action';return}
  if(h==='joy'){if(!JOY){const L=layout();const cx=clamp(x,90,SW*.45),cy=clamp(y,SH*.35,SH-40);JOY={id:e.pointerId,ox:cx,oy:cy,x,y,r:L.joy.r};PTR[e.pointerId]='joy'}return}
  PTR[e.pointerId]=h},{passive:false});
 hc.addEventListener('pointermove',e=>{if(G.rotDrag&&G.rotDrag.id===e.pointerId){G.prevRot=(G.prevRot||0)+(e.clientX-G.rotDrag.x)*.012;G.rotDrag.x=e.clientX;return}if(e.pointerType==='mouse'){MOUSE.x=e.clientX;MOUSE.y=e.clientY;MOUSE.on=true;return}
  if(JOY&&JOY.id===e.pointerId){JOY.x=e.clientX;JOY.y=e.clientY}});
 const up=e=>{if(G.rotDrag&&G.rotDrag.id===e.pointerId)G.rotDrag=null;if(e.pointerType==='mouse'){if(e.button===0)MOUSE.down=false;return}if(JOY&&JOY.id===e.pointerId)JOY=null;delete PTR[e.pointerId]};
 hc.addEventListener('pointerup',up);hc.addEventListener('pointercancel',up);hc.addEventListener('lostpointercapture',up);
 addEventListener('mousemove',e=>{MOUSE.x=e.clientX;MOUSE.y=e.clientY;MOUSE.on=true});
 addEventListener('keydown',e=>{if(e.code==='Tab'){e.preventDefault()}if(e.repeat){KB[e.code]=true;return}KB[e.code]=true;
  if(G.mode==='fly'){if(e.code==='KeyE')IN.actionEdge=true;if(e.code==='Tab')IN.targetEdge=true;if(e.code==='KeyQ'||e.code==='Digit1'||e.code==='Digit2')IN.weaponEdge=true;if(e.code==='KeyF'||e.code==='KeyR')IN.missileEdge=true;if(e.code==='KeyJ')IN.jamEdge=true;if(e.code==='KeyC')IN.stealthEdge=true;
   if(e.code==='KeyM')uiMap();if(e.code==='Escape')uiPause()}
  else if(G.mode==='scene'&&(e.code==='Escape'||e.code==='Space'||e.code==='Enter'))endScene();
  else if(e.code==='Escape'){if(!$('pause').classList.contains('hide'))uiResume();else if(!$('map').classList.contains('hide'))uiCloseMap()}});
 addEventListener('keyup',e=>{KB[e.code]=false});
 addEventListener('blur',resetInput);
 document.addEventListener('visibilitychange',()=>{if(document.hidden){resetInput();if(G.mode==='fly')uiPause();sndSuspend(true)}else{sndSuspend(false);lastT=performance.now()}});
 hc.addEventListener('contextmenu',e=>e.preventDefault())}
function readInput(dt){let yaw=0,pitch=0;
 const held=v=>Object.values(PTR).includes(v);
 if(JOY){let dx=JOY.x-JOY.ox,dy=JOY.y-JOY.oy;const l=Math.hypot(dx,dy);if(l>JOY.r){JOY.ox+=dx*(1-JOY.r/l);JOY.oy+=dy*(1-JOY.r/l);dx=JOY.x-JOY.ox;dy=JOY.y-JOY.oy}yaw=dx/JOY.r;pitch=-dy/JOY.r}
 else if(!G.touch&&MOUSE.on){const R=Math.min(SW,SH)*.42;yaw=(MOUSE.x-SW/2)/R;pitch=-(MOUSE.y-SH/2)/R}
 const dz=v=>{const a=Math.abs(v);return a<.06?0:Math.sign(v)*Math.min(1,(a-.06)/.94)};yaw=dz(yaw);pitch=dz(pitch);
 if(KB.ArrowLeft)yaw=-1;if(KB.ArrowRight)yaw=1;if(KB.ArrowUp)pitch=1;if(KB.ArrowDown)pitch=-1;
 IN.yaw=yaw;IN.pitch=pitch;IN.roll=(KB.KeyD?1:0)-(KB.KeyA?1:0);IN.thrDelta=(KB.KeyW?1:0)-(KB.KeyS?1:0);
 IN.fire=held('fire')||MOUSE.down;IN.boost=held('boost')||!!KB.ShiftLeft||!!KB.ShiftRight;IN.actionHeld=held('action')||!!KB.KeyE;
 if(Math.abs(yaw)+Math.abs(pitch)>.3)G.turnAcc=(G.turnAcc||0)+dt;uiHintCheck()}

// ================= HUD =================
let noteT=0,noteTxt='',toast=null;
function uiNote(t){noteTxt=t;noteT=3.2}
const HINTS=[{id:'turn',t:()=>G.touch?'Поворот: тяните джойстик слева':'Поворот: ведите мышью от центра экрана',done:()=>(G.turnAcc||0)>1},
 {id:'thrust',t:()=>G.touch?'Тяга: нажмите «100%» слева от джойстика':'Тяга: удерживайте W до максимума',done:()=>P&&P.thr>=.95},
 {id:'pickup',t:()=>'Подлетите к контейнеру и нажмите «Подобрать»'+(G.touch?'':' (E)'),done:()=>S.citems.includes('recorder')||!msActive('m1')},
 {id:'dock',t:()=>'Летите к Кромке. У створок ангара нажмите «Стыковаться»'+(G.touch?'':' (E)'),done:()=>!msActive('m1')}];
let hintI=-1;
function uiFlightStart(){if(!S.tut&&!G.duel){hintI=0;G.turnAcc=0}else hintI=-1}
function uiHintCheck(){if(hintI<0||!S)return;while(hintI<HINTS.length&&HINTS[hintI].done())hintI++;if(hintI>=HINTS.length){hintI=-1;S.tut=true}}
function uiHintDone(){uiHintCheck()}
function drawHUD(dt){const w=SW,h=SH;hx.setTransform(HDPR,0,0,HDPR,0,0);hx.clearRect(0,0,w,h);if(!P||!W)return;
 if(G.mode==='hangar'||G.mode==='menu')return;
 if(G.mode==='scene'){drawScene();return}
 if(G.mode==='jump'){const k=G.anim/1.6;hx.fillStyle=`rgba(180,220,255,${Math.max(0,k-.6)*2.2})`;hx.fillRect(0,0,w,h);hx.strokeStyle='rgba(160,210,255,.5)';hx.lineWidth=2;
  for(let i=0;i<40;i++){const a=i/40*Math.PI*2,r0=60+((G.time*600+i*37)%400)*k;hx.beginPath();hx.moveTo(w/2+Math.cos(a)*r0,h/2+Math.sin(a)*r0);hx.lineTo(w/2+Math.cos(a)*(r0+60*k),h/2+Math.sin(a)*(r0+60*k));hx.stroke()}return}
 const st=shipStats(),f=FWD(P.q),L=layout();
 if(P.alive&&G.mode==='fly'){
  // crosshair
  const c=proj(add(P.pos,scl(f,400)));const cx=c.w>0?c.x:w/2,cy=c.w>0?c.y:h/2;
  hx.lineWidth=2;hx.strokeStyle='rgba(0,0,0,.55)';drawCross(cx+1,cy+1);hx.strokeStyle='rgba(170,235,255,.95)';hx.lineWidth=1.6;drawCross(cx,cy);
  if(G.hitMark>0){G.hitMark-=dt;hx.strokeStyle='rgba(255,230,120,'+Math.min(1,G.hitMark*6)+')';hx.lineWidth=2.4;hx.beginPath();for(const [sx,sy] of [[-1,-1],[1,-1],[1,1],[-1,1]]){hx.moveTo(cx+sx*8,cy+sy*8);hx.lineTo(cx+sx*16,cy+sy*16)}hx.stroke()}
  if(!W.enemies.length){for(const a of W.asts){if(a.ore<=0||a===P.target)continue;const d=dist(a.pos,P.pos);if(d>1600)continue;const q=proj(a.pos);if(q.w<=0||q.x<0||q.x>w||q.y<0||q.y>h)continue;
   hx.fillStyle='rgba(255,160,70,.9)';hx.beginPath();hx.moveTo(q.x,q.y-7);hx.lineTo(q.x+6,q.y);hx.lineTo(q.x,q.y+7);hx.lineTo(q.x-6,q.y);hx.closePath();hx.fill();if(d<600)txt(Math.round(d)+' м',q.x,q.y+19,'#ffb070',10,'center',true)}}
  // damage direction arcs
  for(const d of P.dmgDirs){const rel=sub(d.from,P.pos);const x=dot(rel,RIGHT(P.q)),y=dot(rel,UP(P.q));const a=Math.atan2(-y,x);hx.strokeStyle=`rgba(255,70,50,${Math.min(1,d.t)})`;hx.lineWidth=5;hx.beginPath();hx.arc(cx,cy,46,a-.45,a+.45);hx.stroke()}
  // objective & target markers
  const ob=objective();const tg=P.target;
  if(ob.target&&ob.target!==tg)marker(ob.target,'#ffd166',ob.target.name||'',14,true);
  if(!P.nav&&S.routeDest&&routeNext())P.nav=navToward(S.routeDest);if(P.nav&&P.nav!==tg&&P.nav!==ob.target)marker(P.nav,'#7fe3ff',P.nav.name,12,true);
  for(const n of W.npcs||[]){const q=proj(n.pos);if(q.w>0&&q.x>0&&q.x<w&&q.y>0&&q.y<h&&dist(n.pos,P.pos)<2500){const al=rep(n.faction)>=30||n.role==='bhpatrol'&&false;hx.strokeStyle=al?'rgba(120,255,150,.85)':'rgba(230,240,255,.75)';hx.lineWidth=1.5;hx.beginPath();if(al)hx.arc(q.x,q.y,7,0,7);else{hx.moveTo(q.x,q.y-8);hx.lineTo(q.x+8,q.y);hx.lineTo(q.x,q.y+8);hx.lineTo(q.x-8,q.y);hx.closePath()}hx.stroke()}}
  if(W.id==='gar'&&hasClue('bh_lights')&&!hasClue('bh_corridor')&&W.bhAlign<.5){const k=clamp(1-W.bhAlign/.25,0,1);bar(w/2-70,h-62,140,7,k,k>.9?'#fff':'#ffb347','');txt('Створ огней '+Math.round(k*100)+'%',w/2,h-66,'#ffd98a',11,'center',true)}
  if(W.id==='white_pocket'){bar(w/2-70,h-62,140,7,(P.starHeat||0)/100,P.starHeat>80?'#ff4030':'#ffb347','');txt((W.inShadow?'В тени · ':'Жар звезды · ')+Math.round(P.starHeat||0)+'%',w/2,h-66,P.starHeat>80?'#ff8a7a':'#ffd98a',11,'center',true)}
  for(const e of W.enemies)if(e!==tg){const q=proj(e.pos);if(q.w>0&&q.x>0&&q.x<w&&q.y>0&&q.y<h){hx.strokeStyle='rgba(255,90,70,.8)';hx.lineWidth=1.5;hx.strokeRect(q.x-7,q.y-7,14,14)}}
  if(tg){const col=tg.kind==='enemy'?'#ff5a46':'#e8f1ff';marker(tg,col,'',18,true);const fm=fitOf(S.active).mis;if(fm&&tg.kind==='enemy'&&P.lockT>0){const q=proj(tg.pos);if(q.w>0){const need=REG.weapons[fm.id].lock*(st.scan?.75:1);hx.strokeStyle=P.locked?'#ffd166':'rgba(255,210,100,.6)';hx.lineWidth=3;hx.beginPath();hx.arc(q.x,q.y,26,-Math.PI/2,-Math.PI/2+Math.PI*2*Math.min(1,P.lockT/need));hx.stroke()}}
   if(tg.kind==='enemy'){const wp=REG.weapons[activeWeapon()]||REG.weapons.p_iskra;const lt=leadTime(P.pos,P.vel,wp.speed,tg.pos,tg.vel);const lp=add(tg.pos,scl(sub(tg.vel,P.vel),lt));const q=proj(lp);
    if(q.w>0){hx.strokeStyle='#ffcf5a';hx.lineWidth=2;hx.beginPath();hx.arc(q.x,q.y,6,0,7);hx.moveTo(q.x-10,q.y);hx.lineTo(q.x-4,q.y);hx.moveTo(q.x+4,q.y);hx.lineTo(q.x+10,q.y);hx.stroke()}}}
  // transport marker
  if(W.transport&&W.transport!==tg&&W.transport!==ob.target)marker(W.transport,'#9dff9d','',14,true);
  // bars
  bar(12,12,150,12,P.shield/st.shield,'#3aa7ff','Щит '+Math.ceil(P.shield));bar(12,28,150,12,P.hull/st.hull,P.hull/st.hull<.3?'#ff4a3a':'#e2a33a','Корпус '+Math.ceil(P.hull));
  hx.fillStyle='rgba(8,16,32,.6)';hx.fillRect(12,44,150,6);hx.fillStyle=P.boostT<.3?'#567':'#9fd4ff';hx.fillRect(12,44,150*P.boostT/3,6);
  txt(Math.round(P.spd)+' м/с',12,66,'#e8f1ff',14,'left',true);txt('тяга '+Math.round(P.thr*100)+'%'+(P.boosting?' · ФОРСАЖ':''),78,66,'#9fb6d8',11);
  {const aw=activeWeapon();const wd=aw&&REG.weapons[aw];bar(12,74,150,7,P.energy/st.energy,'#7fd0ff','');if(P.heat>1)bar(12,83,150,5,P.heat/100,P.ovh>0?'#ff4030':'#ff9a40','');
   if(wd)txt(wd.name.replace(/^[^«]*«|»$/g,'')+(weaponGroups().length>1?' ⇄':''),12,100,P.ovh>0?'#ff8a7a':'#a8ffb8',11);const fm=fitOf(S.active).mis;if(fm)txt('Ракеты: '+fm.ammo+(P.locked?' · ЗАХВАТ':''),12,114,P.locked?'#ffd166':'#cfe0ff',11)}
  if(P.stealthT>0)txt('СИГНАТУРА СКРЫТА '+Math.ceil(P.stealthT)+' с',w/2,h-50,'#9fd0ff',12,'center',true);
  {const inc=W.missiles.filter(m=>m.tgt===P&&!m.lost);if(inc.length||P.warnT>0){if(Math.sin(G.time*14)>0){hx.strokeStyle='rgba(255,60,40,.85)';hx.lineWidth=6;hx.strokeRect(3,3,w-6,h-6);txt(inc.length?'РАКЕТА! УВОРАЧИВАЙТЕСЬ'+(shipStats().jam?' ИЛИ ПОМЕХИ':''):'ВАС ЗАХВАТЫВАЮТ',w/2,h*.27,'#ff6050',15,'center',true)}
   for(const m of inc){const rel=sub(m.p,P.pos);const x=dot(rel,RIGHT(P.q)),y=dot(rel,UP(P.q));const a=Math.atan2(-y,x);hx.fillStyle='#ff5040';hx.save();hx.translate(cx+Math.cos(a)*62,cy+Math.sin(a)*62);hx.rotate(a);hx.beginPath();hx.moveTo(10,0);hx.lineTo(-6,-7);hx.lineTo(-6,7);hx.fill();hx.restore()}}}
  // mission line
  txt(ob.text,w/2,20,'#ffd98a',13,'center',true);const nh=routeNext();if(nh)txt('Маршрут → '+REG.systems[S.routeDest].name+' · следующий участок: '+(W.sys.main?'ворота → '+REG.systems[nh].name:'орбитальный переход'),w/2,35,'#7fe3ff',11,'center',true);
  // target info
  if(tg){const x=w-212,y=52;hx.fillStyle='rgba(6,12,26,.6)';hx.fillRect(x,y,200,tg.hull!=null?42:28);txt(tg.name||'',x+8,y+16,'#e8f1ff',12);txt(fmtD(dist(tg.pos,P.pos)),x+192,y+16,'#9fd0ff',12,'right');
   if(tg.hull!=null){bar(x+8,y+24,90,7,(tg.shield||0)/(tg.maxSh||1),'#3aa7ff','');bar(x+102,y+24,90,7,tg.hull/tg.max,'#e2a33a','')}
   else if(tg.kind==='ast'&&tg.ore!=null&&tg.maxOre)txt(st.scan?GOODS[tg.good]+' · '+RICH[tg.rich]+' · '+tg.ore+'/'+tg.maxOre+' · трюм '+cargoUsed()+'/'+st.cargo:'Состав: нужен сканер · трюм '+cargoUsed()+'/'+st.cargo,x+8,y+24+2,'#d9b48a',11)}
  // hint
  const coach=miningCoach();const hintTxt=hintI>=0&&hintI<HINTS.length?HINTS[hintI].t():coach;
  if(hintTxt){const t=hintTxt;hx.font='bold 14px system-ui';const tw=hx.measureText(t).width+28;hx.fillStyle='rgba(20,40,80,.82)';rr(w/2-tw/2,42,tw,30,8);hx.fill();hx.strokeStyle='#5aa0ff';hx.stroke();txt(t,w/2,62,'#fff',14,'center')}
  // drilling
  if(DR){const bw=Math.min(260,w*.34),x=w/2-bw/2,y=h*.7;hx.fillStyle='rgba(6,12,26,.75)';hx.fillRect(x-8,y-24,bw+16,48);
   hx.fillStyle='#253348';hx.fillRect(x,y,bw,12);hx.fillStyle='rgba(80,220,120,.55)';hx.fillRect(x+bw*.55,y,bw*.25,12);
   hx.fillStyle=DR.lock>0?'#f44':'#ffb347';hx.fillRect(x+bw*clamp(DR.heat,0,1)-2,y-4,4,20);
   hx.fillStyle='#6f6';hx.fillRect(x,y+15,bw*DR.zone/2,3);
   txt(DR.lock>0?'ПЕРЕГРЕВ — ждите':DR.full?'Трюм полон — освободите место':DR.heat<.5?'Держите кнопку — нагрев':DR.heat>.82?'Отпустите — перегрев близко!':'Так держать! В зелёной зоне',w/2,y-8,DR.heat>.82?'#ff9a7a':'#e8f1ff',12,'center',true);txt('жила '+DR.ast.ore+' · трюм '+cargoUsed()+'/'+st.cargo,w/2,y+30,'#bcd',10,'center')}
  // touch controls
  if(G.touch){for(const b of L.thr){const on=Math.abs(P.thr-b.v)<.05;hx.fillStyle=on?'rgba(90,160,255,.55)':'rgba(30,55,100,.4)';rr(b.x,b.y,b.w,b.h,7);hx.fill();hx.strokeStyle='rgba(160,200,255,.5)';hx.stroke();txt(b.label,b.x+b.w/2,b.y+b.h/2+5,'#e8f1ff',13,'center')}
   txt('ТЯГА',37,L.thr[2].y-6,'rgba(200,220,255,.6)',10,'center');
   const j=JOY||{ox:L.joy.x,oy:L.joy.y,x:L.joy.x,y:L.joy.y,r:L.joy.r};hx.strokeStyle='rgba(150,200,255,.4)';hx.lineWidth=2;hx.beginPath();hx.arc(j.ox,j.oy,j.r,0,7);hx.stroke();
   hx.fillStyle=JOY?'rgba(150,200,255,.45)':'rgba(150,200,255,.2)';hx.beginPath();hx.arc(j.x,j.y,j.r*.4,0,7);hx.fill();
   circBtn(L.fire,'ОГОНЬ',IN.fire,'rgba(255,90,60,.6)','fire');circBtn(L.boost,'ФОРСАЖ',IN.boost,'rgba(90,160,255,.6)','boost');
   if(weaponGroups().length>1)circBtn(L.weapon,'⇄ ОРУЖ',false,'','weapon');const fm=fitOf(S.active).mis;if(fm)circBtn(L.missile,'РАКЕТА '+fm.ammo,!!P.locked,'rgba(255,200,80,.6)','missile');
   if(st.jam)circBtn(L.jam,'ПОМ '+(P.jamCharges??st.jam),P.jamT>0,'rgba(255,220,120,.6)','jam');if(st.stealth)circBtn(L.stealth,(P.stealthCd>0?Math.ceil(P.stealthCd):'СКР')+'',P.stealthT>0,'rgba(120,200,255,.6)','stealth');
   for(const [b,ic,im] of [[L.pause,'II','pause'],[L.map,'⌖','map'],[L.target,'◎','target']]){hx.fillStyle='rgba(30,55,100,.6)';hx.beginPath();hx.arc(b.x,b.y,b.r,0,7);hx.fill();if(!hudIcon(im,b.x,b.y,b.r*1.15))txt(ic,b.x,b.y+6,'#e8f1ff',16,'center')}}
  const act=currentAction();if(act){const r=L.action;const on=Object.values(PTR).includes('action')||KB.KeyE;hx.fillStyle=on?'rgba(60,200,120,.75)':'rgba(30,140,80,.6)';rr(r.x-r.w/2,r.y-r.h/2,r.w,r.h,22);hx.fill();hx.strokeStyle='#7fffb0';hx.lineWidth=1.5;hx.stroke();
   txt(act.label+(G.touch?'':' [E]'),r.x,r.y+6,'#fff',15,'center',true)}
  if(P.hull/st.hull<.25&&Math.sin(G.time*8)>0){hx.fillStyle='rgba(255,30,20,.1)';hx.fillRect(0,0,w,h)}
 }
 if(noteT>0){noteT-=dt;hx.globalAlpha=Math.min(1,noteT*2);hx.font='bold 14px system-ui';const tw=hx.measureText(noteTxt).width+24;hx.fillStyle='rgba(6,12,26,.75)';rr(w/2-tw/2,h-34,tw,26,8);hx.fill();txt(noteTxt,w/2,h-16,'#fff',14,'center');hx.globalAlpha=1}
 if(toast){toast.t-=dt;if(toast.t<=0)toast=null;else{const [who,line]=toast.lines[0];hx.globalAlpha=Math.min(1,toast.t);hx.font='13px system-ui';const tw=Math.min(w*.6,hx.measureText(line).width+30);
  hx.fillStyle='rgba(10,24,48,.85)';rr(w/2-tw/2,74,tw,44,8);hx.fill();txt(who,w/2-tw/2+12,90,'#ffd98a',11);txt(line,w/2-tw/2+12,108,'#e8f1ff',13);hx.globalAlpha=1;
  if(toast.t<.5&&toast.lines.length>1){toast.lines.shift();toast.t=5}}}}
function drawCross(x,y){hx.beginPath();hx.arc(x,y,13,0,7);for(const [a,b,c,d] of [[-26,0,-15,0],[15,0,26,0],[0,-26,0,-15],[0,15,0,26]]){hx.moveTo(x+a,y+b);hx.lineTo(x+c,y+d)}hx.stroke();hx.fillRect(x-1,y-1,2,2)}
function marker(o,col,label,size,arrow){const q=proj(o.pos);const m=46;const d=dist(o.pos,P.pos);
 if(q.w>0&&q.x>m&&q.x<SW-m&&q.y>m&&q.y<SH-m){const r=Math.max(size,Math.min(60,(o.r||10)*camF*SH*.5/q.w));hx.strokeStyle=col;hx.lineWidth=2;hx.beginPath();
  for(const [sx,sy] of [[-1,-1],[1,-1],[1,1],[-1,1]]){hx.moveTo(q.x+sx*r,q.y+sy*r*.45);hx.lineTo(q.x+sx*r,q.y+sy*r);hx.lineTo(q.x+sx*r*.45,q.y+sy*r)}hx.stroke();
  txt((label?label+' · ':'')+fmtD(d),q.x,q.y+r+14,col,11,'center',true);return}
 if(!arrow)return;const rel=sub(o.pos,P.pos);let x=dot(rel,RIGHT(P.q)),y=dot(rel,UP(P.q));if(Math.abs(x)+Math.abs(y)<1e-3)y=1;
 const a=Math.atan2(-y,x);const rx=SW/2-58,ry=SH/2-58;const k=Math.min(rx/Math.abs(Math.cos(a)||1e-6),ry/Math.abs(Math.sin(a)||1e-6));
 const px=SW/2+Math.cos(a)*k,py=SH/2+Math.sin(a)*k;hx.save();hx.translate(px,py);hx.rotate(a);hx.fillStyle=col;hx.beginPath();hx.moveTo(16,0);hx.lineTo(-7,-10);hx.lineTo(-7,10);hx.fill();hx.restore();
 txt(fmtD(d),px-Math.cos(a)*24,py-Math.sin(a)*24+4,col,11,'center',true)}
function bar(x,y,w,h,v,c,l){hx.fillStyle='rgba(8,16,32,.65)';hx.fillRect(x,y,w,h);hx.fillStyle=c;hx.fillRect(x,y,w*clamp(v,0,1),h);hx.strokeStyle='rgba(150,190,255,.35)';hx.lineWidth=1;hx.strokeRect(x,y,w,h);if(l)txt(l,x+4,y+h-2,'#fff',10)}
function txt(t,x,y,c,s,a='left',sh=false){hx.font=(sh?'bold ':'')+s+'px system-ui';hx.textAlign=a;if(sh){hx.fillStyle='rgba(0,0,0,.6)';hx.fillText(t,x+1,y+1)}hx.fillStyle=c;hx.fillText(t,x,y);hx.textAlign='left'}
function rr(x,y,w,h,r){hx.beginPath();hx.moveTo(x+r,y);hx.arcTo(x+w,y,x+w,y+h,r);hx.arcTo(x+w,y+h,x,y+h,r);hx.arcTo(x,y+h,x,y,r);hx.arcTo(x,y,x+w,y,r);hx.closePath()}
function circBtn(b,t,on,col,ic){hx.fillStyle=on?col:'rgba(30,55,100,.42)';hx.strokeStyle='rgba(170,205,255,.6)';hx.lineWidth=2;hx.beginPath();hx.arc(b.x,b.y,b.r,0,7);hx.fill();hx.stroke();
 if(ic&&hudIcon(ic,b.x,b.y-b.r*.12,b.r*.95)){const sub=String(t).match(/\d+$/);txt(sub?sub[0]:'',b.x,b.y+b.r*.72,'#e8f1ff',Math.max(10,Math.round(b.r*.3)),'center',true);return}
 txt(t,b.x,b.y+5,'#e8f1ff',Math.max(10,Math.round(b.r*.3)),'center',true)}

// ================= screens =================
function show(id,on){$(id).classList.toggle('hide',!on)}
function hideAll(){for(const id of ['menu','station','pause','map','dead','dlg','confirm','win','m4fail','choice','credits'])show(id,false);if(G.mode==='map')G.mode='fly'}
function uiMenu(){hideAll();show('menu',true);G.mode='menu';const ls=loadSlot();if(G.bootStatus&&G.bootStatus!=='ok'){ls.status=G.bootStatus;G.bootStatus=null}$('contBtn').style.display=ls.save?'':'none';$('verLine').textContent='версия '+GAME_VERSION;
 $('saveMsg').textContent=ls.status==='backup'?'Основное сохранение повреждено — загружена резервная копия.':ls.status==='corrupt'?'Сохранение повреждено и резервной копии нет. Можно импортировать прогресс в настройках.':ls.status==='migrated'?'Прогресс первой версии перенесён (копия сохранена).':''}
let stTab='hangar',stMsg='';
function uiShowStation(){hideAll();show('station',true);renderStation()}
function uiHideStation(){show('station',false)}
function head(){const st=shipStats();const f=REG.stations[S.station].faction;return `<div class="sthead"><b>${isHome()&&S.home.level>0?STATIONS[S.station].homeName:STATIONS[S.station].name}</b>${f&&f!=='none'?`<span class="dim">${emblemSVG(f,16)} ${REG.factions[f].short}: ${repLabel(rep(f))}</span>`:''}<span>💰 ${S.cr} кр.</span><span>Трюм ${cargoUsed()}/${st.cargo}</span></div>`}
function svcHas(s){return REG.stations[S.station].services.includes(s)}
function statRow(st){return `Корпус ${st.hull} · Щит ${st.shield} · Трюм ${st.cargo} · Энергия ${st.energy} (+${st.regen}/с) · Скорость ${st.speed} м/с · Манёвр ${st.turn}`}
function delta(a,b,k,lbl,inv){const d=Math.round((b[k]-a[k])*100)/100;if(!d)return '';const good=inv?d<0:d>0;return `<span style="color:${good?'#7fe0a0':'#ff8a7a'}">${lbl} ${a[k]}→${b[k]}</span>`}
function diffLine(a,b){return [delta(a,b,'hull','Корпус'),delta(a,b,'shield','Щит'),delta(a,b,'cargo','Трюм'),delta(a,b,'energy','Энергия'),delta(a,b,'regen','Реген'),delta(a,b,'speed','Скорость'),delta(a,b,'turn','Манёвр'),delta(a,b,'boost','Форсаж')].filter(Boolean).join(' · ')||'<span class="dim">без изменений в цифрах</span>'}
function renderStation(){try{const el=$('station');const bgk=stationBg(S.station,stTab);if(el.dataset.bg!==bgk){el.dataset.bg=bgk;el.style.backgroundImage=`linear-gradient(90deg,rgba(4,10,24,.35),rgba(4,10,24,.82) 14%,rgba(4,10,24,.88)),url(${UIA}station_bg/bg_${bgk}.jpg)`}}catch(e){}const tabs=[['hangar',isHome()?'Ваш док':'Ангар'],['market','Рынок'],['equip','Оборудование'],...(svcHas('shipyard')?[['yard','Верфь']]:[]),['jobs','Контракты'],...(svcHas('bar')?[['bar','Бар']]:[])];if(stTab==='yard'&&!svcHas('shipyard'))stTab='hangar';
 let html=head()+'<div class="tabs">'+tabs.map(([k,n])=>`<button class="tab${stTab==k?' on':''}" data-tab="${k}">${svcIcon(k==='hangar'&&isHome()?'home':k==='equip'?'equip':k)}<span class="tl">${n}</span>${k==='jobs'&&hasOffer()?' •':''}</button>`).join('')+'</div><div class="stbody">';
 const st=shipStats();const f=fitOf(S.active);
 if(stTab==='hangar'){G.preview=null;html+=`<div class="shipcard"><div class="big">${clsIcon(REG.ships[S.active].cls)}«${st.name}» <span class="dim" style="font-size:13px">${CLASS_NAME[REG.ships[S.active].cls]} · ${st.maker}</span></div><div class="dim">${st.desc}</div>
   <div class="stats">${statRow(st)}</div><div class="stats">Оружие: ${f.w.map(x=>x?REG.weapons[x].name:'—').join(', ')}${f.mis?' · '+REG.weapons[f.mis.id].name+' ×'+f.mis.ammo:''}</div>
   <div class="stats">Модули: ${f.m.map(x=>REG.modules[x].name).join(', ')||'нет'}</div>${S.ships.length>1?'<div class="row">Ваш флот: '+S.ships.map(id=>id===S.active?`<b>${REG.ships[id].name}</b>`:`<button data-ship="${id}">${REG.ships[id].name}</button>`).join(' ')+'</div>':''}</div>
   <div class="cargo">${cargoList()}</div>${homeHTML()}${storageHTML()}<div class="obj">Задание: ${objectiveText()}</div><div class="dim">Ведите пальцем по кораблю слева, чтобы повернуть его.</div>
   <button id="launchBtn" class="huge">Вылет</button>`}
 else if(stTab==='market'){const law=lawOf(S.sys);html+=`<div class="dim">Закон: ${law.name}${law.banned.length?' · запрещено: '+law.banned.map(g=>GOODS[g]).join(', '):' · запретов нет'}</div><div class="mk">`;
  let lastCat='';for(const g of marketGoods(S.station).sort((a,b)=>Object.keys(GOOD_CATS).indexOf(REG.goods[a].cat)-Object.keys(GOOD_CATS).indexOf(REG.goods[b].cat))){const b=bat[g]||1;const cat=REG.goods[g].cat;
   if(cat!==lastCat){html+=`<div class="sec">${GOOD_CATS[cat]}</div>`;lastCat=cat}const pb=price(g,'buy'),ps=price(g,'sell');const tip=bestKnown(g);
   html+=`<div class="good"><div class="gn">${goodIcon(g)}${GOODS[g]}</div>
   <div class="gp">${pb?'купить <b>'+pb+'</b> · ':'не продают · '}продать <b>${ps}</b>${tip?' · <span style="color:#7fe0a0">'+tip+'</span>':''}</div><div class="gs">склад ${stockOf(S.station)[g]||0} · у вас ${S.cargo[g]||0}</div>
   <div class="row"><button data-dec="${g}">−</button><span class="bat">${b}</span><button data-inc="${g}">+</button>${pb?`<button data-max="${g}">Максимум</button><button class="buy" data-buy="${g}">Купить ×${b}</button>`:''}<button class="sell" data-sell="${g}">Продать ×${b}</button></div></div>`}
  html+='</div>';if(S.citems.length)html+=`<div class="dim">Контрактный груз (не продаётся): ${S.citems.map(c=>CITEMS[c]).join(', ')}</div>`;
  const ill=illegalCargo(S.station);if(ill.length)html+=`<div class="bad">В трюме запрещённое здесь: ${ill.map(g=>GOODS[g]).join(', ')}</div>`}
 else if(stTab==='equip'){const sh=svcHas('equip')?shopEquipment(S.station):{w:[],m:[]};const inv=invOf();
  html+=`<div class="sec">Ваш корабль «${st.name}» · энергия +${st.regen}/с</div>`;
  f.w.forEach((x,i)=>{html+=`<div class="item">${x?wpnIcon(x):''}<span style="flex:1">Узел ${i+1}: ${x?REG.weapons[x].name:'<span class="dim">пусто</span>'}</span>${x?`<button data-unw="${i}">Снять</button>`:''}</div>`});
  if(REG.ships[S.active].missile)html+=`<div class="item"><span>Ракетный узел: ${f.mis?REG.weapons[f.mis.id].name+' · '+f.mis.ammo+'/'+REG.weapons[f.mis.id].ammo:'<span class="dim">пусто</span>'}</span>${f.mis?`<button data-ammo="1">Боезапас</button><button data-unmis="1">Снять</button>`:''}</div>`;
  for(let i=0;i<st.mslots;i++){const x=f.m[i];html+=`<div class="item">${x?modIcon(x):''}<span style="flex:1">Слот ${i+1}: ${x?REG.modules[x].name:'<span class="dim">пусто</span>'}</span>${x?`<button data-unm="${i}">Снять</button>`:''}</div>`}
  if(inv.w.length||inv.m.length){html+='<div class="sec">Склад снаряжения</div>';inv.w.forEach((x,i)=>{html+=`<div class="item"><span>${REG.weapons[x].name}</span><button data-eqw="${i}">Установить</button></div>`});inv.m.forEach((x,i)=>{html+=`<div class="item"><span>${REG.modules[x].name}</span><button data-eqm="${i}">Установить</button></div>`})}
  html+=blueprintHTML();
  if(!svcHas('equip'))html+='<div class="dim">Здесь не продают снаряжение.</div>';
  else{html+='<div class="sec">Продаётся здесь</div>';
   for(const id of sh.m){const m=REG.modules[id];const pv=previewWith('m',id);const pr=moduleProblem(id);html+=`<div class="item">${modIcon(id)}<div style="flex:1"><b>${m.name}</b> — ${m.price} кр.<div class="dim">${m.desc} · энергия −${m.draw}/с</div><div class="dim">${pr?'<span class="bad">'+pr+'</span>':pv?diffLine(st,pv):'Нет свободного слота — уйдёт на склад'}</div></div><button data-mod="${id}">Купить</button></div>`}
   for(const id of sh.w){const w=REG.weapons[id];const dps=w.fam==='beam'?w.dmg:Math.round(w.dmg*w.rate*(w.pellets||1)*(w.burst||1));
    html+=`<div class="item">${wpnIcon(id)}<div style="flex:1"><b>${w.name}</b> — ${w.price} кр. <span class="dim">${WFAM[w.fam]}</span><div class="dim">${w.role} · урон ~${dps}/с${w.energy?' · энергия '+w.energy+(w.fam==='beam'?'/с':'/выстр.'):''}${w.heat?' · нагрев':''}${w.fam==='missile'?' · захват '+w.lock+' с · боезапас '+w.ammo:''}</div>
     ${w.fam==='missile'&&!REG.ships[S.active].missile?'<div class="bad dim">У этого корабля нет ракетного узла</div>':''}</div><button data-wpn="${id}">Купить</button></div>`}}}
 else if(stTab==='yard'){const here=Object.values(REG.ships).filter(s=>s.shops.includes(S.station));
  html+=`<div class="dim">Нажмите «Осмотреть», чтобы увидеть корабль в ангаре и повернуть его пальцем.</div>`;
  for(const s of here){const own=S.ships.includes(s.id);const cand=statsFor(s.id,own?fitOf(s.id):defaultFit(s.id));
   html+=`<div class="item">${clsIcon(s.cls)}<div style="flex:1"><b>«${s.name}»</b> — ${s.price} кр. <span class="dim">${CLASS_NAME[s.cls]} · ${s.maker}</span><div class="dim">${s.tradeoff}</div>
    <div class="dim">Оруж. узлов ${s.wslots}${s.missile?' + ракеты':''} · модулей ${s.mslots} · ${diffLine(st,cand)}</div></div>
    <div><button data-prev="${s.id}">Осмотреть</button>${S.active===s.id?'<span class="ok">Ваш</span>':own?`<button data-ship="${s.id}">Пересесть</button>`:shipLocked(s.id)?`<span class="bad dim">${shipLocked(s.id)}</span>`:`<button data-buyship="${s.id}">Купить ${discPrice(s.price)!==s.price?'('+discPrice(s.price)+')':''}</button>`}</div></div>`}}
 else if(stTab==='bar'){const tp=barTopics();G.barTopics=tp;html+='<div class="sec">Разговоры</div>'+tp.map((t,i)=>`<div class="item">${portraitHTML(t.who,false,'s')}<div style="flex:1"><b>${t.who}</b><div class="dim">${t.text}</div></div>${t.buy?`<button data-bar="${i}">${t.buy} кр.</button>`:t.fn?`<button data-bar="${i}">Запомнить</button>`:''}</div>`).join('')}
 else if(stTab==='jobs'){syncLegacy();const c=camp();
  if(c.cur){const m=MIS[c.cur];const o=campObjective();html+=`<div class="sec">Текущее задание</div><div class="item"><div><b>Акт ${m.act}. ${m.title}</b> — ${m.reward} кр.<div class="dim">${m.desc}</div><div class="act">${o?o.text:''}</div></div>${campStepDef()&&campStepDef().t==='choice'?'<button data-choice="1">Решить</button>':''}</div>`}
  const offers=campOffersHere();if(offers.length){html+='<div class="sec">Сюжетные задания здесь</div>';for(const id of offers){const m=MIS[id];html+=`<div class="item"><div><b>Акт ${m.act}. ${m.title}</b> — ${m.reward} кр.<div class="dim">${REG.heroes[m.giver].name}: ${m.desc}</div></div><button data-camp="${id}">Принять</button></div>`}}
  syncSide();const sd=slotState('side');if(sd.cur){withSlot('side',()=>{const m=campMis();const o=campObjective();html+=`<div class="sec">Побочное задание</div><div class="item"><div><b>${CHAIN_NAME[m.chain]}: ${m.title}</b> — ${m.reward} кр.<div class="act">${o?o.text:''}</div></div>${campStepDef()&&campStepDef().t==='choice'?'<button data-choice="side">Решить</button>':''}</div>`})}
  const so=sd.avail.filter(id=>MIS[id].from===S.station);if(so.length){html+='<div class="sec">Побочные истории здесь</div>';for(const id of so){const m=MIS[id];html+=`<div class="item"><div><b>${CHAIN_NAME[m.chain]} ${m.n}/3: ${m.title}</b> — ${m.reward} кр.<div class="dim">${m.desc}</div></div><button data-camp="${id}">Принять</button></div>`}}
  const jb=slotState('job');if(jb.cur){withSlot('job',()=>{const m=campMis();const o=campObjective();html+=`<div class="sec">Контракт</div><div class="item"><div><b>${m.title}</b> — ${m.reward} кр.<div class="act">${o?o.text:''}</div></div><button data-dropjob="1">Отказаться</button></div>`})}
  else if(svcHas('contracts')&&S.ms.m1.st==='done'){html+='<div class="sec">Доска контрактов</div>';genJobs(S.station).forEach((j,i)=>{html+=`<div class="item"><div><b>${j.title}</b> — ${j.reward} кр.<div class="dim">${JOB_NAME[j.type]} · ${j.desc}</div></div><button data-job="${i}">Принять</button></div>`})}
  const elsewhere=c.avail.filter(id=>MIS[id].from!==S.station);if(elsewhere.length)html+=`<div class="dim">Вас ждут: ${elsewhere.map(id=>'«'+MIS[id].title+'» на станции '+STATIONS[MIS[id].from].name).join('; ')}</div>`;
  html+='<div class="sec">Поручения</div>';
  for(const m of MISSIONS){const s=S.ms[m.id];if(s.st==='locked')continue;
   html+=`<div class="item"><div><b>${m.name}</b> — ${m.reward} кр.<div class="dim">${m.desc}</div></div>${s.st==='done'?'<span class="ok">Выполнено'+(s.paid?' · оплачено':'')+'</span>':s.st==='active'?'<span class="act">Выполняется</span>':
   S.station===m.from?`<button data-accept="${m.id}">Принять</button>`:`<span class="dim">на ${STATIONS[m.from].name}</span>`}</div>`}
  if(false){if(S.contract){const c=S.contract;html+=`<div class="item"><div><b>${c.name}</b> — ${c.reward} кр.<div class="dim">${c.type==='mine'?'Добыто '+c.mined+'/'+c.qty+'. ':''}Сдать на станции ${STATIONS[c.to].name}.</div></div><button data-drop="1">Отказаться</button></div>`}
   else{genOffers();(S.offers[S.station]||[]).forEach((c,i)=>{html+=`<div class="item"><div><b>${c.name}</b> — ${c.reward} кр.<div class="dim">${c.type==='mine'?'Руду нужно добыть буром.':'Товар купите сами.'}</div></div><button data-contract="${i}">Принять</button></div>`})}}}
 html+=`</div><div class="stmsg">${stMsg}</div>`;$('station').innerHTML=html;stMsg='';
 $('station').onclick=onStationClick;const lb=$('launchBtn');if(lb)lb.onclick=()=>{sfx('click');G.preview=null;launch()}}
const bat={};
function bestKnown(g){let best=null;for(const id in (S.known||{})){if(id===S.station)continue;const k=S.known[id].p[g];if(k&&(!best||k[1]>best.p))best={p:k[1],id}}const here=price(g,'buy');if(best&&here&&best.p>here)return 'на «'+REG.stations[best.id].name+'» берут по '+best.p;return ''}
function storageHTML(){const st=storageOf(S.station);const cargoG=Object.keys(S.cargo).filter(g=>S.cargo[g]>0);const stG=Object.keys(st).filter(g=>st[g]>0);if(!cargoG.length&&!stG.length)return '';
 let h='<div class="sec">Склад станции</div>';for(const g of cargoG)h+=`<div class="item"><span>${GOODS[g]} ×${S.cargo[g]} (в трюме)</span><button data-store="${g}">На склад</button></div>`;
 for(const g of stG)h+=`<div class="item"><span>${GOODS[g]} ×${st[g]} (на складе)</span><button data-take="${g}">В трюм</button></div>`;return h}
function blueprintHTML(){let h='';const here=Object.values(REG.blueprints).filter(b=>b.where===S.station&&!(S.bps||[]).includes(b.id));const mine=(S.bps||[]).map(id=>REG.blueprints[id]);
 if(here.length){h+='<div class="sec">Чертежи на продажу</div>';for(const b of here)h+=`<div class="item"><div><b>${b.name}</b> — ${b.price} кр.<div class="dim">Материалы: ${Object.entries(b.mats).map(([g,n])=>GOODS[g]+' ×'+n).join(', ')} · работа ${b.fee} кр.</div></div><button data-bp="${b.id}">Купить</button></div>`}
 if(mine.length){h+='<div class="sec">Мастерская: ваши чертежи</div>';for(const b of mine){const miss=bpMissing(b.id);h+=`<div class="item"><div><b>${b.name}</b><div class="dim">${miss.length?'<span class="bad">Не хватает: '+miss.join(', ')+'</span>':'Материалы есть (трюм + склад) · работа '+b.fee+' кр.'}</div></div>${svcHas('equip')?`<button data-craft="${b.id}" ${miss.length?'disabled':''}>Изготовить</button>`:''}</div>`}}
 return h}
function hasOffer(){return ['m2','m3','m4'].some(k=>S.ms[k].st==='offered'&&MISSIONS.find(m=>m.id==k).from===S.station)||campOffersHere().length>0||(camp().cur&&campStepDef()&&campStepDef().t==='choice')}
function objectiveText(){if(!W)return '';const o=objective();return o.text}
function cargoList(){const items=Object.keys(S.cargo).filter(g=>S.cargo[g]>0).map(g=>GOODS[g]+' ×'+S.cargo[g]);const ci=S.citems.map(c=>'<span class="ci">'+CITEMS[c]+' (контракт)</span>');return 'Трюм: '+([...items,...ci].join(', ')||'пусто')}
function onStationClick(e){const b=e.target.closest('button');if(!b)return;sfx('click');const d=b.dataset;
 if(d.tab){stTab=d.tab;renderStation();return}
 if(d.inc){bat[d.inc]=(bat[d.inc]||1)+1;renderStation();return}if(d.dec){bat[d.dec]=Math.max(1,(bat[d.dec]||1)-1);renderStation();return}
 if(d.max){const m=maxBuy(d.max);bat[d.max]=Math.max(1,m);stMsg=m?'Максимум для покупки: '+m:'Купить нельзя: '+(S.cr<price(d.max,'buy')?'нет денег':cargoFree()<=0?'трюм полон':'склад пуст');renderStation();return}
 if(d.buy){const r=buy(d.buy,bat[d.buy]||1);stMsg=r||'Куплено: '+GOODS[d.buy]+' ×'+(bat[d.buy]||1);if(r)sfx('deny');renderStation();return}
 if(d.sell){const r=sell(d.sell,bat[d.sell]||1);stMsg=r||'Продано: '+GOODS[d.sell]+' ×'+(bat[d.sell]||1);if(r)sfx('deny');renderStation();return}
 if(d.mod){const m=REG.modules[d.mod];const st=shipStats();const pv=previewWith('m',d.mod);const pr=moduleProblem(d.mod);
  confirmBox(`Купить «${m.name}» за ${m.price} кр.?`,`Останется: ${S.cr-m.price} кр.<br>${pr?pr:pv?'Щит: '+st.shield+' → '+pv.shield+'<br>'+diffLine(st,pv):'Нет свободного слота: модуль уйдёт на склад'}`,S.cr>=m.price,()=>{const r=buyModule(d.mod);stMsg=r||'Установлено: '+m.name;renderStation()});return}
 if(d.wpn){const w=REG.weapons[d.wpn];confirmBox(`Купить «${w.name}» за ${w.price} кр.?`,`Останется: ${S.cr-w.price} кр.<br>${w.role}`,S.cr>=w.price,()=>{const r=buyWeapon(d.wpn);stMsg=r||'Установлено: '+w.name;renderStation()});return}
 if(d.store){stMsg=storeGood(d.store,S.cargo[d.store])||'Сдано на склад';renderStation();return}if(d.take){stMsg=takeGood(d.take,storageOf(S.station)[d.take])||'Взято в трюм';renderStation();return}
 if(d.bp){const b=REG.blueprints[d.bp];confirmBox('Купить «'+b.name+'» за '+b.price+' кр.?','Останется: '+(S.cr-b.price)+' кр.',S.cr>=b.price,()=>{stMsg=buyBlueprint(d.bp)||'Чертёж ваш';renderStation()});return}
 if(d.craft){const r=craft(d.craft);stMsg=r.startsWith('✓')?r.slice(1):r;renderStation();return}
 if(d.ammo){const r=buyAmmo();stMsg=r||'Боезапас пополнен';renderStation();return}
 if(d.unw!=null){stMsg=unequip('w',+d.unw)||'Снято на склад';renderStation();return}if(d.unm!=null){stMsg=unequip('m',+d.unm)||'Снято на склад';renderStation();return}if(d.unmis){stMsg=unequip('mis')||'Снято на склад';renderStation();return}
 if(d.eqw!=null){stMsg=equip('w',+d.eqw)||'Установлено';renderStation();return}if(d.eqm!=null){stMsg=equip('m',+d.eqm)||'Установлено';renderStation();return}
 if(d.prev){G.preview=d.prev;G.prevRot=0;stMsg='В ангаре: «'+REG.ships[d.prev].name+'». Ведите пальцем по кораблю, чтобы повернуть.';renderStation();return}
 if(d.buyship){const s=REG.ships[d.buyship],c=shipStats();const cand=statsFor(s.id,defaultFit(s.id));confirmBox(`Купить корабль «${s.name}» за ${s.price} кр.?`,`Останется: ${S.cr-s.price} кр.<br>${diffLine(c,cand)}<br>${s.tradeoff}`,S.cr>=s.price,()=>{const r=buyShip(d.buyship);stMsg=r||'Вы пересели на «'+s.name+'»';G.preview=null;renderStation()});return}
 if(d.ship){const r=switchShip(d.ship);stMsg=r||'Вы пересели на «'+REG.ships[d.ship].name+'»';G.preview=null;renderStation();return}
 if(d.bar!=null){const t=G.barTopics[+d.bar];if(t.buy){if(S.cr<t.buy){stMsg='Не хватает кредитов';renderStation();return}S.cr-=t.buy}t.fn&&t.fn();saveGame();stMsg='Записано в журнал';renderStation();return}
 if(d.job!=null){stMsg=acceptJob(+d.job)||'Контракт принят';renderStation();return}if(d.dropjob){dropJob();stMsg='Контракт отменён';renderStation();return}
 if(d.home){stMsg=homeUpgrade()||'Работы завершены!';renderStation();return}
 if(d.camp){const r=campAccept(d.camp);stMsg=r||'Задание принято';renderStation();return}
 if(d.choice){const sl=d.choice==='side'?'side':'camp';withSlot(sl,()=>uiChoice(campStepDef(),sl));return}
 if(d.accept){const r=acceptMission(d.accept);stMsg=r||'Поручение принято';if(!r&&d.accept==='m3')stMsg='Анализатор в трюме. Маршрут на Иней проложен.';renderStation();return}
 if(d.contract){const r=acceptContract(+d.contract);stMsg=r||'Контракт принят';renderStation();return}
 if(d.drop){dropContract();stMsg='Контракт отменён';renderStation()}}
function confirmBox(title,body,ok,fn){$('confirm').innerHTML=`<div class="box"><h3>${title}</h3><p>${body}</p>${ok?'':'<p class="bad">Недостаточно кредитов</p>'}<div><button id="cYes" ${ok?'':'disabled'}>Подтвердить</button><button id="cNo">Отмена</button></div></div>`;
 show('confirm',true);$('cYes').onclick=()=>{show('confirm',false);sfx('click');fn()};$('cNo').onclick=()=>{show('confirm',false);sfx('click')}}
let dlgQ=[];
function uiDialog(lines,inFlight){sfx('radio');G.radioLog=G.radioLog||[];for(const l of lines){G.radioLog.push(l);if(S){S.log=S.log||[];S.log.push(l);if(S.log.length>40)S.log.shift()}}if(G.radioLog.length>60)G.radioLog.splice(0,20);if(inFlight&&G.mode!=='hangar'){toast={lines:[...lines],t:5};return}dlgQ=[...lines];nextDlg()}
function nextDlg(){if(!dlgQ.length){show('dlg',false);if(G.mode==='hangar')renderStation();return}const [who,line]=dlgQ.shift();$('dlg').innerHTML=`<div class="box" style="display:flex;gap:12px;align-items:flex-start">${portraitHTML(who,false)}<div style="flex:1"><div class="who">${who}</div><p>${line}</p><button id="dlgOk">${dlgQ.length?'Дальше':'Понятно'}</button></div></div>`;show('dlg',true);$('dlgOk').onclick=()=>{sfx('click');nextDlg()}}
function uiPause(){if(G.mode!=='fly')return;G.mode='pause';resetInput();renderPause('main');show('pause',true);sndEngine(0,false,false)}
function uiResume(){show('pause',false);show('map',false);if(G.mode==='pause'||G.mode==='map')G.mode='fly';lastT=performance.now()}
function renderPause(view){let h='<div class="box">';
 if(view==='main')h+=`<h2>Пауза</h2><button data-p="resume">Продолжить</button><button data-p="journal">Журнал</button><button data-p="cargo">Трюм</button><button data-p="map">Карта</button><button data-p="settings">Настройки</button><button data-p="menu">Главное меню</button>`;
 if(view==='cargo'){h+=`<h2>Трюм ${cargoUsed()}/${shipStats().cargo}</h2>`;let any=false;for(const g of Object.keys(S.cargo))if(S.cargo[g]>0){any=true;h+=`<div class="item"><span>${GOODS[g]} ×${S.cargo[g]}</span><button data-j="${g}">Выбросить 1</button></div>`}
  for(const c of S.citems){any=true;h+=`<div class="item"><span>${CITEMS[c]}</span><span class="dim">контракт</span></div>`}if(!any)h+='<p class="dim">Трюм пуст</p>';h+=`<button data-p="main">Назад</button>`}
 if(view==='settings')h+=settingsHTML()+`<button data-p="main">Назад</button>`;
 if(view==='journal')h+=journalHTML()+`<button data-p="main">Назад</button>`;
 h+='</div>';$('pause').innerHTML=h;bindSettings();
 $('pause').onclick=e=>{const b=e.target.closest('button');if(!b)return;sfx('click');const d=b.dataset;
  if(d.p==='resume')uiResume();else if(d.p==='cargo')renderPause('cargo');else if(d.p==='journal')renderPause('journal');else if(d.p==='inspect'){addClue('bh_lights');renderPause('journal')}else if(d.p==='settings')renderPause('settings');else if(d.p==='main')renderPause('main');
  else if(d.p==='map'){show('pause',false);G.mode='fly';uiMap()}else if(d.p==='menu'){confirmBox('Выйти в меню?','Прогресс после последней стыковки будет потерян.',true,()=>{show('pause',false);if(G.duel)G.duel=false;uiMenu()})}
  else if(d.j){jettison(d.j);renderPause('cargo')}}}
const ASSIST_N=['выкл','слабая','сильная'];
function rng(id,label,min,max,step,val){return `<label>${label} <input id="${id}" type="range" min="${min}" max="${max}" step="${step}" value="${val}"></label>`}
function settingsHTML(){return `<h2>Настройки</h2>
 ${rng('volMusic','Музыка',0,1,.05,SET.volMusic)}${rng('volSfx','Эффекты',0,1,.05,SET.volSfx)}${rng('volRadio','Радио',0,1,.05,SET.volRadio)}
 ${rng('sens','Чувствительность',.5,1.6,.05,SET.sens)}${rng('joySize','Размер джойстика',.8,1.4,.05,SET.joySize)}${rng('btnScale','Размер кнопок',.8,1.3,.05,SET.btnScale)}${rng('shake','Тряска',0,1,.1,SET.shake)}
 <button id="aBtn">Помощь в прицеливании: ${ASSIST_N[SET.assist|0]}</button>
 <button id="qBtn">Качество: ${SET.quality==='low'?'низкое (телефон)':'высокое'}</button><button id="iBtn">Инверсия по вертикали: ${SET.invert?'вкл':'выкл'}</button>
 <button id="rBtn">Сбросить управление</button>
 <div style="margin-top:8px"><button id="expBtn">Экспорт прогресса</button><button id="impBtn">Импорт прогресса</button></div><div id="xio"></div>
 <div class="dim" style="margin-top:6px">Версия ${GAME_VERSION} · <button id="diagBtn" style="min-height:28px;padding:2px 8px;font-size:12px">Скопировать диагностику</button></div><div id="diagOut" class="dim"></div>`}
function bindSettings(){for(const k of ['volMusic','volSfx','volRadio','sens','joySize','btnScale','shake']){const el=$(k);if(el)el.oninput=()=>{SET[k]=+el.value;sndApplyVolumes();storeSettings()}}
 const a=$('aBtn');if(a)a.onclick=e=>{e.stopPropagation();SET.assist=((SET.assist|0)+1)%3;storeSettings();a.textContent='Помощь в прицеливании: '+ASSIST_N[SET.assist]};
 const q=$('qBtn');if(q)q.onclick=e=>{e.stopPropagation();SET.quality=SET.quality==='low'?'high':'low';applyQuality();storeSettings();q.textContent='Качество: '+(SET.quality==='low'?'низкое (телефон)':'высокое')};
 const i=$('iBtn');if(i)i.onclick=e=>{e.stopPropagation();SET.invert=!SET.invert;storeSettings();i.textContent='Инверсия по вертикали: '+(SET.invert?'вкл':'выкл')};
 const r=$('rBtn');if(r)r.onclick=e=>{e.stopPropagation();for(const k of ['sens','joySize','btnScale','shake','assist','invert'])SET[k]=SET_DEF[k];storeSettings();const box=r.closest('.box');const holder=box&&box.parentElement;if(holder&&holder.id==='pause')renderPause('settings');else{$('menuSet').innerHTML=settingsHTML();bindSettings()}};
 const ex=$('expBtn');if(ex)ex.onclick=e=>{e.stopPropagation();const s=exportSave();$('xio').innerHTML=s?`<textarea id="xta" readonly style="width:100%;height:70px;font-size:11px">${s}</textarea><button id="xcp">Копировать</button>`:'<p class="dim">Сохранения пока нет</p>';
  const c=$('xcp');if(c)c.onclick=ev=>{ev.stopPropagation();const t=$('xta');t.select();try{navigator.clipboard.writeText(t.value).then(()=>c.textContent='Скопировано',()=>c.textContent='Выделено — скопируйте вручную')}catch(_){c.textContent='Выделено — скопируйте вручную'}}};
 const im=$('impBtn');if(im)im.onclick=e=>{e.stopPropagation();$('xio').innerHTML=`<textarea id="ita" style="width:100%;height:70px;font-size:11px" placeholder="Вставьте строку прогресса (DR2:...)"></textarea><button id="ild">Загрузить</button><div id="imsg" class="dim"></div>`;
  $('ild').onclick=ev=>{ev.stopPropagation();const r=importSave($('ita').value);$('imsg').textContent=r||'Прогресс загружен. Нажмите «Продолжить» в главном меню.';if(!r&&G.mode!=='menu'){hideAll();enterHangar(false)}}};
 const dg=$('diagBtn');if(dg)dg.onclick=e=>{e.stopPropagation();const s=diagLine();$('diagOut').textContent=s;try{navigator.clipboard.writeText(s)}catch(_){}}}
function applyQuality(){G.low=SET.quality==='low';G.maxParts=G.low?700:2500;resizeGL()}
// ----- map -----
const MAPV={x:540,y:320,z:1,sel:null,tab:'gal',filter:'',q:''};
function uiMap(){if(G.mode!=='fly'&&G.mode!=='pause')return;G.mode='map';resetInput();if(!MAPV.sel)MAPV.sel=W.id;const m=REG.systems[W.id].map;MAPV.x=m[0];MAPV.y=m[1];show('map',true);renderMap();requestAnimationFrame(drawMapCanvas)}
function uiCloseMap(){show('map',false);if(G.mode==='map')G.mode='fly';lastT=performance.now()}
function fmtDate(t){const d=new Date(t);return String(d.getDate()).padStart(2,'0')+'.'+String(d.getMonth()+1).padStart(2,'0')}
function renderMap(){$('map').innerHTML=`<div class="box wide mapbox"><div class="mapL"><canvas id="mapc"></canvas>
  <div class="mapbtns"><button data-z="1.3">+</button><button data-z="0.77">−</button><button data-me="1">Я здесь</button></div></div>
  <div class="mapR"><div class="tabs"><button class="tab${MAPV.tab==='gal'?' on':''}" data-mt="gal">Галактика</button><button class="tab${MAPV.tab==='sys'?' on':''}" data-mt="sys">Эта система</button></div>
  <div id="mapPanel" class="mapP"></div><button data-close="1" style="width:100%;margin:4px 0 0">Закрыть</button></div></div>`;
 renderMapPanel();bindMapCanvas();drawMapCanvas();
 $('map').onclick=e=>{const b=e.target.closest('button');if(!b)return;sfx('click');const d=b.dataset;
  if(d.close){uiCloseMap();return}if(d.z){MAPV.z=clamp(MAPV.z*+d.z,.5,4);drawMapCanvas();return}if(d.me){const m=REG.systems[W.id].map;MAPV.x=m[0];MAPV.y=m[1];MAPV.sel=W.id;renderMapPanel();drawMapCanvas();return}
  if(d.mt){MAPV.tab=d.mt;renderMap();return}
  if(d.pick){MAPV.sel=d.pick;const m=REG.systems[d.pick].map;MAPV.x=m[0];MAPV.y=m[1];renderMapPanel();drawMapCanvas();return}
  if(d.route){const r=findRoute(W.id,d.route);if(!r){uiNote('Маршрут не найден');return}S.routeDest=d.route===W.id?null:d.route;P.nav=S.routeDest?navToward(S.routeDest):null;P.navUser=!!P.nav;uiNote(S.routeDest?'Маршрут: '+(r.length-1)+' прыж. до «'+REG.systems[d.route].name+'»':'Маршрут сброшен');renderMapPanel();drawMapCanvas();return}
  if(d.unroute){S.routeDest=null;P.nav=null;renderMapPanel();drawMapCanvas();return}
  if(d.mark){S.marks=S.marks||[];const i=S.marks.indexOf(d.mark);if(i>=0)S.marks.splice(i,1);else S.marks.push(d.mark);renderMapPanel();drawMapCanvas();return}
  if(d.pt!=null){const L=localPoints();const p=L[+d.pt];P.nav=p;P.target=p;P.navUser=true;uiCloseMap();uiNote('Цель: '+p.name);return}
  if(d.st){P.nav=navToStation(d.st);P.target=P.nav;P.navUser=true;uiCloseMap();uiNote('Курс: '+REG.stations[d.st].name);return}}
 const si=$('mapSearch');if(si){si.oninput=()=>{MAPV.q=si.value;renderMapList()};}const sf=$('mapFilter');if(sf)sf.onchange=()=>{MAPV.filter=sf.value;renderMapList();drawMapCanvas()}}
function localPoints(){return [W.station,...W.gates,...W.pois,...(W.beacon?[W.beacon]:[])]}
function renderMapPanel(){const P2=$('mapPanel');if(!P2)return;
 if(MAPV.tab==='sys'){const L=localPoints();let h=`<div class="dim">«${W.sys.name}», орбита «${W.station.name}»</div>`+L.map((p,i)=>`<button class="li" data-pt="${i}">${p.name} · ${fmtD(dist(p.pos,P.pos))}</button>`).join('');
  const others=REG.systems[W.id].stations.filter(s=>s!==W.orbit);if(others.length)h+=`<div class="dim" style="margin-top:6px">Другие орбиты (через переход):</div>`+others.map(s=>`<button class="li" data-st="${s}">${REG.stations[s].name}</button>`).join('');P2.innerHTML=h;return}
 const opts=Object.entries(SERVICE_NAME).filter(([k])=>k!=='black'||S.discovered&&S.discovered.length).map(([k,n])=>`<option value="${k}"${MAPV.filter===k?' selected':''}>${n}</option>`).join('');
 P2.innerHTML=`<input id="mapSearch" placeholder="Поиск системы или станции" value="${MAPV.q}"><select id="mapFilter"><option value="">Все услуги</option>${opts}</select><div id="mapList"></div><div id="mapInfo"></div>`;renderMapList();renderMapInfo()}
function renderMapList(){const el=$('mapList');if(!el)return;const q=MAPV.q.trim().toLowerCase();if(!q){el.innerHTML='';return}const res=[];
 for(const s of Object.values(REG.systems)){if(!sysKnown(s.id))continue;if(s.name.toLowerCase().includes(q))res.push([s.id,s.name]);for(const st of stationsOf(s.id))if(st.name.toLowerCase().includes(q))res.push([s.id,st.name+' ('+s.name+')'])}
 el.innerHTML=res.slice(0,8).map(([id,n])=>`<button class="li" data-pick="${id}">${n}</button>`).join('')||'<div class="dim">Ничего не найдено</div>'}
function renderMapInfo(){const el=$('mapInfo');if(!el)return;const s=REG.systems[MAPV.sel];if(!s||!sysKnown(s.id)){el.innerHTML='';return}const f=REG.factions[s.owner];
 const r=findRoute(W.id,s.id);const vis=S.visited&&S.visited.includes(s.id);const marked=S.marks&&S.marks.includes(s.id);
 let h=`<div class="mi">${emblemSVG(s.owner,20)} <b style="font-size:16px">${s.name}</b> <span style="color:${f.color}">${f.short}</span><div class="dim">${lawOf(s.id).name}${lawOf(s.id).banned.length?' (запрет: '+lawOf(s.id).banned.map(g=>GOODS[g]).join(', ')+')':''}</div><div class="dim">${REG.regions[s.region].name} · опасность ${'●'.repeat(s.danger)+'○'.repeat(3-s.danger)}</div>
  <div class="dim">${s.landmark}. ${s.reason}.</div>`;
 if(r)h+=`<div class="dim">${s.id===W.id?'Вы здесь':'Прыжков: '+(r.length-1)+' · следующий: '+REG.systems[r[1]].name}</div>`;
 h+=`<div class="row"><button data-route="${s.id}">${S.routeDest===s.id?'Маршрут проложен':'Проложить маршрут'}</button>${S.routeDest?'<button data-unroute="1">Сбросить</button>':''}<button data-mark="${s.id}">${marked?'★ Снять метку':'☆ Метка'}</button></div>`;
 for(const st of stationsOf(s.id)){const k=S.known&&S.known[st.id];const svc=st.services.map(x=>SERVICE_NAME[x]).join(', ');
  h+=`<div class="ms"><b>${st.name}</b> <span class="dim">${st.bespoke?'':FAMILY_NAME[st.family]||''}</span><div class="dim">${vis?svc:'Услуги: известны после посещения'}</div>`;
  if(k)h+=`<div class="dim">Цены (${fmtDate(k.t)}): `+Object.keys(k.p).slice(0,8).map(g=>GOODS[g]+' '+k.p[g][0]+'/'+k.p[g][1]).join(' · ')+'</div>';h+='</div>'}
 el.innerHTML=h+'</div>'}
function mapXY(c,m){const s=Math.min(c.width,c.height)/700*MAPV.z;return [c.width/2+(m[0]-MAPV.x)*s,c.height/2+(m[1]-MAPV.y)*s]}
function drawMapCanvas(){const c=$('mapc');if(!c)return;const r=c.getBoundingClientRect();const dp=Math.min(2,devicePixelRatio||1);c.width=r.width*dp;c.height=r.height*dp;const x=c.getContext('2d');x.clearRect(0,0,c.width,c.height);{const bg=mapImg('map_bg.jpg');if(bg.complete&&bg.naturalWidth){const k=Math.max(c.width/bg.naturalWidth,c.height/bg.naturalHeight);const ox=((MAPV.x||0)*.15)%60,oy=((MAPV.y||0)*.15)%60;x.globalAlpha=.9;x.drawImage(bg,(c.width-bg.naturalWidth*k)/2-ox,(c.height-bg.naturalHeight*k)/2-oy,bg.naturalWidth*k+60,bg.naturalHeight*k+60);x.globalAlpha=1}else if(!bg.onload)bg.onload=()=>drawMapCanvas()}
 const route=S.routeDest?findRoute(W.id,S.routeDest):null;const onRoute=(a,b)=>{if(!route)return false;const i=route.indexOf(a),j=route.indexOf(b);return i>=0&&j>=0&&Math.abs(i-j)===1};
 for(const l of REG.links){if(!sysKnown(l.a)||!sysKnown(l.b)||!linkOpen(l.a,l.b))continue;const [ax,ay]=mapXY(c,REG.systems[l.a].map),[bx,by]=mapXY(c,REG.systems[l.b].map);
  x.strokeStyle=onRoute(l.a,l.b)?'#7fe3ff':'rgba(120,150,200,.35)';x.lineWidth=(onRoute(l.a,l.b)?3:1.2)*dp;x.beginPath();x.moveTo(ax,ay);x.lineTo(bx,by);x.stroke()}
 for(const s of Object.values(REG.systems)){if(!sysKnown(s.id))continue;const [px,py]=mapXY(c,s.map);const f=REG.factions[s.owner];
  const dim=MAPV.filter&&!stationsOf(s.id).some(st=>st.services.includes(MAPV.filter));x.globalAlpha=dim?.25:1;
  x.fillStyle=f.color;x.beginPath();x.arc(px,py,(s.id===W.id?8:6)*dp,0,7);x.fill();
  if(s.id===MAPV.sel){x.strokeStyle='#fff';x.lineWidth=2*dp;x.beginPath();x.arc(px,py,11*dp,0,7);x.stroke()}
  if(s.id===W.id){x.strokeStyle='#ffd166';x.lineWidth=2*dp;x.beginPath();x.arc(px,py,(15+Math.sin(G.time*4)*2)*dp,0,7);x.stroke();const pi=mapImg('map_player.png');if(pi.complete&&pi.naturalWidth)x.drawImage(pi,px-9*dp,py-36*dp,18*dp,18*dp)}
  if(S.home&&S.home.st&&REG.stations[S.home.st]&&REG.stations[S.home.st].sys===s.id){const hi=mapImg('map_home.png');if(hi.complete&&hi.naturalWidth)x.drawImage(hi,px+8*dp,py+4*dp,14*dp,14*dp)}
  if(S.routeDest===s.id){const mi=mapImg('map_mission.png');if(mi.complete&&mi.naturalWidth)x.drawImage(mi,px-8*dp,py-30*dp,16*dp,16*dp)}
  if(S.marks&&S.marks.includes(s.id)){x.fillStyle='#ffd166';x.font=(12*dp)+'px system-ui';x.fillText('★',px+8*dp,py-8*dp)}
  x.fillStyle='#e8f1ff';x.font=((MAPV.z>1.2?12:10)*dp)+'px system-ui';x.textAlign='center';x.fillText(s.name,px,py+18*dp);x.globalAlpha=1}
 x.textAlign='left'}
function bindMapCanvas(){const c=$('mapc');if(!c)return;const pts={};let pinch=null,moved=0;
 c.onpointerdown=e=>{c.setPointerCapture(e.pointerId);pts[e.pointerId]=[e.clientX,e.clientY];moved=0;const ks=Object.keys(pts);if(ks.length===2){const [a,b]=ks.map(k=>pts[k]);pinch={d:Math.hypot(a[0]-b[0],a[1]-b[1]),z:MAPV.z}}};
 c.onpointermove=e=>{if(!pts[e.pointerId])return;const o=pts[e.pointerId];const dx=e.clientX-o[0],dy=e.clientY-o[1];pts[e.pointerId]=[e.clientX,e.clientY];moved+=Math.abs(dx)+Math.abs(dy);
  const ks=Object.keys(pts);if(ks.length===2&&pinch){const [a,b]=ks.map(k=>pts[k]);MAPV.z=clamp(pinch.z*Math.hypot(a[0]-b[0],a[1]-b[1])/pinch.d,.5,4)}
  else if(ks.length===1){const s=Math.min(c.clientWidth,c.clientHeight)/700*MAPV.z;MAPV.x-=dx/s;MAPV.y-=dy/s}drawMapCanvas()};
 c.onpointerup=c.onpointercancel=e=>{const was=Object.keys(pts).length;delete pts[e.pointerId];if(Object.keys(pts).length<2)pinch=null;
  if(was===1&&moved<10){const r=c.getBoundingClientRect();const dp=c.width/r.width;const mx=(e.clientX-r.left)*dp,my=(e.clientY-r.top)*dp;let best=null,bd=24*dp;
   for(const s of Object.values(REG.systems)){if(!sysKnown(s.id))continue;const [px,py]=mapXY(c,s.map);const d=Math.hypot(px-mx,py-my);if(d<bd){bd=d;best=s.id}}
   if(best){MAPV.sel=best;renderMapInfo();drawMapCanvas()}}};
 c.onwheel=e=>{e.preventDefault();MAPV.z=clamp(MAPV.z*(e.deltaY<0?1.15:.87),.5,4);drawMapCanvas()}}
function uiTransit(){if(G.mode!=='fly')return;G.mode='map';resetInput();const others=REG.systems[W.id].stations.filter(s=>s!==W.orbit);
 $('map').innerHTML=`<div class="box"><h2>Орбитальный переход</h2><p class="dim">Система «${W.sys.name}». Выберите орбиту:</p>${others.map(s=>{const st=REG.stations[s];return `<button class="li" data-to="${s}" style="width:100%">${st.name} <span class="dim">· ${st.bespoke?'порт':FAMILY_NAME[st.family]}</span></button>`}).join('')}<button data-close="1">Отмена</button></div>`;
 show('map',true);$('map').onclick=e=>{const b=e.target.closest('button');if(!b)return;sfx('click');if(b.dataset.close){uiCloseMap();return}if(b.dataset.to){show('map',false);G.mode='fly';startTransit(b.dataset.to)}}}
function uiDeath(cause){hideAll();$('dead').innerHTML=`<div class="box"><h2 class="bad">Корабль потерян</h2><p>${cause}</p><button id="rtd">${G.duel?'Повторить дуэль':'Вернуться к последней стыковке'}</button>${G.duel?'<button id="dmenu">В меню</button>':''}</div>`;show('dead',true);
 $('rtd').onclick=()=>{sfx('click');hideAll();returnToDock()};if($('dmenu'))$('dmenu').onclick=()=>{hideAll();exitDuel()}}
function uiM4Failed(){$('m4fail').innerHTML=`<div class="box"><h2 class="bad">Рудовоз уничтожен</h2><p>Задание можно повторить: вернитесь к обломкам конвоя.</p><button id="m4r">Повторить сопровождение</button></div>`;show('m4fail',true);
 G.mode='pause';resetInput();$('m4r').onclick=()=>{show('m4fail',false);retryM4();G.mode='fly';lastT=performance.now()}}
function uiDuelWin(){$('win').innerHTML=`<div class="box"><h2>Победа!</h2><p>Оба пирата уничтожены.</p><button id="dAgain">Ещё раз</button><button id="dMenu">В меню</button></div>`;show('win',true);G.mode='pause';resetInput();
 $('dAgain').onclick=()=>{show('win',false);startDuel()};$('dMenu').onclick=()=>{show('win',false);exitDuel()}}
function menuInit(){$('contBtn').onclick=()=>{sfx('click');hideAll();continueGame()};
 $('newBtn').onclick=()=>{sfx('click');if(hasSave())confirmBox('Начать новую игру?','Текущее сохранение будет удалено.',true,()=>{hideAll();newGame()});else{hideAll();newGame()}};
 $('duelBtn').onclick=()=>{sfx('click');hideAll();startDuel()};
 $('setBtn').onclick=()=>{sfx('click');$('menuSet').innerHTML=settingsHTML();bindSettings();$('menuSet').classList.toggle('hide')}}

// ----- portraits (placeholder badge; full vector portraits drawn in portraits.js if present) -----
function heroByName(n){return Object.values(REG.heroes).find(h=>h.name===n)}
function portraitHTML(who,alt,size){if(typeof portraitArt==='function')return portraitArt(who,alt,size);if(typeof portraitSVG==='function'){const h=Object.entries(REG.heroes).find(([k,v])=>v.name===who);if(h)return portraitSVG(h[0],alt)}
 const h=heroByName(who);const col=h?h.col:'#8aa';const ini=(who||'?').split(' ').map(s=>s[0]).join('').slice(0,2);return `<div style="width:56px;height:56px;border-radius:10px;background:${col}33;border:2px solid ${col};display:flex;align-items:center;justify-content:center;font-weight:bold;color:${col};flex:none">${ini}</div>`}
// ----- choice, fail, credits -----
function uiChoice(sd,sl){sl=sl||CSLOT;if(!sd||sd.t!=='choice')return;const m=withSlot(sl,()=>campMis());$('choice').innerHTML=`<div class="box"><h2>${sd.title}</h2><div class="dim">${m?m.title:''}</div>${sd.opts.map((o,i)=>`<div class="item"><div><b>${o.label}</b>${o.cost?' — '+o.cost+' кр.':''}<div class="dim">${o.desc||''}</div></div><button data-o="${i}" ${o.cost&&S.cr<o.cost?'disabled':''}>Выбрать</button></div>`).join('')}
 <div class="dim">Решение окончательное. ${sd.ending?'После него — финальные титры и свободный полёт.':''}</div><button data-o="x">Отложить</button></div>`;show('choice',true);
 $('choice').onclick=e=>{const b=e.target.closest('button');if(!b)return;sfx('click');if(b.dataset.o==='x'){show('choice',false);return}const r=campChoose(+b.dataset.o,sl);if(r){uiNote(r);return}show('choice',false);if(G.mode==='hangar')renderStation()}}
function uiCampFail(text){$('m4fail').innerHTML=`<div class="box"><h2 class="bad">Задание сорвано</h2><p>${text}</p><button id="cfr">Повторить с контрольной точки</button></div>`;show('m4fail',true);G.mode='pause';resetInput();
 $('cfr').onclick=()=>{show('m4fail',false);campRetry()}}
function uiCredits(){const c=camp();const e=c.ending;$('credits').innerHTML=`<div class="box wide"><h2>Дальний рубеж — «Долгий сигнал»</h2><p>${ENDING_TEXT[e]||''}</p>
 <div class="dim" style="text-align:left">${Object.values(REG.heroes).map(h=>'<b>'+h.name+'</b> — '+h.role).join('<br>')}</div>
 <p class="dim">Сюжет, корабли, станции, музыка и код созданы для этой игры.</p><button id="crOk">Продолжить свободный полёт</button></div>`;show('credits',true);G.mode='pause';
 $('crOk').onclick=()=>{show('credits',false);G.mode='fly';lastT=performance.now();uiNote('Свободный полёт. Изнанка остаётся на карте.')}}
// ----- journal: where / whom / what / where to -----
function journalHTML(){const c=camp();const ob=W?objective():{text:'—'};const m=campMis();const sd=campStepDef();
 const where=W?`«${W.sys.name}», орбита «${W.station.name}»`:'—';const whom=m?REG.heroes[m.giver].name+' ('+REG.heroes[m.giver].role+')':'никому — свободный полёт';
 const to=ob.target?ob.target.name+(ob.target.pos&&P?' · '+fmtD(dist(ob.target.pos,P.pos)):''):'—';
 const log=(S.log||[]).slice(-8).map(([w,l])=>`<div class="dim"><b>${w}:</b> ${l}</div>`).join('');
 const clues=(S.clues||[]).map(k=>'<li>'+(CLUES[k]||k)+'</li>').join('');
 return `<h2>Журнал</h2><div style="text-align:left"><div><b>Где я:</b> ${where}</div><div><b>Кому помогаю:</b> ${whom}</div><div><b>Что делать:</b> ${ob.text}</div><div><b>Куда лететь:</b> ${to}</div>
  <div class="sec">Пройдено заданий: ${Object.keys(c.done).filter(k=>MIS[k]&&!MIS[k].side).length} из ${CAMPAIGN_ORDER.length} · побочных: ${Object.keys(slotState('side').done).length} из 24</div>
  <div class="dim">Отношения: ${['league','union','teira','essen','wake'].map(f=>REG.factions[f].short+' '+repLabel(rep(f))).join(' · ')}</div>${(S.keyItems||[]).length?'<div class="dim">Особые предметы: '+S.keyItems.map(k=>k==='token'?'старый портовый жетон <button data-p="inspect" style="min-height:26px;padding:2px 8px;font-size:12px">Осмотреть</button>':k).join(', ')+'</div>':''}${clues?'<div class="sec">Улики</div><ul>'+clues+'</ul>':''}${log?'<div class="sec">Радио (последнее)</div>'+log:''}</div>`}

function homeHTML(){if(!isHome())return '';const h=S.home;const lv=HOME_LV[h.level];const nx=HOME_LV[h.level+1];let s=`<div class="sec">${STATIONS[S.station].homeName}: ${lv.name}</div>`;
 if(h.level>=2)s+=`<div class="dim">Ваш флот на стоянке: ${S.ships.map(id=>REG.ships[id].name).join(', ')}</div><div class="dim">Стена трофеев: ${trophies().join(' · ')||'пока пусто'}</div>`;
 if(nx)s+=`<div class="item"><div>Следующий этап: <b>${nx.name}</b> — ${nx.cost} кр. + ${Object.entries(nx.mats).map(([g,n])=>GOODS[g]+' ×'+n).join(', ')}<div class="dim">${nx.adds}</div></div><button data-home="1">Восстановить</button></div>`;return s}
function uiChoiceAd(sd){$('choice').innerHTML=`<div class="box"><h2>${sd.title}</h2>${sd.opts.map((o,i)=>`<div class="item"><div><b>${o.label}</b>${o.cost?' — '+o.cost+' кр.':''}<div class="dim">${o.desc||''}</div></div><button data-o="${i}" ${o.cost&&S.cr<o.cost?'disabled':''}>Выбрать</button></div>`).join('')}</div>`;show('choice',true);
 $('choice').onclick=e=>{const b=e.target.closest('button');if(!b)return;sfx('click');const o=sd.opts[+b.dataset.o];if(o.cost){if(S.cr<o.cost)return;S.cr-=o.cost}if(o.eff.fn)SIDE_FX[o.eff.fn]();saveGame();show('choice',false);if(G.mode==='hangar')renderStation()}}
