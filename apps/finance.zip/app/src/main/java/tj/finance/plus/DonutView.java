package tj.finance.plus;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.view.View;

public class DonutView extends View {
    float[] vals = new float[0];
    int[] cols = new int[]{0xFFEEEEEE};
    String l1 = "", l2 = null;
    float thick = 0.2f;
    int ringBg = 0xFF2C2C2C;
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint t = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF rf = new RectF();

    public DonutView(Context c) {
        super(c);
        p.setStyle(Paint.Style.STROKE);
        t.setTextAlign(Paint.Align.CENTER);
        t.setColor(0xFFEDEDED);
    }

    public void setData(float[] v, int[] c, String a, String b) {
        vals = v;
        cols = c;
        l1 = a == null ? "" : a;
        l2 = b;
        invalidate();
    }

    private void fit(String s, float size, float maxW) {
        t.setTextSize(size);
        while (t.measureText(s) > maxW && t.getTextSize() > 6) t.setTextSize(t.getTextSize() * 0.9f);
    }

    @Override
    protected void onDraw(Canvas cv) {
        float w = getWidth(), h = getHeight(), s = Math.min(w, h);
        if (s <= 0) return;
        float sw = s * thick;
        p.setStrokeWidth(sw);
        float cx = w / 2f, cy = h / 2f, r = (s - sw) / 2f;
        rf.set(cx - r, cy - r, cx + r, cy + r);
        float tot = 0;
        int n = 0;
        for (float v : vals) if (v > 0) { tot += v; n++; }
        if (tot <= 0) {
            p.setColor(ringBg);
            cv.drawArc(rf, 0, 360, false, p);
        } else {
            float a = -90;
            for (int i = 0; i < vals.length; i++) {
                if (vals[i] <= 0) continue;
                float sweep = 360f * vals[i] / tot;
                p.setColor(cols[i % cols.length]);
                cv.drawArc(rf, a, n > 1 ? Math.max(0.5f, sweep - 1.2f) : sweep, false, p);
                a += sweep;
            }
        }
        float maxW = (r - sw / 2f) * 2f * 0.85f;
        if (l2 == null) {
            t.setFakeBoldText(true);
            fit(l1, s * 0.11f, maxW);
            cv.drawText(l1, cx, cy - (t.descent() + t.ascent()) / 2f, t);
        } else {
            t.setFakeBoldText(false);
            fit(l1, s * 0.12f, maxW);
            cv.drawText(l1, cx, cy - s * 0.02f, t);
            fit(l2, s * 0.11f, maxW);
            cv.drawText(l2, cx, cy + s * 0.12f, t);
        }
    }
}
