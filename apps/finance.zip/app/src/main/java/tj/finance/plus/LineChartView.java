package tj.finance.plus;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.DashPathEffect;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Shader;
import android.view.MotionEvent;
import android.view.View;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/** Stock-style line chart of capital over time with touch scrubbing. */
public class LineChartView extends View {
    interface Fmt {
        String f(double v);
    }

    float[] v = new float[0];
    long[] t = new long[0];
    float base;
    Fmt fmt = x -> String.format(Locale.US, "%.2f", x);
    int up = 0xFF34C46A, down = 0xFFFF5A5F, grid = 0xFF2C2C2C, label = 0xFF9A9A9A, txt = 0xFFEDEDED, bubble = 0xFF2C2C2E;
    private int touch = -1;
    private final float d;
    private final Paint line = new Paint(Paint.ANTI_ALIAS_FLAG), fill = new Paint(Paint.ANTI_ALIAS_FLAG),
            gp = new Paint(Paint.ANTI_ALIAS_FLAG), tp = new Paint(Paint.ANTI_ALIAS_FLAG), dot = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path path = new Path(), area = new Path();
    private final SimpleDateFormat sdf = new SimpleDateFormat("dd.MM.yy", Locale.US);

    public LineChartView(Context c) {
        super(c);
        d = c.getResources().getDisplayMetrics().density;
        line.setStyle(Paint.Style.STROKE);
        line.setStrokeWidth(2.2f * d);
        line.setStrokeJoin(Paint.Join.ROUND);
        line.setStrokeCap(Paint.Cap.ROUND);
        fill.setStyle(Paint.Style.FILL);
        gp.setStrokeWidth(1 * d);
        tp.setTextSize(11 * d);
    }

    public void setData(float[] v, long[] t, float base) {
        this.v = v;
        this.t = t;
        this.base = base;
        touch = -1;
        invalidate();
    }

    private float padL() { return 8 * d; }
    private float padR() { return 8 * d; }
    private float padT() { return 40 * d; }
    private float padB() { return 22 * d; }

    private float xOf(int i, int n, float w) {
        float pw = w - padL() - padR();
        return n <= 1 ? padL() + pw / 2f : padL() + pw * i / (n - 1f);
    }

    @Override
    protected void onDraw(Canvas c) {
        int n = v.length;
        float w = getWidth(), h = getHeight();
        if (n == 0 || w <= 0) return;
        float min = base, max = base;
        for (float x : v) { min = Math.min(min, x); max = Math.max(max, x); }
        if (max - min < 0.01f) { max += 1; min -= 1; }
        float span = max - min;
        max += span * 0.08f;
        min -= span * 0.08f;
        final float fmin = min, fmax = max;
        float top = padT(), bot = h - padB();
        java.util.function.DoubleUnaryOperator yOf = val -> top + (bot - top) * (fmax - val) / (fmax - fmin);

        // grid + labels
        gp.setColor(grid);
        gp.setPathEffect(null);
        tp.setColor(label);
        tp.setTextAlign(Paint.Align.LEFT);
        for (int i = 0; i < 3; i++) {
            float val = max - (max - min) * i / 2f;
            float y = (float) yOf.applyAsDouble(val);
            c.drawLine(padL(), y, w - padR(), y, gp);
            c.drawText(fmt.f(val), padL(), y - 4 * d, tp);
        }
        // base line (start of period)
        float by = (float) yOf.applyAsDouble(base);
        gp.setPathEffect(new DashPathEffect(new float[]{6 * d, 5 * d}, 0));
        gp.setColor(label);
        c.drawLine(padL(), by, w - padR(), by, gp);
        gp.setPathEffect(null);

        int col = v[n - 1] >= base ? up : down;
        path.reset();
        area.reset();
        for (int i = 0; i < n; i++) {
            float x = xOf(i, n, w), y = (float) yOf.applyAsDouble(v[i]);
            if (i == 0) {
                path.moveTo(x, y);
                area.moveTo(x, bot);
                area.lineTo(x, y);
            } else {
                path.lineTo(x, y);
                area.lineTo(x, y);
            }
        }
        if (n == 1) path.lineTo(xOf(0, n, w) + 1, (float) yOf.applyAsDouble(v[0]));
        area.lineTo(xOf(n - 1, n, w), bot);
        area.close();
        fill.setShader(new LinearGradient(0, top, 0, bot, (col & 0x00FFFFFF) | 0x55000000, col & 0x00FFFFFF, Shader.TileMode.CLAMP));
        c.drawPath(area, fill);
        line.setColor(col);
        c.drawPath(path, line);

        // x labels
        tp.setColor(label);
        tp.setTextAlign(Paint.Align.LEFT);
        c.drawText(sdf.format(new Date(t[0])), padL(), h - 6 * d, tp);
        tp.setTextAlign(Paint.Align.RIGHT);
        c.drawText(sdf.format(new Date(t[n - 1])), w - padR(), h - 6 * d, tp);

        // last point dot
        int i = touch >= 0 ? touch : n - 1;
        float x = xOf(i, n, w), y = (float) yOf.applyAsDouble(v[i]);
        if (touch >= 0) {
            gp.setColor(label);
            c.drawLine(x, top - 6 * d, x, bot, gp);
        }
        dot.setColor(col);
        c.drawCircle(x, y, 5 * d, dot);
        dot.setColor(0xFF121212);
        c.drawCircle(x, y, 2.2f * d, dot);

        if (touch >= 0) {
            String s = sdf.format(new Date(t[i])) + "   " + fmt.f(v[i]);
            tp.setTextAlign(Paint.Align.CENTER);
            tp.setTextSize(13 * d);
            float tw = tp.measureText(s) + 20 * d;
            float bx = Math.max(tw / 2f, Math.min(w - tw / 2f, x));
            dot.setColor(bubble);
            c.drawRoundRect(new RectF(bx - tw / 2f, 4 * d, bx + tw / 2f, 30 * d), 8 * d, 8 * d, dot);
            tp.setColor(txt);
            c.drawText(s, bx, 22 * d, tp);
            tp.setTextSize(11 * d);
        }
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        int n = v.length;
        if (n == 0) return false;
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
            case MotionEvent.ACTION_MOVE:
                getParent().requestDisallowInterceptTouchEvent(true);
                float pw = getWidth() - padL() - padR();
                int i = n <= 1 ? 0 : Math.round((e.getX() - padL()) / pw * (n - 1));
                touch = Math.max(0, Math.min(n - 1, i));
                invalidate();
                return true;
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                touch = -1;
                invalidate();
                if (e.getActionMasked() == MotionEvent.ACTION_UP) performClick();
                return true;
        }
        return super.onTouchEvent(e);
    }

    @Override
    public boolean performClick() {
        return super.performClick();
    }
}
