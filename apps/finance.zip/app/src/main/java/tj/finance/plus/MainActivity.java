package tj.finance.plus;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.text.Editable;
import android.text.InputType;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.AbsListView;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.BaseAdapter;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.GridView;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.OutputStream;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.nio.charset.StandardCharsets;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public class MainActivity extends Activity {
    static final int Y = 0xFFFFD94A, YD = 0xFFFFD94A, BG = 0xFF121212, CARD = 0xFF1E1E1E, HEAD = 0xFF1E1E1E,
            TXT = 0xFFEDEDED, ONY = 0xFF1A1A1A, GREY = 0xFF9A9A9A, LINE = 0xFF2C2C2C, GREEN = 0xFF34C46A,
            RED = 0xFFFF5A5F, KEY = 0xFF2C2C2E, PANEL = 0xFF181818;
    static final int[] PASTEL = {0xFF5A4E1F, 0xFF2F4A55, 0xFF463A63, 0xFF22504A, 0xFF3C5434,
            0xFF5A2F3A, 0xFF2A5252, 0xFF5A4030, 0xFF35473D, 0xFF3A3A3C, 0xFF2E4058, 0xFF553A50};
    static final int[] CHART = {0xFFF7D154, 0xFF7FB3C2, 0xFFF28AA0, 0xFF3AA6A0, 0xFFA58CE0};
    static final int OTHER = 0xFF9ED48F;
    static final String[] MONTHS = {"Январь", "Февраль", "Март", "Апрель", "Май", "Июнь", "Июль",
            "Август", "Сентябрь", "Октябрь", "Ноябрь", "Декабрь"};
    static final String[] MSHORT = {"Янв", "Фев", "Мар", "Апр", "Май", "Июн", "Июл", "Авг", "Сен", "Окт", "Ноя", "Дек"};
    static final String[] DOW = {"Воскресенье", "Понедельник", "Вторник", "Среда", "Четверг", "Пятница", "Суббота"};
    static final String[] EMOJI = {"🛒", "🍽️", "📱", "🎤", "📚", "💄", "🏊", "👥", "🚌", "👕", "🚗", "🥤",
            "🚬", "🎧", "✈️", "💊", "🐶", "🔧", "🏠", "🎁", "❤️", "🌐", "🧁", "👶", "🥕", "🍇", "📦", "➕",
            "🏷️", "💰", "💼", "🏆", "📈", "↩️", "👟", "👜", "🧸", "🎮", "📷", "🎙️", "💡", "🧾", "⛽", "🚕",
            "🍞", "🥩", "☕", "🍕", "🧴", "🧹", "🪑", "📺", "💻", "🖨️", "🛠️", "🏪", "🚚", "💳", "🏦", "🎓"};
    static final int REQ_SAVE = 11, REQ_OPEN = 12;

    Store st;
    FrameLayout content;
    LinearLayout nav;
    int tab = 0;
    int selY, selM;
    boolean chYear = false, prodAll = false;
    int chMode = 0, chOff = 0, capRange = 1;
    DecimalFormat df;

    interface IntCb {
        void on(int i);
    }

    // ---------------------------------------------------------------- lifecycle

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        DecimalFormatSymbols sy = new DecimalFormatSymbols(Locale.US);
        sy.setGroupingSeparator(' ');
        df = new DecimalFormat("#,##0.00", sy);
        st = new Store(this);
        st.load();
        Calendar c = Calendar.getInstance();
        selY = c.get(Calendar.YEAR);
        selM = c.get(Calendar.MONTH);
        styleWindow(getWindow());

        LinearLayout root = col();
        root.setBackgroundColor(BG);
        root.setClipChildren(false);
        content = new FrameLayout(this);
        root.addView(content, lp(-1, 0, 1f));
        View line = new View(this);
        line.setBackgroundColor(LINE);
        root.addView(line, lp(-1, dp(1), 0));
        nav = row();
        nav.setGravity(Gravity.CENTER_VERTICAL);
        nav.setBackgroundColor(CARD);
        nav.setClipChildren(false);
        root.addView(nav, lp(-1, dp(60), 0));
        setContentView(root);
        refresh();
    }

    void styleWindow(Window w) {
        w.setStatusBarColor(HEAD);
        w.setNavigationBarColor(CARD);
        w.getDecorView().setSystemUiVisibility(0);
    }

    @Override
    public void onBackPressed() {
        if (tab != 0) {
            tab = 0;
            refresh();
        } else super.onBackPressed();
    }

    void refresh() {
        content.removeAllViews();
        View v;
        switch (tab) {
            case 1: v = buildCharts(); break;
            case 2: v = buildReports(); break;
            case 3: v = buildMe(); break;
            default: v = buildRecords();
        }
        content.addView(v, new FrameLayout.LayoutParams(-1, -1));
        buildNav();
    }

    void buildNav() {
        nav.removeAllViews();
        String[][] it = {{"📋", "Записи"}, {"📊", "Графики"}, {"", ""}, {"🧾", "Отчёты"}, {"👤", "Я"}};
        int[] tabs = {0, 1, -1, 2, 3};
        for (int i = 0; i < 5; i++) {
            if (i == 2) {
                FrameLayout f = new FrameLayout(this);
                f.setClipChildren(false);
                TextView plus = tv("+", 30, ONY, false);
                plus.setGravity(Gravity.CENTER);
                plus.setIncludeFontPadding(false);
                plus.setBackground(oval(Y));
                plus.setElevation(dp(4));
                plus.setTranslationY(-dp(10));
                plus.setOnClickListener(v -> openEditor(null));
                f.addView(plus, new FrameLayout.LayoutParams(dp(54), dp(54), Gravity.CENTER));
                nav.addView(f, lp(0, -1, 1f));
                continue;
            }
            final int t = tabs[i];
            boolean on = tab == t;
            LinearLayout c = col();
            c.setGravity(Gravity.CENTER);
            TextView ic = tv(it[i][0], 20, TXT, false);
            ic.setAlpha(on ? 1f : 0.4f);
            ic.setGravity(Gravity.CENTER);
            c.addView(ic, mw());
            TextView lb = tv(it[i][1], 11, on ? YD : GREY, on);
            lb.setGravity(Gravity.CENTER);
            lb.setSingleLine(true);
            c.addView(lb, mw());
            c.setOnClickListener(v -> {
                tab = t;
                refresh();
            });
            nav.addView(c, lp(0, -1, 1f));
        }
    }

    // ---------------------------------------------------------------- tab: records

    View buildRecords() {
        LinearLayout root = col();
        root.setBackgroundColor(BG);
        LinearLayout head = col();
        head.setBackgroundColor(HEAD);
        head.setPadding(dp(18), dp(12), dp(18), dp(16));
        TextView title = tv("Денежный менеджер", 18, TXT, true);
        title.setGravity(Gravity.CENTER);
        head.addView(title, mw());

        long[] r = monthRange(selY, selM);
        double[] s = sums(r);
        LinearLayout line = row();
        line.setGravity(Gravity.CENTER_VERTICAL);
        line.setPadding(0, dp(12), 0, 0);
        LinearLayout mc = col();
        mc.addView(tv(String.valueOf(selY), 13, GREY, false));
        mc.addView(tv(String.format(Locale.US, "%02d ▾", selM + 1), 28, Y, false));
        mc.setOnClickListener(v -> pickMonth());
        line.addView(mc, lp(dp(88), -2, 0));
        View sep = new View(this);
        sep.setBackgroundColor(0xFF444444);
        LinearLayout.LayoutParams sl = lp(dp(1), dp(40), 0);
        sl.rightMargin = dp(16);
        line.addView(sep, sl);
        line.addView(stat("Расходы", "-" + num(s[0])), lp(0, -2, 1f));
        line.addView(stat("Доходы", num(s[1])), lp(0, -2, 1f));
        head.addView(line, mw());
        root.addView(head, mw());

        ScrollView sv = new ScrollView(this);
        LinearLayout list = col();
        list.setPadding(0, 0, 0, dp(16));
        sv.addView(list);
        root.addView(sv, lp(-1, 0, 1f));

        List<Rec> rs = recsIn(r);
        if (rs.isEmpty()) {
            list.addView(empty("Нет записей за " + MONTHS[selM].toLowerCase(Locale.ROOT) + " " + selY
                    + ".\nНажмите «+», чтобы добавить."));
            return root;
        }
        int lastDay = -1;
        for (Rec x : rs) {
            int dk = dayKey(x.time);
            if (dk != lastDay) {
                lastDay = dk;
                list.addView(dayHeader(x.time, rs, dk));
            }
            list.addView(recRow(x, null));
        }
        return root;
    }

    View dayHeader(long t, List<Rec> rs, int dk) {
        double e = 0, in = 0;
        for (Rec x : rs) if (dayKey(x.time) == dk) { if (x.inc) in += x.amt; else e += x.amt; }
        Calendar c = Calendar.getInstance();
        c.setTimeInMillis(t);
        LinearLayout h = row();
        h.setGravity(Gravity.CENTER_VERTICAL);
        h.setBackgroundColor(PANEL);
        h.setPadding(dp(16), dp(8), dp(16), dp(8));
        h.addView(tv(String.format(Locale.US, "%02d.%02d  ", c.get(Calendar.DAY_OF_MONTH), c.get(Calendar.MONTH) + 1)
                + DOW[c.get(Calendar.DAY_OF_WEEK) - 1], 13, GREY, false), lp(0, -2, 1f));
        StringBuilder sb = new StringBuilder();
        if (e > 0) sb.append("Расходы: -").append(num(e));
        if (in > 0) sb.append(sb.length() > 0 ? "   " : "").append("Доход: ").append(num(in));
        h.addView(tv(sb.toString(), 12, GREY, false));
        return h;
    }

    View recRow(final Rec x, final Dialog parent) {
        Cat c = st.cat(x.inc, x.cat);
        LinearLayout r = row();
        r.setGravity(Gravity.CENTER_VERTICAL);
        r.setPadding(dp(16), dp(10), dp(16), dp(10));
        r.setBackgroundResource(selectable());
        r.addView(iconCircle(c, 44), lp(dp(44), dp(44), 0));
        LinearLayout tc = col();
        tc.setPadding(dp(12), 0, dp(8), 0);
        tc.addView(tv(c.name, 16, TXT, false));
        String sub = x.memo;
        if (parent != null) sub = dateStr(x.time) + (sub.isEmpty() ? "" : "  ·  " + sub);
        if (!sub.isEmpty()) {
            TextView s = tv(sub, 13, GREY, false);
            s.setSingleLine(true);
            s.setEllipsize(TextUtils.TruncateAt.END);
            tc.addView(s);
        }
        r.addView(tc, lp(0, -2, 1f));
        r.addView(tv((x.inc ? "+" : "-") + num(x.amt), 16, x.inc ? GREEN : TXT, false));
        r.setOnClickListener(v -> {
            if (parent != null) parent.dismiss();
            showRec(x);
        });
        return r;
    }

    void pickMonth() {
        final int[] y = {selY};
        LinearLayout v = col();
        v.setPadding(dp(16), dp(8), dp(16), dp(8));
        LinearLayout yr = row();
        yr.setGravity(Gravity.CENTER);
        TextView prev = tv("  ◀  ", 20, TXT, false);
        final TextView yt = tv(String.valueOf(y[0]), 20, TXT, true);
        TextView next = tv("  ▶  ", 20, TXT, false);
        yr.addView(prev);
        yr.addView(yt, lp(dp(90), -2, 0));
        yt.setGravity(Gravity.CENTER);
        yr.addView(next);
        v.addView(yr, mw());
        final TextView[] cells = new TextView[12];
        final AlertDialog[] d = new AlertDialog[1];
        for (int rr = 0; rr < 4; rr++) {
            LinearLayout line = row();
            for (int cc = 0; cc < 3; cc++) {
                final int m = rr * 3 + cc;
                TextView t = tv(MSHORT[m], 16, TXT, false);
                t.setGravity(Gravity.CENTER);
                LinearLayout.LayoutParams l = lp(0, dp(46), 1f);
                l.setMargins(dp(4), dp(4), dp(4), dp(4));
                line.addView(t, l);
                cells[m] = t;
                t.setOnClickListener(x -> {
                    selY = y[0];
                    selM = m;
                    d[0].dismiss();
                    refresh();
                });
            }
            v.addView(line, mw());
        }
        final Runnable paint = () -> {
            yt.setText(String.valueOf(y[0]));
            for (int i = 0; i < 12; i++) {
                boolean on = i == selM && y[0] == selY;
                cells[i].setBackground(round(on ? Y : KEY, 8));
                cells[i].setTextColor(on ? ONY : TXT);
            }
        };
        prev.setOnClickListener(x -> { y[0]--; paint.run(); });
        next.setOnClickListener(x -> { y[0]++; paint.run(); });
        paint.run();
        d[0] = new AlertDialog.Builder(this).setTitle("Выберите месяц").setView(v)
                .setNegativeButton("Отмена", null).create();
        d[0].show();
    }

    // ---------------------------------------------------------------- tab: charts

    View buildCharts() {
        final boolean chInc = chMode == 1;
        LinearLayout root = col();
        root.setBackgroundColor(BG);
        LinearLayout head = col();
        head.setBackgroundColor(HEAD);
        head.setGravity(Gravity.CENTER_HORIZONTAL);
        head.setPadding(dp(48), dp(10), dp(48), dp(14));
        final String[] modes = {"Расходы", "Доходы", "Капитал"};
        TextView t = tv(modes[chMode] + " ▾", 18, TXT, true);
        t.setPadding(dp(12), dp(4), dp(12), dp(4));
        t.setOnClickListener(v -> new AlertDialog.Builder(this)
                .setItems(modes, (d, w) -> {
                    chMode = w;
                    refresh();
                }).show());
        head.addView(t);
        if (chMode == 2) {
            root.addView(head, mw());
            buildCapital(root);
            return root;
        }
        LinearLayout.LayoutParams sl = mw();
        sl.topMargin = dp(8);
        head.addView(seg(new String[]{"Месяц", "Год"}, chYear ? 1 : 0, i -> {
            chYear = i == 1;
            chOff = 0;
            refresh();
        }), sl);
        root.addView(head, mw());

        final HorizontalScrollView hs = new HorizontalScrollView(this);
        hs.setHorizontalScrollBarEnabled(false);
        LinearLayout tabs = row();
        Calendar now = Calendar.getInstance();
        int n = chYear ? 6 : 13;
        View selCell = null;
        for (int k = n - 1; k >= 0; k--) {
            String lab;
            if (chYear) {
                lab = k == 0 ? "Этот год" : k == 1 ? "Прошлый год" : String.valueOf(now.get(Calendar.YEAR) - k);
            } else {
                Calendar c = (Calendar) now.clone();
                c.add(Calendar.MONTH, -k);
                lab = k == 0 ? "Этот месяц" : k == 1 ? "Прошлый месяц" : c.get(Calendar.YEAR) + "." + (c.get(Calendar.MONTH) + 1);
            }
            final int kk = k;
            boolean on = k == chOff;
            LinearLayout cell = col();
            cell.setGravity(Gravity.CENTER_HORIZONTAL);
            cell.setPadding(dp(14), dp(12), dp(14), 0);
            cell.addView(tv(lab, 15, on ? TXT : GREY, on));
            View bar = new View(this);
            bar.setBackgroundColor(on ? Y : Color.TRANSPARENT);
            LinearLayout.LayoutParams bl = lp(-1, dp(3), 0);
            bl.topMargin = dp(10);
            cell.addView(bar, bl);
            cell.setOnClickListener(v -> {
                chOff = kk;
                refresh();
            });
            tabs.addView(cell);
            if (on) selCell = cell;
        }
        hs.addView(tabs);
        root.addView(hs, mw());
        root.addView(divider());
        final View sc = selCell;
        hs.post(() -> {
            if (sc != null) hs.scrollTo(Math.max(0, sc.getLeft() - (hs.getWidth() - sc.getWidth()) / 2), 0);
        });

        long[] r;
        if (chYear) r = yearRange(now.get(Calendar.YEAR) - chOff);
        else {
            Calendar c = (Calendar) now.clone();
            c.add(Calendar.MONTH, -chOff);
            r = monthRange(c.get(Calendar.YEAR), c.get(Calendar.MONTH));
        }
        final long[] range = r;
        LinkedHashMap<String, Double> m = new LinkedHashMap<>();
        double tot = 0;
        for (Rec x : st.recs) {
            if (x.inc != chInc || x.time < r[0] || x.time >= r[1]) continue;
            Double old = m.get(x.cat);
            m.put(x.cat, (old == null ? 0 : old) + x.amt);
            tot += x.amt;
        }
        List<Map.Entry<String, Double>> es = new ArrayList<>(m.entrySet());
        es.sort((a, b) -> Double.compare(b.getValue(), a.getValue()));

        ScrollView sv = new ScrollView(this);
        LinearLayout body = col();
        body.setPadding(0, 0, 0, dp(16));
        sv.addView(body);
        root.addView(sv, lp(-1, 0, 1f));
        if (tot <= 0) {
            body.addView(empty(chInc ? "Нет доходов за этот период" : "Нет расходов за этот период"));
            return root;
        }

        int slices = es.size() <= 5 ? es.size() : 5;
        float[] vals = new float[slices];
        int[] cols = new int[slices];
        String[] names = new String[slices];
        for (int i = 0; i < slices; i++) {
            if (es.size() > 5 && i == 4) {
                double o = 0;
                for (int j = 4; j < es.size(); j++) o += es.get(j).getValue();
                vals[i] = (float) o;
                cols[i] = OTHER;
                names[i] = "Другое";
            } else {
                vals[i] = es.get(i).getValue().floatValue();
                cols[i] = CHART[i];
                names[i] = es.get(i).getKey();
            }
        }
        LinearLayout top = row();
        top.setGravity(Gravity.CENTER_VERTICAL);
        top.setPadding(dp(16), dp(20), dp(16), dp(20));
        DonutView dv = new DonutView(this);
        dv.thick = 0.24f;
        dv.setData(vals, cols, num(tot), null);
        top.addView(dv, lp(dp(140), dp(140), 0));
        LinearLayout leg = col();
        leg.setPadding(dp(18), 0, 0, 0);
        for (int i = 0; i < slices; i++) {
            LinearLayout lr = row();
            lr.setGravity(Gravity.CENTER_VERTICAL);
            lr.setPadding(0, dp(5), 0, dp(5));
            View dot = new View(this);
            GradientDrawable g = new GradientDrawable();
            g.setShape(GradientDrawable.OVAL);
            g.setStroke(dp(3), cols[i]);
            dot.setBackground(g);
            lr.addView(dot, lp(dp(13), dp(13), 0));
            TextView nm = tv("  " + names[i], 13, TXT, false);
            nm.setSingleLine(true);
            nm.setEllipsize(TextUtils.TruncateAt.END);
            lr.addView(nm, lp(0, -2, 1f));
            lr.addView(tv(pct(vals[i] * 100.0 / tot), 12, GREY, false));
            leg.addView(lr, mw());
        }
        top.addView(leg, lp(0, -2, 1f));
        body.addView(top, mw());
        body.addView(divider());

        double max = es.get(0).getValue();
        for (Map.Entry<String, Double> e : es) {
            final String cn = e.getKey();
            double v = e.getValue();
            Cat c = st.cat(chInc, cn);
            LinearLayout rr = row();
            rr.setGravity(Gravity.CENTER_VERTICAL);
            rr.setPadding(dp(16), dp(12), dp(16), dp(12));
            rr.setBackgroundResource(selectable());
            rr.addView(iconCircle(c, 42), lp(dp(42), dp(42), 0));
            LinearLayout cc = col();
            cc.setPadding(dp(12), 0, 0, 0);
            LinearLayout tl = row();
            tl.setGravity(Gravity.CENTER_VERTICAL);
            tl.addView(tv(c.name, 16, TXT, false));
            tl.addView(tv("  " + pct(v * 100 / tot), 13, GREY, false), lp(0, -2, 1f));
            tl.addView(tv(num(v), 15, TXT, false));
            cc.addView(tl, mw());
            LinearLayout bar = row();
            View b = new View(this);
            b.setBackground(round(Y, 3));
            float f = (float) (v / max);
            bar.addView(b, lp(0, dp(6), f));
            bar.addView(new View(this), lp(0, dp(6), 1f - f));
            LinearLayout.LayoutParams bp = mw();
            bp.topMargin = dp(6);
            cc.addView(bar, bp);
            rr.addView(cc, lp(0, -2, 1f));
            rr.setOnClickListener(x -> {
                List<Rec> l = new ArrayList<>();
                for (Rec q : st.recs) if (q.inc == chInc && q.cat.equals(cn) && q.time >= range[0] && q.time < range[1]) l.add(q);
                sortDesc(l);
                listDialog(c.icon + "  " + c.name, (chInc ? "Доходы: " : "Расходы: ") + num(v), l);
            });
            body.addView(rr, mw());
        }
        return root;
    }

    // ---------------------------------------------------------------- tab: reports

    View buildReports() {
        LinearLayout root = col();
        root.setBackgroundColor(BG);
        root.addView(header("Отчёты"), mw());
        ScrollView sv = new ScrollView(this);
        LinearLayout b = col();
        b.setPadding(dp(12), dp(12), dp(12), dp(24));
        sv.addView(b);
        root.addView(sv, lp(-1, 0, 1f));

        final Calendar now = Calendar.getInstance();
        long[] mr = monthRange(now.get(Calendar.YEAR), now.get(Calendar.MONTH));
        double[] s = sums(mr);

        // this month
        LinearLayout c1 = card();
        LinearLayout h = row();
        h.addView(tv("Этот месяц", 16, TXT, true), lp(0, -2, 1f));
        h.addView(tv("›", 22, GREY, false));
        c1.addView(h, mw());
        LinearLayout l = row();
        l.setGravity(Gravity.CENTER_VERTICAL);
        l.setPadding(0, dp(8), 0, 0);
        l.addView(tv(String.format(Locale.US, "%02d", now.get(Calendar.MONTH) + 1), 32, TXT, false), lp(dp(66), -2, 0));
        View sep = new View(this);
        sep.setBackgroundColor(0xFF444444);
        LinearLayout.LayoutParams sl = lp(dp(1), dp(40), 0);
        sl.rightMargin = dp(16);
        l.addView(sep, sl);
        l.addView(stat("Расходы", "-" + num(s[0])), lp(0, -2, 1f));
        l.addView(stat("Доход", num(s[1])), lp(0, -2, 1f));
        c1.addView(l, mw());
        c1.setOnClickListener(v -> {
            selY = now.get(Calendar.YEAR);
            selM = now.get(Calendar.MONTH);
            tab = 0;
            refresh();
        });
        b.addView(c1, cardLp());

        // budget
        LinearLayout c2 = card();
        LinearLayout h2 = row();
        h2.setGravity(Gravity.CENTER_VERTICAL);
        h2.addView(tv("Месячный бюджет", 16, TXT, true), lp(0, -2, 1f));
        TextView pb = tv("⊕ Параметр", 13, ONY, false);
        pb.setBackground(round(Y, 6));
        pb.setPadding(dp(12), dp(6), dp(12), dp(6));
        pb.setOnClickListener(v -> editBudget());
        h2.addView(pb);
        c2.addView(h2, mw());
        LinearLayout br = row();
        br.setGravity(Gravity.CENTER_VERTICAL);
        br.setPadding(0, dp(14), 0, dp(4));
        DonutView ring = new DonutView(this);
        ring.thick = 0.14f;
        double bud = st.budget, rem = bud - s[0];
        LinearLayout info = col();
        info.setPadding(dp(18), 0, 0, 0);
        if (bud > 0) {
            float fr = (float) Math.max(0, Math.min(1, rem / bud));
            ring.setData(new float[]{fr, 1 - fr}, new int[]{Y, LINE}, "Остаток", pct(Math.max(0, rem) * 100 / bud));
            TextView rt = tv("Остаток средств: " + num(rem), 16, rem < 0 ? RED : TXT, true);
            info.addView(rt);
            View d = divider();
            LinearLayout.LayoutParams dl = mw();
            dl.setMargins(0, dp(6), 0, dp(6));
            info.addView(d, dl);
            info.addView(kv("Бюджет:", num(bud)), mw());
            info.addView(kv("Расходы:", num(s[0])), mw());
            if (rem < 0) info.addView(tv("Бюджет превышен на " + num(-rem), 13, RED, false));
        } else {
            ring.setData(new float[]{0, 1}, new int[]{Y, LINE}, "Бюджет", "—");
            info.addView(tv("Задайте сумму, которую планируете потратить за месяц, кнопкой «Параметр».", 14, GREY, false));
        }
        br.addView(ring, lp(dp(108), dp(108), 0));
        br.addView(info, lp(0, -2, 1f));
        c2.addView(br, mw());
        b.addView(c2, cardLp());

        // products
        LinearLayout c3 = card();
        c3.addView(tv("📦 Прибыль по товарам", 16, TXT, true));
        c3.addView(tv("Одинаковые названия категорий в расходах и доходах", 12, GREY, false));
        LinearLayout.LayoutParams sgl = mw();
        sgl.setMargins(0, dp(10), 0, dp(10));
        c3.addView(seg(new String[]{"Этот месяц", "Всё время"}, prodAll ? 1 : 0, i -> {
            prodAll = i == 1;
            refresh();
        }), sgl);
        long[] pr = prodAll ? new long[]{Long.MIN_VALUE, Long.MAX_VALUE} : mr;
        List<PStat> ps = productStats(pr);
        if (ps.isEmpty()) {
            c3.addView(tv("Пока нет данных" + (prodAll ? "" : " за этот месяц") + ".\n\nСоздайте категорию с одинаковым названием и в «Расходах», и в «Доходах», например «Микрофон». "
                    + "Покупку записывайте в расходы, продажу — в доходы. Здесь появится прибыль или убыток.", 14, GREY, false));
            TextView add = tv("＋ Создать товар", 15, ONY, true);
            add.setGravity(Gravity.CENTER);
            add.setBackground(round(Y, 8));
            add.setPadding(0, dp(10), 0, dp(10));
            add.setOnClickListener(v -> catDialog(null, false, this::refresh, true));
            LinearLayout.LayoutParams al = mw();
            al.topMargin = dp(12);
            c3.addView(add, al);
        } else {
            double ti = 0, te = 0;
            for (PStat p : ps) { ti += p.inc; te += p.exp; }
            double tp = ti - te;
            LinearLayout sum = col();
            sum.setPadding(dp(12), dp(10), dp(12), dp(10));
            sum.setBackground(round(tp > 0.004 ? 0x2634C46A : tp < -0.004 ? 0x26FF5A5F : KEY, 10));
            sum.addView(tv("Итого: " + profitWord(tp) + " " + signed(tp), 17, profitColor(tp), true));
            sum.addView(tv("Доход " + num(ti) + "  ·  Расход " + num(te), 13, GREY, false));
            c3.addView(sum, mw());
            for (final PStat p : ps) {
                double pp = p.inc - p.exp;
                LinearLayout rr = row();
                rr.setGravity(Gravity.CENTER_VERTICAL);
                rr.setPadding(0, dp(12), 0, dp(12));
                rr.setBackgroundResource(selectable());
                LinearLayout lc = col();
                TextView nm = tv(p.name, 16, TXT, true);
                nm.setSingleLine(true);
                nm.setEllipsize(TextUtils.TruncateAt.END);
                lc.addView(nm);
                lc.addView(tv("Доход " + num(p.inc) + "  ·  Расход " + num(p.exp), 13, GREY, false));
                rr.addView(lc, lp(0, -2, 1f));
                LinearLayout rc = col();
                rc.setGravity(Gravity.END);
                rc.addView(tv(signed(pp), 16, profitColor(pp), true));
                rc.addView(tv(profitWord(pp), 12, profitColor(pp), false));
                rr.addView(rc);
                rr.setOnClickListener(v -> showProduct(p.name));
                c3.addView(divider());
                c3.addView(rr, mw());
            }
        }
        b.addView(c3, cardLp());
        return root;
    }

    static class PStat {
        String name;
        double inc, exp;
        long last;
    }

    /** Category names that exist both in expenses and in incomes (normalized). */
    java.util.Set<String> pairNames() {
        java.util.HashSet<String> e = new java.util.HashSet<>(), in = new java.util.HashSet<>();
        for (Cat c : st.cats) (c.inc ? in : e).add(Store.norm(c.name));
        e.retainAll(in);
        return e;
    }

    boolean isPair(String name) {
        return pairNames().contains(Store.norm(name));
    }

    List<PStat> productStats(long[] r) {
        java.util.Set<String> pairs = pairNames();
        LinkedHashMap<String, PStat> m = new LinkedHashMap<>();
        for (Rec x : st.recs) {
            String k = Store.norm(x.cat);
            if (!pairs.contains(k) || x.time < r[0] || x.time >= r[1]) continue;
            PStat p = m.get(k);
            if (p == null) {
                p = new PStat();
                p.name = st.cat(false, x.cat).name;
                for (Cat c : st.cats) if (!c.inc && Store.norm(c.name).equals(k)) p.name = c.name;
                m.put(k, p);
            }
            if (x.inc) p.inc += x.amt;
            else p.exp += x.amt;
        }
        List<PStat> l = new ArrayList<>(m.values());
        l.sort((a, b) -> Double.compare(b.inc - b.exp, a.inc - a.exp));
        return l;
    }

    double[] pairTotals(String name, Rec exclude) {
        String k = Store.norm(name);
        double[] t = new double[2];
        for (Rec x : st.recs) {
            if (x == exclude || !Store.norm(x.cat).equals(k)) continue;
            if (x.inc) t[0] += x.amt;
            else t[1] += x.amt;
        }
        return t;
    }

    void showProduct(String name) {
        String k = Store.norm(name);
        List<Rec> l = new ArrayList<>();
        for (Rec x : st.recs) if (Store.norm(x.cat).equals(k)) l.add(x);
        sortDesc(l);
        double[] t = pairTotals(name, null);
        double p = t[0] - t[1];
        listDialog("📦 " + name, "За всё время: доход " + num(t[0]) + ", расход " + num(t[1])
                + "\n" + profitWord(p) + ": " + signed(p), l);
    }

    String profitWord(double p) {
        return p > 0.004 ? "Прибыль" : p < -0.004 ? "Убыток" : "В ноль";
    }

    int profitColor(double p) {
        return p > 0.004 ? GREEN : p < -0.004 ? RED : GREY;
    }

    String signed(double p) {
        return (p > 0.004 ? "+" : p < -0.004 ? "−" : "") + num(Math.abs(p));
    }

    // ---------------------------------------------------------------- tab: me

    View buildMe() {
        LinearLayout root = col();
        root.setBackgroundColor(BG);
        ScrollView sv = new ScrollView(this);
        LinearLayout b = col();
        sv.addView(b);
        root.addView(sv, lp(-1, -1, 1f));

        LinearLayout head = col();
        head.setBackgroundColor(HEAD);
        head.setGravity(Gravity.CENTER_HORIZONTAL);
        head.setPadding(dp(20), dp(24), dp(20), dp(24));
        TextView logo = tv("💰", 34, TXT, false);
        logo.setGravity(Gravity.CENTER);
        logo.setBackground(oval(KEY));
        head.addView(logo, lp(dp(72), dp(72), 0));
        TextView nm = tv("Финансы+", 20, TXT, true);
        nm.setPadding(0, dp(10), 0, dp(2));
        head.addView(nm);
        head.addView(tv("Записей: " + st.recs.size(), 13, GREY, false));
        b.addView(head, mw());

        LinearLayout box = col();
        box.setPadding(dp(12), dp(12), dp(12), dp(24));
        b.addView(box, mw());

        LinearLayout c1 = card0();
        c1.addView(menuItem("🗂️", "Категории", null, v -> catEditor(false, this::refresh)));
        c1.addView(divider());
        c1.addView(menuItem("🎯", "Месячный бюджет", st.budget > 0 ? num(st.budget) : "не задан", v -> editBudget()));
        c1.addView(divider());
        c1.addView(menuItem("🚀", "Начальная сумма", num(st.startCap), v -> editStartCap()));
        c1.addView(divider());
        c1.addView(menuItem("💱", "Валюта", st.cur.isEmpty() ? "без значка" : st.cur, v -> editCurrency()));
        box.addView(c1, cardLp());

        LinearLayout c2 = card0();
        c2.addView(menuItem("💾", "Сохранить резервную копию", null, v -> backup()));
        c2.addView(divider());
        c2.addView(menuItem("📂", "Восстановить из копии", null, v -> restore()));
        box.addView(c2, cardLp());

        LinearLayout c3 = card0();
        c3.addView(menuItem("🗑️", "Удалить все записи", null, v -> wipe()));
        c3.addView(divider());
        c3.addView(menuItem("ℹ️", "О приложении", "1.1", v -> about()));
        box.addView(c3, cardLp());
        return root;
    }

    View menuItem(String icon, String title, String value, View.OnClickListener cl) {
        LinearLayout r = row();
        r.setGravity(Gravity.CENTER_VERTICAL);
        r.setPadding(dp(16), dp(15), dp(14), dp(15));
        r.setBackgroundResource(selectable());
        r.addView(tv(icon, 20, TXT, false));
        TextView t = tv(title, 16, TXT, false);
        t.setPadding(dp(14), 0, dp(8), 0);
        r.addView(t, lp(0, -2, 1f));
        if (value != null) r.addView(tv(value, 14, GREY, false));
        r.addView(tv("  ›", 20, GREY, false));
        r.setOnClickListener(cl);
        return r;
    }

    void editBudget() {
        final EditText e = new EditText(this);
        e.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        e.setHint("Например: 5000");
        if (st.budget > 0) e.setText(plain(st.budget));
        AlertDialog.Builder bld = new AlertDialog.Builder(this).setTitle("Бюджет на месяц").setView(wrap(e))
                .setPositiveButton("Сохранить", (d, w) -> {
                    st.budget = parse(e.getText().toString());
                    st.save();
                    refresh();
                })
                .setNegativeButton("Отмена", null);
        if (st.budget > 0) bld.setNeutralButton("Убрать", (d, w) -> {
            st.budget = 0;
            st.save();
            refresh();
        });
        bld.show();
    }

    void editCurrency() {
        final EditText e = new EditText(this);
        e.setSingleLine(true);
        e.setHint("Например: смн, $, ₽");
        e.setText(st.cur);
        new AlertDialog.Builder(this).setTitle("Значок валюты")
                .setMessage("Будет показан после сумм. Оставьте пустым, чтобы не показывать.")
                .setView(wrap(e))
                .setPositiveButton("Сохранить", (d, w) -> {
                    st.cur = e.getText().toString().trim();
                    st.save();
                    refresh();
                })
                .setNegativeButton("Отмена", null).show();
    }

    void backup() {
        Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("application/json");
        i.putExtra(Intent.EXTRA_TITLE, "finansy-" + new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(new Date()) + ".json");
        try {
            startActivityForResult(i, REQ_SAVE);
        } catch (Exception e) {
            toast("Не удалось открыть выбор файла");
        }
    }

    void restore() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("*/*");
        try {
            startActivityForResult(i, REQ_OPEN);
        } catch (Exception e) {
            toast("Не удалось открыть выбор файла");
        }
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (res != RESULT_OK || data == null || data.getData() == null) return;
        Uri u = data.getData();
        try {
            if (req == REQ_SAVE) {
                OutputStream os = getContentResolver().openOutputStream(u);
                os.write(st.toJson().toString(2).getBytes(StandardCharsets.UTF_8));
                os.close();
                toast("Копия сохранена");
            } else if (req == REQ_OPEN) {
                final JSONObject o = new JSONObject(Store.readAll(getContentResolver().openInputStream(u)));
                JSONArray a = o.optJSONArray("recs");
                if (a == null) {
                    toast("Это не файл копии");
                    return;
                }
                new AlertDialog.Builder(this).setTitle("Восстановить?")
                        .setMessage("В копии записей: " + a.length() + ".\nТекущие данные (" + st.recs.size()
                                + " записей) будут заменены.")
                        .setPositiveButton("Восстановить", (d, w) -> {
                            try {
                                st.fromJson(o);
                                st.save();
                                refresh();
                                toast("Готово");
                            } catch (Exception e) {
                                toast("Ошибка: " + e.getMessage());
                            }
                        })
                        .setNegativeButton("Отмена", null).show();
            }
        } catch (Exception e) {
            toast("Ошибка: " + e.getMessage());
        }
    }

    void wipe() {
        new AlertDialog.Builder(this).setTitle("Удалить все записи?")
                .setMessage("Категории и настройки останутся. Отменить это нельзя, поэтому сначала можно сохранить резервную копию.")
                .setPositiveButton("Удалить", (d, w) -> {
                    st.recs.clear();
                    st.save();
                    refresh();
                })
                .setNegativeButton("Отмена", null).show();
    }

    void about() {
        new AlertDialog.Builder(this).setTitle("Финансы+ 1.1")
                .setMessage("Учёт расходов и доходов по категориям, графики, месячный бюджет, капитал и прибыль по товарам.\n\n"
                        + "Прибыль по товару: создайте категорию с одинаковым названием и в «Расходах», и в «Доходах» "
                        + "(например, «Микрофон»). Покупку записывайте в расходы, продажу — в доходы. "
                        + "Если доходов больше, чем расходов, будет прибыль, если меньше — убыток. Смотрите во вкладке «Отчёты».\n\n"
                        + "Капитал: укажите начальную сумму (с чего начинаете бизнес). График в «Графики → Капитал» "
                        + "показывает, как растёт или падает капитал, как цена акции на бирже.\n\nДанные хранятся только на этом телефоне.")
                .setPositiveButton("OK", null).show();
    }

    void editStartCap() {
        final EditText e = new EditText(this);
        e.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        e.setHint("Например: 10000");
        if (st.startCap != 0) e.setText(plain(st.startCap));
        new AlertDialog.Builder(this).setTitle("Начальная сумма")
                .setMessage("С какой суммы вы начинаете бизнес. От неё строится график капитала.")
                .setView(wrap(e))
                .setPositiveButton("Сохранить", (d, w) -> {
                    st.startCap = parse(e.getText().toString());
                    st.save();
                    refresh();
                })
                .setNegativeButton("Отмена", null).show();
    }

    static long dayStart(long t) {
        Calendar c = Calendar.getInstance();
        c.setTimeInMillis(t);
        c.set(Calendar.HOUR_OF_DAY, 0);
        c.set(Calendar.MINUTE, 0);
        c.set(Calendar.SECOND, 0);
        c.set(Calendar.MILLISECOND, 0);
        return c.getTimeInMillis();
    }

    void buildCapital(LinearLayout root) {
        ScrollView sv = new ScrollView(this);
        LinearLayout body = col();
        body.setPadding(dp(12), dp(14), dp(12), dp(24));
        sv.addView(body);
        root.addView(sv, lp(-1, 0, 1f));

        List<Rec> all = new ArrayList<>(st.recs);
        all.sort((a, b) -> Long.compare(a.time, b.time));
        long today = dayStart(System.currentTimeMillis());
        int[] daysOpt = {7, 30, 91, 365, -1};
        String[] labs = {"1Н", "1М", "3М", "1Г", "Всё"};
        long from;
        if (daysOpt[capRange] < 0) {
            from = all.isEmpty() ? today : Math.min(today, dayStart(all.get(0).time));
        } else {
            Calendar c = Calendar.getInstance();
            c.setTimeInMillis(today);
            c.add(Calendar.DAY_OF_YEAR, -(daysOpt[capRange] - 1));
            from = c.getTimeInMillis();
        }
        double base = st.startCap;
        for (Rec x : all) if (x.time < from) base += x.inc ? x.amt : -x.amt;

        ArrayList<Float> vals = new ArrayList<>();
        ArrayList<Long> times = new ArrayList<>();
        double cur = base, pInc = 0, pExp = 0, hi = base, lo = base;
        int idx = 0;
        while (idx < all.size() && all.get(idx).time < from) idx++;
        Calendar day = Calendar.getInstance();
        day.setTimeInMillis(from);
        while (day.getTimeInMillis() <= today) {
            Calendar nx = (Calendar) day.clone();
            nx.add(Calendar.DAY_OF_YEAR, 1);
            long end = nx.getTimeInMillis();
            while (idx < all.size() && all.get(idx).time < end) {
                Rec x = all.get(idx++);
                if (x.inc) { cur += x.amt; pInc += x.amt; } else { cur -= x.amt; pExp += x.amt; }
            }
            vals.add((float) cur);
            times.add(day.getTimeInMillis());
            hi = Math.max(hi, cur);
            lo = Math.min(lo, cur);
            day = nx;
        }
        while (idx < all.size()) { // records dated in the future
            Rec x = all.get(idx++);
            if (x.inc) { cur += x.amt; pInc += x.amt; } else { cur -= x.amt; pExp += x.amt; }
        }
        double change = cur - base;
        int col = profitColor(change);

        LinearLayout c1 = card();
        c1.addView(tv("Капитал сейчас", 14, GREY, false));
        TextView big = tv(num(cur), 32, TXT, true);
        big.setPadding(0, dp(2), 0, dp(2));
        c1.addView(big);
        String pc = Math.abs(base) > 0.004 ? String.format(Locale.US, " (%s%.2f%%)", change >= 0 ? "+" : "−", Math.abs(change * 100 / base)) : "";
        c1.addView(tv((change >= 0 ? "▲ " : "▼ ") + signed(change) + pc + "  за период", 15, col, true));

        LinearLayout chips = row();
        LinearLayout.LayoutParams chl = mw();
        chl.setMargins(0, dp(12), 0, dp(4));
        for (int i = 0; i < labs.length; i++) {
            final int ii = i;
            boolean on = i == capRange;
            TextView ch = tv(labs[i], 14, on ? ONY : TXT, on);
            ch.setGravity(Gravity.CENTER);
            ch.setPadding(0, dp(7), 0, dp(7));
            ch.setBackground(round(on ? Y : KEY, 16));
            LinearLayout.LayoutParams l = lp(0, -2, 1f);
            l.setMargins(dp(3), 0, dp(3), 0);
            ch.setOnClickListener(v -> {
                capRange = ii;
                refresh();
            });
            chips.addView(ch, l);
        }
        c1.addView(chips, chl);

        LineChartView chart = new LineChartView(this);
        chart.fmt = this::short2;
        float[] fv = new float[vals.size()];
        long[] ft = new long[times.size()];
        for (int i = 0; i < fv.length; i++) { fv[i] = vals.get(i); ft[i] = times.get(i); }
        chart.setData(fv, ft, (float) base);
        c1.addView(chart, lp(-1, dp(250), 0));
        c1.addView(tv("Проведите пальцем по графику, чтобы увидеть сумму на любой день. Пунктир — капитал в начале периода.", 12, GREY, false));
        body.addView(c1, cardLp());

        LinearLayout c2 = card();
        LinearLayout h = row();
        h.setGravity(Gravity.CENTER_VERTICAL);
        h.addView(tv("За период", 16, TXT, true), lp(0, -2, 1f));
        c2.addView(h, mw());
        LinearLayout.LayoutParams kl = mw();
        kl.topMargin = dp(6);
        c2.addView(kv("В начале периода:", num(base)), kl);
        c2.addView(kv("Доходы:", "+" + num(pInc)), mw());
        c2.addView(kv("Расходы:", "-" + num(pExp)), mw());
        c2.addView(kv("Максимум:", num(hi)), mw());
        c2.addView(kv("Минимум:", num(lo)), mw());
        body.addView(c2, cardLp());

        LinearLayout c3 = card();
        LinearLayout h3 = row();
        h3.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout lc = col();
        lc.addView(tv("Начальная сумма", 16, TXT, true));
        lc.addView(tv(st.startCap == 0 ? "Не задана — с какой суммы вы начинаете бизнес" : num(st.startCap), 14, GREY, false));
        h3.addView(lc, lp(0, -2, 1f));
        TextView eb = tv("Изменить", 13, ONY, false);
        eb.setBackground(round(Y, 6));
        eb.setPadding(dp(12), dp(6), dp(12), dp(6));
        eb.setOnClickListener(v -> editStartCap());
        h3.addView(eb);
        c3.addView(h3, mw());
        body.addView(c3, cardLp());
    }

    String short2(double v) {
        double a = Math.abs(v);
        String s;
        if (a >= 1e6) s = String.format(Locale.US, "%.2fM", v / 1e6);
        else if (a >= 1e4) s = String.format(Locale.US, "%.1fK", v / 1e3);
        else s = df.format(v);
        return s;
    }

    // ---------------------------------------------------------------- dialogs

    void showRec(final Rec x) {
        Cat c = st.cat(x.inc, x.cat);
        StringBuilder m = new StringBuilder();
        m.append("Тип: ").append(x.inc ? "Доход" : "Расход");
        m.append("\nСумма: ").append(x.inc ? "+" : "-").append(num(x.amt));
        m.append("\nДата: ").append(new SimpleDateFormat("dd.MM.yyyy, HH:mm", Locale.US).format(new Date(x.time)));
        if (!x.memo.isEmpty()) m.append("\nПамятка: ").append(x.memo);
        if (isPair(x.cat)) {
            double[] t = pairTotals(x.cat, null);
            double p = t[0] - t[1];
            m.append("\n\nПо товару «").append(x.cat).append("»:\nдоход ").append(num(t[0]))
                    .append(", расход ").append(num(t[1])).append("\n").append(profitWord(p)).append(": ").append(signed(p));
        }
        new AlertDialog.Builder(this).setTitle(c.icon + "  " + c.name).setMessage(m.toString())
                .setPositiveButton("Изменить", (d, w) -> openEditor(x))
                .setNegativeButton("Удалить", (d, w) -> new AlertDialog.Builder(this)
                        .setMessage("Удалить эту запись?")
                        .setPositiveButton("Удалить", (d2, w2) -> {
                            st.recs.remove(x);
                            st.save();
                            refresh();
                        })
                        .setNegativeButton("Отмена", null).show())
                .setNeutralButton("Закрыть", null).show();
    }

    void listDialog(String title, String headerText, List<Rec> l) {
        final AlertDialog[] d = new AlertDialog[1];
        LinearLayout v = col();
        if (headerText != null) {
            TextView h = tv(headerText, 14, TXT, false);
            h.setPadding(dp(20), dp(4), dp(20), dp(10));
            v.addView(h);
        }
        ScrollView sv = new ScrollView(this);
        final LinearLayout list = col();
        sv.addView(list);
        v.addView(sv, mw());
        d[0] = new AlertDialog.Builder(this).setTitle(title).setView(v).setPositiveButton("Закрыть", null).create();
        if (l.isEmpty()) list.addView(empty("Нет записей"));
        for (Rec x : l) list.addView(recRow(x, d[0]));
        d[0].show();
    }

    // ---------------------------------------------------------------- categories

    class CatAdapter extends BaseAdapter {
        List<Cat> items;
        String sel;
        final String extraLabel, extraIcon;

        CatAdapter(List<Cat> items, String sel, String extraLabel, String extraIcon) {
            this.items = items;
            this.sel = sel;
            this.extraLabel = extraLabel;
            this.extraIcon = extraIcon;
        }

        @Override public int getCount() { return items.size() + 1; }
        @Override public Object getItem(int p) { return p < items.size() ? items.get(p) : null; }
        @Override public long getItemId(int p) { return p; }

        @Override
        public View getView(int p, View cv, ViewGroup parent) {
            LinearLayout c = col();
            c.setGravity(Gravity.CENTER_HORIZONTAL);
            c.setPadding(dp(2), dp(6), dp(2), dp(6));
            boolean extra = p >= items.size();
            String icon = extra ? extraIcon : items.get(p).icon;
            String name = extra ? extraLabel : items.get(p).name;
            boolean on = !extra && sel != null && sel.equals(name);
            TextView ic = tv(icon, 24, TXT, false);
            ic.setGravity(Gravity.CENTER);
            ic.setBackground(oval(on ? Y : KEY));
            c.addView(ic, lp(dp(54), dp(54), 0));
            TextView nt = tv(name, 13, on ? Y : TXT, on);
            nt.setGravity(Gravity.CENTER);
            nt.setMaxLines(2);
            nt.setEllipsize(TextUtils.TruncateAt.END);
            nt.setPadding(0, dp(4), 0, 0);
            c.addView(nt, mw());
            c.setLayoutParams(new AbsListView.LayoutParams(-1, dp(104)));
            return c;
        }
    }

    static boolean hasCat(List<Cat> l, String name) {
        for (Cat c : l) if (c.name.equals(name)) return true;
        return false;
    }

    Dialog fullDialog() {
        Dialog d = new Dialog(this, android.R.style.Theme_DeviceDefault_NoActionBar);
        styleWindow(d.getWindow());
        return d;
    }

    void catEditor(boolean inc0, final Runnable after) {
        final Dialog d = fullDialog();
        final boolean[] inc = {inc0};
        LinearLayout root = col();
        root.setBackgroundColor(BG);
        LinearLayout top = col();
        top.setBackgroundColor(HEAD);
        top.setPadding(dp(14), dp(12), dp(14), dp(14));
        FrameLayout tr = new FrameLayout(this);
        TextView done = tv("Готово", 16, TXT, false);
        done.setOnClickListener(v -> d.dismiss());
        tr.addView(done, new FrameLayout.LayoutParams(-2, -2, Gravity.START | Gravity.CENTER_VERTICAL));
        tr.addView(tv("Категории", 17, TXT, true), new FrameLayout.LayoutParams(-2, -2, Gravity.CENTER));
        top.addView(tr, mw());
        final CatAdapter ad = new CatAdapter(st.cats(inc[0]), null, "Добавить", "＋");
        LinearLayout.LayoutParams sgl = lp(-1, -2, 0);
        sgl.setMargins(dp(40), dp(10), dp(40), 0);
        top.addView(seg(new String[]{"Расходы", "Доходы"}, inc[0] ? 1 : 0, i -> {
            inc[0] = i == 1;
            ad.items = st.cats(inc[0]);
            ad.notifyDataSetChanged();
        }), sgl);
        root.addView(top, mw());
        TextView hint = tv("Нажмите на категорию, чтобы изменить или удалить её. Одинаковое название в «Расходах» и «Доходах» — это товар, по нему считается прибыль.", 13, GREY, false);
        hint.setPadding(dp(16), dp(10), dp(16), 0);
        root.addView(hint);
        GridView g = new GridView(this);
        g.setNumColumns(4);
        g.setPadding(dp(6), dp(8), dp(6), dp(16));
        g.setClipToPadding(false);
        g.setSelector(new ColorDrawable(Color.TRANSPARENT));
        g.setAdapter(ad);
        final Runnable reload = () -> {
            ad.items = st.cats(inc[0]);
            ad.notifyDataSetChanged();
        };
        g.setOnItemClickListener((p, v, pos, id) -> {
            if (pos >= ad.items.size()) {
                catDialog(null, inc[0], reload);
                return;
            }
            final Cat c = ad.items.get(pos);
            new AlertDialog.Builder(this).setTitle(c.icon + "  " + c.name)
                    .setItems(new String[]{"Изменить", "Удалить"}, (dd, w) -> {
                        if (w == 0) catDialog(c, c.inc, reload);
                        else deleteCat(c, reload);
                    }).show();
        });
        root.addView(g, lp(-1, 0, 1f));
        d.setContentView(root);
        d.setOnDismissListener(x -> after.run());
        d.show();
    }

    void deleteCat(final Cat c, final Runnable after) {
        if (st.cats(c.inc).size() <= 1) {
            toast("Нельзя удалить последнюю категорию");
            return;
        }
        int n = 0;
        for (Rec r : st.recs) if (r.inc == c.inc && r.cat.equals(c.name)) n++;
        new AlertDialog.Builder(this).setTitle("Удалить «" + c.name + "»?")
                .setMessage(n == 0 ? "Записей с этой категорией нет." : "Записей с этой категорией: " + n + ". Они останутся и будут показаны со значком ❔.")
                .setPositiveButton("Удалить", (d, w) -> {
                    st.cats.remove(c);
                    st.save();
                    after.run();
                })
                .setNegativeButton("Отмена", null).show();
    }

    void catDialog(final Cat edit, final boolean inc, final Runnable after) {
        catDialog(edit, inc, after, false);
    }

    void catDialog(final Cat edit, final boolean inc, final Runnable after, boolean pairDefault) {
        LinearLayout v = col();
        v.setPadding(dp(20), dp(8), dp(20), 0);
        final EditText name = new EditText(this);
        name.setSingleLine(true);
        name.setHint(pairDefault ? "Название товара, например: Микрофон" : "Название");
        if (edit != null) name.setText(edit.name);
        v.addView(name, mw());
        final CheckBox both = new CheckBox(this);
        both.setText("Создать и в «" + (inc ? "Расходах" : "Доходах") + "» — это товар, по нему будет считаться прибыль");
        both.setTextColor(TXT);
        both.setChecked(pairDefault);
        if (edit == null) v.addView(both, mw());
        final String[] icon = {edit != null ? edit.icon : EMOJI[0]};
        GridView eg = new GridView(this);
        eg.setNumColumns(6);
        eg.setSelector(new ColorDrawable(Color.TRANSPARENT));
        final BaseAdapter ea = new BaseAdapter() {
            @Override public int getCount() { return EMOJI.length; }
            @Override public Object getItem(int p) { return EMOJI[p]; }
            @Override public long getItemId(int p) { return p; }

            @Override
            public View getView(int p, View cv, ViewGroup parent) {
                TextView t = tv(EMOJI[p], 22, TXT, false);
                t.setGravity(Gravity.CENTER);
                t.setBackground(EMOJI[p].equals(icon[0]) ? oval(Y) : null);
                t.setLayoutParams(new AbsListView.LayoutParams(-1, dp(46)));
                return t;
            }
        };
        eg.setAdapter(ea);
        eg.setOnItemClickListener((p, vv, pos, id) -> {
            icon[0] = EMOJI[pos];
            ea.notifyDataSetChanged();
        });
        LinearLayout.LayoutParams el = lp(-1, dp(230), 0);
        el.topMargin = dp(8);
        v.addView(eg, el);
        final AlertDialog dlg = new AlertDialog.Builder(this)
                .setTitle(edit == null ? "Новая категория" : "Изменить категорию")
                .setView(v).setPositiveButton("Сохранить", null).setNegativeButton("Отмена", null).create();
        dlg.setOnShowListener(x -> dlg.getButton(DialogInterface.BUTTON_POSITIVE).setOnClickListener(bb -> {
            String n = name.getText().toString().trim();
            if (n.isEmpty()) {
                toast("Введите название");
                return;
            }
            for (Cat c : st.cats) {
                if (c != edit && c.inc == inc && c.name.equalsIgnoreCase(n)) {
                    toast("Такая категория уже есть");
                    return;
                }
            }
            if (edit == null) {
                st.cats.add(new Cat(n, icon[0], st.cats.size(), inc));
                if (both.isChecked()) {
                    boolean exists = false;
                    for (Cat c : st.cats) if (c.inc != inc && c.name.equalsIgnoreCase(n)) exists = true;
                    if (!exists) st.cats.add(new Cat(n, icon[0], st.cats.size() - 1, !inc));
                }
            } else {
                String old = edit.name;
                edit.name = n;
                edit.icon = icon[0];
                if (!old.equals(n)) for (Rec r : st.recs) if (r.inc == edit.inc && r.cat.equals(old)) r.cat = n;
            }
            st.save();
            dlg.dismiss();
            after.run();
        }));
        dlg.show();
    }

    // ---------------------------------------------------------------- add / edit screen

    void openEditor(Rec edit) {
        new Editor(edit).show();
    }

    class Editor {
        final Rec edit;
        final Dialog d = fullDialog();
        boolean inc;
        final StringBuilder ex = new StringBuilder();
        final Calendar date = Calendar.getInstance();
        CatAdapter ad;
        TextView amt, ind, ok, dateKey;
        EditText memo;

        Editor(Rec edit) {
            this.edit = edit;
            if (edit != null) {
                inc = edit.inc;
                ex.append(plain(edit.amt));
                date.setTimeInMillis(edit.time);
            }
        }

        void show() {
            List<Cat> l0 = st.cats(inc);
            String sel = edit != null ? edit.cat : (l0.isEmpty() ? "" : l0.get(0).name);
            ad = new CatAdapter(l0, sel, "Настройки", "⚙️");

            LinearLayout root = col();
            root.setBackgroundColor(BG);
            FrameLayout top = new FrameLayout(MainActivity.this);
            top.setBackgroundColor(HEAD);
            top.setPadding(dp(14), dp(12), dp(14), dp(12));
            TextView cancel = tv("Отмена", 16, TXT, false);
            cancel.setPadding(0, dp(6), dp(10), dp(6));
            cancel.setOnClickListener(v -> d.dismiss());
            top.addView(cancel, new FrameLayout.LayoutParams(-2, -2, Gravity.START | Gravity.CENTER_VERTICAL));
            top.addView(seg(new String[]{"Расходы", "Доходы"}, inc ? 1 : 0, i -> {
                inc = i == 1;
                reloadCats();
                render();
            }), new FrameLayout.LayoutParams(dp(210), -2, Gravity.CENTER));
            root.addView(top, mw());

            GridView g = new GridView(MainActivity.this);
            g.setNumColumns(4);
            g.setPadding(dp(6), dp(8), dp(6), dp(8));
            g.setClipToPadding(false);
            g.setSelector(new ColorDrawable(Color.TRANSPARENT));
            g.setAdapter(ad);
            g.setOnItemClickListener((p, v, pos, id) -> {
                if (pos >= ad.items.size()) {
                    catEditor(inc, () -> {
                        reloadCats();
                        refresh();
                    });
                } else {
                    ad.sel = ad.items.get(pos).name;
                    ad.notifyDataSetChanged();
                    updInd();
                }
            });
            root.addView(g, lp(-1, 0, 1f));

            LinearLayout bp = col();
            bp.setBackgroundColor(PANEL);
            bp.setPadding(dp(10), dp(6), dp(10), dp(10));
            amt = tv("0", 34, TXT, false);
            amt.setGravity(Gravity.END);
            amt.setSingleLine(true);
            amt.setPadding(dp(8), 0, dp(8), dp(4));
            bp.addView(amt, mw());

            ind = tv("", 13, GREY, false);
            ind.setPadding(dp(8), 0, dp(8), dp(6));
            ind.setVisibility(View.GONE);
            bp.addView(ind, mw());

            LinearLayout mr = fieldRow("Памятка:");
            memo = new EditText(MainActivity.this);
            styleField(memo, "Введите памятку…");
            if (edit != null) memo.setText(edit.memo);
            mr.addView(memo, lp(0, -2, 1f));
            LinearLayout.LayoutParams ml = mw();
            ml.bottomMargin = dp(4);
            bp.addView(mr, ml);

            String[][] K = {{"7", "8", "9", "D"}, {"4", "5", "6", "+"}, {"1", "2", "3", "-"}, {".", "0", "⌫", "OK"}};
            for (String[] rowk : K) {
                LinearLayout kr = row();
                for (final String k : rowk) {
                    TextView b = tv(k.equals("-") ? "−" : k, 22, k.equals("OK") ? ONY : TXT, false);
                    b.setGravity(Gravity.CENTER);
                    b.setBackground(round(k.equals("OK") ? Y : KEY, 8));
                    if (k.equals("D")) {
                        dateKey = b;
                        b.setTextSize(14);
                    }
                    if (k.equals("OK")) ok = b;
                    LinearLayout.LayoutParams kl = lp(0, dp(50), 1f);
                    kl.setMargins(dp(3), dp(3), dp(3), dp(3));
                    kr.addView(b, kl);
                    b.setOnClickListener(v -> key(k));
                }
                bp.addView(kr, mw());
            }
            root.addView(bp, mw());

            d.setContentView(root);
            d.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE
                    | WindowManager.LayoutParams.SOFT_INPUT_STATE_HIDDEN);
            render();
            d.show();
        }

        void reloadCats() {
            List<Cat> l = st.cats(inc);
            ad.items = l;
            if (!hasCat(l, ad.sel) && (edit == null || edit.inc != inc || !edit.cat.equals(ad.sel)))
                ad.sel = l.isEmpty() ? "" : l.get(0).name;
            ad.notifyDataSetChanged();
        }

        String curNum(String s) {
            int i = Math.max(s.lastIndexOf('+'), s.lastIndexOf('-'));
            return s.substring(i + 1);
        }

        void key(String k) {
            String s = ex.toString();
            switch (k) {
                case "⌫":
                    if (s.length() > 0) ex.setLength(s.length() - 1);
                    break;
                case "+":
                case "-": {
                    if (s.isEmpty() || s.equals("-")) break;
                    char last = s.charAt(s.length() - 1);
                    if (last == '+' || last == '-') ex.setCharAt(s.length() - 1, k.charAt(0));
                    else {
                        if (last == '.') ex.setLength(s.length() - 1);
                        ex.append(k);
                    }
                    break;
                }
                case ".": {
                    String c = curNum(s);
                    if (!c.contains(".")) {
                        if (c.isEmpty()) ex.append("0");
                        ex.append(".");
                    }
                    break;
                }
                case "D":
                    new DatePickerDialog(MainActivity.this, (view, y, m, dd) -> {
                        date.set(y, m, dd);
                        render();
                    }, date.get(Calendar.YEAR), date.get(Calendar.MONTH), date.get(Calendar.DAY_OF_MONTH)).show();
                    return;
                case "OK":
                    if (hasOp(s)) {
                        double v = eval(s);
                        ex.setLength(0);
                        ex.append(plain(v));
                    } else {
                        save();
                        return;
                    }
                    break;
                default: {
                    String c = curNum(s);
                    int dot = c.indexOf('.');
                    if (dot >= 0 && c.length() - dot > 2) break;
                    if (dot < 0 && c.length() >= 9) break;
                    if (c.equals("0")) ex.setLength(s.length() - 1);
                    ex.append(k);
                }
            }
            render();
        }

        void render() {
            String s = ex.toString();
            amt.setText(s.isEmpty() ? "0" : s.replace("-", "−"));
            ok.setText(hasOp(s) ? "=" : "✓");
            Calendar now = Calendar.getInstance();
            boolean today = now.get(Calendar.YEAR) == date.get(Calendar.YEAR)
                    && now.get(Calendar.DAY_OF_YEAR) == date.get(Calendar.DAY_OF_YEAR);
            dateKey.setText(today ? "📅 Сегодня" : String.format(Locale.US, "📅 %02d.%02d.%02d",
                    date.get(Calendar.DAY_OF_MONTH), date.get(Calendar.MONTH) + 1, date.get(Calendar.YEAR) % 100));
            updInd();
        }

        void updInd() {
            if (ind == null || ad == null) return;
            String name = ad.sel == null ? "" : ad.sel;
            if (name.isEmpty() || !isPair(name)) {
                ind.setVisibility(View.GONE);
                return;
            }
            double[] t = pairTotals(name, edit);
            double v = Math.max(0, eval(ex.toString()));
            String s = "«" + name + "»: доход " + num(t[0]) + " · расход " + num(t[1]);
            double p = (t[0] + (inc ? v : 0)) - (t[1] + (inc ? 0 : v));
            s += "\n" + (v > 0 ? "С этой записью: " : "Сейчас: ") + profitWord(p).toLowerCase(Locale.ROOT) + " " + signed(p);
            ind.setText(s);
            ind.setTextColor(profitColor(p));
            ind.setVisibility(View.VISIBLE);
        }

        void save() {
            double v = eval(ex.toString());
            if (v <= 0) {
                toast("Введите сумму больше нуля");
                return;
            }
            if (ad.sel == null || ad.sel.isEmpty()) {
                toast("Выберите категорию");
                return;
            }
            Rec r = edit;
            if (r == null) {
                r = new Rec();
                r.id = st.nextId();
                st.recs.add(r);
            }
            r.inc = inc;
            r.cat = ad.sel;
            r.amt = v;
            r.item = "";
            r.memo = memo.getText().toString().trim();
            r.time = date.getTimeInMillis();
            st.save();
            selY = date.get(Calendar.YEAR);
            selM = date.get(Calendar.MONTH);
            d.dismiss();
            refresh();
        }
    }

    static boolean hasOp(String s) {
        for (int i = 1; i < s.length(); i++) {
            char c = s.charAt(i);
            if (c == '+' || c == '-') return true;
        }
        return false;
    }

    static double eval(String s) {
        double tot = 0;
        int sign = 1;
        StringBuilder n = new StringBuilder();
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (c == '+' || c == '-') {
                if (n.length() > 0) {
                    tot += sign * parse(n.toString());
                    n.setLength(0);
                }
                sign = c == '-' ? -1 : 1;
            } else n.append(c);
        }
        if (n.length() > 0) tot += sign * parse(n.toString());
        return Math.round(tot * 100) / 100.0;
    }

    static double parse(String s) {
        try {
            return Double.parseDouble(s.trim().replace(',', '.').replace(" ", ""));
        } catch (Exception e) {
            return 0;
        }
    }

    static String plain(double v) {
        return new BigDecimal(v).setScale(2, RoundingMode.HALF_UP).stripTrailingZeros().toPlainString();
    }

    // ---------------------------------------------------------------- data helpers

    long[] monthRange(int y, int m) {
        Calendar c = Calendar.getInstance();
        c.clear();
        c.set(y, m, 1);
        long a = c.getTimeInMillis();
        c.add(Calendar.MONTH, 1);
        return new long[]{a, c.getTimeInMillis()};
    }

    long[] yearRange(int y) {
        Calendar c = Calendar.getInstance();
        c.clear();
        c.set(y, 0, 1);
        long a = c.getTimeInMillis();
        c.add(Calendar.YEAR, 1);
        return new long[]{a, c.getTimeInMillis()};
    }

    double[] sums(long[] r) {
        double[] s = new double[2];
        for (Rec x : st.recs) {
            if (x.time < r[0] || x.time >= r[1]) continue;
            if (x.inc) s[1] += x.amt;
            else s[0] += x.amt;
        }
        return s;
    }

    List<Rec> recsIn(long[] r) {
        List<Rec> l = new ArrayList<>();
        for (Rec x : st.recs) if (x.time >= r[0] && x.time < r[1]) l.add(x);
        sortDesc(l);
        return l;
    }

    static void sortDesc(List<Rec> l) {
        l.sort((a, b) -> a.time != b.time ? Long.compare(b.time, a.time) : Long.compare(b.id, a.id));
    }

    static int dayKey(long t) {
        Calendar c = Calendar.getInstance();
        c.setTimeInMillis(t);
        return c.get(Calendar.YEAR) * 1000 + c.get(Calendar.DAY_OF_YEAR);
    }

    static String dateStr(long t) {
        return new SimpleDateFormat("dd.MM.yy", Locale.US).format(new Date(t));
    }

    String num(double v) {
        String r = df.format(v);
        return st.cur.isEmpty() ? r : r + " " + st.cur;
    }

    static String pct(double v) {
        return String.format(Locale.US, "%.2f%%", v);
    }

    // ---------------------------------------------------------------- view helpers

    int dp(float v) {
        return Math.round(TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, getResources().getDisplayMetrics()));
    }

    LinearLayout col() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        return l;
    }

    LinearLayout row() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.HORIZONTAL);
        return l;
    }

    LinearLayout.LayoutParams lp(int w, int h, float wt) {
        return new LinearLayout.LayoutParams(w, h, wt);
    }

    LinearLayout.LayoutParams mw() {
        return new LinearLayout.LayoutParams(-1, -2);
    }

    TextView tv(String text, float sp, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextSize(sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    GradientDrawable round(int color, float r) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(r));
        return g;
    }

    GradientDrawable oval(int color) {
        GradientDrawable g = new GradientDrawable();
        g.setShape(GradientDrawable.OVAL);
        g.setColor(color);
        return g;
    }

    int selectable() {
        TypedValue v = new TypedValue();
        getTheme().resolveAttribute(android.R.attr.selectableItemBackground, v, true);
        return v.resourceId;
    }

    TextView iconCircle(Cat c, int size) {
        TextView t = tv(c.icon, size * 0.45f, TXT, false);
        t.setGravity(Gravity.CENTER);
        t.setBackground(oval(PASTEL[Math.abs(c.color) % PASTEL.length]));
        return t;
    }

    View stat(String label, String value) {
        LinearLayout c = col();
        c.addView(tv(label, 13, GREY, false));
        TextView v = tv(value, 19, TXT, false);
        v.setSingleLine(true);
        v.setEllipsize(TextUtils.TruncateAt.END);
        c.addView(v);
        return c;
    }

    View kv(String k, String v) {
        LinearLayout r = row();
        r.setPadding(0, dp(2), 0, dp(2));
        r.addView(tv(k, 14, TXT, false), lp(0, -2, 1f));
        r.addView(tv(v, 14, GREY, false));
        return r;
    }

    View divider() {
        View v = new View(this);
        v.setBackgroundColor(LINE);
        v.setLayoutParams(lp(-1, dp(1), 0));
        return v;
    }

    View empty(String s) {
        TextView t = tv(s, 15, GREY, false);
        t.setGravity(Gravity.CENTER);
        t.setPadding(dp(32), dp(48), dp(32), dp(48));
        return t;
    }

    View header(String title) {
        TextView t = tv(title, 18, TXT, true);
        t.setGravity(Gravity.CENTER);
        t.setBackgroundColor(HEAD);
        t.setPadding(0, dp(16), 0, dp(16));
        return t;
    }

    LinearLayout card() {
        LinearLayout c = card0();
        c.setPadding(dp(16), dp(14), dp(16), dp(14));
        return c;
    }

    LinearLayout card0() {
        LinearLayout c = col();
        c.setBackground(round(CARD, 12));
        return c;
    }

    LinearLayout.LayoutParams cardLp() {
        LinearLayout.LayoutParams l = mw();
        l.bottomMargin = dp(12);
        return l;
    }

    LinearLayout fieldRow(String label) {
        LinearLayout r = row();
        r.setGravity(Gravity.CENTER_VERTICAL);
        r.setBackground(round(KEY, 8));
        r.setPadding(dp(12), 0, dp(8), 0);
        r.addView(tv(label, 15, GREY, false));
        return r;
    }

    void styleField(EditText e, String hint) {
        e.setBackground(null);
        e.setHint(hint);
        e.setTextSize(15);
        e.setTextColor(TXT);
        e.setHintTextColor(0xFF6A6A6A);
        e.setSingleLine(true);
        e.setPadding(dp(8), dp(10), dp(4), dp(10));
    }

    View wrap(View v) {
        FrameLayout f = new FrameLayout(this);
        f.setPadding(dp(20), dp(8), dp(20), 0);
        f.addView(v);
        return f;
    }

    LinearLayout seg(String[] items, int sel, final IntCb cb) {
        LinearLayout l = row();
        GradientDrawable bg = new GradientDrawable();
        bg.setCornerRadius(dp(6));
        bg.setStroke(dp(1.5f), Y);
        l.setBackground(bg);
        l.setPadding(dp(2), dp(2), dp(2), dp(2));
        final TextView[] ts = new TextView[items.length];
        for (int i = 0; i < items.length; i++) {
            final int ii = i;
            TextView t = tv(items[i], 15, TXT, false);
            t.setGravity(Gravity.CENTER);
            t.setPadding(dp(6), dp(6), dp(6), dp(6));
            t.setSingleLine(true);
            ts[i] = t;
            t.setOnClickListener(v -> {
                for (int j = 0; j < ts.length; j++) paintSeg(ts[j], j == ii);
                cb.on(ii);
            });
            l.addView(t, lp(0, -2, 1f));
        }
        for (int j = 0; j < ts.length; j++) paintSeg(ts[j], j == sel);
        return l;
    }

    void paintSeg(TextView t, boolean on) {
        t.setBackground(on ? round(Y, 4) : null);
        t.setTextColor(on ? ONY : TXT);
    }

    void toast(String s) {
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show();
    }
}
