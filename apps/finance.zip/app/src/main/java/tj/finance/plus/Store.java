package tj.finance.plus;

import android.content.Context;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

class Rec {
    long id;
    boolean inc;
    String cat = "";
    String item = "";
    String memo = "";
    double amt;
    long time;
}

class Cat {
    String name;
    String icon;
    int color;
    boolean inc;

    Cat() {}

    Cat(String name, String icon, int color, boolean inc) {
        this.name = name;
        this.icon = icon;
        this.color = color;
        this.inc = inc;
    }
}

class Store {
    final ArrayList<Rec> recs = new ArrayList<>();
    final ArrayList<Cat> cats = new ArrayList<>();
    double budget = 0;
    double startCap = 0;
    String cur = "";
    private final File file;

    Store(Context c) {
        file = new File(c.getFilesDir(), "data.json");
    }

    static final String[][] DEF_EXP = {
            {"Покупка", "🛒"}, {"Еда", "🍽️"}, {"Телефон", "📱"}, {"Развлечения", "🎤"},
            {"Образование", "📚"}, {"Красота", "💄"}, {"Спорт", "🏊"}, {"Социальное", "👥"},
            {"Транспорт", "🚌"}, {"Одежда", "👕"}, {"Автомобиль", "🚗"}, {"Напитки", "🥤"},
            {"Сигареты", "🚬"}, {"Электроника", "🎧"}, {"Путешествия", "✈️"}, {"Здоровье", "💊"},
            {"Питомец", "🐶"}, {"Ремонт", "🔧"}, {"Дом", "🏠"}, {"Подарок", "🎁"},
            {"Пожертвование", "❤️"}, {"Связь и интернет", "🌐"}, {"Закуски", "🧁"}, {"Малыш", "👶"},
            {"Овощи", "🥕"}, {"Фрукты", "🍇"}, {"Товар", "📦"}, {"Другое", "➕"}
    };
    static final String[][] DEF_INC = {
            {"Продажи", "🏷️"}, {"Зарплата", "💰"}, {"Подработка", "💼"}, {"Премия", "🏆"},
            {"Инвестиции", "📈"}, {"Подарок", "🎁"}, {"Возврат", "↩️"}, {"Другое", "➕"}
    };

    void defaults() {
        cats.clear();
        int i = 0;
        for (String[] s : DEF_EXP) cats.add(new Cat(s[0], s[1], i++, false));
        for (String[] s : DEF_INC) cats.add(new Cat(s[0], s[1], i++, true));
    }

    void load() {
        try {
            if (file.exists()) {
                fromJson(new JSONObject(readAll(new FileInputStream(file))));
                return;
            }
        } catch (Exception ignored) {
        }
        defaults();
    }

    void save() {
        try {
            File tmp = new File(file.getParentFile(), "data.tmp");
            FileOutputStream os = new FileOutputStream(tmp);
            os.write(toJson().toString().getBytes(StandardCharsets.UTF_8));
            os.getFD().sync();
            os.close();
            if (!tmp.renameTo(file)) {
                FileOutputStream o2 = new FileOutputStream(file);
                o2.write(toJson().toString().getBytes(StandardCharsets.UTF_8));
                o2.close();
            }
        } catch (Exception ignored) {
        }
    }

    JSONObject toJson() throws Exception {
        JSONObject o = new JSONObject();
        o.put("app", "finance-plus");
        o.put("v", 1);
        JSONArray a = new JSONArray();
        for (Rec r : recs) {
            JSONObject j = new JSONObject();
            j.put("id", r.id);
            j.put("inc", r.inc);
            j.put("cat", r.cat);
            j.put("item", r.item);
            j.put("memo", r.memo);
            j.put("amt", r.amt);
            j.put("time", r.time);
            a.put(j);
        }
        o.put("recs", a);
        JSONArray c = new JSONArray();
        for (Cat k : cats) {
            JSONObject j = new JSONObject();
            j.put("name", k.name);
            j.put("icon", k.icon);
            j.put("color", k.color);
            j.put("inc", k.inc);
            c.put(j);
        }
        o.put("cats", c);
        o.put("budget", budget);
        o.put("cur", cur);
        o.put("startCap", startCap);
        return o;
    }

    void fromJson(JSONObject o) throws Exception {
        ArrayList<Rec> nr = new ArrayList<>();
        JSONArray a = o.optJSONArray("recs");
        if (a != null) {
            for (int i = 0; i < a.length(); i++) {
                JSONObject j = a.getJSONObject(i);
                Rec r = new Rec();
                r.id = j.optLong("id", i + 1);
                r.inc = j.optBoolean("inc", false);
                r.cat = j.optString("cat", "Другое");
                r.item = j.optString("item", "");
                r.memo = j.optString("memo", "");
                r.amt = j.optDouble("amt", 0);
                r.time = j.optLong("time", System.currentTimeMillis());
                nr.add(r);
            }
        }
        ArrayList<Cat> nc = new ArrayList<>();
        JSONArray c = o.optJSONArray("cats");
        if (c != null) {
            for (int i = 0; i < c.length(); i++) {
                JSONObject j = c.getJSONObject(i);
                nc.add(new Cat(j.optString("name", "?"), j.optString("icon", "❔"),
                        j.optInt("color", i), j.optBoolean("inc", false)));
            }
        }
        recs.clear();
        recs.addAll(nr);
        if (nc.isEmpty()) defaults();
        else {
            cats.clear();
            cats.addAll(nc);
        }
        budget = o.optDouble("budget", 0);
        cur = o.optString("cur", "");
        startCap = o.optDouble("startCap", 0);
    }

    List<Cat> cats(boolean inc) {
        ArrayList<Cat> l = new ArrayList<>();
        for (Cat c : cats) if (c.inc == inc) l.add(c);
        return l;
    }

    Cat cat(boolean inc, String name) {
        for (Cat c : cats) if (c.inc == inc && c.name.equals(name)) return c;
        return new Cat(name, "❔", 9, inc);
    }

    long nextId() {
        long m = System.currentTimeMillis();
        for (Rec r : recs) if (r.id >= m) m = r.id + 1;
        return m;
    }

    static String norm(String s) {
        return s == null ? "" : s.trim().replaceAll("\\s+", " ").toLowerCase(Locale.ROOT);
    }

    static String readAll(InputStream is) throws Exception {
        ByteArrayOutputStream bo = new ByteArrayOutputStream();
        byte[] b = new byte[8192];
        int n;
        while ((n = is.read(b)) > 0) bo.write(b, 0, n);
        is.close();
        return new String(bo.toByteArray(), StandardCharsets.UTF_8);
    }
}
